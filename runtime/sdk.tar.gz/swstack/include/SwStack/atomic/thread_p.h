#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "atomic/thread.h"

#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#endif

struct SW_CORE_EXPORT sw::atomic::Thread::RegistryMutex_ {
#if defined(_WIN32)
    RegistryMutex_();

    ~RegistryMutex_();

    RegistryMutex_(const RegistryMutex_&) = delete;
    RegistryMutex_& operator=(const RegistryMutex_&) = delete;

    CRITICAL_SECTION section;
#else
    std::mutex mutex;
#endif
};

class SW_CORE_EXPORT sw::atomic::Thread::RegistryLock_ {
public:
    friend class ThreadCondition_;

    explicit RegistryLock_(RegistryMutex_& mutex);

    ~RegistryLock_();

    void lock();

    void unlock();

    RegistryLock_(const RegistryLock_&) = delete;
    RegistryLock_& operator=(const RegistryLock_&) = delete;

#if defined(_WIN32)
    CRITICAL_SECTION* nativeHandle_();
#endif

private:
    RegistryMutex_& mutex_;
    bool locked_ = false;
};

class SW_CORE_EXPORT sw::atomic::Thread::ThreadCondition_ {
public:
#if defined(_WIN32)
    ThreadCondition_();

    void notify_all();

    template<typename Predicate>
    void wait(RegistryLock_& lock, Predicate predicate) {
        while (!predicate()) {
            SleepConditionVariableCS(&condition_, lock.nativeHandle_(), INFINITE);
        }
    }

private:
    CONDITION_VARIABLE condition_;
#else
    void notify_all();

    template<typename Predicate>
    void wait(RegistryLock_& lock, Predicate predicate) {
        condition_.wait(lock, predicate);
    }

private:
    std::condition_variable_any condition_;
#endif
};

// Join state survives a reentrant owner's destruction while another fiber waits.
struct SwAtomicThreadJoinState_ {
    std::thread thread;
    std::mutex mutex;
    std::atomic<bool> exited{true};
};

struct sw::atomic::Thread::Data {
    SwString m_name;
    int m_fiberInitialCount = -1;
    int m_fiberWarmCount = -1;
    int m_fiberMaxCount = -1;
    unsigned int m_fiberStackSize = 0;
    std::shared_ptr<SwAtomicThreadJoinState_> m_joinState = std::make_shared<SwAtomicThreadJoinState_>();
    std::thread::id m_threadId;
    std::atomic<bool> m_running{false};
    std::atomic<bool> m_shouldQuit{false};
    bool m_isAdopted = false;
    SwCoreApplication* m_app = nullptr;
    std::unique_ptr<SwCoreApplication> m_ownedApp;
    mutable RegistryMutex_ m_appMutex;
    ThreadCondition_ m_startCv;
    RegistryMutex_ m_startMutex;
    bool m_appReady = false;
    RegistryMutex_ m_objectsMutex;
    std::set<SwObject*> m_objects;
    RegistryMutex_ m_pendingMutex;
    std::vector<PendingTask_> m_pendingTasks;
    RegistryMutex_ m_callbackMutex;
    std::function<void()> m_onStarted;
    std::function<void()> m_onFinished;
};
