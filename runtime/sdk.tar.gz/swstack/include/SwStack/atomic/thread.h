#pragma once

#include "../core/SwStackExport.h"

/**
 * @file src/atomic/thread.h
 * @ingroup atomic_primitives
 * @brief Declares the public interface exposed by thread in the CoreSw low-level concurrency
 * layer.
 *
 * This header belongs to the CoreSw low-level concurrency layer. It exposes foundational
 * threading primitives used by the object and runtime subsystems.
 *
 * Within that layer, this file focuses on the thread interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * This header mainly contributes module-level utilities, helper declarations, or namespaced types
 * that are consumed by the surrounding subsystem.
 *
 * Thread-oriented declarations here define execution-context ownership, affinity, or
 * synchronization boundaries that the rest of the framework relies on.
 *
 * This layer stays close to operating-system and standard-library concepts so higher abstractions
 * can build predictable lifecycle and dispatch behavior on top.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

// SwCoreApplication includes SwObject, whose affinity alias refers to this type.
namespace sw { namespace atomic { class Thread; } }
#include "SwCoreApplication.h"

#include <atomic>
#include <condition_variable>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <unordered_set>
#include <thread>
#include <utility>
#include <vector>

class SwObject;

namespace sw {
namespace atomic {

/**
 * @class Thread
 * @brief Lightweight worker thread hosting its own SwCoreApplication event loop.
 *
 * This class provides an isolated event loop
 * for objects that need to live outside of the main thread. Each Thread owns a
 * dedicated SwCoreApplication instance, allowing SwObject::moveToThread() to safely
 * migrate objects and execute their queued events in the appropriate context.
 */
class SW_CORE_EXPORT Thread {
private:
    // The threads' registry locks (thread_p.h).
    struct RegistryMutex_;
    class RegistryLock_;
    class ThreadCondition_;

public:
    /**
     * @brief Constructs a `Thread` instance.
     * @param name Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit Thread(const SwString& name = "Thread");

    /**
     * @brief Destroys the `Thread` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~Thread();

    /**
     * @brief Starts the worker thread and initializes its internal SwCoreApplication.
     * @return true if the thread successfully started, false otherwise.
     */
    /**
     * @brief Sizes the fiber pool of the loop this thread will run, before start().
     * @param initialCount Fibers created before the first task; negative keeps the default.
     * @param warmCount The most kept warm; negative keeps the default.
     * @param maxCount The ceiling; negative keeps the default.
     *
     * @details Applied to the loop the moment it exists, before any task posted to this thread
     * is replayed, so even the first task finds the pool sized as asked. A thread that runs a few
     * background jobs wants a small pool: see SwCoreApplication::setEventFiberCounts().
     */
    void setFiberCounts(int initialCount, int warmCount, int maxCount);

    /**
     * @brief Stack size of the loop's fibers, before start(); zero keeps the default.
     */
    void setFiberStackSize(unsigned int stackSizeBytes);

    bool start();

    /**
     * @brief Requests the internal event loop to quit.
     *
     * The quit request is posted inside the thread's event queue to avoid
     * blocking the caller. It goes through the reliable queue: a lane saturated
     * by the thread's own work must not drop the request that would end it,
     * or wait() never returns.
     */
    void quit();

    /**
     * @brief Waits until the worker thread finishes execution.
     */
    void wait();

    /**
     * @brief Indicates whether the thread is currently running.
     */
    bool isRunning() const;

    /** Native execution and finished callbacks have returned (or never started).
     * Adopted event-loop threads have no owned execution to reap. */
    bool hasExited() const;

    /**
     * @brief Retrieves the SwCoreApplication associated with this thread.
     *
     * @return Pointer to the internal SwCoreApplication, or nullptr if the
     *         event loop is not ready yet.
     */
    SwCoreApplication* application() const;

    /**
     * @brief Retrieves the native std::thread::id.
     */
    std::thread::id threadId() const;

    /**
     * @brief Posts a task to the internal event loop.
     *
     * @param task Functor to execute inside the thread's SwCoreApplication event loop.
     * @return true when ownership was accepted either by the event loop or by
     *         the pre-start queue; false when runtime backpressure rejected it.
     */
    bool postTask(std::function<void()> task);

    /**
     * @brief Posts a task to the internal event loop on the requested fiber lane.
     *
     * @param task Functor to execute inside the thread's SwCoreApplication event loop.
     * @param lane Fiber lane used when the owning application is already available.
     * @return true when ownership was accepted either by the event loop or by
     *         the pre-start queue; false when runtime backpressure rejected it.
     */
    bool postTaskOnLane(std::function<void()> task, SwFiberLane lane);

    /** Queue a lifecycle/control completion even when the target fiber lane is full. */
    bool postTaskOnLaneReliable(std::function<void()> task,
                                SwFiberLane lane = SwFiberLane::Control);

    /**
     * @brief Returns the Thread representing the current thread if registered.
     *
     * If the current thread is not running under a Thread context but owns a
     * SwCoreApplication, it is automatically adopted.
     */
    static Thread* currentThread();

    /**
     * @brief Returns a process-wide fallback runtime thread.
     *
     * This thread owns a SwCoreApplication event loop and is used when code creates
     * SwObject instances without any SwCoreApplication bound to the current thread.
     */
    static Thread* sharedFallbackThread();

    static bool isLive(const Thread* thread);

    /** Atomically verifies thread lifetime and queues reliable affinity work. */
    static bool postTaskOnLaneReliableIfLive(
        Thread* thread,
        std::function<void()> task,
        SwFiberLane lane = SwFiberLane::Control);

    /**
     * @brief Adopts the current thread if it already owns a SwCoreApplication.
     *
     * @param name Optional friendly name used for logging/debugging.
     * @return A Thread wrapper for the current thread, or nullptr if
     *         no SwCoreApplication is bound to it.
     */
    static Thread* adoptCurrentThread(const SwString& name = "MainThread");

    /**
     * @brief Internal helper used by SwObject to track residency.
     */
    void attachObject(SwObject* object);

    /**
     * @brief Internal helper used by SwObject to detach residency.
     */
    void detachObject(SwObject* object);

    /**
     * @brief Sets the started Callback.
     * @param cb Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStartedCallback(std::function<void()> cb);

    /**
     * @brief Sets the finished Callback.
     * @param cb Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFinishedCallback(std::function<void()> cb);

private:
    Thread(SwCoreApplication* existingApp, const SwString& name, bool adopted);

    void threadEntry();

    void flushPendingTasks();

    static void flushPendingTasksFor(Thread* thread);

    void detachAllObjects();

    static void registerThreadInstance(Thread* thread);

    static void unregisterThreadInstance(const std::thread::id& id);

    static Thread*& localThreadInstance();

    static RegistryMutex_& registryMutex();

    static std::map<std::thread::id, Thread*>& registry();

    static void registerLiveThread_(const Thread* thread);

    static void unregisterLiveThread_(const Thread* thread);

    static RegistryMutex_& liveThreadsMutex();

    static std::unordered_set<const Thread*>& liveThreads();

    void invokeStartedCallback();

    void invokeFinishedCallback();

    struct PendingTask_ {
        std::function<void()> task;
        SwFiberLane lane = SwFiberLane::Normal;
        bool reliable = false;
    };

    static constexpr std::size_t kMaxPendingTasks_ = 16 * 1024;

private:
    // What the class keeps (thread_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

} // namespace atomic
} // namespace sw
