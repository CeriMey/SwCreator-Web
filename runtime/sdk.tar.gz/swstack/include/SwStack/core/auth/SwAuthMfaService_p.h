#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/auth/SwAuthMfaService.h"

struct SwAuthMfaService::Data {
    // Given by the constructor: store_, config_.
    Data(SwHttpAuthStore& store, const SwHttpAuthConfig& config)
        : store_(store), config_(config) {}

    SwHttpAuthStore& store_;
    const SwHttpAuthConfig& config_;
};
