#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwObject.h"
#include "auth/SwHttpAuthStore.h"

class SW_AUTH_EXPORT SwAuthAccountService final : public SwObject {
    SW_OBJECT(SwAuthAccountService, SwObject)

public:
    explicit SwAuthAccountService(SwHttpAuthStore& store, SwObject* parent = nullptr);

    SwDbStatus findById(const SwString& accountId, SwHttpAuthAccount& outAccount);
    SwDbStatus findByEmail(const SwString& email, SwHttpAuthAccount& outAccount);
    SwDbStatus createWithoutPassword(const SwString& email,
                                     const SwString& subjectId,
                                     SwHttpAuthAccount& outAccount);
    SwDbStatus setSubject(const SwString& accountId, const SwString& subjectId);
    SwDbStatus markEmailVerified(const SwString& accountId);
    SwDbStatus remove(const SwString& accountId);

signals:
    SW_SIGNAL(accountCreated, const SwHttpAuthAccount&)
    SW_SIGNAL(accountUpdated, const SwHttpAuthAccount&)
    SW_SIGNAL(accountRemoved, const SwString&)

private:
public:
    ~SwAuthAccountService();
private:
    // What the class keeps (SwAuthAccountService_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
