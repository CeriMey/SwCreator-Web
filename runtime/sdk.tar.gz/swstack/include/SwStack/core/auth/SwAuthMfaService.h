#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwObject.h"
#include "auth/SwHttpAuthStore.h"

class SW_AUTH_EXPORT SwAuthMfaService final : public SwObject {
    SW_OBJECT(SwAuthMfaService, SwObject)

public:
    SwAuthMfaService(SwHttpAuthStore& store,
                     const SwHttpAuthConfig& config,
                     SwObject* parent = nullptr);

    bool isRequired(const SwHttpAuthAccount& account) const;
    SwDbStatus createLoginChallenge(const SwHttpAuthAccount& account,
                                    SwHttpAuthMfaLoginChallenge& outChallenge);

signals:
    SW_SIGNAL(challengeCreated,
                   const SwHttpAuthAccount&,
                   const SwHttpAuthMfaLoginChallenge&)

private:
public:
    ~SwAuthMfaService();
private:
    // What the class keeps (SwAuthMfaService_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
