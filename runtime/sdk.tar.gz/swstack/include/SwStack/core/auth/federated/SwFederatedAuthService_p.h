#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/auth/federated/SwFederatedAuthService.h"

struct SwFederatedAuthService::Data {
    // Built with its owner: providers_ have it as parent.
    explicit Data(SwFederatedAuthService* owner)
        : providers_(owner) {}

    SwFederatedAuthProviderRegistry providers_;
    SwFederatedAuthTransactionStore transactions_;
    SwString storageDir_ = "federated-auth-transactions";
    bool started_ = false;
};
