#pragma once

#include "../../SwStackExport.h"

#include "SwMap.h"
#include "SwObject.h"
#include "SwString.h"

class SW_AUTH_EXPORT SwOidcClientCredential : public SwObject {
    SW_OBJECT(SwOidcClientCredential, SwObject)

public:
    explicit SwOidcClientCredential(SwObject* parent = nullptr);

    ~SwOidcClientCredential() override;

    virtual SwString clientId() const = 0;
    virtual bool applyTokenAuthentication(SwMap<SwString, SwString>& fields,
                                          SwMap<SwString, SwString>& headers,
                                          SwString* errorOut = nullptr) const = 0;
};
