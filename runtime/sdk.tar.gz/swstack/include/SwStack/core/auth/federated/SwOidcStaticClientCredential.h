#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "auth/federated/SwOidcClientCredential.h"

class SW_AUTH_EXPORT SwOidcStaticClientCredential final : public SwOidcClientCredential {
    SW_OBJECT(SwOidcStaticClientCredential, SwOidcClientCredential)

public:
    SwOidcStaticClientCredential(const SwString& clientId,
                                 const SwString& clientSecret,
                                 SwObject* parent = nullptr);

    SwString clientId() const override;
    bool applyTokenAuthentication(SwMap<SwString, SwString>& fields,
                                  SwMap<SwString, SwString>& headers,
                                  SwString* errorOut = nullptr) const override;

private:
public:
    ~SwOidcStaticClientCredential();
private:
    // What the class keeps (SwOidcStaticClientCredential_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
