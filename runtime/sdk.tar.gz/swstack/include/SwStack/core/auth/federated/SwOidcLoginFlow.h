#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwHttpClient.h"
#include "SwJsonObject.h"
#include "auth/federated/SwFederatedAuthProvider.h"
#include "auth/federated/SwFederatedLoginFlow.h"
#include "auth/federated/SwOidcJwtValidator.h"

class SW_AUTH_EXPORT SwOidcLoginFlow final : public SwFederatedLoginFlow {
    SW_OBJECT(SwOidcLoginFlow, SwFederatedLoginFlow)

public:
    SwOidcLoginFlow(SwFederatedAuthProvider& provider,
                    const SwString& code,
                    const SwString& redirectUri,
                    const SwString& expectedNonce,
                    const SwJsonObject& callbackUser,
                    SwObject* parent = nullptr);

public slots:
    void start() override;
    void cancel() override;

private slots:
    void onTokenResponse_(const SwByteArray& body);
    void onTokenError_(int error);
    void onJwksResponse_(const SwByteArray& body);
    void onJwksError_(int error);

private:
    void fail_(const SwString& code, const SwString& message);
    void finishIdentity_(SwFederatedIdentity identity);

public:
    ~SwOidcLoginFlow();
private:
    // What the class keeps (SwOidcLoginFlow_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
