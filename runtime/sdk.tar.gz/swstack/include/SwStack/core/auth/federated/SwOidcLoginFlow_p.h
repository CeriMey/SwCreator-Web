#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/auth/federated/SwOidcLoginFlow.h"

struct SwOidcLoginFlow::Data {
    // Given by the constructor: provider_.
    explicit Data(SwFederatedAuthProvider& provider)
        : provider_(provider) {}

    SwFederatedAuthProvider& provider_;
    SwString code_;
    SwString redirectUri_;
    SwString expectedNonce_;
    SwJsonObject callbackUser_;
    SwHttpClient* tokenClient_ = nullptr;
    SwHttpClient* jwksClient_ = nullptr;
    SwString idToken_;
    bool started_ = false;
    bool done_ = false;
    SwOidcJwtValidator validator_;
};
