#pragma once

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwJsonValue.h"
#include "SwMap.h"
#include "SwString.h"

#include <vector>

enum class SwFederatedProtocol {
    OpenIdConnect,
    OAuth2UserInfo
};

enum class SwFederatedResponseMode {
    Query,
    FormPost
};

enum class SwFederatedIdentitySource {
    IdToken,
    UserInfo,
    IdTokenAndCallback
};

struct SW_AUTH_EXPORT SwFederatedProviderDefinition {
    SwString key;
    SwString displayName;
    SwFederatedProtocol protocol = SwFederatedProtocol::OpenIdConnect;
    SwString issuer;
    std::vector<SwString> acceptedIssuers;
    SwString authorizationEndpoint;
    SwString tokenEndpoint;
    SwString jwksEndpoint;
    SwString userInfoEndpoint;
    SwString scope = "openid profile email";
    SwFederatedResponseMode responseMode = SwFederatedResponseMode::Query;
    SwFederatedIdentitySource identitySource = SwFederatedIdentitySource::IdToken;
    SwString accountSelectionPrompt;
    bool requiresNonce = true;
};

struct SW_AUTH_EXPORT SwFederatedAuthorizationRequest {
    SwString redirectUri;
    SwString state;
    SwString nonce;
    bool forceAccountSelection = false;
};

struct SW_AUTH_EXPORT SwFederatedTokenRequest {
    SwString url;
    SwByteArray body;
    SwString contentType = "application/x-www-form-urlencoded";
    SwMap<SwString, SwString> headers;
};

struct SW_AUTH_EXPORT SwFederatedIdentity {
    SwString provider;
    SwString providerSubject;
    SwString email;
    bool emailVerified = false;
    SwString displayName;
    SwString pictureUrl;
    SwJsonValue rawClaims;
};

struct SW_AUTH_EXPORT SwFederatedAuthTransaction {
    SwString stateHash;
    SwString provider;
    SwString nonce;
    SwString redirectUri;
    SwString continuationId;
    long long expiresAtMs = 0;
    SwString createdAt;
    SwString consumedAt;
};

struct SW_AUTH_EXPORT SwFederatedIdentityLink {
    SwString provider;
    SwString providerSubject;
    SwString accountId;
    SwString email;
    SwString displayName;
    SwString createdAt;
    SwString updatedAt;
};

struct SW_AUTH_EXPORT SwFederatedFlowError {
    SwString code;
    SwString message;
};
