#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwEmbeddedDb.h"
#include "SwMutex.h"
#include "auth/federated/SwFederatedAuthTypes.h"

class SW_AUTH_EXPORT SwFederatedIdentityStore {
public:
    SwFederatedIdentityStore();

    void setStorageDir(const SwString& storageDir);
    SwDbStatus open();
    void close();
    bool isOpen() const;

    SwDbStatus get(const SwString& provider,
                   const SwString& providerSubject,
                   SwFederatedIdentityLink* outLink);
    SwDbStatus upsert(const SwFederatedIdentityLink& link,
                      SwFederatedIdentityLink* outLink = nullptr);
    SwDbStatus remove(const SwString& provider, const SwString& providerSubject);

private:
    static SwByteArray primaryKey_(const SwString& provider, const SwString& providerSubject);
    static SwJsonObject toJson_(const SwFederatedIdentityLink& link);
    static SwFederatedIdentityLink fromJson_(const SwJsonObject& object);

public:
    ~SwFederatedIdentityStore();
private:
    // What the class keeps (SwFederatedIdentityStore_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
