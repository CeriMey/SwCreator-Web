#pragma once

#include "../../SwStackExport.h"

#include "SwObject.h"
#include "auth/federated/SwFederatedAuthTypes.h"

class SW_AUTH_EXPORT SwFederatedLoginFlow : public SwObject {
    SW_OBJECT(SwFederatedLoginFlow, SwObject)

public:
    ~SwFederatedLoginFlow() override;
    explicit SwFederatedLoginFlow(SwObject* parent = nullptr);

public slots:
    virtual void start() = 0;
    virtual void cancel() = 0;

signals:
    SW_SIGNAL(identityVerified, const SwFederatedIdentity&)
    SW_SIGNAL(failed, const SwFederatedFlowError&)
};
