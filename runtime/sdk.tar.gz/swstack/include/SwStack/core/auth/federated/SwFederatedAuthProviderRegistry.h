#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwMap.h"
#include "SwObject.h"
#include "auth/federated/SwFederatedAuthProvider.h"

class SW_AUTH_EXPORT SwFederatedAuthProviderRegistry final : public SwObject {
    SW_OBJECT(SwFederatedAuthProviderRegistry, SwObject)

public:
    explicit SwFederatedAuthProviderRegistry(SwObject* parent = nullptr);

    bool registerProvider(SwFederatedAuthProvider* provider, SwString* errorOut = nullptr);
    SwFederatedAuthProvider* provider(const SwString& key) const;
    bool contains(const SwString& key) const;
    SwList<SwString> providerKeys() const;

signals:
    SW_SIGNAL(providerRegistered, const SwString&)

private:
public:
    ~SwFederatedAuthProviderRegistry();
private:
    // What the class keeps (SwFederatedAuthProviderRegistry_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
