#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwEmbeddedDb.h"
#include "SwMutex.h"
#include "auth/federated/SwFederatedAuthTypes.h"

class SW_AUTH_EXPORT SwFederatedAuthTransactionStore {
public:
    SwFederatedAuthTransactionStore();

    void setStorageDir(const SwString& storageDir);
    SwDbStatus open();
    void close();
    bool isOpen() const;

    SwDbStatus create(const SwString& provider,
                      const SwString& redirectUri,
                      const SwString& continuationId,
                      unsigned long long ttlMs,
                      SwString& outState,
                      SwFederatedAuthTransaction* outTransaction = nullptr);
    SwDbStatus consume(const SwString& provider,
                       const SwString& state,
                       SwFederatedAuthTransaction* outTransaction);

private:
    static SwString stateHash_(const SwString& state);
    static SwByteArray primaryKey_(const SwString& stateHash);
    static SwJsonObject toJson_(const SwFederatedAuthTransaction& transaction);
    static SwFederatedAuthTransaction fromJson_(const SwJsonObject& object);

public:
    ~SwFederatedAuthTransactionStore();
private:
    // What the class keeps (SwFederatedAuthTransactionStore_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
