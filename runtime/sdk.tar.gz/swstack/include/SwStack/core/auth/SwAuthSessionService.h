#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwObject.h"
#include "auth/SwHttpAuthStore.h"

class SW_AUTH_EXPORT SwAuthSessionService final : public SwObject {
    SW_OBJECT(SwAuthSessionService, SwObject)

public:
    SwAuthSessionService(SwHttpAuthStore& store,
                         const SwHttpAuthConfig& config,
                         SwObject* parent = nullptr);

    SwDbStatus create(const SwHttpAuthAccount& account,
                      const SwJsonValue& subject,
                      const SwString& userAgent,
                      bool viaTls,
                      SwString& outRawToken,
                      SwHttpAuthSession& outSession);
    SwDbStatus revoke(const SwString& rawToken);

signals:
    SW_SIGNAL(sessionCreated,
                   const SwHttpAuthAccount&,
                   const SwHttpAuthSession&,
                   const SwJsonValue&)
    SW_SIGNAL(sessionRevoked, const SwString&)

private:
public:
    ~SwAuthSessionService();
private:
    // What the class keeps (SwAuthSessionService_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
