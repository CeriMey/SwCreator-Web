#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/auth/SwAuthAccountService.h"

struct SwAuthAccountService::Data {
    // Given by the constructor: store_.
    explicit Data(SwHttpAuthStore& store)
        : store_(store) {}

    SwHttpAuthStore& store_;
};
