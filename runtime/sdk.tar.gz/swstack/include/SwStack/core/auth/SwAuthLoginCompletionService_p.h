#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/auth/SwAuthLoginCompletionService.h"

struct SwAuthLoginCompletionService::Data {
    // Given by the constructor: mfaService_, sessionService_.
    Data(SwAuthMfaService& mfaService, SwAuthSessionService& sessionService)
        : mfaService_(mfaService), sessionService_(sessionService) {}

    SwAuthMfaService& mfaService_;
    SwAuthSessionService& sessionService_;
};
