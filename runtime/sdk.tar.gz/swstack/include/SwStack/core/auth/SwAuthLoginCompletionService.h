#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwObject.h"
#include "auth/SwAuthLoginResult.h"
#include "auth/SwAuthMfaService.h"
#include "auth/SwAuthSessionService.h"

class SW_AUTH_EXPORT SwAuthLoginCompletionService final : public SwObject {
    SW_OBJECT(SwAuthLoginCompletionService, SwObject)

public:
    SwAuthLoginCompletionService(SwAuthMfaService& mfaService,
                                 SwAuthSessionService& sessionService,
                                 SwObject* parent = nullptr);

    SwDbStatus complete(const SwHttpAuthAccount& account,
                        const SwJsonValue& subject,
                        const SwString& userAgent,
                        bool viaTls,
                        SwAuthLoginResult& outResult);

signals:
    SW_SIGNAL(completed, const SwAuthLoginResult&)

private:
public:
    ~SwAuthLoginCompletionService();
private:
    // What the class keeps (SwAuthLoginCompletionService_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
