#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/hw/SwPinOut.h
 * @ingroup core_hw
 * @brief Declares the public interface exposed by SwPinOut in the CoreSw hardware description
 * layer.
 *
 * This header belongs to the CoreSw hardware description layer. It provides lightweight
 * descriptors for serial devices, pin mappings, and other hardware-facing metadata.
 *
 * Within that layer, this file focuses on the pin out interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwPinOut.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * These declarations focus on transportable metadata and capability description rather than
 * direct device access.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwString.h"
#include "SwVector.h"
#include "SwDebug.h"
#include "SwFile.h"
#include "SwDir.h"
#include "SwMap.h"

#include <cctype>
#include <cstdio>
static constexpr const char* kSwLogCategory_SwPinOut = "sw.core.hw.swpinout";


/**
 * @brief Utility class able to enumerate the GPIO/pin capabilities of the host platform.
 *
 * Under Linux (Jetson, Raspberry Pi, etc.) this class introspects either
 * /sys/kernel/debug/gpio (preferred because it provides direction + logical level)
 * or, as a fallback, /sys/class/gpio/gpiochip* to at least expose the available
 * GPIO chips and their ranges.
 *
 * On unsupported platforms the helpers simply return an empty list.
 */
class SW_HARDWARE_EXPORT SwPinOut
{
public:
    struct PinInfo {
        SwString chipLabel;      ///< Friendly name, e.g. "tegra-gpio"
        int      chipIndex{0};   ///< gpiochip index
        int      chipBase{0};    ///< first GPIO number handled by the chip
        int      chipEnd{0};     ///< last GPIO handled by the chip
        int      globalNumber{0};///< Absolute GPIO number (as seen in sysfs/debugfs)
        int      localNumber{0}; ///< Relative index inside the chip
        SwString direction;      ///< "in", "out", "hi", etc.
        SwString value;          ///< "hi"/"lo"/"1"/"0"
        SwString consumer;       ///< Optional consumer label
    };

    /**
     * @brief Enumerate the best knowledge the host can provide about available pins.
     */
    static SwVector<PinInfo> availablePins();

    /**
     * @brief Convenience helper returning a formatted textual dump.
     */
    static SwString dumpAvailablePins();

private:
#if defined(__linux__)
    static PinInfo* findPin(SwVector<PinInfo>& pins, int globalNumber);

    static void mergeWithSysPins(SwVector<PinInfo>& pins, const SwVector<PinInfo>& sysPins);

    static SwString runCommand(const char* command);

    static void enrichWithGpioInfo(SwVector<PinInfo>& pins);

    static SwVector<PinInfo> readFromDebugGpio();

    static void parseDebugChipLine(const SwString &line, SwString &label, int &chipIndex, int &base, int &end);

    static PinInfo parseDebugPinLine(const SwString &line,
                                     const SwString &chipLabel,
                                     int chipIndex,
                                     int chipBase,
                                     int chipEnd);

    static SwVector<PinInfo> readFromSysClassGpio();
#endif
};
