#ifndef SWSERIALINFO_H
#define SWSERIALINFO_H

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/hw/SwSerialInfo.h
 * @ingroup core_hw
 * @brief Declares the public interface exposed by SwSerialInfo in the CoreSw hardware description
 * layer.
 *
 * This header belongs to the CoreSw hardware description layer. It provides lightweight
 * descriptors for serial devices, pin mappings, and other hardware-facing metadata.
 *
 * Within that layer, this file focuses on the serial info interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwSerialInfo.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * These declarations focus on transportable metadata and capability description rather than
 * direct device access.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwString.h"
#include "SwList.h"
#include "SwSerial.h"

#include <cstdint>
#include <algorithm>
#include <vector>
#include <functional>
#include <cwctype>
#include <cwchar>
#include <string>
#include <utility>


#if defined(_WIN32)
// Windows' registry and device-setup types, only declared (SwSerialInfo.cpp includes them).
struct HKEY__;
struct _SP_DEVINFO_DATA;
#endif

class SW_HARDWARE_EXPORT SwSerialInfo {
public:
    /**
     * @brief Constructs a `SwSerialInfo` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSerialInfo();
    /**
     * @brief Constructs a `SwSerialInfo` instance.
     * @param portName Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwSerialInfo(const SwString& portName);
    /**
     * @brief Constructs a `SwSerialInfo` instance.
     * @param serial Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSerialInfo(const SwSerial& serial);

    /**
     * @brief Constructs a `SwSerialInfo` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSerialInfo(const SwSerialInfo&);
    /**
     * @brief Constructs a `SwSerialInfo` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSerialInfo(SwSerialInfo&& other) noexcept;
    /**
     * @brief Performs the `operator=` operation.
     * @return The requested operator =.
     */
    SwSerialInfo& operator=(const SwSerialInfo&);
    /**
     * @brief Performs the `operator=` operation.
     * @return The requested operator =.
     */
    SwSerialInfo& operator=(SwSerialInfo&& other) noexcept;
    /**
     * @brief Destroys the `SwSerialInfo` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwSerialInfo();

    /**
     * @brief Performs the `swap` operation.
     * @param other Value passed to the method.
     */
    void swap(SwSerialInfo& other) noexcept;

    /**
     * @brief Returns whether the object reports null.
     * @return `true` when the object reports null; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isNull() const;
    /**
     * @brief Returns whether the object reports valid.
     * @return `true` when the object reports valid; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isValid() const;
    /**
     * @brief Returns whether the object reports busy.
     * @return `true` when the object reports busy; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isBusy() const;

    /**
     * @brief Returns the current port Name.
     * @return The current port Name.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString portName() const;
    /**
     * @brief Returns the current system Location.
     * @return The current system Location.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString systemLocation() const;
    /**
     * @brief Returns the current description.
     * @return The current description.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString description() const;
    /**
     * @brief Returns the current manufacturer.
     * @return The current manufacturer.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString manufacturer() const;
    /**
     * @brief Returns the current serial Number.
     * @return The current serial Number.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString serialNumber() const;

    /**
     * @brief Returns whether the object reports vendor Identifier.
     * @return `true` when the object reports vendor Identifier; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasVendorIdentifier() const;
    /**
     * @brief Returns the current vendor Identifier.
     * @return The current vendor Identifier.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    uint16_t vendorIdentifier() const;
    /**
     * @brief Returns whether the object reports product Identifier.
     * @return `true` when the object reports product Identifier; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasProductIdentifier() const;
    /**
     * @brief Returns the current product Identifier.
     * @return The current product Identifier.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    uint16_t productIdentifier() const;

    /**
     * @brief Performs the `operator==` operation.
     * @param other Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator==(const SwSerialInfo& other) const;
    /**
     * @brief Performs the `operator!=` operation.
     * @param this Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator!=(const SwSerialInfo& other) const;

    /**
     * @brief Returns the current available Ports.
     * @return The current available Ports.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwList<SwSerialInfo> availablePorts();
    /**
     * @brief Returns the current standard Baud Rates.
     * @return The current standard Baud Rates.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwList<int> standardBaudRates();

private:
#if defined(_WIN32)
    static SwString readRegistryString(HKEY__* key, const wchar_t* valueName);   // an HKEY
    static bool extractVidPid(const std::wstring& hardwareId, uint16_t& vid, uint16_t& pid);
    static void fillFromSetupDi(SwSerialInfo& info, void* devInfoSet, _SP_DEVINFO_DATA& devInfo);   // HDEVINFO
#else
    static bool tryOpenDevice(const char* path);
    static void appendFromGlob(SwList<SwSerialInfo>& list, const char* pattern);
#endif


    void refreshFromSystem();
private:
    // What the class keeps (SwSerialInfo_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif // SWSERIALINFO_H
