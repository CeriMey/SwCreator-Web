#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/hw/SwSerialInfo.h"

// The platform, which the public header no longer shows (SwSerialInfo.h).
#if defined(_WIN32)
#include <Windows.h>
#include <setupapi.h>
#include <devguid.h>
#include <regstr.h>
#include <initguid.h>
#else
#include <glob.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#endif

struct SwSerialInfo::Data : SwSharedData {
    SwString portName_;
    SwString systemLocation_;
    SwString description_;
    SwString manufacturer_;
    SwString serialNumber_;
    bool busy_;
    bool hasVendorId_;
    uint16_t vendorId_;
    bool hasProductId_;
    uint16_t productId_;
};
