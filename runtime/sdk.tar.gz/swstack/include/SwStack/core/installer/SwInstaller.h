#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

#include "SwInstallerPayload.h"
#include "SwInstallerWindows.h"

#include "SwDir.h"
#include "SwFile.h"
#include "SwFileInfo.h"
#include "SwJsonArray.h"
#include "SwJsonDocument.h"
#include "SwJsonObject.h"
#include "SwStandardPaths.h"
#include "SwString.h"

#include <cstdio>
#include <string>

namespace swinstaller {

enum class SwInstallerShortcutLocation {
    Desktop,
    StartMenu,
    Both
};

enum class SwInstallerPlanKind {
    Install,
    Repair,
    Uninstall
};

enum class SwInstallerActionKind {
    ExtractPayloadFile,
    WriteJsonFile,
    RunPrerequisite,
    CopySetupSelf,
    CreateShortcut,
    RegisterUninstall,
    RemoveOwnedFile,
    RemoveOwnedDirectory,
    RemoveShortcut,
    RemoveUninstallRegistration,
    RemoveStateFile
};

struct SW_INSTALLER_EXPORT SwInstallerPayloadFileSpec {
    const SwInstallerEmbeddedPayload* payload{nullptr};
    SwString relativePath;
};

struct SW_INSTALLER_EXPORT SwInstallerShortcutSpec {
    SwString linkName;
    SwString targetRelativePath;
    SwString arguments;
    SwString workingDirectoryRelativePath;
    SwString description;
    SwString iconRelativePath;
    int iconIndex{0};
    SwInstallerShortcutLocation location{SwInstallerShortcutLocation::StartMenu};
};

struct SW_INSTALLER_EXPORT SwInstallerPrerequisiteSpec {
    SwString displayName;
    SwString targetRelativePath;
    SwString arguments;
    bool createNoWindow{true};
    long long expectedExitCode{0};
    bool optional{false};
};

struct SW_INSTALLER_EXPORT SwInstallerWriteJsonSpec {
    SwString targetRelativePath;
    SwJsonObject document;
    bool overwrite{true};
    bool owned{true};
    bool preserveIfModified{false};
};

struct SW_INSTALLER_EXPORT SwInstallerLaunchSpec {
    SwString displayName;
    SwString targetRelativePath;
    SwString arguments;
    SwString workingDirectoryRelativePath;
};

class SW_INSTALLER_EXPORT SwInstallerComponent {
public:
    SwString componentId;
    SwString displayName;
    SwString description;
    bool selectedByDefault{true};
    SwList<const SwInstallerEmbeddedPayload*> payloadTrees;
    SwList<SwInstallerPayloadFileSpec> payloadFiles;
    SwList<SwInstallerShortcutSpec> shortcuts;
    SwList<SwInstallerPrerequisiteSpec> prerequisites;
    SwList<SwInstallerWriteJsonSpec> jsonFiles;
    SwList<SwInstallerLaunchSpec> finalLaunches;

    SwInstallerComponent() = default;

    explicit SwInstallerComponent(const SwString& id, const SwString& title = SwString());

    SwInstallerComponent& setDescription(const SwString& value);

    SwInstallerComponent& setSelectedByDefault(bool value);

    SwInstallerComponent& addPayloadTree(const SwInstallerEmbeddedPayload* payload);

    SwInstallerComponent& addPayloadFile(const SwInstallerEmbeddedPayload* payload,
                                         const SwString& relativePath);

    SwInstallerComponent& addShortcut(const SwInstallerShortcutSpec& shortcut);

    SwInstallerComponent& addPrerequisite(const SwInstallerPrerequisiteSpec& prerequisite);

    SwInstallerComponent& addJsonFile(const SwInstallerWriteJsonSpec& jsonFile);

    SwInstallerComponent& addFinalLaunch(const SwInstallerLaunchSpec& launch);
};

class SW_INSTALLER_EXPORT SwInstallerProduct {
public:
    SwString productId;
    SwString displayName;
    SwString publisher;
    SwString version;
    SwString mainExecutableRelativePath;
    SwString displayIconRelativePath;
    SwString defaultInstallRootOverride;
    SwString cachedSetupFileName{"Setup.exe"};
    bool machineWideInstall{false};
    SwList<SwInstallerComponent> components;

    SwInstallerProduct& setProductId(const SwString& value);
    SwInstallerProduct& setDisplayName(const SwString& value);
    SwInstallerProduct& setPublisher(const SwString& value);
    SwInstallerProduct& setVersion(const SwString& value);
    SwInstallerProduct& setMainExecutableRelativePath(const SwString& value);
    SwInstallerProduct& setDisplayIconRelativePath(const SwString& value);
    SwInstallerProduct& setDefaultInstallRoot(const SwString& value);
    SwInstallerProduct& setCachedSetupFileName(const SwString& value);
    SwInstallerProduct& addComponent(const SwInstallerComponent& component);

    SwString effectiveDisplayName() const;

    SwString resolveDefaultInstallRoot() const;

    SwString resolveStateRoot() const;

    SwString resolveStateFilePath() const;

    SwString resolveCachedSetupPath() const;

    const SwInstallerComponent* findComponent(const SwString& componentIdValue) const;

    const SwInstallerEmbeddedPayload* findPayload(const SwString& payloadIdValue) const;

private:
    static SwString sanitizeLeaf_(SwString value);
};

struct SW_INSTALLER_EXPORT SwInstallerPlanAction {
    SwInstallerActionKind kind{SwInstallerActionKind::ExtractPayloadFile};
    SwString title;
    SwString payloadId;
    SwString payloadRelativePath;
    SwString sourcePath;
    SwString targetPath;
    SwString arguments;
    SwString workingDirectory;
    SwString linkPath;
    SwString description;
    SwString iconPath;
    int iconIndex{0};
    SwString registryKeyPath;
    SwString checksumSha256;
    bool overwrite{true};
    bool preserveIfModified{false};
    bool createNoWindow{true};
    long long expectedExitCode{0};
    bool optional{false};
    SwJsonObject jsonDocument;

    static SwString kindToString(SwInstallerActionKind kindValue);

    static SwInstallerActionKind stringToKind(const SwString& value);

    SwJsonObject toJson() const;

    static SwInstallerPlanAction fromJson(const SwJsonObject& obj);
};

struct SW_INSTALLER_EXPORT SwInstallerPlan {
    SwInstallerPlanKind kind{SwInstallerPlanKind::Install};
    SwString productId;
    SwString displayName;
    SwString publisher;
    SwString version;
    SwString installRoot;
    SwString stateRoot;
    SwString stateFilePath;
    SwString setupSelfPath;
    SwString cachedSetupPath;
    SwString uninstallRegistryKeyPath;
    bool silent{false};
    SwList<SwString> selectedComponentIds;
    SwList<SwInstallerPlanAction> actions;
    SwList<SwInstallerLaunchSpec> finalLaunches;

    static SwString kindToString(SwInstallerPlanKind kindValue);

    static SwInstallerPlanKind stringToKind(const SwString& value);

    SwJsonObject toJsonObject() const;
    SwString toJson() const;
    static SwInstallerPlan fromJson(const SwString& jsonText, SwString* errOut = nullptr);
    static SwInstallerPlan fromJsonObject(const SwJsonObject& obj);
};

struct SW_INSTALLER_EXPORT SwInstallerDetection {
    bool installed{false};
    SwString installRoot;
    SwString stateFilePath;
    SwJsonObject stateObject;
};

struct SW_INSTALLER_EXPORT SwInstallerExecutionResult {
    bool ok{false};
    SwString message;
    SwJsonObject stateObject;

    SwString toJson() const;

    static SwInstallerExecutionResult fromJson(const SwString& jsonText, SwString* errOut = nullptr);
};

class SW_INSTALLER_EXPORT SwInstallerEngine {
public:
    explicit SwInstallerEngine(const SwInstallerProduct& product,
                               const SwString& setupSelfPath = SwInstallerWindows::currentExecutablePath());

    const SwInstallerProduct& product() const;
    SwInstallerDetection detect() const;
    SwInstallerPlan planInstall(const SwString& installRootOverride = SwString(),
                                const SwList<SwString>& selectedComponentIds = SwList<SwString>(),
                                bool silent = false) const;
    SwInstallerPlan planRepair(bool silent = false) const;
    SwInstallerPlan planUninstall(bool silent = false) const;
    SwInstallerExecutionResult execute(const SwInstallerPlan& plan,
                                       bool allowPostInstallLaunch = false,
                                       SwString* errOut = nullptr);
    bool rollback(SwString* errOut = nullptr);
    bool launchPostInstallActions(const SwInstallerPlan& plan, SwString* errOut = nullptr) const;

private:
    struct RollbackState_ {
        SwList<SwString> files;
        SwList<SwString> directories;
        SwList<SwString> shortcuts;
        SwList<SwString> registryKeys;
        SwString stateFilePath;
    };


    void initializePlanHeader_(SwInstallerPlan& plan, const SwString& installRootOverride, bool silent) const;
    SwList<SwString> resolveSelectedComponents_(const SwList<SwString>& requestedIds) const;
    SwList<SwInstallerLaunchSpec> collectFinalLaunches_(const SwList<SwString>& selectedIds) const;
    void appendInstallActionsForComponent_(const SwInstallerComponent& component,
                                           SwInstallerPlan& plan,
                                           SwList<SwString>& seenPayloadKeys) const;
    void appendPayloadAction_(const SwInstallerEmbeddedPayload* payload,
                              const SwString& relativePath,
                              SwInstallerPlan& plan,
                              SwList<SwString>& seenPayloadKeys) const;
    void appendShortcutAction_(const SwInstallerShortcutSpec& shortcut, SwInstallerPlan& plan) const;
    void appendUninstallActions_(const SwJsonObject& state, SwInstallerPlan& plan) const;

    bool executeAction_(const SwInstallerPlan& plan,
                        const SwInstallerPlanAction& action,
                        SwJsonObject& state,
                        SwString* errOut);
    bool executeExtractPayload_(const SwInstallerPlanAction& action,
                                const SwInstallerPlan& plan,
                                SwJsonObject& state,
                                SwString* errOut);
    bool executeWriteJson_(const SwInstallerPlanAction& action,
                           const SwInstallerPlan& plan,
                           SwJsonObject& state,
                           SwString* errOut);
    bool executePrerequisite_(const SwInstallerPlanAction& action, SwString* errOut);
    bool executeCopySetup_(const SwInstallerPlanAction& action,
                           const SwInstallerPlan& plan,
                           SwJsonObject& state,
                           SwString* errOut);
    bool executeCreateShortcut_(const SwInstallerPlanAction& action,
                                SwJsonObject& state,
                                SwString* errOut);
    bool executeRegisterUninstall_(const SwInstallerPlanAction& action,
                                   const SwInstallerPlan& plan,
                                   SwJsonObject& state,
                                   SwString* errOut);
    bool executeRemoveOwnedFile_(const SwInstallerPlanAction& action, SwString* errOut);
    bool executeRemoveOwnedDirectory_(const SwInstallerPlanAction& action, SwString* errOut);
    bool executeRemoveShortcut_(const SwInstallerPlanAction& action, SwString* errOut);
    bool executeRemoveUninstallRegistration_(const SwInstallerPlanAction& action, SwString* errOut);
    bool executeRemoveStateFile_(const SwInstallerPlanAction& action, SwString* errOut);

    SwJsonObject initialStateObject_(const SwInstallerPlan& plan) const;
    static bool saveStateObject_(const SwString& path, const SwJsonObject& state, SwString* errOut);
    static SwJsonObject loadStateObject_(const SwString& path, SwString* errOut);

    static void appendOwnedFile_(SwJsonObject& state, const SwString& path, const SwString& checksum, bool preserveIfModified);
    static void collectOwnedDirectoriesFromPath_(SwJsonObject& state, SwString path, const SwString& stopRoot);
    static void appendUniqueStringArray_(SwJsonObject& state, const SwString& key, const SwString& value);

    void appendRollbackFile_(const SwString& path);
    void appendRollbackDirectoriesFromPath_(SwString path, const SwString& stopRoot);
    void clearRollback_();

    static void appendSortedByDepth_(const SwList<SwInstallerPlanAction>& input, SwList<SwInstallerPlanAction>& output);
    static void removeDirectoriesReverse_(const SwList<SwString>& dirs);
    static SwString parentPath_(SwString path);
    static SwString expandTokens_(SwString value, const SwString& installRoot, const SwString& stateRoot);
    SwString displayIconAbsolute_(const SwString& installRoot) const;
    static SwList<SwString> splitCommandLine_(const SwString& text);
    static SwString checksumForFile_(const SwString& path);
    static bool replaceFile_(const SwString& tempPath, const SwString& destinationPath, SwString* errOut);
    static bool launchDetached_(const SwString& executablePath,
                                const SwList<SwString>& arguments,
                                const SwString& workingDirectory,
                                SwString* errOut);
    static std::wstring quoteArgument_(const std::wstring& s);
public:
    ~SwInstallerEngine();
public:
    SwInstallerEngine(const SwInstallerEngine& other);
    SwInstallerEngine& operator=(const SwInstallerEngine& other);
private:
    // What the class keeps (SwInstaller_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace swinstaller
