#pragma once

#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/installer/SwInstallerWindows.h
 * @brief Header-only Windows integration helpers used by the Sw installer runtime.
 */

#include "SwDir.h"
#include "SwFile.h"
#include "SwFileInfo.h"
#include "SwList.h"
#include "SwString.h"

#include <cstdio>


namespace swinstaller {

class SW_INSTALLER_EXPORT SwInstallerWindows {
public:
#if defined(_WIN32)
    struct SW_INSTALLER_EXPORT MutexHandle {
        HANDLE handle{nullptr};
        bool alreadyExists{false};

        ~MutexHandle();
    };
#endif

    static SwString currentExecutablePath();

    static SwString programFilesDir();

    static SwString programDataDir();

    static SwString commonDesktopDir();

    static SwString userDesktopDir();

    static SwString commonProgramsDir();

    static SwString userProgramsDir();

    static SwString makeUninstallRegistryKey(const SwString& productId);

    static bool isProcessElevated();

    static bool createSingleInstanceMutex(const SwString& productId,
#if defined(_WIN32)
                                          MutexHandle& outHandle,
#else
                                          int&,
#endif
                                          SwString* errOut = nullptr);

    static bool launchElevatedAndWait(const SwString& executablePath,
                                      const SwList<SwString>& arguments,
                                      const SwString& workingDirectory,
                                      unsigned long& exitCode,
                                      SwString* errOut = nullptr);

    static bool runProcessAndWait(const SwString& executablePath,
                                  const SwList<SwString>& arguments,
                                  const SwString& workingDirectory,
                                  bool hiddenWindow,
                                  unsigned long& exitCode,
                                  SwString* errOut = nullptr);

    static bool createShortcut(const SwString& linkPath,
                               const SwString& targetPath,
                               const SwString& arguments,
                               const SwString& workingDirectory,
                               const SwString& description,
                               const SwString& iconPath,
                               int iconIndex,
                               SwString* errOut = nullptr);

    static bool writeUninstallEntry(const SwString& registryKeyPath,
                                    const SwString& displayName,
                                    const SwString& publisher,
                                    const SwString& version,
                                    const SwString& installLocation,
                                    const SwString& uninstallCommand,
                                    const SwString& displayIcon,
                                    SwString* errOut = nullptr);

    static bool removeUninstallEntry(const SwString& registryKeyPath, SwString* errOut = nullptr);

    static bool deleteFileOrScheduleReboot(const SwString& path);

    static bool deleteDirectoryIfEmpty(const SwString& path);

private:
#if defined(_WIN32)
    static SwString knownFolder_(const GUID& id);

    static std::wstring quoteArgument_(const std::wstring& s);

    static std::wstring joinCommandLine_(const SwList<SwString>& arguments);

    static bool writeRegString_(HKEY key, const wchar_t* valueName, const SwString& value);

    static bool writeRegDword_(HKEY key, const wchar_t* valueName, DWORD value);
#endif

    static SwString parentPath_(SwString path);
};

} // namespace swinstaller
