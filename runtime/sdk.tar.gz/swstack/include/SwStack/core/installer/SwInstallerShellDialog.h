#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/installer/SwInstallerShellDialog.h
 * @brief Dark, modern shell dialog for the Sw installer wizard.
 */

#include "SwDialog.h"
#include "SwFrame.h"
#include "SwLabel.h"
#include "SwList.h"
#include "SwPushButton.h"
#include "SwStackedWidget.h"
#include "SwWizard.h"

#include <functional>

namespace swinstaller {

class SW_INSTALLER_EXPORT SwInstallerShellDialog : public SwDialog {
    SW_OBJECT(SwInstallerShellDialog, SwDialog)

public:
    explicit SwInstallerShellDialog(const SwString& productName,
                                    bool installed,
                                    SwWidget* parent = nullptr);

    int addPage(SwWizardPage* page);

    int currentId() const;

    void setCurrentId(int id);

    SwWizardPage* currentPage() const;

    void next();

    void back();

    void setCurrentIdChangedHandler(std::function<void(int)> handler);

    void setAbortVisible(bool visible);

    void setNextButtonText(const SwString& text);

    void setNextButtonVisible(bool visible);

protected:
    void resizeEvent(ResizeEvent* event) override;

private:

    /* ─── Sidebar step indicator ──────────────────────────────── */

    class SW_INSTALLER_EXPORT SidebarStepItem_ : public SwFrame {
        SW_OBJECT(SidebarStepItem_, SwFrame)

    public:
        explicit SidebarStepItem_(SwWidget* parent = nullptr);

        void setStep(int stepNumber, const SwString& caption);

        void setVisualState(bool current, bool completed);

    protected:
        void resizeEvent(ResizeEvent* event) override;

    private:
        void updateBadge_();

        void applyState_(bool current, bool completed);

        int stepNumber_{1};
        bool current_{false};
        bool completed_{false};
        SwLabel* badge_{nullptr};
        SwLabel* title_{nullptr};
    };

    /* ─── Build ───────────────────────────────────────────────── */

    void buildUi_();

    /* ─── Button styles ───────────────────────────────────────── */

    static void stylePrimary_(SwPushButton* b);

    static void styleDanger_(SwPushButton* b);

    static void styleSecondary_(SwPushButton* b);

    /* ─── Navigation ──────────────────────────────────────────── */

    void setCurrentIndex_(int index, bool notify);

    void updateUi_();

    /* ─── Layout ──────────────────────────────────────────────── */

    void layoutShell_();

    /* ─── Members ─────────────────────────────────────────────── */

public:
    ~SwInstallerShellDialog();
private:
    // What the class keeps (SwInstallerShellDialog_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

} // namespace swinstaller
