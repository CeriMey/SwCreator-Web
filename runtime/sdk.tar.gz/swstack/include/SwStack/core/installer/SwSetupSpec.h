#pragma once

/**
 * @file src/core/installer/SwSetupSpec.h
 * @brief installer.json: the one description of a setup that SwCreator edits, the builder packages
 * and the setup runtime executes.
 *
 * The file is kept as JSON (unknown keys survive a load/save round trip); this class gives typed
 * access to it, the default content of a new installer, the default page flows and validation.
 *
 * Layout of the document (every key optional unless stated):
 *
 *     schema       "swsetup/1"
 *     product      id (required), name (required), publisher, version (required, or "@cmake"),
 *                  description, mainExecutable, icon, url
 *     install      scope "user" | "machine" | "ask", userDirectory, machineDirectory
 *     sources      [{id, type "cmake-target" | "directory" | "file", target, path, dependencies,
 *                    include[], exclude[]}]
 *     components   [{id, name, description, required, selected}]
 *     variables    [{name, default, description}]
 *     deploy       [{id, action "copy" | "file" | "shortcut" | "registry" | "environment" |
 *                    "association" | "run", component, when, ...}]
 *     pages        {install: [...], maintenance: [...], uninstall: [...]}, each page
 *                  {id, type, title, subtitle, form, when, skipSilent, nextLabel}
 *     appearance   accent, oneClick, license, icon, launchAtEnd, launchArguments, welcomeText
 *     output       file, compression "fast" | "balanced" | "max", signing {certificate, timestamp}
 */

#include "SwSharedData.h"
#include "../SwStackExport.h"

#include "SwJsonArray.h"
#include "SwJsonObject.h"
#include "SwList.h"
#include "SwString.h"

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupSpec {
public:
    SwSetupSpec();
    explicit SwSetupSpec(const SwJsonObject& document);
    ~SwSetupSpec();
    SwSetupSpec(const SwSetupSpec& other);
    SwSetupSpec& operator=(const SwSetupSpec& other);

    static SwSetupSpec load(const SwString& path, SwString* error = nullptr);
    static SwSetupSpec fromJsonText(const SwString& text, SwString* error = nullptr);
    bool save(const SwString& path, SwString* error = nullptr) const;
    SwString toJsonText() const;

    const SwJsonObject& document() const;
    void setDocument(const SwJsonObject& document);
    bool isNull() const;

    /// The folder installer.json lives in: relative paths in the document start there.
    SwString baseDirectory() const;
    void setBaseDirectory(const SwString& directory);
    SwString resolvePath(const SwString& relativeOrAbsolute) const;

    SwJsonObject product() const;
    SwString productId() const;
    SwString productName() const;
    SwString publisher() const;
    SwString version() const;
    SwString description() const;
    SwString mainExecutable() const;

    /// "user", "machine" or "ask".
    SwString scope() const;
    /// The default install folder for a scope ("user" or "machine"), before substitution.
    SwString installDirectory(const SwString& scope) const;

    SwJsonArray sources() const;
    SwJsonArray components() const;
    SwJsonArray variables() const;
    SwJsonArray deployRules() const;
    /// The pages of a flow ("install", "maintenance", "uninstall"), or the default flow when none is set.
    SwJsonArray pages(const SwString& flow) const;
    bool hasCustomPages(const SwString& flow) const;
    SwJsonObject appearance() const;
    SwJsonObject output() const;

    SwJsonObject findSource(const SwString& id) const;
    SwJsonObject findComponent(const SwString& id) const;
    SwJsonObject findPage(const SwString& flow, const SwString& id) const;

    /// Problems found in the document, each starting with "error: " or "warning: ".
    SwList<SwString> validate() const;
    bool hasErrors() const;

    /// The installer a project gets before anyone edits it.
    static SwSetupSpec createDefault(const SwString& productName, const SwString& publisher,
                                     const SwString& version, const SwString& cmakeTarget,
                                     const SwString& mainExecutable);
    static SwJsonArray defaultPages(const SwString& flow);
    static SwList<SwString> pageTypes();
    static SwList<SwString> flows();
    static SwList<SwString> deployActions();
    /// Page types whose content is a form designed in the UI builder.
    static bool pageTypeUsesForm(const SwString& type);
    /// A turnkey .swui form for a page type (license, location, components, form, choice, info, blank, confirm).
    static SwString presetForm(const SwString& pageType);

    static SwString stringOf(const SwJsonObject& object, const char* key, const SwString& fallback = SwString());
    static bool boolOf(const SwJsonObject& object, const char* key, bool fallback);

private:
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace swinstaller
