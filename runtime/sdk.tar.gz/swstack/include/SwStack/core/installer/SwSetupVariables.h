#pragma once

/**
 * @file src/core/installer/SwSetupVariables.h
 * @brief The values a setup works with — known folders, product facts, answers given on the pages —
 * the {Name} substitutions that use them and the conditions that test them.
 *
 * Substitution: `{Name}` is replaced by the value of the variable Name (names are case-insensitive).
 * A modifier changes how the value is written: `{Name:json}` escapes it for a JSON string,
 * `{Name:slash}` uses forward slashes, `{Name:quote}` quotes it for a command line. A brace that does
 * not open a known variable is kept as it is, so JSON or registry text passes through untouched.
 *
 * Conditions: `{IsUpdate}`, `!{Silent}`, `{SetupType} == 'Complete'`, `{Scope} != 'machine'`,
 * `component(examples)`, combined with `&&`, `||`, `!` and parentheses. A lone value is true when it
 * reads as yes: 1, true, yes, on, oui, vrai. An empty condition is true.
 */

#include "SwSharedData.h"
#include "../SwStackExport.h"

#include "SwJsonObject.h"
#include "SwList.h"
#include "SwString.h"

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupVariables {
public:
    SwSetupVariables();
    ~SwSetupVariables();
    SwSetupVariables(const SwSetupVariables& other);
    SwSetupVariables& operator=(const SwSetupVariables& other);

    void set(const SwString& name, const SwString& value);
    void setBool(const SwString& name, bool value);
    SwString value(const SwString& name, const SwString& fallback = SwString()) const;
    bool boolValue(const SwString& name, bool fallback = false) const;
    bool contains(const SwString& name) const;
    void remove(const SwString& name);
    /// The names, with the case they were first set with.
    SwList<SwString> names() const;

    void setComponentSelected(const SwString& componentId, bool selected);
    bool isComponentSelected(const SwString& componentId) const;
    SwList<SwString> selectedComponents() const;
    void setSelectedComponents(const SwList<SwString>& componentIds);

    /// Adds every known folder (LocalAppData, ProgramFiles, Documents, Temp, ...) with native separators.
    void addSystemFolders();

    SwString expand(const SwString& text) const;
    /// expand(), then every '/' turned into the native separator.
    SwString expandPath(const SwString& text) const;
    bool evaluate(const SwString& condition, SwString* error = nullptr) const;

    /// The variables that are not system folders, as {name: value}; components under "components".
    SwJsonObject toJson() const;
    void mergeJson(const SwJsonObject& object);

    static bool isTrue(const SwString& value);
    static bool isValidName(const SwString& name);
    static SwString jsonEscaped(const SwString& value);

private:
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace swinstaller
