#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/installer/SwInstallerShellDialog.h"

struct swinstaller::SwInstallerShellDialog::Data {
    SwString productName_;
    bool installed_{false};
    SwFrame* sidebar_{nullptr};
    SwLabel* brandTitle_{nullptr};
    SwLabel* brandTag_{nullptr};
    SwFrame* brandSep_{nullptr};
    SwFrame* stepsContainer_{nullptr};
    SwList<SidebarStepItem_*> stepItems_;
    SwFrame* contentPanel_{nullptr};
    SwLabel* pageTitle_{nullptr};
    SwLabel* pageSubtitle_{nullptr};
    SwFrame* titleSep_{nullptr};
    SwFrame* pageCard_{nullptr};
    SwStackedWidget* stack_{nullptr};
    SwPushButton* cancelBtn_{nullptr};
    SwPushButton* backBtn_{nullptr};
    SwPushButton* nextBtn_{nullptr};
    SwPushButton* finishBtn_{nullptr};
    SwPushButton* abortBtn_{nullptr};
    SwList<SwWizardPage*> pages_;
    int currentIndex_{0};
    std::function<void(int)> currentIdChangedHandler_;
};
