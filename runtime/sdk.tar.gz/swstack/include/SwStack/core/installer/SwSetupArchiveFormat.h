#pragma once

/**
 * @file src/core/installer/SwSetupArchiveFormat.h
 * @brief The byte layout of the archive a Setup.exe carries after its PE image.
 *
 * A Setup.exe is a small native launcher followed by an archive:
 *
 *     [launcher PE image][entry bytes ...][index][footer (48 bytes)][Authenticode certificates, if signed]
 *
 * Every entry is stored once, raw or as one zlib stream, at an absolute file offset. The index lists the
 * entries; the footer, read just before the certificate table (or at the end of the file when the
 * executable is unsigned), locates the index. Signing a Setup.exe after the archive is appended is
 * therefore supported: the certificates land after the footer and are skipped when reading.
 *
 * This header only depends on the C++ standard library so that the launcher, which links nothing of
 * SwStack, reads the same format as the runtime and the builder.
 */

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace swinstaller {
namespace setupformat {

static const char kFooterMagic[8] = {'S', 'W', 'S', 'E', 'T', 'U', 'P', '1'};
static const char kFooterEnd[8] = {'S', 'W', 'S', 'E', 'T', 'E', 'N', 'D'};
static const std::size_t kFooterSize = 48;

/// Group of the entries the launcher extracts and runs: the setup runtime and its DLLs.
static const char* const kRuntimeGroup = "runtime";
/// Group holding installer.json, as resolved by the builder.
static const char* const kManifestGroup = "manifest";
/// Group of the files the setup UI reads: page forms, license, images, icon.
static const char* const kUiGroup = "ui";
/// Prefix of the groups that hold a source declared in installer.json ("src:<id>").
static const char* const kSourceGroupPrefix = "src:";
/// Name of the runtime executable inside the runtime group.
static const char* const kRuntimeExecutable = "SwSetupRuntime.exe";

enum Method : std::uint8_t {
    Stored = 0,
    Zlib = 1
};

struct Entry {
    std::string group;
    std::string path;
    std::uint64_t offset;
    std::uint64_t storedSize;
    std::uint64_t originalSize;
    std::uint8_t method;
    std::uint8_t sha256[32];

    Entry() : offset(0), storedSize(0), originalSize(0), method(Stored) { std::memset(sha256, 0, sizeof(sha256)); }
};

struct Footer {
    std::uint64_t overlayStart;
    std::uint64_t indexOffset;
    std::uint64_t indexSize;
    std::uint32_t entryCount;
    std::uint32_t flags;

    Footer() : overlayStart(0), indexOffset(0), indexSize(0), entryCount(0), flags(0) {}
};

inline void putU16(std::string& out, std::uint16_t v) {
    out.push_back(static_cast<char>(v & 0xFF));
    out.push_back(static_cast<char>((v >> 8) & 0xFF));
}

inline void putU32(std::string& out, std::uint32_t v) {
    for (int i = 0; i < 4; ++i) out.push_back(static_cast<char>((v >> (8 * i)) & 0xFF));
}

inline void putU64(std::string& out, std::uint64_t v) {
    for (int i = 0; i < 8; ++i) out.push_back(static_cast<char>((v >> (8 * i)) & 0xFF));
}

inline bool getU16(const unsigned char*& p, const unsigned char* end, std::uint16_t& v) {
    if (end - p < 2) return false;
    v = static_cast<std::uint16_t>(p[0] | (p[1] << 8));
    p += 2;
    return true;
}

inline bool getU32(const unsigned char*& p, const unsigned char* end, std::uint32_t& v) {
    if (end - p < 4) return false;
    v = 0;
    for (int i = 0; i < 4; ++i) v |= static_cast<std::uint32_t>(p[i]) << (8 * i);
    p += 4;
    return true;
}

inline bool getU64(const unsigned char*& p, const unsigned char* end, std::uint64_t& v) {
    if (end - p < 8) return false;
    v = 0;
    for (int i = 0; i < 8; ++i) v |= static_cast<std::uint64_t>(p[i]) << (8 * i);
    p += 8;
    return true;
}

inline std::string encodeIndex(const std::vector<Entry>& entries) {
    std::string out;
    for (std::size_t i = 0; i < entries.size(); ++i) {
        const Entry& e = entries[i];
        putU16(out, static_cast<std::uint16_t>(e.group.size()));
        out.append(e.group);
        putU16(out, static_cast<std::uint16_t>(e.path.size()));
        out.append(e.path);
        putU64(out, e.offset);
        putU64(out, e.storedSize);
        putU64(out, e.originalSize);
        out.push_back(static_cast<char>(e.method));
        out.append(reinterpret_cast<const char*>(e.sha256), sizeof(e.sha256));
    }
    return out;
}

inline bool decodeIndex(const unsigned char* data, std::size_t size, std::uint32_t count, std::vector<Entry>& out) {
    const unsigned char* p = data;
    const unsigned char* end = data + size;
    out.clear();
    out.reserve(count);
    for (std::uint32_t i = 0; i < count; ++i) {
        Entry e;
        std::uint16_t len = 0;
        if (!getU16(p, end, len) || end - p < len) return false;
        e.group.assign(reinterpret_cast<const char*>(p), len);
        p += len;
        if (!getU16(p, end, len) || end - p < len) return false;
        e.path.assign(reinterpret_cast<const char*>(p), len);
        p += len;
        if (!getU64(p, end, e.offset) || !getU64(p, end, e.storedSize) || !getU64(p, end, e.originalSize)) return false;
        if (end - p < 1 + 32) return false;
        e.method = *p++;
        std::memcpy(e.sha256, p, sizeof(e.sha256));
        p += sizeof(e.sha256);
        out.push_back(e);
    }
    return p == end;
}

inline std::string encodeFooter(const Footer& f) {
    std::string out(kFooterMagic, sizeof(kFooterMagic));
    putU64(out, f.overlayStart);
    putU64(out, f.indexOffset);
    putU64(out, f.indexSize);
    putU32(out, f.entryCount);
    putU32(out, f.flags);
    out.append(kFooterEnd, sizeof(kFooterEnd));
    return out;
}

inline bool decodeFooter(const unsigned char* data, Footer& f) {
    if (std::memcmp(data, kFooterMagic, sizeof(kFooterMagic)) != 0) return false;
    if (std::memcmp(data + kFooterSize - sizeof(kFooterEnd), kFooterEnd, sizeof(kFooterEnd)) != 0) return false;
    const unsigned char* p = data + sizeof(kFooterMagic);
    const unsigned char* end = data + kFooterSize - sizeof(kFooterEnd);
    return getU64(p, end, f.overlayStart) && getU64(p, end, f.indexOffset) && getU64(p, end, f.indexSize) &&
           getU32(p, end, f.entryCount) && getU32(p, end, f.flags);
}

/**
 * @brief Where the archive ends in a PE file: the start of its Authenticode certificate table when the
 * file is signed and the table sits at the end of the file, the file size otherwise.
 * @param head The first bytes of the file (4 KiB is enough for every linker in use).
 */
inline std::uint64_t peArchiveLimit(const unsigned char* head, std::size_t headSize, std::uint64_t fileSize) {
    if (headSize < 0x40 || head[0] != 'M' || head[1] != 'Z') return fileSize;
    std::uint32_t peOffset = 0;
    const unsigned char* p = head + 0x3C;
    if (!getU32(p, head + headSize, peOffset)) return fileSize;
    if (static_cast<std::size_t>(peOffset) + 24 > headSize) return fileSize;
    const unsigned char* pe = head + peOffset;
    if (pe[0] != 'P' || pe[1] != 'E' || pe[2] != 0 || pe[3] != 0) return fileSize;
    const unsigned char* optional = pe + 24;
    if (optional + 2 > head + headSize) return fileSize;
    const std::uint16_t magic = static_cast<std::uint16_t>(optional[0] | (optional[1] << 8));
    const std::size_t directories = magic == 0x20b ? 112 : (magic == 0x10b ? 96 : 0);
    if (directories == 0) return fileSize;
    const unsigned char* security = optional + directories + 4 * 8;
    if (security + 8 > head + headSize) return fileSize;
    std::uint32_t address = 0;
    std::uint32_t size = 0;
    const unsigned char* q = security;
    getU32(q, head + headSize, address);
    getU32(q, head + headSize, size);
    if (address == 0 || size == 0) return fileSize;
    // The table is the last thing in a signed file; anything else means it was not appended last.
    if (static_cast<std::uint64_t>(address) + size >= fileSize && address < fileSize) return address;
    return fileSize;
}

} // namespace setupformat
} // namespace swinstaller
