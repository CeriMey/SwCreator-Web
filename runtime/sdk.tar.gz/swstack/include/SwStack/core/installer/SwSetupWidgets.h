#pragma once

/**
 * @file src/core/installer/SwSetupWidgets.h
 * @brief The widgets setup pages are built from in the UI builder, the light theme every setup
 * shares, and the binding of page widgets to setup variables.
 *
 * A page form (.swui) may use any SwStack widget plus the setup widgets below. A widget answers a
 * question when it carries the dynamic property InstallerVariable (the variable it reads and writes);
 * InstallerRequired makes the answer mandatory, InstallerValue gives a radio button its value. Text
 * shown by labels, check boxes and radio buttons may use {Variables}.
 *
 * The setup widgets read what they show (components, sizes, license, images) from the current
 * SwSetupFormContext: the running setup provides one; without one (in the designer) they show sample
 * content.
 */

#include "../SwStackExport.h"

#include "SwByteArray.h"
#include "Sw.h"
#include "SwLabel.h"
#include "SwLineEdit.h"
#include "SwList.h"
#include "SwPlainTextEdit.h"
#include "SwPushButton.h"
#include "SwString.h"
#include "SwWidget.h"
#include "graphics/SwImage.h"

#include <functional>

namespace swinstaller {

struct SW_INSTALLER_EXPORT SwSetupComponentInfo {
    SwString id;
    SwString name;
    SwString description;
    long long bytes{0};
    bool required{false};
    bool selected{true};
};

/// What the setup widgets of a page read and change.
class SW_INSTALLER_EXPORT SwSetupFormContext {
public:
    virtual ~SwSetupFormContext();

    virtual SwColor accent() const;
    virtual SwString expand(const SwString& text) const;
    virtual SwString variable(const SwString& name) const;
    virtual void setVariable(const SwString& name, const SwString& value);
    virtual SwList<SwSetupComponentInfo> components() const;
    virtual void setComponentSelected(const SwString& id, bool selected);
    virtual long long requiredBytes() const;
    virtual SwString installDirectory() const;
    /// A file of the setup's UI (license, image) by its path in installer.json.
    virtual SwByteArray readFile(const SwString& relativePath) const;
    virtual SwString licenseText() const;
    /// Called when an answer changes, so the page can re-check what it requires.
    virtual void changed();

    static SwSetupFormContext* current();
    static void setCurrent(SwSetupFormContext* context);
};

/// The colours and type every setup page uses.
struct SW_INSTALLER_EXPORT SwSetupTheme {
    SwColor accent{0, 120, 212};
    SwColor accentSoft{235, 243, 251};
    SwColor accentLine{140, 190, 232};
    SwColor text{17, 24, 39};
    SwColor heading{15, 23, 42};
    SwColor body{55, 65, 81};
    SwColor muted{107, 114, 128};
    SwColor border{212, 216, 222};
    SwColor divider{238, 240, 243};
    SwColor footer{249, 250, 251};
    SwColor field{255, 255, 255};
    SwColor danger{180, 35, 24};
    SwColor success{21, 128, 61};
    SwColor successSoft{231, 246, 236};

    static SwSetupTheme withAccent(const SwColor& accent);
    static SwColor parseColor(const SwString& hex, const SwColor& fallback);
    static SwColor mix(const SwColor& color, const SwColor& with, double amount);
    static SwString css(const SwColor& color);
    /// The stylesheet that gives the standard widgets of a page form the setup look.
    SwString formStyleSheet() const;
};

/// Registers the setup widgets with the UI loader (and so with the designer). Safe to call twice.
SW_INSTALLER_EXPORT void registerSetupWidgets();
/// The class names registerSetupWidgets() adds.
SW_INSTALLER_EXPORT SwList<SwString> setupWidgetClassNames();

/// Fills the widgets of a loaded form from the context and writes their answers back as they change.
SW_INSTALLER_EXPORT void bindSetupForm(SwWidget* formRoot, SwSetupFormContext* context);
/// Writes every answer of a form to the context.
SW_INSTALLER_EXPORT void collectSetupForm(SwWidget* formRoot, SwSetupFormContext* context);
/// The first required answer that is missing, by its widget; empty when the form is complete.
SW_INSTALLER_EXPORT SwString missingSetupAnswer(SwWidget* formRoot);

SW_INSTALLER_EXPORT SwString formatSetupBytes(long long bytes);

} // namespace swinstaller

/// A semibold caption above a field.
class SW_INSTALLER_EXPORT SwSetupHeading : public SwLabel {
    SW_OBJECT(SwSetupHeading, SwLabel)
public:
    explicit SwSetupHeading(SwWidget* parent = nullptr);
    SwSize sizeHint() const override;
};

/// A paragraph that wraps.
class SW_INSTALLER_EXPORT SwSetupText : public SwLabel {
    SW_OBJECT(SwSetupText, SwLabel)
public:
    explicit SwSetupText(SwWidget* parent = nullptr);
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;
};

/// A folder field with its Browse button.
class SW_INSTALLER_EXPORT SwSetupPathEdit : public SwWidget {
    SW_OBJECT(SwSetupPathEdit, SwWidget)
public:
    explicit SwSetupPathEdit(SwWidget* parent = nullptr);
    SwString path() const;
    void setPath(const SwString& path);
    SwLineEdit* lineEdit() const;
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;

    SW_SIGNAL(pathEdited, const SwString&);

protected:
    void resizeEvent(ResizeEvent* event) override;

private:
    SwLineEdit* edit_{nullptr};
    SwPushButton* browse_{nullptr};
};

/// The components of the product, to tick.
class SW_INSTALLER_EXPORT SwSetupComponentList : public SwWidget {
    SW_OBJECT(SwSetupComponentList, SwWidget)
public:
    explicit SwSetupComponentList(SwWidget* parent = nullptr);
    void refresh();
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;

protected:
    void paintEvent(PaintEvent* event) override;
    void mousePressEvent(MouseEvent* event) override;

private:
    SwList<swinstaller::SwSetupComponentInfo> items_;
    int rowHeight_{46};
};

/// "120 Mo nécessaires · 210 Go disponibles sur C:".
class SW_INSTALLER_EXPORT SwSetupDiskSpace : public SwLabel {
    SW_OBJECT(SwSetupDiskSpace, SwLabel)
public:
    explicit SwSetupDiskSpace(SwWidget* parent = nullptr);
    void refresh();
    SwSize sizeHint() const override;
};

/// The license text, read-only.
class SW_INSTALLER_EXPORT SwSetupLicenseView : public SwPlainTextEdit {
    SW_OBJECT(SwSetupLicenseView, SwPlainTextEdit)
public:
    explicit SwSetupLicenseView(SwWidget* parent = nullptr);
    void refresh();
};

/// A picture from the setup's files (dynamic property Source), scaled to fit.
class SW_INSTALLER_EXPORT SwSetupImage : public SwWidget {
    SW_OBJECT(SwSetupImage, SwWidget)
public:
    explicit SwSetupImage(SwWidget* parent = nullptr);
    void refresh();
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;

protected:
    void paintEvent(PaintEvent* event) override;

private:
    SwImage image_;
    bool loaded_{false};
    SwString source_;
};

/// One answer among several, as cards (dynamic property Options: one "Title|Description" per line).
class SW_INSTALLER_EXPORT SwSetupChoice : public SwWidget {
    SW_OBJECT(SwSetupChoice, SwWidget)
public:
    explicit SwSetupChoice(SwWidget* parent = nullptr);
    void refresh();
    SwString currentTitle() const;
    void setCurrentTitle(const SwString& title);
    int currentIndex() const;
    void setCurrentIndex(int index);
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;

    SW_SIGNAL(choiceChanged, int);

protected:
    void paintEvent(PaintEvent* event) override;
    void mousePressEvent(MouseEvent* event) override;

private:
    struct Option {
        SwString title;
        SwString description;
    };
    SwList<Option> options_;
    int current_{0};
    int cardHeight_{62};
};
