#pragma once

/**
 * @file src/core/installer/SwSetupSystem.h
 * @brief The operating-system services a setup needs: known folders, registry, environment,
 * processes, elevation and disk space.
 *
 * Every function has a Windows implementation and a portable fallback that reports failure, so the
 * Installer module keeps building everywhere while setups themselves target Windows.
 */

#include "../SwStackExport.h"

#include "SwList.h"
#include "SwString.h"

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupSystem {
public:
    enum class Hive {
        CurrentUser,
        LocalMachine
    };

    /// Names of the folders knownFolder() resolves (LocalAppData, AppData, ProgramFiles, ...).
    static SwList<SwString> knownFolderNames();
    /// A well-known folder, with native separators; empty when the name is unknown.
    static SwString knownFolder(const SwString& name);
    static SwString temporaryDirectory();
    static SwString currentExecutablePath();
    static SwString userName();
    static SwString computerName();
    static bool isElevated();
    static bool is64BitWindows();

    static bool parseHive(const SwString& text, Hive* hive);
    static SwString hiveName(Hive hive);

    static bool registryKeyExists(Hive hive, const SwString& key);
    static bool readRegistryString(Hive hive, const SwString& key, const SwString& name, SwString* value);
    static bool writeRegistryString(Hive hive, const SwString& key, const SwString& name, const SwString& value,
                                    bool expandable, SwString* error);
    static bool writeRegistryDword(Hive hive, const SwString& key, const SwString& name, unsigned int value,
                                   SwString* error);
    static bool deleteRegistryValue(Hive hive, const SwString& key, const SwString& name, SwString* error);
    static bool deleteRegistryTree(Hive hive, const SwString& key, SwString* error);
    /// Deletes @p key when it has neither values nor subkeys, then each empty parent up to @p stopAt.
    static void deleteEmptyRegistryKeys(Hive hive, const SwString& key, const SwString& stopAt);

    /// The persistent environment of the user (machine == false) or of the machine.
    static bool readEnvironment(bool machine, const SwString& name, SwString* value);
    static bool writeEnvironment(bool machine, const SwString& name, const SwString& value, SwString* error);
    static bool deleteEnvironment(bool machine, const SwString& name, SwString* error);
    static void broadcastEnvironmentChange();
    static void notifyFileAssociationsChanged();

    /// Runs @p program and waits for it; @p arguments is a command line tail, quoted as needed.
    static bool runProcess(const SwString& program, const SwString& arguments, const SwString& workingDirectory,
                           bool hidden, long long* exitCode, SwString* error);
    /// Starts @p program through UAC ("runas") and waits for it.
    static bool runElevated(const SwString& program, const SwString& arguments, const SwString& workingDirectory,
                            long long* exitCode, SwString* error);
    static bool launchDetached(const SwString& program, const SwString& arguments, const SwString& workingDirectory,
                               SwString* error);
    /// Removes @p files, then the @p directories that are empty, once the current process has exited.
    static bool deleteAfterExit(const SwList<SwString>& files, const SwList<SwString>& directories);

    /// Free bytes on the volume holding @p path (or its nearest existing parent); -1 when unknown.
    static long long freeDiskSpace(const SwString& path);

    static SwString quoteArgument(const SwString& argument);
    static SwString nativePath(const SwString& path);
};

} // namespace swinstaller
