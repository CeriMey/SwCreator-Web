#pragma once

/**
 * @file src/core/installer/SwSetupBuilder.h
 * @brief Turns installer.json and a built project into one Setup.exe — no compiler involved.
 *
 * The Setup.exe is the setup launcher (SwSetupBootstrap.exe) given the product's icon and version,
 * followed by an archive holding the setup runtime (SwSetupRuntime.exe and the DLLs it needs),
 * installer.json, the page forms and every source file. The launcher and the runtime are looked for
 * next to the running program, in SWSETUP_RUNTIME_DIR, or in the folder given in the options.
 */

#include "../SwStackExport.h"

#include "SwJsonObject.h"
#include "SwList.h"
#include "SwString.h"

#include <atomic>
#include <functional>

namespace swinstaller {

struct SW_INSTALLER_EXPORT SwSetupBuildOptions {
    /// installer.json.
    SwString specPath;
    /// The CMake project; empty: the folder above the one holding installer.json.
    SwString projectDirectory;
    /// The CMake build folder that holds the targets named by "cmake-target" sources.
    SwString buildDirectory;
    /// Debug, Release, ... ; empty: whatever the build folder holds.
    SwString configuration;
    /// Overrides output.file.
    SwString outputPath;
    /// Where SwSetupBootstrap.exe and SwSetupRuntime.exe are; empty: searched.
    SwString runtimeDirectory;
    /// More folders to look for DLLs in (compiler runtime, third-party SDKs).
    SwList<SwString> librarySearchDirectories;
    /// Sign when output.signing is configured.
    bool sign{true};
};

struct SW_INSTALLER_EXPORT SwSetupBuildResult {
    bool ok{false};
    SwString outputPath;
    long long setupBytes{0};
    long long installedBytes{0};
    int fileCount{0};
    bool signedOutput{false};
    double seconds{0.0};
    SwString error;
    SwList<SwString> warnings;
    SwString log;
};

class SW_INSTALLER_EXPORT SwSetupBuilder {
public:
    /// step counts from 1 to stepCount; fraction is the progress inside the step.
    using Progress = std::function<void(int step, int stepCount, const SwString& title, double fraction)>;

    static SwSetupBuildResult build(const SwSetupBuildOptions& options, const Progress& progress = Progress(),
                                    const std::atomic<bool>* cancel = nullptr);

    /// The folder holding SwSetupBootstrap.exe and SwSetupRuntime.exe, or empty.
    static SwString findRuntimeDirectory(const SwString& hint = SwString());

    /// The executable a CMake target produced in @p buildDirectory (CMake File API, then a file search).
    static SwString findTargetExecutable(const SwString& buildDirectory, const SwString& configuration,
                                         const SwString& target, SwString* error = nullptr);
    /// Reads a value from CMakeCache.txt.
    static SwString cmakeCacheValue(const SwString& buildDirectory, const SwString& name);

    /// True when @p relativePath (with '/') matches the glob @p pattern (*, ?, **).
    static bool globMatch(const SwString& pattern, const SwString& relativePath);

    /// The files a source of installer.json contributes, as {relative path in the package -> file on disk}.
    static bool resolveSource(const SwJsonObject& source, const SwSetupBuildOptions& options,
                              SwList<SwString>* relativePaths, SwList<SwString>* files, SwList<SwString>* warnings,
                              SwString* error);

    /// Where the Setup.exe goes, before any override.
    static SwString defaultOutputPath(const SwSetupBuildOptions& options, SwString* error = nullptr);

    /// The path signtool.exe has on this machine, or empty.
    static SwString findSignTool();
};

} // namespace swinstaller
