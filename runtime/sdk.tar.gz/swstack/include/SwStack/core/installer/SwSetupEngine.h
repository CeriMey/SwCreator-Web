#pragma once

/**
 * @file src/core/installer/SwSetupEngine.h
 * @brief Plans and carries out what installer.json describes: install, repair, modify, update and
 * uninstall, for one user or for the whole machine.
 *
 * A plan is plain JSON ({mode, scope, installDir, actions: [...]}) so that a non-elevated setup can
 * hand it to an elevated copy of itself. Execution keeps a backup of every file it replaces and of
 * every registry or environment value it changes, and undoes everything if an action fails or the
 * user cancels. What was installed is recorded in a state file next to a copy of the Setup.exe,
 * which maintenance and uninstallation start from.
 */

#include "../SwStackExport.h"

#include "SwJsonObject.h"
#include "SwList.h"
#include "SwString.h"

#include "core/installer/SwSetupSpec.h"
#include "core/installer/SwSetupVariables.h"

#include <atomic>
#include <functional>

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupEngine {
public:
    enum class Mode {
        Install,
        Repair,
        Modify,
        Uninstall
    };

    using Progress = std::function<void(double fraction, const SwString& title)>;

    SwSetupEngine();
    ~SwSetupEngine();

    void setSpec(const SwSetupSpec& spec);
    const SwSetupSpec& spec() const;

    /// The Setup.exe that holds the archive (and is copied for maintenance).
    void setPackagePath(const SwString& packagePath);
    SwString packagePath() const;

    SwSetupVariables& variables();
    const SwSetupVariables& variables() const;

    /**
     * @brief Fills the variables a setup starts from: known folders, product facts, the existing
     * installation, the declared variables' defaults and the default install folder. Values already
     * set (from the command line, for instance) are kept.
     */
    void prepareVariables(bool silent);
    /// Recomputes InstallDir for the scope in {Scope} unless the user chose a folder.
    void applyScopeDefaults();

    bool isInstalled() const;
    /// The state of the installation found on this machine (empty when none).
    SwJsonObject installedState() const;
    SwString installedScope() const;

    /// Uncompressed bytes the selected components install.
    long long requiredBytes() const;
    /// Uncompressed bytes of one component.
    long long componentBytes(const SwString& componentId) const;

    SwJsonObject plan(Mode mode, SwString* error);
    bool execute(const SwJsonObject& plan, const Progress& progress, const std::atomic<bool>* cancel, SwString* error);

    /// The state recorded by the last successful execute().
    SwJsonObject lastState() const;
    SwString logText() const;
    void appendLog(const SwString& line);

    static SwString modeName(Mode mode);
    static bool parseMode(const SwString& text, Mode* mode);
    static SwString stateDirectory(const SwString& productId, bool machine);
    static SwJsonObject readState(const SwString& productId, bool machine);

    SwSetupEngine(const SwSetupEngine&) = delete;
    SwSetupEngine& operator=(const SwSetupEngine&) = delete;

private:
    struct Data;
    Data* d_;
};

} // namespace swinstaller
