#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/installer/SwInstallerPayload.h
 * @brief Header-only embedded payload manifest and extraction helpers for the Sw installer runtime.
 */

#include "SwByteArray.h"
#include "SwCrypto.h"
#include "SwDir.h"
#include "SwFile.h"
#include "SwFileInfo.h"
#include "SwList.h"
#include "SwString.h"

#include <cstdio>
#include <vector>


namespace swinstaller {

inline SwString swInstallerNormalizePath(SwString path) {
    if (path.isEmpty()) {
        return SwString();
    }
    path = SwDir::normalizePath(path);
    path.replace("\\", "/");
    while (path.startsWith("///?/")) {
        path.remove(0, 1);
    }
    if (path.startsWith("//?/UNC/")) {
        path.remove(0, 8);
        path = "//" + path;
        return path;
    }
    while (path.startsWith("//?/")) {
        path.remove(0, 4);
    }
    while (path.startsWith("/?/")) {
        path.remove(0, 3);
    }
    while (path.startsWith("/") && path.size() > 2 && path[2] == ':') {
        path.remove(0, 1);
    }
    return path;
}

struct SW_INSTALLER_EXPORT SwInstallerEmbeddedChunk {
    const unsigned char* bytes{nullptr};
    long long size{0};
};

struct SW_INSTALLER_EXPORT SwInstallerEmbeddedFile {
    SwString relativePath;
    SwString checksumSha256;
    long long originalSize{0};
    long long storedSize{0};
    bool compressed{false};
    const unsigned char* bytes{nullptr};
    SwList<SwInstallerEmbeddedChunk> chunks;
};

struct SW_INSTALLER_EXPORT SwInstallerEmbeddedPayload {
    SwString payloadId;
    SwString displayName;
    SwList<SwInstallerEmbeddedFile> files;

    const SwInstallerEmbeddedFile* findFile(const SwString& relativePath) const;

private:
    static SwString normalizeRelativePath_(SwString path);
};

class SW_INSTALLER_EXPORT SwInstallerPayload {
public:
    static SwString normalizeRelativePath(SwString path);

    static bool isSafeRelativePath(const SwString& path);

    static SwString joinRootAndRelative(const SwString& root, const SwString& relativePath);

    static bool extractAll(const SwInstallerEmbeddedPayload& payload,
                           const SwString& targetRoot,
                           SwList<SwString>* writtenFiles = nullptr,
                           SwList<SwString>* writtenDirs = nullptr,
                           SwString* errOut = nullptr);

    static bool extractFile(const SwInstallerEmbeddedPayload& payload,
                            const SwString& relativePath,
                            const SwString& targetRoot,
                            SwList<SwString>* writtenDirs = nullptr,
                            SwString* errOut = nullptr);

    static bool extractFile(const SwInstallerEmbeddedFile& file,
                            const SwString& targetRoot,
                            SwList<SwString>* writtenDirs = nullptr,
                            SwString* errOut = nullptr);

    static SwString fileChecksum(const SwInstallerEmbeddedFile& file);

private:
    static void setErr_(SwString* errOut, const SwString& value);

    static void appendUnique_(SwList<SwString>& list, const SwString& value);

    static SwString parentPath_(SwString path);

    static void collectParentDirs_(SwString directoryPath,
                                   const SwString& stopRoot,
                                   SwList<SwString>& writtenDirs);

    static SwString fileChecksum_(const SwString& path);

    static SwString sha256_(const SwByteArray& bytes);

    static bool decodeFile_(const SwInstallerEmbeddedFile& file, SwByteArray& out, SwString* errOut);

    static bool deleteFileQuiet_(const SwString& path);

    static bool replaceFile_(const SwString& tempPath, const SwString& destinationPath, SwString* errOut);
};

} // namespace swinstaller
