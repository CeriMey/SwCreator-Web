#pragma once

/**
 * @file src/core/installer/SwSetupPe.h
 * @brief What the setup builder needs to know about Windows executables: the DLLs they import, the
 * DLLs to ship with them, and their icon.
 */

#include "../SwStackExport.h"

#include "SwList.h"
#include "SwString.h"

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupPe {
public:
    static bool isPortableExecutable(const SwString& path);
    /// The DLL names an executable imports, directly or through delay loading.
    static SwList<SwString> importedLibraries(const SwString& path, SwString* error = nullptr);
    /// True for DLLs Windows provides (System32, API sets) and that must never be shipped.
    static bool isSystemLibrary(const SwString& dllName);
    /// True for the Microsoft C++ runtime DLLs an application may ship next to itself.
    static bool isRedistributableRuntime(const SwString& dllName);

    /**
     * @brief Every DLL @p executable needs that Windows does not provide, followed recursively.
     * @param searchDirectories where to look for them, in order, after the executable's own folder.
     * @param missing receives the names found nowhere.
     * @return absolute paths, the executable not included.
     */
    static SwList<SwString> dependencyClosure(const SwString& executable, const SwList<SwString>& searchDirectories,
                                              SwList<SwString>* missing = nullptr);

    /// The folder of the Visual C++ runtime DLLs to ship app-locally (Visual Studio redist, else System32).
    static SwString visualCppRuntimeDirectory();

    /// Gives @p targetExecutable the icon of @p iconSource (.ico file, or the first icon of an .exe/.dll).
    static bool copyIcon(const SwString& iconSource, const SwString& targetExecutable, SwString* error = nullptr);

    /// Sets the version resource Explorer shows (description, product, version, company).
    static bool setVersionInfo(const SwString& targetExecutable, const SwString& description,
                               const SwString& productName, const SwString& version, const SwString& company,
                               SwString* error = nullptr);
};

} // namespace swinstaller
