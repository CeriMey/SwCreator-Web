#pragma once

/**
 * @file src/core/installer/SwSetupArchive.h
 * @brief Writes and reads the archive appended to a Setup.exe (format: SwSetupArchiveFormat.h).
 *
 * Both sides stream: a file is compressed while it is read and decompressed while it is written, so
 * entry size is bounded by the disk, not by memory. Every entry carries the SHA-256 of its content,
 * checked when it is extracted.
 */

#include "SwSharedData.h"
#include "../SwStackExport.h"

#include "SwByteArray.h"
#include "SwList.h"
#include "SwString.h"

namespace swinstaller {

struct SW_INSTALLER_EXPORT SwSetupArchiveEntry {
    SwString group;
    SwString path;
    long long offset{0};
    long long storedSize{0};
    long long originalSize{0};
    bool compressed{false};
    SwString sha256;
};

class SW_INSTALLER_EXPORT SwSetupArchiveWriter {
public:
    SwSetupArchiveWriter();
    ~SwSetupArchiveWriter();

    /// 0 stores everything raw; 1 is fastest, 9 smallest. Already compressed formats are always stored.
    void setCompressionLevel(int level);
    int compressionLevel() const;

    /// Opens @p executablePath, a launcher copy, to append the archive after its image.
    bool open(const SwString& executablePath, SwString* error);
    bool addFile(const SwString& group, const SwString& path, const SwString& sourceFile, SwString* error);
    bool addData(const SwString& group, const SwString& path, const SwByteArray& data, SwString* error);
    /// Writes the index and the footer, then closes the file.
    bool finish(SwString* error);
    /// Closes without writing the index: the file is left unusable.
    void abort();

    int entryCount() const;
    long long originalBytes() const;
    long long storedBytes() const;
    SwList<SwSetupArchiveEntry> entries() const;

    SwSetupArchiveWriter(const SwSetupArchiveWriter&) = delete;
    SwSetupArchiveWriter& operator=(const SwSetupArchiveWriter&) = delete;

private:
    struct Data;
    Data* d_;
};

class SW_INSTALLER_EXPORT SwSetupArchiveReader {
public:
    SwSetupArchiveReader();
    ~SwSetupArchiveReader();

    bool open(const SwString& path, SwString* error);
    void close();
    bool isOpen() const;
    SwString path() const;

    SwList<SwSetupArchiveEntry> entries() const;
    SwList<SwSetupArchiveEntry> entries(const SwString& group) const;
    bool find(const SwString& group, const SwString& path, SwSetupArchiveEntry* entry) const;
    /// Total uncompressed size of a group.
    long long groupSize(const SwString& group) const;

    /// The content of an entry in memory: for small entries (manifest, forms, license).
    bool read(const SwSetupArchiveEntry& entry, SwByteArray* data, SwString* error) const;
    /// Streams an entry to @p destinationFile through a temporary file, checks its SHA-256, then
    /// replaces the destination.
    bool extract(const SwSetupArchiveEntry& entry, const SwString& destinationFile, SwString* error) const;

    SwSetupArchiveReader(const SwSetupArchiveReader&) = delete;
    SwSetupArchiveReader& operator=(const SwSetupArchiveReader&) = delete;

private:
    struct Data;
    Data* d_;
};

/// SHA-256 of a file, as lowercase hex; empty when the file cannot be read.
SW_INSTALLER_EXPORT SwString swSetupFileSha256(const SwString& path);

} // namespace swinstaller
