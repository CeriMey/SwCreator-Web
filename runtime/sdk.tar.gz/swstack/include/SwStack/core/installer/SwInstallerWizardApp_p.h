#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/installer/SwInstallerWizardApp.h"

struct swinstaller::SwInstallerWizardApp::Data : SwSharedData {
    // The engine is built for the product and the setup's own path.
    Data(const SwInstallerProduct& product, const SwString& setupSelfPath)
        : product_(product), setupSelfPath_(setupSelfPath), engine_(product_, setupSelfPath_) {}

    SwInstallerProduct product_;
    SwString setupSelfPath_;
    SwInstallerEngine engine_;
    SwInstallerPlan activePlan_;
    SwInstallerExecutionResult lastResult_;
    bool installInProgress_{false};
    bool progressTaskPosted_{false};
    SwMap<SwString, SwString> arguments_;
    SwInstallerShellDialog* wizard_{nullptr};
    WelcomePage_* welcomePage_{nullptr};
    TargetPage_* targetPage_{nullptr};
    ComponentsPage_* componentsPage_{nullptr};
    ProgressPage_* progressPage_{nullptr};
    FinishPage_* finishPage_{nullptr};
#if defined(_WIN32)
    SwInstallerWindows::MutexHandle mutexHandle_{};
#endif
};
