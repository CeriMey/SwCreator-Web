#pragma once

/**
 * @file src/core/installer/SwSetupView.h
 * @brief The setup's user interface: one light 780 x 520 surface (title bar, page, footer) driven by
 * a session that holds the package, the engine, the answers and the running installation.
 *
 * The same view runs inside Setup.exe and inside SwCreator's live preview: a session opened on a
 * package installs for real, a session opened on installer.json (preview) shows the same pages with
 * sample sizes and simulates the installation.
 */

#include "../SwStackExport.h"

#include "core/installer/SwSetupEngine.h"
#include "core/installer/SwSetupSpec.h"
#include "core/installer/SwSetupWidgets.h"

#include "SwByteArray.h"
#include "SwJsonArray.h"
#include "SwString.h"
#include "SwWidget.h"

#include <functional>

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupSession : public SwSetupFormContext {
public:
    SwSetupSession();
    ~SwSetupSession() override;

    /// A real setup: installer.json and the UI files come from the package's archive.
    bool openPackage(const SwString& packagePath, bool silent, SwString* error);
    /// A preview: installer.json and forms from disk, nothing is installed.
    void openPreview(const SwSetupSpec& spec);
    bool isPreview() const;

    SwSetupEngine& engine();
    const SwSetupSpec& spec() const;
    SwString packagePath() const;

    /// "install", "maintenance" or "uninstall".
    SwString flow() const;
    void setFlow(const SwString& flow);
    SwJsonArray flowPages() const;
    SwString language() const;
    SwString text(const char* key) const;

    // SwSetupFormContext
    SwColor accent() const override;
    SwString expand(const SwString& text) const override;
    SwString variable(const SwString& name) const override;
    void setVariable(const SwString& name, const SwString& value) override;
    SwList<SwSetupComponentInfo> components() const override;
    void setComponentSelected(const SwString& id, bool selected) override;
    long long requiredBytes() const override;
    SwString installDirectory() const override;
    SwByteArray readFile(const SwString& relativePath) const override;
    SwString licenseText() const override;
    void changed() override;

    /// Called when an answer changes (the view re-checks its buttons).
    void setChangedHandler(std::function<void()> handler);

    /// Starts the installation, repair, modification or removal in the background.
    bool start(SwSetupEngine::Mode mode, SwString* error);
    bool isRunning() const;
    /// True once the background work is over (it then stops running).
    bool poll(double* fraction, SwString* title, SwList<SwString>* newLogLines);
    bool succeeded() const;
    SwString failure() const;
    void cancel();
    SwSetupEngine::Mode runningMode() const;
    bool rebootRequired() const;

    /// Starts the installed product (main executable).
    bool launchProduct(SwString* error);

private:
    struct Data;
    Data* d_;
};

class SW_INSTALLER_EXPORT SwSetupView : public SwWidget {
    SW_OBJECT(SwSetupView, SwWidget)
public:
    explicit SwSetupView(SwSetupSession* session, SwWidget* parent = nullptr);
    ~SwSetupView() override;

    static int defaultWidth() { return 780; }
    static int defaultHeight() { return 520; }

    /// Shows the first page of the session's flow.
    void start();
    /// Shows a page of the flow by its id (preview and snapshots); false when it does not exist.
    bool showPage(const SwString& pageId);
    /// The id of the page on screen.
    SwString currentPageId() const;

    /// True when (x, y) lies on the title bar, outside its buttons: the native window drags from there.
    bool isCaption(int x, int y) const;
    /// Called with the result when the user closes the setup (0 success, 1 failure, 2 cancelled).
    void setFinishedHandler(std::function<void(int exitCode)> handler);
    void setMinimizeHandler(std::function<void()> handler);
    /// Asks to close (title bar button, Alt+F4): refused while work is running.
    void requestClose();

protected:
    void paintEvent(PaintEvent* event) override;
    void resizeEvent(ResizeEvent* event) override;

private:
    struct Data;
    Data* d_;
    friend struct Data;
};

} // namespace swinstaller
