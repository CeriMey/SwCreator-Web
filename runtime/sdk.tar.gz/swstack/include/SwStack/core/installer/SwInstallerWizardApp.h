#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/installer/SwInstallerWizardApp.h
 * @brief Header-only SwWizard facade for the Sw installer runtime.
 */

#include "SwInstaller.h"
#include "SwInstallerShellDialog.h"

#include "SwCheckBox.h"
#include "SwDateTime.h"
#include "SwGuiApplication.h"
#include "SwLabel.h"
#include "SwLineEdit.h"
#include "SwMap.h"
#include "SwMessageBox.h"
#include "SwPathDialog.h"
#include "SwCodeEditor.h"
#include "SwPlainTextEdit.h"
#include "SwThread.h"
#include "SwProgressBar.h"
#include "SwPushButton.h"
#include "SwWidgetSnapshot.h"

namespace swinstaller {

class SW_INSTALLER_EXPORT SwInstallerWizardApp {
public:
    explicit SwInstallerWizardApp(const SwInstallerProduct& product,
                                  const SwString& setupSelfPath = SwInstallerWindows::currentExecutablePath());

    static int run(SwGuiApplication& app,
                   int argc,
                   char* argv[],
                   const SwInstallerProduct& product,
                   SwWidget* parent = nullptr,
                   const SwString& setupSelfPath = SwInstallerWindows::currentExecutablePath());

    static bool saveSnapshots(SwGuiApplication& app,
                              const SwInstallerProduct& product,
                              const SwString& outputDirectory,
                              SwWidget* parent = nullptr,
                              const SwString& setupSelfPath = SwInstallerWindows::currentExecutablePath());

private:
    class WelcomePage_ : public SwWizardPage {
        SW_OBJECT(WelcomePage_, SwWizardPage)
    public:
        WelcomePage_(const SwString& productName, bool installed, SwWidget* parent = nullptr);

    protected:
        void resizeEvent(ResizeEvent* event) override;

    private:
        SwLabel* body_{nullptr};
        SwLabel* details_{nullptr};
    };

    class TargetPage_ : public SwWizardPage {
        SW_OBJECT(TargetPage_, SwWizardPage)
    public:
        explicit TargetPage_(SwWidget* parent = nullptr);
        SwString installRoot() const;
        void setInstallRoot(const SwString& value);

    protected:
        void resizeEvent(ResizeEvent* event) override;

    private:
        SwLabel* label_{nullptr};
        SwLineEdit* edit_{nullptr};
        SwPushButton* browse_{nullptr};
        SwLabel* hint_{nullptr};
    };

    class ComponentsPage_ : public SwWizardPage {
        SW_OBJECT(ComponentsPage_, SwWizardPage)
    public:
        explicit ComponentsPage_(const SwInstallerProduct& product, SwWidget* parent = nullptr);
        SwList<SwString> selectedComponents() const;
        void setSelectedComponents(const SwList<SwString>& ids);

    protected:
        void resizeEvent(ResizeEvent* event) override;

    private:
        SwLabel* intro_{nullptr};
        SwList<SwCheckBox*> checkBoxes_;
        SwList<SwString> componentIds_;
        SwList<SwLabel*> descriptions_;
    };

    class ProgressPage_ : public SwWizardPage {
        SW_OBJECT(ProgressPage_, SwWizardPage)
    public:
        explicit ProgressPage_(SwWidget* parent = nullptr);
        void reset();
        void setStatus(const SwString& value);
        void setProgress(int value);
        void appendLog(const SwString& value);
        void showProgressWidgets();

    protected:
        void resizeEvent(ResizeEvent* event) override;

    private:
        SwLabel* status_{nullptr};
        SwProgressBar* progress_{nullptr};
        SwCodeEditor* log_{nullptr};
    };

    class FinishPage_ : public SwWizardPage {
        SW_OBJECT(FinishPage_, SwWizardPage)
    public:
        explicit FinishPage_(SwWidget* parent = nullptr);
        void setSummary(const SwString& text);
        void setLaunchVisible(bool visible);
        void setLaunchChecked(bool checked);
        bool launchAfterFinish() const;

    protected:
        void resizeEvent(ResizeEvent* event) override;

    private:
        SwLabel* summary_{nullptr};
        SwCheckBox* launch_{nullptr};
    };

    int run_(int argc, char* argv[], SwWidget* parent);
    bool saveSnapshots_(SwGuiApplication& app, const SwString& outputDirectory, SwWidget* parent);
    bool handleExecutePlanMode_(int& exitCode);
    bool acquireSingleInstanceMutex_(SwWidget* parent);
    int runWizard_(SwWidget* parent);
    void onWizardPageChanged_(int currentId);
    void runWizardInstall_();

    int runRepairInteractive_(SwWidget* parent, bool allowPostInstallLaunch);
    int runRepairSilent_(bool allowPostInstallLaunch);
    int runUninstallInteractive_(SwWidget* parent, bool allowPostInstallLaunch);
    int runUninstallSilent_(bool allowPostInstallLaunch);

    bool runPlanWithElevation_(const SwInstallerPlan& plan,
                               bool allowPostInstallLaunch,
                               SwInstallerExecutionResult& result,
                               SwString* errOut);

    static bool writeResultFileIfNeeded_(const SwString& resultPath,
                                         const SwInstallerExecutionResult& result);
    static bool writeTextFile_(const SwString& path, const SwString& text, SwString* errOut);
    static SwString readTextFile_(const SwString& path, SwString* errOut);
    static SwString parentPath_(SwString path);

    SwString temporaryRoot_() const;
    SwString uniqueToken_() const;
    SwList<SwString> defaultSelectedComponents_() const;

    static SwList<SwString> parseCsv_(const SwString& text);
    static SwMap<SwString, SwString> parseArguments_(int argc, char* argv[]);
    static bool parseBool_(SwString value);
    static SwString normalizePath_(SwString path);

    static void styleTitleText_(SwLabel* label, int fontSize, bool accent);
    static void styleBodyText_(SwLabel* label);
    static void styleLineEdit_(SwLineEdit* edit);
    static void styleActionButton_(SwPushButton* button);
    static void styleCheckBox_(SwCheckBox* box);
    static void styleProgress_(SwProgressBar* bar);

public:
    ~SwInstallerWizardApp();
public:
    SwInstallerWizardApp(const SwInstallerWizardApp& other);
    SwInstallerWizardApp& operator=(const SwInstallerWizardApp& other);
private:
    // What the class keeps (SwInstallerWizardApp_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace swinstaller

namespace swinstaller {

} // namespace swinstaller
