#pragma once

/**
 * @file src/core/installer/SwSetupApp.h
 * @brief The setup runtime's entry point: what SwSetupRuntime.exe (and so every Setup.exe) does with
 * its command line.
 *
 *     Setup.exe                         the setup window (install, or maintenance when installed)
 *     Setup.exe --silent                install with no window; exit code 0, 3010 (restart), 1, 2
 *     Setup.exe --uninstall [--silent]  remove the product
 *     Setup.exe --repair | --modify | --maintenance
 *     Setup.exe --scope user|machine --install-dir <dir> --components a,b --set Name=Value ...
 *     Setup.exe --log <file>            write the log there (default: %TEMP%\SwSetup-<product>.log)
 *     SwSetupRuntime.exe --preview <installer.json> [--snapshot <dir>] [--flow install|maintenance|uninstall]
 *
 * The launcher adds --package <Setup.exe> when it starts the runtime.
 */

#include "../SwStackExport.h"

#include "SwList.h"
#include "SwString.h"

namespace swinstaller {

class SW_INSTALLER_EXPORT SwSetupApp {
public:
    static int main(int argc, char** argv);
    static int run(const SwList<SwString>& arguments);
    static SwString usage();

    enum ExitCode {
        Success = 0,
        Failure = 1,
        Cancelled = 2,
        InvalidArguments = 4,
        RestartRequired = 3010
    };
};

} // namespace swinstaller
