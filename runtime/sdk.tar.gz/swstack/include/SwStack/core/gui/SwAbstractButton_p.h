#pragma once

#include "core/gui/SwAbstractButton.h"
#include "core/gui/graphics/SwImage.h"

struct SwAbstractButton::Data {
    SwString m_Text;
    bool m_Text_registered_ = sw_register_Text_();
    bool m_Pressed{false};
    bool m_Pressed_registered_ = sw_register_Pressed_();
    bool m_Checkable{false};
    bool m_Checkable_registered_ = sw_register_Checkable_();
    DrawTextFormats m_Alignment = DrawTextFormats(DrawTextFormat::Center | DrawTextFormat::VCenter | DrawTextFormat::SingleLine);
    bool m_Alignment_registered_ = sw_register_Alignment_();
    bool m_checked{false};
    ContentsMargins m_contentsMargins{};
    SwImage m_icon;
    SwImage m_disabledIcon;
    SwSize m_iconSize{16, 16};
};
