#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwChart.h"

struct SwChart::Data {
    SwString m_title{};
    SwValueAxis* m_axisX{nullptr};
    SwValueAxis* m_axisY{nullptr};
    SwVector<SwAbstractSeries*> m_series{};
};
