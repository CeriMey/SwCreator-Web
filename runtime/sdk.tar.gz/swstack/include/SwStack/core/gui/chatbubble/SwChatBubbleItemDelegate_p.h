#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/chatbubble/SwChatBubbleItemDelegate.h"

struct SwChatBubbleItemDelegate::Data {
    SwChatBubbleTheme m_theme;
    SwChatBubbleColumns m_columns;
    SwImage m_defaultImage;
};
