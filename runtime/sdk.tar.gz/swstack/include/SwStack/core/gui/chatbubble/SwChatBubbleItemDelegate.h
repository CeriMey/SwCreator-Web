#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file
 * @ingroup core_chatbubble
 * @brief Declares item delegates that render model rows as chat bubbles.
 *
 * The delegates in this header translate model data into bubble geometry, spacing,
 * avatar placement, and text layout. The specialized user and bot variants reuse the
 * same rendering contract while applying different alignment and visual defaults.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwStyledItemDelegate.h"

#include "chatbubble/SwChatBubble.h"

struct SW_WIDGETS_EXPORT SwChatBubbleColumns {
    int text{0};
    int role{1};
    int kind{2};
    int meta{3};
    int reaction{4};
};

class SW_WIDGETS_EXPORT SwChatBubbleItemDelegate : public SwStyledItemDelegate {
    SW_OBJECT(SwChatBubbleItemDelegate, SwStyledItemDelegate)

public:
    /**
     * @brief Constructs a `SwChatBubbleItemDelegate` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwChatBubbleItemDelegate(SwObject* parent = nullptr);

    /**
     * @brief Sets the theme.
     * @param theme Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTheme(const SwChatBubbleTheme& theme);
    /**
     * @brief Returns the current theme.
     * @return The current theme.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwChatBubbleTheme& theme() const;

    /**
     * @brief Sets the columns.
     * @param columns Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumns(const SwChatBubbleColumns& columns);
    /**
     * @brief Returns the current columns.
     * @return The current columns.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwChatBubbleColumns columns() const;

    /**
     * @brief Sets the default Image.
     * @param image Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDefaultImage(const SwImage& image);
    /**
     * @brief Returns the current default Image.
     * @return The current default Image.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwImage& defaultImage() const;

    /**
     * @brief Performs the `sizeHint` operation.
     * @param option Value passed to the method.
     * @param index Value passed to the method.
     * @return The requested size Hint.
     */
    SwSize sizeHint(const SwStyleOptionViewItem& option,
                    const SwModelIndex& index) const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param option Value passed to the method.
     * @param index Value passed to the method.
     */
    void paint(SwPainter* painter,
               const SwStyleOptionViewItem& option,
               const SwModelIndex& index) const override;

protected:
    /**
     * @brief Performs the `bubbleRoleForIndex` operation.
     * @param index Value passed to the method.
     * @return The requested bubble Role For Index.
     */
    virtual SwChatBubbleRole bubbleRoleForIndex(const SwModelIndex& index) const;

private:
    SwChatBubbleMessage messageForIndex_(const SwModelIndex& index) const;

public:
    ~SwChatBubbleItemDelegate();
private:
    // What the class keeps (SwChatBubbleItemDelegate_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwChatUserItemDelegate : public SwChatBubbleItemDelegate {
    SW_OBJECT(SwChatUserItemDelegate, SwChatBubbleItemDelegate)

public:
    /**
     * @brief Constructs a `SwChatUserItemDelegate` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwChatUserItemDelegate(SwObject* parent = nullptr);

protected:
    /**
     * @brief Performs the `bubbleRoleForIndex` operation.
     * @param index Value passed to the method.
     * @return The requested bubble Role For Index.
     */
    SwChatBubbleRole bubbleRoleForIndex(const SwModelIndex& index) const override;
};

class SW_WIDGETS_EXPORT SwChatBotItemDelegate : public SwChatBubbleItemDelegate {
    SW_OBJECT(SwChatBotItemDelegate, SwChatBubbleItemDelegate)

public:
    /**
     * @brief Constructs a `SwChatBotItemDelegate` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwChatBotItemDelegate(SwObject* parent = nullptr);

protected:
    /**
     * @brief Performs the `bubbleRoleForIndex` operation.
     * @param index Value passed to the method.
     * @return The requested bubble Role For Index.
     */
    SwChatBubbleRole bubbleRoleForIndex(const SwModelIndex& index) const override;
};
