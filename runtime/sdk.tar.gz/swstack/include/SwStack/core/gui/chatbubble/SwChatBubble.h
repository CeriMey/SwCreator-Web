﻿#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/chatbubble/SwChatBubble.h
 * @ingroup core_chatbubble
 * @brief Declares the public interface exposed by SwChatBubble in the CoreSw chat bubble UI
 * layer.
 *
 * This header belongs to the CoreSw chat bubble UI layer. It contains models, theme data, and
 * delegates used to render conversation-style user interfaces.
 *
 * Within that layer, this file focuses on the chat bubble interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwChatBubble.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * The declarations in this area focus on layout, theme, item presentation, and delegate behavior
 * rather than business logic.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwWidget.h"
#include "SwPainter.h"

#include "SwGuiApplication.h"
#include "SwWidgetPlatformAdapter.h"

#include "graphics/SwFontMetrics.h"
#include "graphics/SwImage.h"

#include "chatbubble/SwChatBubbleTheme.h"
#include "chatbubble/SwChatBubbleTypes.h"

#include <cmath>
#include <vector>

class SW_WIDGETS_EXPORT SwChatBubble final : public SwWidget {
    SW_OBJECT(SwChatBubble, SwWidget)

public:
    /**
     * @brief Performs the `SwChatBubble` operation.
     * @param parent Optional parent object that owns this instance.
     * @return The requested sw Chat Bubble.
     */
    explicit SwChatBubble(SwWidget* parent = nullptr);

    /**
     * @brief Sets the theme.
     * @param theme Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTheme(const SwChatBubbleTheme& theme);

    /**
     * @brief Returns the current theme.
     * @return The current theme.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwChatBubbleTheme& theme() const;

    /**
     * @brief Sets the message.
     * @param message Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMessage(const SwChatBubbleMessage& message);

    /**
     * @brief Returns the current message.
     * @return The current message.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwChatBubbleMessage& message() const;

    /**
     * @brief Sets the text Selectable.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTextSelectable(bool on);

    /**
     * @brief Returns the current text Selectable.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool textSelectable() const;

    /**
     * @brief Returns whether the object reports selected Text.
     * @return `true` when the object reports selected Text; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasSelectedText() const;

    /**
     * @brief Returns the current selected Text.
     * @return The current selected Text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString selectedText() const;

    /**
     * @brief Clears the current object state.
     */
    void clearSelection();

    /**
     * @brief Performs the `selectAll` operation.
     */
    void selectAll();

    /**
     * @brief Sets the selection Range.
     * @param start Value passed to the method.
     * @param end Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSelectionRange(size_t start, size_t end);

    /**
     * @brief Performs the `defaultTheme` operation.
     * @return The requested default Theme.
     */
    static SwChatBubbleTheme defaultTheme();

    /**
     * @brief Performs the `sizeHintForRow` operation.
     * @param rowWidth Value passed to the method.
     * @param msg Value passed to the method.
     * @param theme Value passed to the method.
     * @return The requested size Hint For Row.
     */
    static SwSize sizeHintForRow(int rowWidth, const SwChatBubbleMessage& msg, const SwChatBubbleTheme& theme);

    /**
     * @brief Performs the `paintRow` operation.
     * @param painter Value passed to the method.
     * @param rowRect Value passed to the method.
     * @param msg Value passed to the method.
     * @param theme Value passed to the method.
     * @return The requested paint Row.
     */
    static void paintRow(SwPainter* painter, const SwRect& rowRect, const SwChatBubbleMessage& msg, const SwChatBubbleTheme& theme);

    /**
     * @brief Returns the current size Hint.
     * @return The current size Hint.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSize sizeHint() const override;

protected:
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

private:
    static int clampInt_(int value, int minValue, int maxValue);

    static int estimateWrappedLines_(const SwString& text, int contentW, const SwFontMetrics& fm);

    struct Layout {
        const SwChatBubbleStyle* style{nullptr};
        const SwChatBubbleLayoutConfig* cfg{nullptr};

        bool outgoing{false};

        int padY{0};
        int marginX{0};
        int bubblePadX{0};
        int bubblePadTop{0};
        int bubblePadBottom{0};
        int metaW{0};
        int bubbleW{0};
        int bubbleH{0};
        int lineH{0};

        SwRect bubbleRect{};
        SwRect contentRect{};
    };

    struct SW_WIDGETS_EXPORT WrappedLine {
        size_t start{0};
        size_t len{0};

        /**
         * @brief Constructs a `WrappedLine` instance.
         *
         * @details The instance is initialized and prepared for immediate use.
         */
        WrappedLine();
        /**
         * @brief Constructs a `WrappedLine` instance.
         * @param startValue Value passed to the method.
         * @param lenValue Value passed to the method.
         *
         * @details The instance is initialized and prepared for immediate use.
         */
        WrappedLine(size_t startValue, size_t lenValue);
    };

    static bool pointInRect_(const SwRect& r, int px, int py);

    static Layout computeLayout_(const SwRect& rowRect, const SwChatBubbleMessage& msg, const SwChatBubbleTheme& theme);

    static std::vector<WrappedLine> wrapTextLines_(const SwString& text,
                                                  int contentW,
                                                  const SwWidgetPlatformHandle& handle,
                                                  const SwFont& font);

    size_t indexFromPosition_(const Layout& layout, int px, int py) const;

    void copySelectionToClipboard_() const;

    void paintSelectableTextRow_(SwPainter* painter,
                                const SwRect& rowRect,
                                const SwChatBubbleMessage& msg,
                                const SwChatBubbleTheme& theme);

    static void paintDoubleTick_(SwPainter* painter, int x, int y, const SwColor& color);

    static void paintTail_(SwPainter* painter,
                           const SwRect& bubbleRect,
                           const SwChatBubbleStyle& style,
                           bool outgoing);


public:
    ~SwChatBubble();
private:
    // What the class keeps (SwChatBubble_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

