#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/chatbubble/SwChatBubble.h"

struct SwChatBubble::Data {
    SwChatBubbleTheme m_theme{swChatBubbleWhatsAppTheme()};
    SwChatBubbleMessage m_message;
    bool m_textSelectable{false};
    bool m_selecting{false};
    size_t m_selectionStart{0};
    size_t m_selectionEnd{0};
};
