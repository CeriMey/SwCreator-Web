/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include "core/threeD/Sw3DPathTracer.h"
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <thread>

// Private widget worker. It never calls widgets, application timers, GPU objects or paint.
// The main thread hands it a COW scene snapshot and polls immutable completed images.
class Sw3DProgressiveViewRenderer {
  public:
    struct Result {
        std::uint64_t generation{0},revision{0};
        SwImage image;
        Sw3DPathTracer::Stats stats;
        Sw3DPathTracer::Status status{Sw3DPathTracer::Status::Idle};
        double progress{0};
        bool running{false},timedOut{false};
        std::string error;
    };
    Sw3DProgressiveViewRenderer():worker_([this]{run();}){}
    ~Sw3DProgressiveViewRenderer() {
        {std::lock_guard<std::mutex> lock(mutex_);stopping_=true;cancelLocked();}
        wake_.notify_all();if(worker_.joinable())worker_.join();
    }
    void submit(std::uint64_t generation,std::shared_ptr<Sw3DScene> scene,const Sw3DCamera &camera,
                const Sw3DEnvironmentSettings &environment,const Sw3DPathTracer::Settings &settings,double limitMs,double stepBudgetMs) {
        auto job=std::make_shared<Job>();job->generation=generation;job->scene=std::move(scene);
        job->camera=camera;job->environment=environment;job->settings=settings;job->limitMs=limitMs;job->stepBudgetMs=stepBudgetMs;
        {std::lock_guard<std::mutex> lock(mutex_);cancelLocked();queued_=job;result_=Result{};result_.generation=generation;result_.running=true;}
        wake_.notify_all();
    }
    void cancel() {
        {std::lock_guard<std::mutex> lock(mutex_);cancelLocked();queued_.reset();result_.running=false;}
        wake_.notify_all();
    }
    // Between two steps the worker waits while paused; the paused time is not part of the budget.
    void setPaused(bool paused) {
        {std::lock_guard<std::mutex> lock(mutex_);paused_=paused;}
        wake_.notify_all();
    }
    Result result() const {std::lock_guard<std::mutex> lock(mutex_);return result_;}
  private:
    struct Job {
        std::uint64_t generation{0};
        std::shared_ptr<Sw3DScene> scene;
        Sw3DCamera camera;
        Sw3DEnvironmentSettings environment;
        Sw3DPathTracer::Settings settings;
        double limitMs{5000};
        double stepBudgetMs{20};
        Sw3DPathTracer tracer;
    };
    mutable std::mutex mutex_;
    std::condition_variable wake_;
    bool stopping_{false},paused_{false};
    std::shared_ptr<Job> queued_,active_;
    Result result_;
    std::thread worker_;
    void cancelLocked() {if(active_)active_->tracer.cancel();if(queued_)queued_->tracer.cancel();}
    void publish(const std::shared_ptr<Job> &job,bool running,bool timedOut=false) {
        Result value;value.generation=job->generation;value.image=job->tracer.image();value.stats=job->tracer.stats();
        value.status=job->tracer.status();value.progress=job->tracer.progress();value.running=running;value.timedOut=timedOut;value.error=job->tracer.lastError();
        if(timedOut && value.error.empty())
            value.error="Progressive preview reached its "+std::to_string(int(job->limitMs))+" ms budget ("+
                std::to_string(value.stats.completedSamples)+"/"+std::to_string(value.stats.requestedSamples)+" samples per pixel).";
        std::lock_guard<std::mutex> lock(mutex_);
        if(active_==job && !queued_ && result_.generation==job->generation) {value.revision=result_.revision+1;result_=std::move(value);}
    }
    void run() {
        for (;;) {
            std::shared_ptr<Job> job;
            {std::unique_lock<std::mutex> lock(mutex_);wake_.wait(lock,[this]{return stopping_ || queued_;});
             if(stopping_)return;
             job=std::move(queued_);active_=job;}
            try {
                const auto began=std::chrono::steady_clock::now();
                double pausedMs=0;
                if(job->tracer.prepare(*job->scene,job->camera,job->environment,job->settings)) {
                    for (;;) {
                        const auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-began).count()-pausedMs;
                        if(elapsed>=job->limitMs) {job->tracer.cancel();job->tracer.renderStep(1);publish(job,false,true);break;}
                        const auto status=job->tracer.renderStep(std::min(job->stepBudgetMs,job->limitMs-elapsed));
                        const bool running=status==Sw3DPathTracer::Status::Ready || status==Sw3DPathTracer::Status::Rendering;
                        publish(job,running);if(!running)break;
                        std::unique_lock<std::mutex> lock(mutex_);
                        wake_.wait_for(lock,std::chrono::milliseconds(10),[this,job]{return stopping_ || queued_ || active_!=job || !result_.running;});
                        if(stopping_)return;
                        if(queued_ || active_!=job || !result_.running) {job->tracer.cancel();break;}
                        if(paused_) {
                            const auto held=std::chrono::steady_clock::now();
                            wake_.wait(lock,[this,job]{return stopping_ || queued_ || active_!=job || !result_.running || !paused_;});
                            pausedMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-held).count();
                            if(stopping_)return;
                            if(queued_ || active_!=job || !result_.running) {job->tracer.cancel();break;}
                        }
                    }
                } else publish(job,false);
            } catch(const std::exception &exception) {
                std::lock_guard<std::mutex> lock(mutex_);
                if(result_.generation==job->generation) {result_.running=false;result_.error=exception.what();++result_.revision;}
            } catch(...) {
                std::lock_guard<std::mutex> lock(mutex_);
                if(result_.generation==job->generation) {result_.running=false;result_.error="Progressive preview failed.";++result_.revision;}
            }
            {std::lock_guard<std::mutex> lock(mutex_);if(active_==job)active_.reset();}
        }
    }
};
