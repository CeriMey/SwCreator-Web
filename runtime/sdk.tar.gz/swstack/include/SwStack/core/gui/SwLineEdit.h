﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwLineEdit.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwLineEdit in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the line edit interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwLineEdit.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


#include "SwFrame.h"
#include "Sw.h"
#include "SwGuiApplication.h"
#include "SwVector.h"
#include "graphics/SwFontMetrics.h"
#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdlib>
#include <cwctype>
#include <limits>
#include <sstream>
#include "SwTimer.h"

// echo mode â—â—â—â—â—â—â—â—â—â—
class SW_WIDGETS_EXPORT SwLineEdit : public SwFrame {

    SW_OBJECT(SwLineEdit, SwFrame)

    SW_PROPERTY_D(SwString, Text);
private:
protected:


    SW_PROPERTY_D(SwString, DisplayText);
private:
protected:


    SW_PROPERTY_D(EchoModeEnum, EchoMode);
private:
protected:

    SW_PROPERTY_D(SwString, Placeholder);
private:
protected:

    SW_PROPERTY_D(bool, ReadOnly);
private:
protected:

public:
    /**
     * @brief Constructs a `SwLineEdit` instance.
     * @param placeholderText Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param false Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    // No default for the text: with one, SwLineEdit() would match both constructors, which an
    // exported class cannot have (MSVC generates its default constructor).
    SwLineEdit(const SwString& placeholderText, SwWidget* parent = nullptr);

    /**
     * @brief Constructs a `SwLineEdit` instance.
     * @param parent Optional parent object that owns this instance.
     * @param false Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwLineEdit(SwWidget* parent = nullptr);

    /**
     * @brief Destroys the `SwLineEdit` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwLineEdit() override;

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    void selectAll();

    void selectAllFromStart();

    /// Undoes the last edit made from the keyboard, as QLineEdit::undo(); setText() forgets them.
    void undo();

    /// Redoes the last edit undone, as QLineEdit::redo().
    void redo();

    bool isUndoAvailable() const;

    bool isRedoAvailable() const;


    // RedÃ©finir la mÃ©thode paintEvent pour dessiner le champ de texte
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested paint Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void paintEvent(PaintEvent* event) override;
    // GÃ©rer les Ã©vÃ©nements de pression de touche
    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested key Press Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void keyPressEvent(KeyEvent* event) override;

    // GÃ©rer le clic de souris pour le focus et le positionnement du curseur
    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested mouse Press Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Double Click Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested mouse Double Click Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mouseDoubleClickEvent(MouseEvent* event) override;

    // GÃ©rer la sÃ©lection avec la souris
    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested mouse Move Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mouseMoveEvent(MouseEvent* event) override;

    // Terminer la sÃ©lection Ã  la libÃ©ration de la souris
    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested mouse Release Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mouseReleaseEvent(MouseEvent* event) override;

signals:
    /** Emitted when Return/Enter is pressed while the line edit has focus. */
    SW_SIGNAL_VOID(returnPressed);

private:

    static constexpr long long kTripleClickIntervalMs_ = 500;
    static constexpr int kTripleClickDistancePx_ = 6;

    static bool isUtf8ContinuationByte_(unsigned char byte);

    struct Utf8CodePoint_ {
        size_t start{0};
        size_t end{0};
        char32_t value{0};
    };

    static size_t clampUtf8Boundary_(const SwString& text, size_t offset);

    static size_t nextUtf8Boundary_(const SwString& text, size_t offset);

    static size_t previousUtf8Boundary_(const SwString& text, size_t offset);

    static char32_t decodeUtf8CodePoint_(const std::string& utf8, size_t start, size_t end);

    static bool isWordCodePoint_(char32_t codePoint);

    static SwVector<Utf8CodePoint_> utf8CodePoints_(const SwString& text);

    static SwString utf8FromWideChar_(wchar_t wc);

    SwPlatformIntegration* currentPlatformIntegration() const;

    struct Padding {
        int top{0};
        int right{0};
        int bottom{0};
        int left{5};
    };

    // Obtenir l'index du caractÃ¨re Ã  une position x
    size_t getCharacterIndexAtPosition(int xPos);
    // Supprimer la sÃ©lection
    void deleteSelection();

    // Copier la sÃ©lection dans le presse-papiers
    void copySelectionToClipboard();

    // Coller depuis le presse-papiers
    void pasteFromClipboard();

    void clearSelection_();

    void selectAllText_();

    void rememberDoubleClick_(const MouseEvent* event);

    void resetPendingMultiClick_();

    bool isTripleClickPress_(const MouseEvent* event) const;

    void selectWordAtCursor_();

    Padding resolvePadding();

    Padding parsePaddingShorthand(const SwString& value, Padding current);

    Padding intrinsicPadding_() const;

    bool hasExplicitPaddingProperty_(StyleSheet* sheet, unsigned int stateFlags, const SwString& propertyName) const;

    int resolvedBorderWidth() const;

    SwRect contentRect(const Padding& padding) const;

    int textAreaWidth(const Padding& padding) const;

    void ensureCursorVisible(const SwString& textToDraw, int areaWidth);
private:
    // What the class keeps (SwLineEdit_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
