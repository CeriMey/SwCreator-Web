#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextEdit.h"
#include "core/gui/graphics/SwTextGeometry_p.h"
#include "core/gui/graphics/SwTextLayout_p.h"

struct SwTextEdit::Data {
    mutable swTextLayout::LineCache m_lineGeometry;
    std::shared_ptr<const swTextLayout::FormattedLine> lineGeometry(
        int index, const SwWidgetPlatformHandle& handle, size_t lineStart,
        const SwString& text, const SwFont& font, bool enabled) const {
        SwList<SwTextLayoutFormatRange> formats;
        const size_t lineEnd = lineStart + text.size();
        size_t position = 0;
        for (const auto& run : m_runs) {
            const size_t end = position + run.text.size();
            if (position >= lineEnd) break;
            if (end > lineStart) {
                const auto& source = run.format;
                SwTextCharFormat format;
                if (source.bold) format.setFontWeight(Bold);
                if (source.italic) format.setFontItalic(true);
                if (source.underline) format.setFontUnderline(true);
                if (source.fontSize > 0) format.setFontPointSize(source.fontSize);
                if (!source.fontFamily.empty()) format.setFontFamily(SwString(source.fontFamily));
                if (!source.href.empty()) format.setAnchorHref(SwString(source.href));
                if (enabled) {
                    if (source.hasColor) format.setForeground(source.color);
                    if (source.hasBgColor) format.setBackground(source.bgColor);
                    if (source.strikethrough) format.setFontStrikeOut(true);
                }
                SwTextLayoutFormatRange range;
                range.start = static_cast<int>((std::max)(position, lineStart) - lineStart);
                range.length = static_cast<int>((std::min)(end, lineEnd) - lineStart) - range.start;
                range.format = format;
                formats.append(range);
            }
            position = end;
        }
        return m_lineGeometry.get(index, handle, text, font, formats);
    }
    mutable swTextGeometry::FontMetricsCache m_fontMetrics;
    int fontHeight(const SwFont& font) const { return m_fontMetrics.height(font); }
    mutable std::vector<Run> m_runs;
    std::vector<LineFormat> m_lineFormats;
    std::vector<EmbeddedTable> m_tables;
};
