#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextEdit.h"

struct SwTextEdit::Data {
    mutable std::vector<Run> m_runs;
    std::vector<LineFormat> m_lineFormats;
    std::vector<EmbeddedTable> m_tables;
};
