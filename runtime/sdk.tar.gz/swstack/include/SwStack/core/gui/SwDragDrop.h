/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwDragDrop.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwDragDrop in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the drag drop interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwDragDrop.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwDragDrop - small internal drag visual helper.
 *
 * Goal:
 * - Provide a lightweight "drag pixmap / + badge" feedback for in-app drags (palette, views, etc.).
 * - No OS drag&drop; purely visual and driven by mouse events.
 **************************************************************************************************/

#include "SwGuiApplication.h"
#include "SwPainter.h"
#include "SwString.h"
#include "SwWidgetPlatformAdapter.h"

#include <algorithm>
#include <functional>

class SW_GUI_EXPORT SwDragDrop {
public:
    // Own captured values in paint: the callback is retained until end().
    struct Preview {
        std::function<void(SwPainter*, const SwRect&)> paint;
        SwPlatformSize size{64, 40};
    };

    /**
     * @brief Returns the current instance.
     * @return The current instance.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwDragDrop& instance();

    /**
     * @brief Returns whether the object reports active.
     * @return `true` when the object reports active; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isActive() const;
    /**
     * @brief Returns the current drop Allowed.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dropAllowed() const;

    /**
     * @brief Performs the `begin` operation.
     * @param windowHandle Value passed to the method.
     * @param text Value passed to the method.
     * @param font Font value used by the operation.
     * @param globalX Value passed to the method.
     * @param globalY Value passed to the method.
     * @param showPlus Value passed to the method.
     * @param dropAllowed Value passed to the method.
     */
    void begin(const SwWidgetPlatformHandle& windowHandle,
               const SwString& text,
               const SwFont& font,
               int globalX,
               int globalY,
               bool showPlus = true,
               bool dropAllowed = true);

    void begin(const SwWidgetPlatformHandle& windowHandle,
               const SwString& text,
               const SwFont& font,
               int globalX,
               int globalY,
               bool showPlus,
               bool dropAllowed,
               const Preview& preview);

    // Also usable for an OS drag image without changing the active in-app drag.
    static void paintVisual(SwPainter* painter,
                            const SwRect& rect,
                            const SwString& text,
                            const SwFont& font,
                            const Preview& preview,
                            bool showPlus = true,
                            bool dropAllowed = true);

    /**
     * @brief Sets the drop Allowed.
     * @param allowed Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDropAllowed(bool allowed);

    /**
     * @brief Updates the position managed by the object.
     * @param globalX Value passed to the method.
     * @param globalY Value passed to the method.
     */
    void updatePosition(int globalX, int globalY);

    /**
     * @brief Performs the `end` operation.
     */
    void end();

    /**
     * @brief Performs the `paintOverlay` operation.
     * @param painter Value passed to the method.
     */
    void paintOverlay(SwPainter* painter) const;

private:
    SwDragDrop();

    static SwRect unionRect_(const SwRect& a, const SwRect& b);

    int textWidthPx_(const SwString& text) const;

    SwRect overlayRect_(int globalX, int globalY) const;

    SwRect clampToClient_(const SwRect& rect) const;

    void invalidate_(const SwRect& rect) const;

public:
    ~SwDragDrop();
public:
    SwDragDrop(const SwDragDrop& other);
    SwDragDrop& operator=(const SwDragDrop& other);
private:
    // What the class keeps (SwDragDrop_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
