﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwDialog.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwDialog in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the dialog interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwDialog.
 *
 * Dialog-oriented declarations here usually describe a bounded modal interaction: configuration
 * enters through setters or constructor state, the user edits the state through child widgets,
 * and the caller retrieves the accepted result through the public API.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwDialog - dialog widget.
 *
 * Focus:
 * - Native top-level window by default on Windows.
 * - Optional in-client modal overlay (snapshot-friendly, cross-platform-ready).
 * - Basic title + content area + button row.
 **************************************************************************************************/

#include "SwFrame.h"
#include "SwGuiApplication.h"
#include "SwLabel.h"
#include "SwPushButton.h"
#include "SwTimer.h"
#include "SwWidgetPlatformAdapter.h"
#include "SwDragDrop.h"
#include "SwToolTip.h"
#include "SwShortcut.h"

#include "core/object/SwPointer.h"
#include "core/runtime/SwCoreApplication.h"
#include "core/runtime/SwEventLoop.h"
#include "platform/SwPlatformTarget.h"

#include <algorithm>
#include <memory>
#include <utility>


class SW_WIDGETS_EXPORT SwDialog : public SwFrame {
    SW_OBJECT(SwDialog, SwFrame)

public:
    enum DialogCode {
        Rejected = 0,
        Accepted = 1
    };

    /**
     * @brief Constructs a `SwDialog` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwDialog(SwWidget* parent = nullptr);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const SwString& title);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const std::wstring& title);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const wchar_t* title);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const char* title);

    /**
     * @brief Returns the current window Title.
     * @return The current window Title.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString windowTitle() const;

#if defined(_WIN32)
    /**
     * @brief Sets the native Window Icon.
     * @param hIcon Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setNativeWindowIcon(HICON hIcon);
#endif

    /**
     * @brief Sets the modal.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setModal(bool on);
    /**
     * @brief Returns whether the object reports modal.
     * @return `true` when the object reports modal; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isModal() const;

    /** Embedded dialogs can dismiss on an outside press; the press is consumed. Default: false. */
    void setDismissOnOutsideClick(bool on);
    bool dismissOnOutsideClick() const;
    /** Hide an unused button bar and let the content occupy its space. */
    void setButtonBarVisible(bool visible);

    /** Application-owned presentation, applied after controls are built and before open().
     * Runs on the GUI thread for both native and embedded dialogs, including factory dialogs.
     * An empty handler disables application presentation for subsequent openings.
     */
    static void setApplicationPresentationHandler(std::function<void(SwDialog&)> handler);
    /** Scrim behind overlay dialogs. With @p opacity below 1 the window stays visible under it,
     * dimmed by @p color; 1 (the default) keeps the opaque overlay of the dialog's style sheet.
     */
    static void setApplicationModalScrim(const SwColor& color, double opacity);
    void setHeaderVisible(bool visible);
    /** Configure chrome without changing child content geometry. Defaults remain 18/44/56. */
    void setLayoutMetrics(int margin, int headerHeight, int footerHeight, bool fullWidthFooter = false);
    /** Preserve a fixed form in a scrollable viewport when the dialog is made smaller. */
    void setContentScrollable(bool enabled);
    bool isContentScrollable() const;

    /**
     * @brief Sets the use Native Window.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setUseNativeWindow(bool on);
    /**
     * @brief Returns the current use Native Window.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool useNativeWindow() const;

    /** Enable user resizing of the native tool window. Set before its first open(). */
    void setNativeWindowResizable(bool on);
    bool nativeWindowResizable() const;

    void setFrameless(bool on);
    bool isFrameless() const;

    // A non-modal tool stays associated with its owner and has no taskbar entry.
    void setToolWindow(bool on);
    bool isToolWindow() const;
    // Lets a custom panel provide its own title, borders and buttons.
    void setContentOnly(bool on);
    bool isContentOnly() const;
    void moveNativeWindow(const SwPoint& position);
    void resizeNativeWindow(const SwSize& size);
    void activateNativeWindow();
    // Configure passive, translucent overlays before open(). Opacity is 0..255.
    void setInputTransparent(bool on);
    /// Whether the window lets the pointer through to what is below it.
    bool isInputTransparent() const;
    void setWindowOpacity(unsigned char opacity);

    /**
     * @brief Returns the current content Widget.
     * @return The current content Widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* contentWidget() const;
    /**
     * @brief Returns the current button Bar Widget.
     * @return The current button Bar Widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* buttonBarWidget() const;

    /**
     * @brief Returns the current result.
     * @return The current result.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int result() const;

    /**
     * @brief Opens the underlying resource managed by the object.
     *
     * @details The call affects the runtime state associated with the underlying resource or service.
     */
    void open();

    /**
     * @brief Returns the current exec.
     * @return The current exec.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual int exec();

    /**
     * @brief Performs the `done` operation.
     * @param code Value passed to the method.
     */
    void done(int code);

    /**
     * @brief Performs the `accept` operation.
     * @param Accepted Value passed to the method.
     */
    void accept();
    /**
     * @brief Performs the `reject` operation.
     * @param Rejected Value passed to the method.
     */
    void reject();

signals:
    SW_SIGNAL_VOID(shown);
    SW_SIGNAL(finished, int);
    SW_SIGNAL_VOID(accepted);
    SW_SIGNAL_VOID(rejected);

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

private:
#if defined(_WIN32)
    static constexpr const wchar_t* nativeDialogWindowClassName() { return L"SwDialogWindowClass"; }

    static void ensureNativeDialogWindowClassRegistered();

    static LRESULT __stdcall nativeDialogWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

    void openNativeWindow();

    void closeNativeWindow();

    void nativeOnPaint(HDC hdc, const RECT& rect);

    void nativeOnResize(int width, int height);

    static void centerNativeWindow(HWND dialogHwnd, HWND owner, int windowW, int windowH);

    void postGuardedNativeEvent_(std::function<void(SwDialog*)> fn);

    void nativePostMousePress(int x, int y, SwMouseButton button, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativePostMouseDoubleClick(int x, int y, SwMouseButton button, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativePostMouseRelease(int x, int y, SwMouseButton button, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativePostMouseMove(int x, int y, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativePostMouseLeave();

    void nativePostMouseWheel(int x, int y, int delta, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativePostKeyPress(int keyCode,
                            bool ctrlPressed,
                            bool shiftPressed,
                            bool altPressed,
                            wchar_t textChar = L'\0',
                            bool textProvided = false);

    void nativePostKeyRelease(int keyCode,
                              bool ctrlPressed,
                              bool shiftPressed,
                              bool altPressed);

    void nativePostCloseRequested();

    void nativeDispatchMousePress(int x, int y, SwMouseButton button, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativeDispatchMouseDoubleClick(int x,
                                        int y,
                                        SwMouseButton button,
                                        bool ctrlPressed,
                                        bool shiftPressed,
                                        bool altPressed);

    void nativeDispatchMouseRelease(int x,
                                    int y,
                                    SwMouseButton button,
                                    bool ctrlPressed,
                                    bool shiftPressed,
                                    bool altPressed);

    void nativeDispatchMouseMove(int x, int y, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativeDispatchMouseWheel(int x, int y, int delta, bool ctrlPressed, bool shiftPressed, bool altPressed);

    void nativeDispatchKeyPress(int keyCode,
                                bool ctrlPressed,
                                bool shiftPressed,
                                bool altPressed,
                                wchar_t textChar = L'\0',
                                bool textProvided = false);

    void nativeDispatchKeyRelease(int keyCode,
                                  bool ctrlPressed,
                                  bool shiftPressed,
                                  bool altPressed);
#endif

#if SW_PLATFORM_X11
    void openNativeWindowX11();

    void closeNativeWindowX11();

    void x11HandlePaintRequest();

    void x11PostEvent(std::function<void(SwDialog*)> fn);
#endif

    template<typename PaintDispatch>
    void paintPlatformSurface_(SwPlatformIntegration* integration,
                               const SwPlatformPaintEvent& baseEvent,
                               const SwWidgetPlatformHandle& handle,
                               int surfaceWidth,
                               int surfaceHeight,
                               bool clearBackground,
                               bool paintOverlay,
                               PaintDispatch&& dispatch) {
        if (!integration || surfaceWidth <= 0 || surfaceHeight <= 0) {
            return;
        }

        SwPlatformPaintEvent resolvedEvent = SwResolvePlatformPaintEvent(baseEvent,
                                                                         SwPlatformSize{surfaceWidth, surfaceHeight},
                                                                         baseEvent.nativePaintDevice
                                                                             ? baseEvent.nativePaintDevice
                                                                             : handle.nativeHandle,
                                                                         handle.nativeHandle,
                                                                         handle.nativeDisplay);
        SwScopedPlatformPainter painter(integration, resolvedEvent);
        if (!painter) {
            return;
        }

        SwRect dirtyRect{resolvedEvent.dirtyRect.x,
                         resolvedEvent.dirtyRect.y,
                         resolvedEvent.dirtyRect.width,
                         resolvedEvent.dirtyRect.height};
        if (dirtyRect.width <= 0 || dirtyRect.height <= 0) {
            dirtyRect = SwRect{0, 0, surfaceWidth, surfaceHeight};
        } else {
            dirtyRect.x = std::max(0, dirtyRect.x);
            dirtyRect.y = std::max(0, dirtyRect.y);
            dirtyRect.width = std::max(0, std::min(surfaceWidth - dirtyRect.x, dirtyRect.width));
            dirtyRect.height = std::max(0, std::min(surfaceHeight - dirtyRect.y, dirtyRect.height));
            if (dirtyRect.width <= 0 || dirtyRect.height <= 0) {
                dirtyRect = SwRect{0, 0, surfaceWidth, surfaceHeight};
            }
        }

        painter->pushClipRect(dirtyRect);

        if (clearBackground) {
            painter->clear(SwColor{241, 245, 249});
        }

        PaintEvent paintEvent(painter.asPainter(), dirtyRect);
        dispatch(paintEvent);

        if (paintOverlay) {
            SwDragDrop::instance().paintOverlay(painter.asPainter());
        }

        painter->popClipRect();

        painter->finalize();
        painter->flush();
    }

    static std::string toUtf8_(const SwString& value);

    void postOrRunNativeEvent_(std::function<void(SwDialog*)> fn);

    SwWindowCallbacks nativePlatformCallbacks_();

    SwPlatformSize implicitMinimumClientSize_() const;

    void openNativePlatformWindow_();

    void closeNativePlatformWindow_();

    void centerNativePlatformWindow_(const SwWidgetPlatformHandle& ownerHandle);

    void handleNativePaintRequest_(const SwPlatformPaintEvent& event);

    void dispatchNativeMousePress_(const SwMouseEvent& evt);

    void dispatchNativeMouseDoubleClick_(const SwMouseEvent& evt);

    void dispatchNativeMouseRelease_(const SwMouseEvent& evt);

    void dispatchNativeMouseMove_(const SwMouseEvent& evt);

    void dispatchNativeMouseLeave_();

    void dispatchNativeMouseWheel_(const SwMouseEvent& evt);

    void dispatchNativeKeyPress_(const SwKeyEvent& evt);

    void dispatchNativeKeyRelease_(const SwKeyEvent& evt);

    class SW_WIDGETS_EXPORT ModalOverlay final : public SwWidget {
        SW_OBJECT(ModalOverlay, SwWidget)

    public:
        /**
         * @brief Performs the `ModalOverlay` operation.
         * @param owner Value passed to the method.
         * @param root Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @param root Value passed to the method.
         */
        ModalOverlay(SwDialog* owner, SwWidget* root, SwWidget* parent = nullptr);

        /**
         * @brief Handles the mouse Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mousePressEvent(MouseEvent* event) override;

        /**
         * @brief Handles the key Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void keyPressEvent(KeyEvent* event) override;

        // Draws the application scrim (setApplicationModalScrim) under the dialog (1.x reimplementation).
        void paintEvent(PaintEvent* event) override;

    private:
        SwDialog* m_owner{nullptr};
        SwWidget* m_root{nullptr};
    };

    static SwWidget* findRootWidget(SwObject* start);

    enum class Presentation {
        Embedded,
        Overlay,
        NativeWindow
    };

    void initDefaults();

    void buildChildren();

    void updateLayout();

    void ensureOverlay();

    void centerInRoot();

    void capturePreviousFocusForActivation_();

    void activateDialogFocus_();

    void restorePreviousFocusAfterClose_();

    void restorePresentationParent();

#if SW_PLATFORM_WIN32 || SW_PLATFORM_X11
#else
    bool m_useNativeWindow{false};
#endif

public:
    ~SwDialog();
private:
    // What the class keeps (SwDialog_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

