#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwJsonSyntaxTheme {
    SwTextCharFormat keyFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat boolNullFormat;
    SwTextCharFormat bracketFormat;
    SwTextCharFormat colonFormat;
};

inline SwTextCharFormat swJsonMakeFormat_(const SwColor& color,
                                           FontWeight weight = Normal,
                                           bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwJsonSyntaxTheme swJsonSyntaxThemeVsCodeDark() {
    SwJsonSyntaxTheme theme;
    theme.keyFormat      = swJsonMakeFormat_(SwColor{156, 220, 254});
    theme.stringFormat   = swJsonMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat   = swJsonMakeFormat_(SwColor{181, 206, 168});
    theme.boolNullFormat = swJsonMakeFormat_(SwColor{86, 156, 214});
    theme.bracketFormat  = swJsonMakeFormat_(SwColor{212, 212, 212});
    theme.colonFormat    = swJsonMakeFormat_(SwColor{212, 212, 212});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwJsonSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwJsonSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwJsonSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwJsonSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    static bool isWordStart_(char ch);

    static bool isWordChar_(char ch);

public:
    ~SwJsonSyntaxHighlighter();
private:
    // What the class keeps (SwJsonSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
