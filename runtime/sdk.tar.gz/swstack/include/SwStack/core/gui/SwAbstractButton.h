#pragma once

#include <memory>
#include "../SwStackExport.h"
#include "SwWidget.h"

class SwImage;

// Common button state and content layout. Concrete buttons provide their own appearance
// and retain their existing clicked signal signatures.
class SW_WIDGETS_EXPORT SwAbstractButton : public SwWidget {
    SW_OBJECT(SwAbstractButton, SwWidget)

    SW_PROPERTY_D(SwString, Text);
private:
protected:
    SW_PROPERTY_D(bool, Pressed);
private:
protected:
    SW_PROPERTY_D(bool, Checkable);
private:
protected:
    SW_PROPERTY_D(DrawTextFormats, Alignment);
private:
protected:

public:
    struct ContentsMargins {
        int left{0};
        int top{0};
        int right{0};
        int bottom{0};
    };

    explicit SwAbstractButton(const SwString& text = {}, SwWidget* parent = nullptr);
    ~SwAbstractButton() override;

    bool isCheckable() const;
    void setChecked(bool checked);
    bool isChecked() const;
    void toggle();

    void setIcon(const SwImage& icon);
    const SwImage& icon() const;
    void setIconSize(const SwSize& size);
    SwSize iconSize() const;

    // Insets around the content, added to stylesheet padding before alignment.
    void setContentsMargins(int left, int top, int right, int bottom);
    ContentsMargins contentsMargins() const;

    SW_SIGNAL(toggled, bool);

protected:
    SwSize buttonLabelSize_(const SwFont& font, bool iconOnly) const;
    StyleSheet::BoxEdges resolveStyledPadding(unsigned int stateFlags) const override;
    WidgetState buttonState() const;
    void mousePressEvent(MouseEvent* event) override;
    void mouseReleaseEvent(MouseEvent* event) override;
    void paintEvent(PaintEvent* event) override = 0;

    virtual void emitClicked_() = 0;
    virtual bool toggleBeforeClicked_() const { return false; }

private:
    friend class SwStyle;
    SwSize fittedIconSize_() const;
    void drawButtonLabel_(SwPainter* painter, const SwRect& contentRect,
                          const SwFont& font, const SwColor& textColor,
                          DrawTextFormats alignment, bool iconOnly) const;
    void invalidateButtonGeometry_();
    struct Data;
    SwObjectDataPointer<Data> d_;
};
