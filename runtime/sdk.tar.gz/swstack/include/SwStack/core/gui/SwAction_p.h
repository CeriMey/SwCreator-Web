#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwAction.h"

struct SwAction::Data {
    SwString m_Text = SwString();
    bool m_Text_registered_ = sw_register_Text_();
    bool m_Enabled = true;
    bool m_Enabled_registered_ = sw_register_Enabled_();
    bool m_Checkable = false;
    bool m_Checkable_registered_ = sw_register_Checkable_();
    bool m_Checked = false;
    bool m_Checked_registered_ = sw_register_Checked_();
    bool m_Separator = false;
    bool m_Separator_registered_ = sw_register_Separator_();
    // Icons are stored by value; submenus are owned by the SwObject tree.
    SwImage m_icon;
    SwMenu* m_menu{nullptr};
};
