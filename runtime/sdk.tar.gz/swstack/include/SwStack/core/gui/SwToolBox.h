﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwToolBox.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwToolBox in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the tool box interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwToolBox.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwFrame.h"
#include "SwToolButton.h"
#include "SwVector.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwToolBox : public SwFrame {
    SW_OBJECT(SwToolBox, SwFrame)

public:
    /**
     * @brief Constructs a `SwToolBox` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwToolBox(SwWidget* parent = nullptr);

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const;

    /**
     * @brief Sets the content Based Layout.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setContentBasedLayout(bool on);

    /**
     * @brief Returns the current content Based Layout.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool contentBasedLayout() const;

    /**
     * @brief Performs the `contentHeightHint` operation.
     * @return The requested content Height Hint.
     */
    int contentHeightHint() const;

    /**
     * @brief Performs the `refreshLayout` operation.
     */
    void refreshLayout();

    /**
     * @brief Sets the header Style Sheet.
     * @param styleSheet Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeaderStyleSheet(const SwString& styleSheet);

    /**
     * @brief Returns the current header Style Sheet.
     * @return The current header Style Sheet.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString headerStyleSheet() const;

    /**
     * @brief Sets the contents Margin.
     * @param margin Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setContentsMargin(int margin);

    /**
     * @brief Returns the current contents Margin.
     * @return The current contents Margin.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int contentsMargin() const;

    /**
     * @brief Sets the spacing.
     * @param spacing Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSpacing(int spacing);

    /**
     * @brief Returns the current spacing.
     * @return The current spacing.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int spacing() const;

    void setHeaderHeight(int h);
    int headerHeight() const;

    /**
     * @brief Sets the exclusive.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setExclusive(bool on);

    /**
     * @brief Returns whether the object reports exclusive.
     * @return `true` when the object reports exclusive; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isExclusive() const;

    /**
     * @brief Adds the specified item.
     * @param page Value passed to the method.
     * @param title Title text applied by the operation.
     * @return The requested item.
     */
    int addItem(SwWidget* page, const SwString& title);

    /**
     * @brief Performs the `insertItem` operation.
     * @param index Value passed to the method.
     * @param page Value passed to the method.
     * @param title Title text applied by the operation.
     * @return The requested insert Item.
     */
    int insertItem(int index, SwWidget* page, const SwString& title);

    /**
     * @brief Returns the current current Index.
     * @return The current current Index.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int currentIndex() const;

    /**
     * @brief Sets the current Index.
     * @param idx Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCurrentIndex(int idx);

    /**
     * @brief Returns whether the object reports item Expanded.
     * @param idx Value passed to the method.
     * @return `true` when the object reports item Expanded; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isItemExpanded(int idx) const;

    /**
     * @brief Sets the item Expanded.
     * @param idx Value passed to the method.
     * @param expanded Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItemExpanded(int idx, bool expanded);

    /**
     * @brief Removes the specified item.
     * @param idx Value passed to the method.
     */
    void removeItem(int idx);

    /**
     * @brief Performs the `indexOf` operation.
     * @param page Value passed to the method.
     * @return The requested index Of.
     */
    int indexOf(const SwWidget* page) const;

    /**
     * @brief Performs the `currentWidget` operation.
     * @param m_currentIndex Value passed to the method.
     * @return The requested current Widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* currentWidget() const;

    /**
     * @brief Sets the current Widget.
     * @param w Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCurrentWidget(SwWidget* w);

    /**
     * @brief Performs the `itemText` operation.
     * @param idx Value passed to the method.
     * @return The requested item Text.
     */
    SwString itemText(int idx) const;

    /**
     * @brief Sets the item Text.
     * @param idx Value passed to the method.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItemText(int idx, const SwString& text);

    /**
     * @brief Sets the item Enabled.
     * @param idx Value passed to the method.
     * @param enabled Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItemEnabled(int idx, bool enabled);

    /**
     * @brief Returns whether the object reports item Enabled.
     * @param idx Value passed to the method.
     * @return `true` when the object reports item Enabled; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isItemEnabled(int idx) const;

    /**
     * @brief Performs the `widget` operation.
     * @param idx Value passed to the method.
     * @return The requested widget.
     */
    SwWidget* widget(int idx) const;

    /**
     * @brief Performs the `header` operation.
     * @param idx Value passed to the method.
     * @return The requested header.
     */
    SwToolButton* header(int idx) const;

signals:
    SW_SIGNAL(currentChanged, int);
    SW_SIGNAL(contentSizeChanged, int);

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Returns the current size Hint.
     * @return The current size Hint.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSize sizeHint() const override;

    /**
     * @brief Performs the `minimumSizeHint` operation.
     * @return The requested minimum Size Hint.
     */
    SwSize minimumSizeHint() const override;

private:
    class SW_WIDGETS_EXPORT SwToolBoxHeaderButton final : public SwToolButton {
        SW_OBJECT(SwToolBoxHeaderButton, SwToolButton)

    public:
        /**
         * @brief Performs the `SwToolBoxHeaderButton` operation.
         * @param text Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @return The requested sw Tool Box Header Button.
         */
        explicit SwToolBoxHeaderButton(const SwString& text, SwWidget* parent = nullptr);

    protected:
        SwSize sizeHint() const override;

        SwSize minimumSizeHint() const override;

        /**
         * @brief Performs the `clampInt_` operation.
         * @param value Value passed to the method.
         * @param minValue Value passed to the method.
         * @param maxValue Value passed to the method.
         * @return The requested clamp Int.
         */
        static int clampInt_(int value, int minValue, int maxValue);

        /**
         * @brief Performs the `clampColor_` operation.
         * @param c Value passed to the method.
         * @return The requested clamp Color.
         */
        static SwColor clampColor_(const SwColor& c);

        /**
         * @brief Performs the `lighten_` operation.
         * @param c Value passed to the method.
         * @param amount Value passed to the method.
         * @return The requested lighten.
         */
        static SwColor lighten_(SwColor c, int amount);

        /**
         * @brief Performs the `darken_` operation.
         * @param c Value passed to the method.
         * @param amount Value passed to the method.
         * @return The requested darken.
         */
        static SwColor darken_(SwColor c, int amount);

        /**
         * @brief Performs the `parsePixelValue_` operation.
         * @param value Value passed to the method.
         * @param defaultValue Value passed to the method.
         * @return The requested parse Pixel Value.
         */
        static int parsePixelValue_(const SwString& value, int defaultValue);

        struct Padding {
            int top{0};
            int right{0};
            int bottom{0};
            int left{0};
        };

        /**
         * @brief Performs the `parsePadding_` operation.
         * @param value Value passed to the method.
         * @return The requested parse Padding.
         */
        static Padding parsePadding_(const SwString& value);

        /**
         * @brief Performs the `styleValue_` operation.
         * @param sheet Value passed to the method.
         * @param hierarchy Value passed to the method.
         * @param propertyName Value passed to the method.
         * @return The requested style Value.
         */
        static SwString styleValue_(const StyleSheet* sheet,
                                   const SwList<SwString>& hierarchy,
                                   const char* propertyName);

        /**
         * @brief Performs the `tryParseColor_` operation.
         * @param sheet Value passed to the method.
         * @param value Value passed to the method.
         * @param out Value passed to the method.
         * @return The requested try Parse Color.
         */
        static bool tryParseColor_(const StyleSheet* sheet, const SwString& value, SwColor& out);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

        /**
         * @brief Performs the `paintRoundedRectWithCorners_` operation.
         * @param painter Value passed to the method.
         * @param rect Rectangle used by the operation.
         * @param tl Value passed to the method.
         * @param tr Value passed to the method.
         * @param br Value passed to the method.
         * @param bl Value passed to the method.
         * @param fill Value passed to the method.
         * @param border Value passed to the method.
         * @param borderWidth Value passed to the method.
         * @return The requested paint Rounded Rect With Corners.
         */
        static void paintRoundedRectWithCorners_(SwPainter* painter,
                                                 const SwRect& rect,
                                                 int tl,
                                                 int tr,
                                                 int br,
                                                 int bl,
                                                 const SwColor& fill,
                                                 const SwColor& border,
                                                 int borderWidth);
    };

    struct Item {
        SwToolButton* header{nullptr};
        SwWidget* page{nullptr};
        bool expanded{false};
        SwString appliedHeaderStyle;
        SwString basePageStyle;
        SwString appliedPageStyle;
    };

    int indexOfHeader_(const SwToolButton* header) const;

    SwString subControlStyleValue_(const char* subControlSelector, const char* propertyName) const;

    SwString resolvedHeaderStyleSheet_() const;

    int effectiveHeaderHeight_() const;

    Item* itemAt_(int idx);

    const Item* itemAtConst_(int idx) const;

    void updateLayout_();

    int computeContentHeight_() const;

    int computeContentHeightHint_(bool minimum) const;

    SwSize toolboxSizeHint_(bool minimum) const;

    static SwString defaultHeaderStyleSheet_();
public:
    ~SwToolBox();
private:
    // What the class keeps (SwToolBox_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
