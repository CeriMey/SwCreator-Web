#pragma once

#include "SwSharedData.h"
#include <memory>
#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwFileExplorer.h
 * @ingroup core_gui
 * @brief Declares `SwFileExplorer`, a toolkit-native filesystem tree widget.
 *
 * The widget is intentionally lightweight:
 * - it renders a filesystem tree with `SwTreeWidget`,
 * - it uses native shell icons on Windows and deterministic fallback icons elsewhere,
 * - it supports file filters, path selection, and path activation,
 * - it can surface marked paths so callers can expose states such as "dirty".
 */

#include "SwDir.h"
#include "SwFileInfo.h"
#include "SwLabel.h"
#include "SwLayout.h"
#include "SwToolButton.h"
#include "SwTreeWidget.h"

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <unordered_map>


namespace swFileExplorerDetail {

inline SwString normalizePath(const SwString& rawPath) {
    SwString normalized = SwDir::normalizePath(rawPath);
    normalized.replace("\\", "/");
    while (normalized.endsWith("/") && normalized.size() > 1) {
        if (normalized.size() == 3 && normalized[1] == ':') {
            break;
        }
        normalized.chop(1);
    }
    return normalized;
}

inline SwString joinPath(const SwString& directoryPath, const SwString& name) {
    if (directoryPath.isEmpty()) {
        return normalizePath(name);
    }

    SwString out = directoryPath;
    if (!out.endsWith("/")) {
        out += "/";
    }
    out += name;
    return normalizePath(out);
}

inline SwString fileName(const SwString& rawPath) {
    const SwFileInfo info(normalizePath(rawPath).toStdString());
    return SwString(info.fileName());
}

inline SwString parentPath(const SwString& rawPath) {
    const SwString path = normalizePath(rawPath);
    if (path.isEmpty()) {
        return SwString();
    }

    const size_t slash = path.lastIndexOf('/');
    if (slash == static_cast<size_t>(-1)) {
        return SwString();
    }
    if (slash == 0) {
        return SwString("/");
    }
    if (slash == 2 && path.size() >= 3 && path[1] == ':') {
        return path.substr(0, slash + 1);
    }
    return path.substr(0, slash);
}

inline bool isSameOrChildPath(const SwString& rawParentPath, const SwString& rawChildPath) {
    const SwString parentPath = normalizePath(rawParentPath);
    const SwString childPath = normalizePath(rawChildPath);
    if (parentPath.isEmpty() || childPath.isEmpty()) {
        return false;
    }
    if (parentPath == childPath) {
        return true;
    }

    SwString prefix = parentPath;
    if (!prefix.endsWith("/")) {
        prefix += "/";
    }
    return childPath.startsWith(prefix);
}

inline void sortEntries(SwStringList& entries) {
    std::sort(entries.begin(), entries.end(), [](const SwString& lhs, const SwString& rhs) {
        return lhs.compare(rhs, Sw::CaseInsensitive) < 0;
    });
}

class SW_WIDGETS_EXPORT SystemIconCache {
public:
    SwImage iconForPath(const SwString& path, bool isDirectory, int sizePx);

    void clear();
    void setFileAssociationMode(bool enabled);

private:
    static SwString cacheKey_(const SwString& path, bool isDirectory, int sizePx);

    static SwString extensionLower_(const SwString& path);

#if defined(_WIN32)
    static SwImage loadShellIconForAttributes_(const SwString& pseudoPath, DWORD attrs, int sizePx);

    static SwImage loadShellIconForPath_(const SwString& path, bool isDirectory, int sizePx);

    static SwImage iconToImage_(HICON icon, int sizePx);
#endif

    static SwImage makeFallbackIcon_(bool isDirectory, int sizePx);

public:
    SystemIconCache();
public:
    ~SystemIconCache();
public:
    SystemIconCache(const SystemIconCache& other);
    SystemIconCache& operator=(const SystemIconCache& other);
private:
    // What the class keeps (SwFileExplorer_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace swFileExplorerDetail

class SW_WIDGETS_EXPORT SwFileExplorer : public SwWidget {
    SW_OBJECT(SwFileExplorer, SwWidget)

public:
    explicit SwFileExplorer(SwWidget* parent = nullptr,
                            bool showWorkspaceButton = true,
                            bool showRootPath = true);

    void setTitle(const SwString& title);

    SwString title() const;
    SwLabel* titleLabel() const;
    // Dense project navigator header and uppercase project root; default layout stays unchanged.
    void setCompactMode(bool enabled);

    void setRootPath(const SwString& rawRootPath);

    SwString rootPath() const;

    void setCurrentPath(const SwString& rawPath);

    SwString currentPath() const;

    void setMarkedPaths(const SwMap<SwString, bool>& markedPaths);

    SwMap<SwString, bool> markedPaths() const;

    void setNameFilters(const SwStringList& filters);

    SwStringList nameFilters() const;

    void setDoubleClickActivationEnabled(bool enabled);

    bool doubleClickActivationEnabled() const;

    // Opt-in IDE mode: avoid inspecting each real path for shell icons, and enumerate on a
    // background worker while inserting small batches on the widget's owning thread.
    void setFileAssociationIconsEnabled(bool enabled);
    bool fileAssociationIconsEnabled() const;
    void setAsynchronousLoadingEnabled(bool enabled);
    bool asynchronousLoadingEnabled() const;
    bool isLoading() const;

    SwSize minimumSizeHint() const override;

    void reload();

    SwTreeWidget* treeWidget() const;

signals:
    SW_SIGNAL(pathActivated, const SwString&);
    SW_SIGNAL(currentPathChanged, const SwString&);
    SW_SIGNAL(pathContextMenuRequested, const SwString&, int, int);
    SW_SIGNAL_VOID(workspaceBrowseRequested);
    SW_SIGNAL(loadingChanged, bool);
    // Emitted on the widget's owner thread before each actual directory enumeration starts.
    SW_SIGNAL(directoryLoading, const SwString&);
    SW_SIGNAL(directoryLoaded, const SwString&);

private:
    class SW_WIDGETS_EXPORT FileTreeWidget final : public SwTreeWidget {
        SW_OBJECT(FileTreeWidget, SwTreeWidget)

    public:
        explicit FileTreeWidget(SwWidget* parent = nullptr);
        void refreshStructure();

    signals:
        SW_SIGNAL(itemDoubleActivated, SwStandardItem*);
        SW_SIGNAL(itemAboutToExpand, SwStandardItem*);

    protected:
        void mousePressEvent(MouseEvent* event) override;
        void mouseDoubleClickEvent(MouseEvent* event) override;
    };

    static SwString lazyPlaceholderToken_();

    bool directoryMayHaveVisibleChildren_(const SwString& directoryPath) const;

    void primeDirectoryItem_(SwStandardItem* item, const SwString& directoryPath);

    void populateDirectoryChildren_(SwStandardItem* parentItem, const SwString& directoryPath);
    void scheduleDirectoryLoad_(SwStandardItem* parentItem, const SwString& directoryPath);
    void processDirectoryLoads_();
    void cancelDirectoryLoads_();

    void ensureDirectoryPopulated_(SwStandardItem* item);

    SwStandardItem* ensureItemForPath_(const SwString& rawPath);

    SwStandardItem* makeDirectoryItem_(const SwString& path);

    SwStandardItem* makeFileItem_(const SwString& path);

    void refreshLabels_();

    void syncSelection_(bool emitSignal);

    void expandToItem_(SwStandardItem* item);

    void onCurrentItemChanged_(SwStandardItem* current);

    void onItemClicked_(SwStandardItem* item);

    void activateItem_(SwStandardItem* item);

    SwModelIndex indexForItem_(SwStandardItem* item) const;

    SwString labelForPath_(const SwString& path) const;

    bool pathHasMarkedChildren_(const SwString& rawPath) const;


public:
    ~SwFileExplorer();
private:
    // What the class keeps (SwFileExplorer_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
