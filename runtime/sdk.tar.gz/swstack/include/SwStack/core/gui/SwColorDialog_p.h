#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwColorDialog.h"

struct SwColorDialog::Data {
    SwColor m_current{0, 0, 0};
    PreviewWidget* m_preview{nullptr};
    SwLineEdit* m_hexEdit{nullptr};
    SwVector<SwWidget*> m_paletteSwatches;
    SwVector<ColorSwatch*> m_recentSwatches;
    SwRoundColorPicker* m_picker{nullptr};
    SwPushButton* m_ok{nullptr};
    SwPushButton* m_cancel{nullptr};
    int m_spacing{10};
    bool m_syncingPicker{false};
    bool m_syncingHex{false};
};
