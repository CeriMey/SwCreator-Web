/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwStyledItemDelegate.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwStyledItemDelegate in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the styled item delegate interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwStyleOptionViewItem and SwStyledItemDelegate.
 *
 * Delegate-oriented declarations here describe customization hooks that let another component
 * vary rendering, editing, or interaction policy without duplicating the parent component.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwStyledItemDelegate - item delegate base.
 *
 * Goal:
 * - Provide a reusable paint/sizeHint hook for model-based views (List/Table/Tree).
 * - Keep the default behaviour simple and "web-ish" (premium, padded, selectable rows).
 **************************************************************************************************/

#include "SwAbstractItemModel.h"
#include "SwObject.h"
#include "SwPainter.h"

#include "graphics/SwFontMetrics.h"

class SwWidget;

struct SW_WIDGETS_EXPORT SwStyleOptionViewItem {
    SwRect rect{};
    SwFont font{};
    bool enabled{true};
    bool selected{false};
    bool hovered{false};
    bool hasFocus{false};
    bool alternate{false};
};

class SW_WIDGETS_EXPORT SwStyledItemDelegate : public SwObject {
    SW_OBJECT(SwStyledItemDelegate, SwObject)

public:
    /**
     * @brief Constructs a `SwStyledItemDelegate` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwStyledItemDelegate(SwObject* parent = nullptr);

    /**
     * @brief Destroys the `SwStyledItemDelegate` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    virtual ~SwStyledItemDelegate();

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param option Value passed to the method.
     * @param index Value passed to the method.
     * @return The requested paint.
     */
    virtual void paint(SwPainter* painter,
                       const SwStyleOptionViewItem& option,
                       const SwModelIndex& index) const;

    /**
     * @brief Performs the `sizeHint` operation.
     * @param option Value passed to the method.
     * @param index Value passed to the method.
     * @return The requested size Hint.
     */
    virtual SwSize sizeHint(const SwStyleOptionViewItem& option,
                            const SwModelIndex& index) const;

    /**
     * @brief Creates an editor widget for an editable item.
     * @param parent Parent widget that should own the editor.
     * @param option Style option associated with the edited item.
     * @param index Model index being edited.
     * @return Newly created editor widget, or `nullptr` when the item is not editor-backed.
     */
    virtual SwWidget* createEditor(SwWidget* parent,
                                   const SwStyleOptionViewItem& option,
                                   const SwModelIndex& index) const;

    /**
     * @brief Populates an editor with the current model value.
     * @param editor Editor widget created by `createEditor`.
     * @param index Model index being edited.
     */
    virtual void setEditorData(SwWidget* editor,
                               const SwModelIndex& index) const;

    /**
     * @brief Pushes the editor state back into the model.
     * @param editor Editor widget created by `createEditor`.
     * @param model Model to update.
     * @param index Model index being edited.
     */
    virtual void setModelData(SwWidget* editor,
                              SwAbstractItemModel* model,
                              const SwModelIndex& index) const;

    /**
     * @brief Updates the editor geometry for the edited cell.
     * @param editor Editor widget created by `createEditor`.
     * @param option Style option associated with the edited item.
     * @param index Model index being edited.
     */
    virtual void updateEditorGeometry(SwWidget* editor,
                                      const SwStyleOptionViewItem& option,
                                      const SwModelIndex& index) const;
};
