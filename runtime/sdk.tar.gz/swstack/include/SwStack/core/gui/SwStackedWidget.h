/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwStackedWidget.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwStackedWidget in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the stacked widget interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwStackedWidget.
 *
 * Widget-oriented declarations here usually capture persistent UI state, input handling, layout
 * participation, and paint-time behavior while keeping platform-specific rendering details behind
 * lower layers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwStackedWidget - stacked container.
 *
 * Shows one child widget at a time; all others are hidden.
 **************************************************************************************************/

#include "SwWidget.h"
#include "SwVector.h"

class SW_WIDGETS_EXPORT SwStackedWidget : public SwWidget {
    SW_OBJECT(SwStackedWidget, SwWidget)

public:
    /**
     * @brief Constructs a `SwStackedWidget` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwStackedWidget(SwWidget* parent = nullptr);

    /**
     * @brief Adds the specified widget.
     * @param widget Widget associated with the operation.
     * @return The requested widget.
     */
    int addWidget(SwWidget* widget);

    /**
     * @brief Performs the `insertWidget` operation.
     * @param index Value passed to the method.
     * @param widget Widget associated with the operation.
     * @return The requested insert Widget.
     */
    int insertWidget(int index, SwWidget* widget);

    /**
     * @brief Removes the specified widget.
     * @param widget Widget associated with the operation.
     */
    void removeWidget(SwWidget* widget);

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const;

    /**
     * @brief Performs the `widget` operation.
     * @param index Value passed to the method.
     * @return The requested widget.
     */
    SwWidget* widget(int index) const;

    /**
     * @brief Returns the current current Index.
     * @return The current current Index.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int currentIndex() const;

    /**
     * @brief Returns the current current Widget.
     * @return The current current Widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* currentWidget() const;

    /**
     * @brief Sets the current Index.
     * @param index Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCurrentIndex(int index);

    SW_SIGNAL(currentChanged, int);

protected:
    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    void initDefaults();

    void applyVisibility();

    void updateLayout();

    SwSize stackedSizeHint_(bool minimum) const;

public:
    ~SwStackedWidget();
private:
    // What the class keeps (SwStackedWidget_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
