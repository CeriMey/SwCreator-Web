#pragma once

#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file src/core/gui/SwTextBlockUserData.h
 * @ingroup core_gui
 * @brief Declares block-scoped transient metadata used by text highlighters and editors.
 *
 * This type mirrors Qt's `QTextBlockUserData` contract: the document owns one optional user data
 * object per block, and editor-side services can attach transient metadata without mutating the
 * textual content itself.
 */

class SW_GUI_EXPORT SwTextBlockUserData {
public:
    virtual ~SwTextBlockUserData();
};
