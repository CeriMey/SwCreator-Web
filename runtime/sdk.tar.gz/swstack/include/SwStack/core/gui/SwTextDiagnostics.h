#pragma once

#include <memory>
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextDocument.h"
#include "../runtime/SwTimer.h"

#include <algorithm>

struct SW_GUI_EXPORT SwTextDiagnosticRange {
    int start{0};
    int length{0};

    int end() const;

    bool isValid() const;

    bool contains(int position) const;

    bool operator==(const SwTextDiagnosticRange& other) const;

    bool operator!=(const SwTextDiagnosticRange& other) const;
};

enum class SwTextDiagnosticSeverity {
    Hint,
    Information,
    Warning,
    Error
};

struct SW_GUI_EXPORT SwTextDiagnostic {
    SwTextDiagnosticRange range;
    SwTextDiagnosticSeverity severity{SwTextDiagnosticSeverity::Error};
    SwString message;
    SwTextCharFormat format;

    bool operator==(const SwTextDiagnostic& other) const;

    bool operator!=(const SwTextDiagnostic& other) const;
};

class SW_GUI_EXPORT SwTextDiagnosticsProvider : public SwObject {
    SW_OBJECT(SwTextDiagnosticsProvider, SwObject)

public:
    explicit SwTextDiagnosticsProvider(SwTextDocument* parent = nullptr);

    virtual ~SwTextDiagnosticsProvider();

    void setDocument(SwTextDocument* doc);

    SwTextDocument* document() const;

    void setDebounceInterval(int ms);

    int debounceInterval() const;

    void setMaxDiagnostics(int maxDiagnostics);

    int maxDiagnostics() const;

    void scheduleReanalysis();

    void reanalyze();

    SwList<SwTextDiagnostic> diagnostics() const;

    SwList<SwTextDiagnostic> diagnosticsForBlock(int blockIndex) const;

    SW_SIGNAL_VOID(diagnosticsChanged)

protected:
    virtual void analyzeDocument(const SwString& text, SwList<SwTextDiagnostic>& diagnostics) = 0;

private:
    void reanalyzeNow_();

    void normalizeDiagnostics_(SwList<SwTextDiagnostic>& diagnostics) const;

private:
    // What the class keeps (SwTextDiagnostics_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
