#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwCppCompletionIndex.h"

struct SwCppCompletionIndex::Data {
    std::function<SwString()> m_textProvider;
    std::shared_ptr<Snapshot> m_snapshot;
    std::shared_ptr<int> m_lifeToken{std::make_shared<int>(0)};
    SwTimer* m_rebuildTimer{nullptr};
    SwThreadPool* m_threadPool{nullptr};
    int m_rebuildDebounceMs{120};
    int m_requestedBuildId{0};
    bool m_asyncEnabled{true};
    bool m_buildInFlight{false};
    bool m_rebuildQueued{false};
};
