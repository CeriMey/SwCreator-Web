#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwMarkdownSyntaxTheme {
    SwTextCharFormat headingFormat;
    SwTextCharFormat boldFormat;
    SwTextCharFormat italicFormat;
    SwTextCharFormat codeFormat;
    SwTextCharFormat linkFormat;
    SwTextCharFormat urlFormat;
    SwTextCharFormat listMarkerFormat;
    SwTextCharFormat blockquoteFormat;
    SwTextCharFormat hrFormat;
    SwTextCharFormat imageFormat;
};

inline SwTextCharFormat swMdMakeFormat_(const SwColor& color,
                                         FontWeight weight = Normal,
                                         bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) { format.setFontWeight(weight); }
    if (italic) { format.setFontItalic(true); }
    return format;
}

inline SwMarkdownSyntaxTheme swMarkdownSyntaxThemeVsCodeDark() {
    SwMarkdownSyntaxTheme theme;
    theme.headingFormat    = swMdMakeFormat_(SwColor{86, 156, 214}, Bold);
    theme.boldFormat       = swMdMakeFormat_(SwColor{212, 212, 212}, Bold);
    theme.italicFormat     = swMdMakeFormat_(SwColor{212, 212, 212}, Normal, true);
    theme.codeFormat       = swMdMakeFormat_(SwColor{206, 145, 120});
    theme.linkFormat       = swMdMakeFormat_(SwColor{78, 201, 176});
    theme.urlFormat        = swMdMakeFormat_(SwColor{86, 156, 214});
    theme.listMarkerFormat = swMdMakeFormat_(SwColor{197, 134, 192});
    theme.blockquoteFormat = swMdMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.hrFormat         = swMdMakeFormat_(SwColor{197, 134, 192});
    theme.imageFormat      = swMdMakeFormat_(SwColor{220, 220, 170});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwMarkdownSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwMarkdownSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwMarkdownSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwMarkdownSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        FencedCodeState = 1
    };

    void highlightInline_(const SwString& text, int start);

public:
    ~SwMarkdownSyntaxHighlighter();
private:
    // What the class keeps (SwMarkdownSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
