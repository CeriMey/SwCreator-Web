#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwAreaSeries.h"

struct SwAreaSeries::Data {
    double m_baseline{0.0};
    bool m_hasFillColor{false};
    SwColor m_fillColor{191, 219, 254};
    int m_borderWidth{2};
};
