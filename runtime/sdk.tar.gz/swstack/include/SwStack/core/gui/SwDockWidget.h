// Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0
#pragma once

#include "SwVector.h"
#include "SwWidget.h"
#include <memory>

/** Dragging the title detaches the entire panel into a frameless tool window.
 * Closing it restores the panel's original slot, order and splitter proportions.
 * Tabs and splitters reclaim vacant slots while preserving content identity.
 * No application, transport or equipment semantics belong in this widget.
 */
class SW_WIDGETS_EXPORT SwDockWidget : public SwWidget {
    SW_OBJECT(SwDockWidget, SwWidget)
  public:
    explicit SwDockWidget(const SwString &title = {}, SwWidget *parent = nullptr);
    ~SwDockWidget() override;

    void setTitle(const SwString &title);
    SwString title() const;
    // Adopts content. Replacing it releases the old widget to the caller.
    void setWidget(SwWidget *content);
    SwWidget *widget() const;
    SwWidget *takeWidget();
    void setFloating(bool floating);
    bool isFloating() const;
    void activate();
    void setFloatingSize(const SwSize &size);
    void setFloatingStyleSheet(const SwString &style);
    struct Appearance {
        SwColor surface{24, 32, 43}, header{32, 43, 56}, border{55, 70, 85};
        SwColor text{233, 239, 246}, muted{151, 168, 185}, accent{61, 185, 200};
    };
    void setAppearance(const Appearance &appearance);
    Appearance appearance() const;
    void setSubtitle(const SwString &subtitle);
    // Only registered containers accept drops. The original home remains available.
    // Tab groups accept the panel as a tab; splitters accept it at their outer edges.
    void setDockTargets(const SwVector<SwWidget *> &containers);
    void setDockPreviewText(const SwString &text);
    SwWidget *dockPreviewTarget() const;
    SwRect dockPreviewRect() const;
    // Free-canvas panels move inside their parent and detach when dragged outside.
    // Managed panels detach as soon as their title is dragged past the threshold.
    void setMovable(bool movable);
    void setResizable(bool resizable);

    // Emitted before reparenting, so a client can interrupt focus-sensitive input.
    SW_SIGNAL_VOID(presentationAboutToChange);
    SW_SIGNAL(floatingChanged, bool);
    SW_SIGNAL(floatingActiveChanged, bool);

  protected:
    void paintEvent(PaintEvent *event) override;
    void keyPressEvent(KeyEvent *event) override;
    void resizeEvent(ResizeEvent *event) override;
    void mousePressEvent(MouseEvent *event) override;
    void mouseMoveEvent(MouseEvent *event) override;
    void mouseReleaseEvent(MouseEvent *event) override;

  private:
    int resizeEdgesAt(const SwPoint &position) const;
    void finishDockInteraction();
    void updateDockPreview(const SwPoint &global);
    void clearDockPreview();
    void commitDockPreview();
    struct Data;
    std::unique_ptr<Data> d_;
};
