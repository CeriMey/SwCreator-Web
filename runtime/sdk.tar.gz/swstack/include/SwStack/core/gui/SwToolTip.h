﻿#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file
 * @ingroup core_gui
 * @brief Declares the tooltip manager used by the widget layer.
 *
 * `SwToolTip` tracks hover state, delays popup creation, measures tooltip text, and paints
 * the floating tooltip widget on demand. The implementation is centralized here so widgets
 * can expose tooltip text without each one reimplementing timing and popup behavior.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwPainter.h"
#include "SwWidget.h"
#include "SwWidgetPlatformAdapter.h"

#include "core/runtime/SwTimer.h"
#include "core/types/SwString.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwToolTip {
public:
    /**
     * @brief Performs the `handleMouseMove` operation.
     * @param root Value passed to the method.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @return The requested handle Mouse Move.
     */
    static void handleMouseMove(SwWidget* root, int x, int y);
    static void handleMouseMove(SwWidget* root, SwWidget* hoveredWidget, int x, int y);
    /**
     * @brief Performs the `handleMousePress` operation.
     * @return The requested handle Mouse Press.
     */
    static void handleMousePress();
    /**
     * @brief Performs the `handleKeyPress` operation.
     * @return The requested handle Key Press.
     */
    static void handleKeyPress();

    /**
     * @brief Performs the `showText` operation.
     * @param root Value passed to the method.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param text Value passed to the method.
     * @return The requested show Text.
     */
    static void showText(SwWidget* root, int x, int y, const SwString& text);
    /**
     * @brief Performs the `hideText` operation.
     * @return The requested hide Text.
     */
    static void hideText();
    /**
     * @brief Returns whether the object reports visible.
     * @return The requested visible.
     *
     * @details This query does not modify the object state.
     */
    static bool isVisible();

private:
    class SW_WIDGETS_EXPORT Popup final : public SwWidget {
        SW_OBJECT(Popup, SwWidget)

    public:
        /**
         * @brief Performs the `Popup` operation.
         * @param parent Optional parent object that owns this instance.
         * @return The requested popup.
         */
        explicit Popup(SwWidget* parent = nullptr);

        /**
         * @brief Sets the text.
         * @param text Value passed to the method.
         *
         * @details Call this method to replace the currently stored value with the caller-provided one.
         */
        void setText(const SwString& text);

        /**
         * @brief Returns the current text.
         * @return The current text.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        SwString text() const;

        /**
         * @brief Returns the current size Hint.
         * @return The current size Hint.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        SwSize sizeHint() const override;

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

    private:
        void updateMetrics_();

        SwString m_text;
        int m_cachedW{120};
        int m_cachedH{32};
    };

    static SwToolTip& instance_();

    static SwWidget* deepestChildAt_(SwWidget* root, int x, int y);

    static SwWidget* tooltipProviderFor_(SwWidget* widget);

    void handleMouseMove_(SwWidget* root, SwWidget* hoveredWidget, int x, int y);

    void startTimer_();

    void ensurePopup_();

    void showPending_();

    void showText_(SwWidget* root, int x, int y, const SwString& text);

    void hide_();

    SwToolTip();
    ~SwToolTip();

public:
    SwToolTip(const SwToolTip& other);
    SwToolTip& operator=(const SwToolTip& other);
private:
    // What the class keeps (SwToolTip_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

