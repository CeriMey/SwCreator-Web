#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwGroupBox.h"

struct SwGroupBox::Data {
    SwString m_Text = "GroupBox";
    bool m_Text_registered_ = sw_register_Text_();
    bool m_Pressed = false;
    bool m_Pressed_registered_ = sw_register_Pressed_();
    bool m_checkable{false};
    bool m_checked{true};
    SwColor m_accent{0, 120, 215};
    int m_headerHeight{18};
    int m_padding{12};
    int m_checkSize{16};
    int m_checkSpacing{8};
};
