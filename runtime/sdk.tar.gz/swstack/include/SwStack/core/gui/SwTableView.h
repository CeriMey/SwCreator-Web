﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwTableView.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwTableView in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the table view interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwTableView.
 *
 * View-oriented declarations here mainly describe how underlying state is projected into a visual
 * or interactive surface, including how refresh, selection, or presentation concerns are exposed
 * at the API boundary.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAbstractItemModel.h"
#include "SwCheckBox.h"
#include "SwComboBox.h"
#include "SwHeaderView.h"
#include "SwItemSelectionModel.h"
#include "SwLineEdit.h"
#include "SwScrollBar.h"
#include "SwScrollBarPolicy.h"
#include "SwStyledItemDelegate.h"
#include "SwTimer.h"
#include "SwWidget.h"
#include "SwWidgetPlatformAdapter.h"
#include "SwDragDrop.h"

#include "SwList.h"
#include <cstdlib>

class SW_WIDGETS_EXPORT SwTableView : public SwWidget {
    SW_OBJECT(SwTableView, SwWidget)

private:
    void updateHeaderSortIndicator_();
    void updateHeaderGeometry_();

public:
    /**
     * @brief Constructs a `SwTableView` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwTableView(SwWidget* parent = nullptr);

    /**
     * @brief Sets the model.
     * @param model Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setModel(SwAbstractItemModel* model);

    /**
     * @brief Returns the current model.
     * @return The current model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwAbstractItemModel* model() const;

    /**
     * @brief Sets the selection Model.
     * @param selectionModel Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSelectionModel(SwItemSelectionModel* selectionModel);

    /**
     * @brief Returns the current selection Model.
     * @return The current selection Model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwItemSelectionModel* selectionModel() const;

    /**
     * @brief Sets the drag Enabled.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDragEnabled(bool on);
    /**
     * @brief Returns the current drag Enabled.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dragEnabled() const;

    /**
     * @brief Sets the accept Drops.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAcceptDrops(bool on);
    /**
     * @brief Returns the current accept Drops.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool acceptDrops() const;

    /**
     * @brief Sets the drop Indicator Shown.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDropIndicatorShown(bool on);
    /**
     * @brief Returns the current drop Indicator Shown.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dropIndicatorShown() const;

    /**
     * @brief Sets the index Widget.
     * @param index Value passed to the method.
     * @param widget Widget associated with the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIndexWidget(const SwModelIndex& index, SwWidget* widget);

    /**
     * @brief Performs the `indexWidget` operation.
     * @param index Value passed to the method.
     * @return The requested index Widget.
     */
    SwWidget* indexWidget(const SwModelIndex& index) const;

    /**
     * @brief Clears the current object state.
     */
    void clearIndexWidgets();

    /**
     * @brief Sets the item Delegate.
     * @param delegate Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItemDelegate(SwStyledItemDelegate* delegate);

    /**
     * @brief Returns the current item Delegate.
     * @return The current item Delegate.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStyledItemDelegate* itemDelegate() const;

    /**
     * @brief Performs the `indexAt` operation.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     * @return The requested index At.
     */
    SwModelIndex indexAt(int px, int py) const;

    /**
     * @brief Performs the `visualRect` operation.
     * @param index Value passed to the method.
     * @return The requested visual Rect.
     */
    SwRect visualRect(const SwModelIndex& index) const;

    /**
     * @brief Performs the `scrollTo` operation.
     * @param index Value passed to the method.
     */
    void scrollTo(const SwModelIndex& index);

    /**
     * @brief Starts editing the given index using the current delegate.
     * @param index Model index to edit.
     * @return `true` when an editor was opened; otherwise `false`.
     */
    bool edit(const SwModelIndex& index);

    /**
     * @brief Commits and closes the active editor, if any.
     */
    void closeEditor();

    /**
     * @brief Returns the currently edited index.
     * @return The currently edited index.
     */
    SwModelIndex editingIndex() const;

signals:
    SW_SIGNAL(clicked, const SwModelIndex&);
    SW_SIGNAL(doubleClicked, const SwModelIndex&);
    SW_SIGNAL(activated, const SwModelIndex&);
    SW_SIGNAL(contextMenuRequested, const SwModelIndex&, int, int);
    SW_SIGNAL(dragStarted, const SwModelIndex&);
    SW_SIGNAL(dragMoved, const SwModelIndex&, int, int);
    SW_SIGNAL(dragDropped, const SwModelIndex&, const SwModelIndex&);

    /**
     * @brief Sets the alternating Row Colors.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAlternatingRowColors(bool on);

    /**
     * @brief Returns the current alternating Row Colors.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool alternatingRowColors() const;

    /**
     * @brief Sets the show Grid.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setShowGrid(bool on);

    /** Colours of the frame, rows, selection and grid; the defaults are the light theme. */
    struct TableColors {
        SwColor background{255, 255, 255};
        SwColor border{220, 224, 232};
        SwColor alternate{248, 250, 252};
        SwColor selection{219, 234, 254};
        SwColor selectionBorder{147, 197, 253};
        SwColor grid{226, 232, 240};
        SwColor dropIndicator{59, 130, 246};
        int radius{12};
        int selectionRadius{8};
    };
    void setTableColors(const TableColors& colors);
    TableColors tableColors() const;

    /**
     * @brief Returns the current show Grid.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool showGrid() const;

    /**
     * @brief Sets the sorting Enabled.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSortingEnabled(bool on);

    /**
     * @brief Returns the current sorting Enabled.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool sortingEnabled() const;

    /**
     * @brief Returns the current sort Column.
     * @return The current sort Column.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int sortColumn() const;
    /**
     * @brief Returns the current sort Order.
     * @return The current sort Order.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSortOrder sortOrder() const;

    /**
     * @brief Performs the `sortByColumn` operation.
     * @param column Value passed to the method.
     * @param order Value passed to the method.
     */
    void sortByColumn(int column, SwSortOrder order = SwSortOrder::AscendingOrder);

    /**
     * @brief Sets the default Column Width.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDefaultColumnWidth(int px);

    /**
     * @brief Returns the current default Column Width.
     * @return The current default Column Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int defaultColumnWidth() const;

    /**
     * @brief Sets the column Width.
     * @param column Value passed to the method.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnWidth(int column, int px);

    /**
     * @brief Performs the `columnWidth` operation.
     * @param column Value passed to the method.
     * @return The requested column Width.
     */
    int columnWidth(int column) const;

    /**
     * @brief Sets the columns Fit To Width.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnsFitToWidth(bool on);

    /**
     * @brief Performs the `columnsFitToWidth` operation.
     * @return `true` on success; otherwise `false`.
     */
    bool columnsFitToWidth() const;

    /**
     * @brief Sets the column Stretch.
     * @param column Value passed to the method.
     * @param stretch Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnStretch(int column, int stretch);

    /**
     * @brief Performs the `columnStretch` operation.
     * @param column Value passed to the method.
     * @return The requested column Stretch.
     */
    int columnStretch(int column) const;

    /**
     * @brief Sets the column Stretches.
     * @param stretches Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnStretches(const SwList<int>& stretches);

    /**
     * @brief Performs the `resizeColumnToContents` operation.
     * @param column Value passed to the method.
     */
    void resizeColumnToContents(int column);

    /**
     * @brief Performs the `resizeColumnsToContents` operation.
     */
    void resizeColumnsToContents();

    /**
     * @brief Sets the horizontal Scroll Bar Policy.
     * @param policy Policy value applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHorizontalScrollBarPolicy(SwScrollBarPolicy policy);

    /**
     * @brief Returns the current horizontal Scroll Bar Policy.
     * @return The current horizontal Scroll Bar Policy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBarPolicy horizontalScrollBarPolicy() const;

    /**
     * @brief Sets the vertical Scroll Bar Policy.
     * @param policy Policy value applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setVerticalScrollBarPolicy(SwScrollBarPolicy policy);

    /**
     * @brief Returns the current vertical Scroll Bar Policy.
     * @return The current vertical Scroll Bar Policy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBarPolicy verticalScrollBarPolicy() const;

    /**
     * @brief Sets the row Height.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRowHeight(int px);

    /**
     * @brief Returns the current row Height.
     * @return The current row Height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int rowHeight() const;

    /**
     * @brief Sets the header Height.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeaderHeight(int px);

    /**
     * @brief Returns the current header Height.
     * @return The current header Height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int headerHeight() const;

    // Horizontal header accessor.
    /**
     * @brief Returns the current horizontal Header.
     * @return The current horizontal Header.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwHeaderView* horizontalHeader() const;

    /**
     * @brief Returns the current horizontal Scroll Bar.
     * @return The current horizontal Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    /** Scrollbar layout extent in pixels (4..32); default 14. */
    void setScrollBarThickness(int pixels);
    int scrollBarThickness() const;

    SwScrollBar* horizontalScrollBar() const;
    /**
     * @brief Returns the current vertical Scroll Bar.
     * @return The current vertical Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBar* verticalScrollBar() const;

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Double Click Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseDoubleClickEvent(MouseEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

private:
    static bool containsPoint(const SwRect& r, int px, int py);

    static bool rectContains(const SwRect& outer, const SwRect& inner);

    bool isIndexEditable_(const SwModelIndex& index) const;

    SwStyleOptionViewItem styleOptionForIndex_(const SwModelIndex& index) const;

    void updateEditorGeometryForIndex_(const SwModelIndex& index);

    void hookEditorSignals_(SwWidget* editor);

    void commitAndCloseEditor_(bool closeEditor);

    bool hitRowResizeHandle_(int px, int py) const;

    SwModelIndex indexAt_(int px, int py) const;

    void validateSortStateAfterModelReset();

    SwModelIndex findIndexForInternalPointer(void* ptr, int columnHint) const;

    void remapCurrentIndexAfterModelReset();

    void remapSelectionAfterModelReset();

    void remapIndexWidgetsAfterModelReset();

    void remapEditorAfterModelReset();

    void initDefaults();

    SwRect viewportRect(const SwRect& bounds) const;

    SwRect contentViewportRect(const SwRect& bounds) const;

    void updateLayout();

    int columnWidthInternal(int column) const;

    int columnsWidth() const;

    int columnStartX(int column) const;

    int columnAtX(int x) const;

    int textWidthPx(const SwString& text, const SwFont& font) const;

    int columnCount() const;
    int rowCount() const;

    int contentWidth() const;

    int contentHeight() const;

    void resetScrollBars();

    void paintRows(SwPainter* painter, const SwRect& viewport, int headerH);

    void ensureDefaultDelegate_();

    int columnAtContentX(int x) const;

    void ensureIndexVisible(const SwModelIndex& index);

    void updateIndexWidgetsGeometry();

    struct IndexWidgetEntry {
        SwModelIndex index;
        SwWidget* widget{nullptr};
    };

public:
    ~SwTableView();
private:
    // What the class keeps (SwTableView_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

