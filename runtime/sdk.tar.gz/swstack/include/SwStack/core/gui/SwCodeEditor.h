#pragma once

#include <memory>
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwCompleter.h"
#include "SwPlainTextEdit.h"
#include "SwScrollBar.h"
#include "SwSyntaxHighlighter.h"
#include "SwTextDecorationRenderer.h"
#include "SwTextDocument.h"
#include "SwTextDiagnostics.h"
#include "SwTextExtraSelection.h"

#include <algorithm>
#include <cstring>
#include <cwctype>
#include <functional>
#include <sstream>

struct SW_CODEEDITOR_EXPORT SwCodeEditorTheme {
    SwColor backgroundColor{255, 255, 255};
    SwColor borderColor{220, 224, 232};
    SwColor focusBorderColor{59, 130, 246};
    SwColor textColor{24, 28, 36};
    SwColor disabledTextColor{150, 150, 150};
    SwColor gutterBackgroundColor{248, 250, 252};
    SwColor gutterTextColor{120, 128, 140};
    SwColor currentLineNumberColor{55, 65, 81};
    SwColor gutterSeparatorColor{226, 232, 240};
    SwColor currentLineBackgroundColor{243, 247, 255};
    SwColor selectionBackgroundColor{219, 234, 254};
    SwColor placeholderColor{160, 160, 160};
    SwColor diagnosticErrorColor{220, 38, 38};
    SwColor diagnosticWarningColor{217, 119, 6};
    SwColor diagnosticInformationColor{37, 99, 235};
    SwColor scrollBarTrackColor{236, 236, 236};
    SwColor scrollBarThumbColor{200, 200, 200};
    SwColor scrollBarThumbHoverColor{170, 170, 170};
    int borderRadius{10};
    int scrollBarWidth{14};
};

inline SwCodeEditorTheme swCodeEditorDefaultTheme() {
    return SwCodeEditorTheme();
}

inline SwCodeEditorTheme swCodeEditorVsCodeDarkTheme() {
    SwCodeEditorTheme theme;
    theme.backgroundColor = SwColor{30, 30, 30};
    theme.borderColor = SwColor{45, 45, 48};
    theme.focusBorderColor = SwColor{0, 122, 204};
    theme.textColor = SwColor{212, 212, 212};
    theme.disabledTextColor = SwColor{112, 112, 112};
    theme.gutterBackgroundColor = SwColor{30, 30, 30};
    theme.gutterTextColor = SwColor{133, 133, 133};
    theme.currentLineNumberColor = SwColor{198, 198, 198};
    theme.gutterSeparatorColor = SwColor{51, 51, 51};
    theme.currentLineBackgroundColor = SwColor{42, 45, 46};
    theme.selectionBackgroundColor = SwColor{38, 79, 120};
    theme.placeholderColor = SwColor{106, 115, 125};
    theme.diagnosticErrorColor = SwColor{244, 71, 71};
    theme.diagnosticWarningColor = SwColor{220, 180, 90};
    theme.diagnosticInformationColor = SwColor{79, 154, 255};
    theme.scrollBarTrackColor = SwColor{30, 30, 30};
    theme.scrollBarThumbColor = SwColor{78, 78, 78};
    theme.scrollBarThumbHoverColor = SwColor{110, 110, 110};
    theme.borderRadius = 0;
    theme.scrollBarWidth = 14;
    return theme;
}

class SW_CODEEDITOR_EXPORT SwCodeEditor : public SwPlainTextEdit {
    SW_OBJECT(SwCodeEditor, SwPlainTextEdit)

public:
    struct CompletionEntry {
        SwString displayText;
        SwString insertText;
        SwString toolTip;
    };

    explicit SwCodeEditor(SwWidget* parent = nullptr);

    void setPlainText(const SwString& text) override;

    void appendPlainText(const SwString& text) override;

    void clear() override;

    SwTextDocument* document() const;

    int firstVisibleLine() const;

    void setDocument(SwTextDocument* doc);

    SwTextCursor textCursor() const;

    void setTextCursor(const SwTextCursor& cursor);

    void setSyntaxHighlighter(SwSyntaxHighlighter* highlighter);

    SwSyntaxHighlighter* syntaxHighlighter() const;

    void setDiagnostics(const SwList<SwTextDiagnostic>& diagnostics);

    SwList<SwTextDiagnostic> diagnostics() const;

    void clearDiagnostics();

    void setDiagnosticsProvider(SwTextDiagnosticsProvider* provider);

    SwTextDiagnosticsProvider* diagnosticsProvider() const;

    void setCompleter(SwCompleter* completer);

    SwCompleter* completer() const;

    void setCompletionProvider(const std::function<SwList<CompletionEntry>(SwCodeEditor*,
                                                                            const SwString&,
                                                                            size_t,
                                                                            bool)>& provider);

    void clearCompletionProvider();
    void showCompletions(const SwList<CompletionEntry>& entries, const SwString& prefix = SwString());
    void setCompletionInsertHandler(const std::function<bool(const SwString&)>& handler);
    void setSemanticFormats(const SwList<SwTextLayoutFormatRange>& formats);
    SwList<SwTextLayoutFormatRange> semanticFormats() const;

    /** Supplies the tooltip for an identifier under the pointer, without moving the text cursor.
     *  The position is a byte offset in the document; an empty result preserves diagnostics. */
    void setWordToolTipProvider(const std::function<SwString(const SwString&, size_t)>& provider);
    void clearWordToolTipProvider();
    SwString wordToolTipAtPosition(size_t position) const;

    void triggerCompletion();

    void setExtraSelections(const SwList<SwTextExtraSelection>& selections);

    SwList<SwTextExtraSelection> extraSelections() const;

    void setLineNumbersVisible(bool on);

    bool lineNumbersVisible() const;

    void setHighlightCurrentLine(bool on);

    bool highlightCurrentLine() const;

    void setCodeFoldingEnabled(bool on);

    bool codeFoldingEnabled() const;

    void setAutoCompletionEnabled(bool on);

    bool autoCompletionEnabled() const;

    void setAutoCompletionMinPrefixLength(int length);

    int autoCompletionMinPrefixLength() const;

    void setIndentSize(int spaces);

    int indentSize() const;

    void setTheme(const SwCodeEditorTheme& theme);

    SwCodeEditorTheme theme() const;

    int lineNumberAreaWidth() const;

    int firstVisibleBlock() const;

    SwRect blockBoundingRect(int blockNumber) const;

    SwRect cursorRect() const;

    SW_SIGNAL_VOID(cursorPositionChanged)
    SW_SIGNAL_VOID(selectionChanged)
    SW_SIGNAL(updateRequest, const SwRect&, int)

protected:
    EditState captureEditState() const override;

    void resizeEvent(ResizeEvent* event) override;

    void paintEvent(PaintEvent* event) override;

    void updateCursorFromPosition(int px, int py) override;

    void insertTextAt(size_t pos, const SwString& text) override;

    void eraseTextAt(size_t pos, size_t len) override;

    void mousePressEvent(MouseEvent* event) override;

    void mouseMoveEvent(MouseEvent* event) override;

    void mouseReleaseEvent(MouseEvent* event) override;

    void mouseDoubleClickEvent(MouseEvent* event) override;

    void wheelEvent(WheelEvent* event) override;

    void keyPressEvent(KeyEvent* event) override;

private:
    enum class FoldMoveBias {
        Preserve,
        PreferStart,
        PreferEnd
    };

    struct FoldRegion {
        int startLine{0};
        int endLine{0};
        bool collapsed{false};
    };

    bool foldingEnabled_() const;

    int foldMarkerRightInset_() const;

    int foldMarkerAreaWidth_() const;

    int visibleLineCount_() const;

    int documentLineForVisibleRow_(int row) const;

    int visibleRowForDocumentLine_(int line) const;

    int anchorVisibleRowForDocumentLine_(int line) const;

    int visibleLineForPainting_(int line) const;

    int visibleLinesForViewport_() const;

    static SwColor mixColor_(const SwColor& lhs, const SwColor& rhs, int lhsWeight, int rhsWeight);

    void clampFirstVisibleCodeLine_(int visibleLines);

    void clampHorizontalScroll_();

    void ensureCursorVisibleForCode_();

    void restoreViewportAfterMouseInteraction_(int previousFirstVisibleLine, int previousHorizontalScrollPx);

    int hoveredExpandedFoldRegionIndex_() const;

    int collapsedRegionContainingLine_(int line) const;

    int foldRegionIndexForStartLine_(int line) const;

    void coerceCursorIntoVisibleContent_(FoldMoveBias bias, bool preserveSelection);

    void normalizeCursorAfterKeyEvent_(const KeyEvent* event);

    SwVector<FoldRegion> parseFoldRegions_() const;

    void rebuildVisibleLineCache_();

    void refreshFolding_();

    bool toggleFoldAtLine_(int line);

    SwRect foldMarkerRectForLine_(const SwRect& gutterRect, int visibleRow, int firstVisibleRow, int lineHeight) const;

    bool isPointInFoldMarker_(int px, int py, int* outLine = nullptr) const;

    void drawFoldMarker_(SwPainter* painter,
                         const SwRect& gutterRect,
                         int visibleRow,
                         int firstVisibleRow,
                         int lineHeight,
                         int lineIndex,
                         const SwColor& baseColor) const;

    void drawFoldGuides_(SwPainter* painter,
                         const SwRect& gutterRect,
                         int firstVisibleRow,
                         int lastVisibleRow,
                         int lineHeight) const;

    void drawCollapsedLineIndicator_(SwPainter* painter, const SwRect& lineRect, int lineIndex, int contentEndX);

    SwString foldRegionPreviewText_(const FoldRegion& region) const;

    SwString foldMarkerToolTipAt_(int px, int py) const;

    void ensureDocument_();

    void bindDocument_();

    void syncFromDocument_();

    void syncDocumentFromPieceTable_();

    SwRect gutterRect_() const;

    SwRect gutterVisualRect_() const;

    struct ScrollLayout_ {
        bool showVertical{false};
        bool showHorizontal{false};
        SwRect textRect{};
    };

    SwRect baseContentRect_() const;

    int visibleLinesForHeight_(int height) const;

    int longestLineWidthPx_() const;

    ScrollLayout_ computeScrollLayout_() const;

    SwRect textRect_() const;

    int resolvedBorderWidth_() const;

    int drawLineText_(SwPainter* painter, const SwRect& lineRect, int lineIndex, const SwColor& defaultTextColor);

    SwList<SwTextLayoutFormatRange> mergedFormatsForLine_(int lineIndex) const;

    void appendDiagnosticFormatsForLine_(int lineIndex, SwList<SwTextLayoutFormatRange>& formats) const;

    SwTextCharFormat resolvedDiagnosticFormat_(const SwTextDiagnostic& diagnostic) const;

    int positionAtPoint_(int px, int py) const;

    SwString diagnosticToolTipAtPosition_(int position) const;

    void updateHoverToolTip_(MouseEvent* event);

    void insertCompletion_(const SwString& completion);

    SwString wordUnderCursor_() const;

    SwString completionPrefixUnderCursor_() const;

    size_t wordStartAt_(size_t pos) const;

    size_t wordEndAt_(size_t pos) const;

    static bool containsNewline_(const SwString& s);

    static bool shouldUseDeferredHighlight_(const SwString& text);

    void scheduleFoldRefresh_();

    void syncVisibleLineCacheAfterTextChange_();

    void ensureVisibleDeferredHighlight_();

    bool processDeferredHighlightChunk_();

    void scheduleDeferredHighlightWork_();

    void stopDeferredHighlightWork_();

    void pasteFromClipboardForCode_();

    void layoutScrollBar_();

    bool isPointInVerticalScrollBar_(int px, int py) const;

    bool isPointInHorizontalScrollBar_(int px, int py) const;

    bool dispatchMousePressToScrollBar_(MouseEvent* event);

    bool dispatchMouseMoveToScrollBar_(MouseEvent* event);

    bool dispatchMouseReleaseToScrollBar_(MouseEvent* event);

    bool dispatchMouseDoubleClickToScrollBar_(MouseEvent* event);

    int selectionAutoScrollDirectionForPoint_(const SwPoint& point) const;

    void updateSelectionAutoScrollState_();

    void stopSelectionAutoScroll_();

    bool applySelectionAutoScrollForPoint_(const SwPoint& point);

    void syncScrollBar_();

    void refreshCharWidthCache_() const;

    int textWidthMono_(size_t charCount) const;

    static bool isWordChar_(char ch);

    static wchar_t typedCharacter_(const KeyEvent* event);

    int documentLineCount_() const;

    size_t documentLength_() const;

    SwString documentLineText_(int lineIndex) const;

    size_t documentLineLength_(int lineIndex) const;

    char documentCharAt_(size_t pos) const;

    SwString documentSubstring_(size_t pos, size_t len) const;

    int lineIndexForPosition_(size_t pos) const;

    void emitEditorSignals_(size_t oldPos, size_t oldSelStart, size_t oldSelEnd);

    SwString indentationForLine_(int lineIndex) const;

    int visualColumnAtCursor_() const;

    char previousNonSpaceCharOnLine_(size_t pos) const;

    char nextNonSpaceCharOnLine_(size_t pos) const;

    bool isWhitespaceOnlyBetween_(size_t start, size_t end) const;

    SwString indentationForPosition_(size_t pos) const;

    SwString indentationForMatchingOpeningBrace_() const;

    bool shouldAutoIndentClosingBrace_() const;

    void insertSoftTab_();

    void unindentCurrentLine_();

    void insertAutoIndentedClosingBrace_();

    void insertIndentedNewLine_();

    void refreshCompletionPopup_(bool forceShow);

    static SwString cssColor_(const SwColor& color);
    void applyCompletionTheme_();
    size_t columnAtTextX_(const SwString& text, int relativeX, int viewportWidth) const;

    void applyThemeStyle_();

public:
    ~SwCodeEditor();
private:
    // What the class keeps (SwCodeEditor_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
