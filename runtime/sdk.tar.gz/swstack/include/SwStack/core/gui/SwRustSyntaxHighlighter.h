#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwRustSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat macroFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat lifetimeFormat;
    SwTextCharFormat attributeFormat;
    SwTextCharFormat constantFormat;
};

inline SwTextCharFormat swRustMakeFormat_(const SwColor& color,
                                           FontWeight weight = Normal,
                                           bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwRustSyntaxTheme swRustSyntaxThemeVsCodeDark() {
    SwRustSyntaxTheme theme;
    theme.keywordFormat   = swRustMakeFormat_(SwColor{197, 134, 192}, Medium);
    theme.typeFormat      = swRustMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat   = swRustMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat    = swRustMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat    = swRustMakeFormat_(SwColor{181, 206, 168});
    theme.macroFormat     = swRustMakeFormat_(SwColor{79, 193, 255});
    theme.functionFormat  = swRustMakeFormat_(SwColor{220, 220, 170});
    theme.lifetimeFormat  = swRustMakeFormat_(SwColor{86, 156, 214}, Normal, true);
    theme.attributeFormat = swRustMakeFormat_(SwColor{220, 220, 170});
    theme.constantFormat  = swRustMakeFormat_(SwColor{79, 193, 255});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwRustSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwRustSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwRustSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwRustSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BlockCommentState = 1
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int findBlockCommentEnd_(const SwString& text, int start);

    static int parseNumber_(const SwString& text, int start);

    static bool isAllUpperCase_(const SwString& word);

    static bool isKeyword_(const SwString& word);

    static bool isType_(const SwString& word);

public:
    ~SwRustSyntaxHighlighter();
private:
    // What the class keeps (SwRustSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
