#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwGuiConsoleApplication.h"

#include <memory>
#include <unordered_map>
#include <vector>

// The platform, which the public header no longer shows (SwGuiConsoleApplication.h).
#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include "platform/win/SwWindows.h"
#else
#include <termios.h>
#include <unistd.h>
#endif

class SwGuiConsoleApplication::ConsoleEchoGuard {
public:
    explicit ConsoleEchoGuard(bool echo);

    ~ConsoleEchoGuard();

private:
    bool m_enabled{false};
#if defined(_WIN32)
    HANDLE m_input{INVALID_HANDLE_VALUE};
    DWORD m_originalMode{0};
#else
    termios m_originalTermios{};
#endif
};

struct SwGuiConsoleApplication::Data : SwSharedData {
    Data() = default;

    Data(const Data& other)
        : SwSharedData(other), m_title(other.m_title), m_footer(other.m_footer),
          m_status(other.m_status), m_beforeRender(other.m_beforeRender),
          m_running(other.m_running) {
        std::vector<std::unique_ptr<Node>> owners;
        std::unordered_map<const Node*, Node*> copies;
        owners.reserve(other.m_storage.size());
        for (const Node* original : other.m_storage) {
            owners.emplace_back(new Node(*original));
            copies.emplace(original, owners.back().get());
        }
        for (size_t i = 0; i < other.m_storage.size(); ++i) {
            const Node* original = other.m_storage[i];
            Node* copy = owners[i].get();
            copy->parent = original->parent ? copies.at(original->parent) : nullptr;
            copy->children.clear();
            for (const Node* child : original->children) {
                copy->children.push_back(copies.at(child));
            }
            m_storage.push_back(copy);
        }
        m_root = other.m_root ? copies.at(other.m_root) : nullptr;
        for (auto& owner : owners) owner.release();
    }

    ~Data() {
        for (Node* node : m_storage) delete node;
    }

    Node* m_root{nullptr};
    SwVector<Node*> m_storage;
    SwString m_title;
    SwString m_footer;
    SwString m_status;
    std::function<void()> m_beforeRender;
    bool m_running{true};
};
