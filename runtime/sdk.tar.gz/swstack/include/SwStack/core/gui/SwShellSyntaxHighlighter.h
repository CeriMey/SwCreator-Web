#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwShellSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat builtinFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat variableFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat operatorFormat;
    SwTextCharFormat shebangFormat;
};

inline SwTextCharFormat swShellMakeFormat_(const SwColor& color,
                                           FontWeight weight = Normal,
                                           bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwShellSyntaxTheme swShellSyntaxThemeVsCodeDark() {
    SwShellSyntaxTheme theme;
    theme.keywordFormat    = swShellMakeFormat_(SwColor{197, 134, 192}, Medium);
    theme.builtinFormat    = swShellMakeFormat_(SwColor{220, 220, 170});
    theme.commentFormat    = swShellMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat     = swShellMakeFormat_(SwColor{206, 145, 120});
    theme.variableFormat   = swShellMakeFormat_(SwColor{156, 220, 254});
    theme.numberFormat     = swShellMakeFormat_(SwColor{181, 206, 168});
    theme.operatorFormat   = swShellMakeFormat_(SwColor{212, 212, 212});
    theme.shebangFormat    = swShellMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    return theme;
}

class SW_CODEEDITOR_EXPORT SwShellSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwShellSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwShellSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwShellSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        HeredocState = 1,
        SingleQuoteState = 2
    };

    static bool isWordStart_(char ch);

    static bool isWordChar_(char ch);

    static int findClosingQuote_(const SwString& text, int start, char quote);

    static int parseVariable_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isBuiltin_(const SwString& word);

public:
    ~SwShellSyntaxHighlighter();
private:
    // What the class keeps (SwShellSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
