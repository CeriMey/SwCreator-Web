#pragma once

/**
 * @file src/core/gui/SwWindow.h
 * @ingroup core_gui
 * @brief A native top-level window without widgets: QWindow's counterpart.
 *
 * SwWindow owns a window of the platform integration (SwPlatformWindow): its title, size and
 * position, its visibility. It receives the window system's events through virtual functions, with
 * the events SwWidget receives (SwGuiEvent.h), and paints with the platform's painter: paintEvent()
 * gets a PaintEvent whose painter draws on the window. An application that needs no widgets (a
 * game loop, a video surface, a map engine) subclasses it; SwMainWindow and SwDialog are widgets
 * shown in their own native window.
 *
 * The native window is created on first need: show(), create() or winId(). An SwGuiApplication must
 * exist then.
 */

#include "../SwStackExport.h"
#include "SwObject.h"
#include "SwGuiEvent.h"
#include "SwString.h"
#include "platform/SwPlatformIntegration.h"

class SW_GUI_EXPORT SwWindow : public SwObject {
    SW_OBJECT(SwWindow, SwObject)

public:
    explicit SwWindow(SwObject* parent = nullptr);
    ~SwWindow() override;

    // The native window, created once (show() creates it); destroy() releases it.
    void create();
    void destroy();
    bool isCreated() const;

    void setTitle(const SwString& title);
    SwString title() const;

    // How the window system shows it (main window, dialog, tool window; frame, taskbar): set it
    // before the window is created.
    void setOptions(const SwPlatformWindowOptions& options);
    SwPlatformWindowOptions options() const;

    // The client area's size, in pixels, and the window's position on screen.
    void resize(int width, int height);
    int width() const;
    int height() const;
    void setPosition(int x, int y);

    void show();
    void hide();
    void setVisible(bool visible);
    bool isVisible() const;

    // Asks the window to close: closeEvent() decides; an accepted close hides the window and emits
    // closed(). Returns whether it closed.
    bool close();

    // Schedules a paintEvent() of the whole window.
    void requestUpdate();

    // The native window (an HWND, an X11 Window, an ANativeWindow) and its display (X11), or null
    // before the window is created.
    void* winId() const;
    void* nativeDisplay() const;
    SwPlatformWindow* platformWindow() const;

    SW_SIGNAL(visibleChanged, bool);
    SW_SIGNAL(resized, int, int);
    SW_SIGNAL(activeChanged, bool);
    SW_SIGNAL_VOID(closed);

protected:
    // The window system's events. The default implementations do nothing (closeEvent accepts).
    virtual void paintEvent(PaintEvent* event);
    virtual void resizeEvent(ResizeEvent* event);
    virtual void mousePressEvent(MouseEvent* event);
    virtual void mouseReleaseEvent(MouseEvent* event);
    virtual void mouseDoubleClickEvent(MouseEvent* event);
    virtual void mouseMoveEvent(MouseEvent* event);
    virtual void mouseLeaveEvent();
    virtual void wheelEvent(WheelEvent* event);
    virtual void keyPressEvent(KeyEvent* event);
    virtual void keyReleaseEvent(KeyEvent* event);
    virtual void closeEvent(CloseEvent* event);
    virtual void activationChangeEvent(bool active);
    // The smallest client size the window system may give the window (0 x 0: no limit).
    virtual SwPlatformSize minimumClientSize() const;

private:
    // What the class keeps (SwWindow_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;

    void handlePaint_(const SwPlatformPaintEvent& event);
    void handleResize_(const SwPlatformSize& size);
    void handleMouse_(EventType type, const SwMouseEvent& event);
    void handleWheel_(const SwMouseEvent& event);
    void handleKey_(EventType type, const SwKeyEvent& event);
    bool handleClose_();
    void handleDestroyed_();
};
