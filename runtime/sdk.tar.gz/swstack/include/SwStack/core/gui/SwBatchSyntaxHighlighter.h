#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwBatchSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat commandFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat variableFormat;
    SwTextCharFormat labelFormat;
    SwTextCharFormat operatorFormat;
    SwTextCharFormat echoTextFormat;
};

inline SwTextCharFormat swBatchMakeFormat_(const SwColor& color,
                                            FontWeight weight = Normal,
                                            bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwBatchSyntaxTheme swBatchSyntaxThemeVsCodeDark() {
    SwBatchSyntaxTheme theme;
    theme.keywordFormat   = swBatchMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.commandFormat   = swBatchMakeFormat_(SwColor{220, 220, 170});
    theme.commentFormat   = swBatchMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat    = swBatchMakeFormat_(SwColor{206, 145, 120});
    theme.variableFormat  = swBatchMakeFormat_(SwColor{156, 220, 254});
    theme.labelFormat     = swBatchMakeFormat_(SwColor{78, 201, 176});
    theme.operatorFormat  = swBatchMakeFormat_(SwColor{212, 212, 212});
    theme.echoTextFormat  = swBatchMakeFormat_(SwColor{206, 145, 120});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwBatchSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwBatchSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwBatchSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwBatchSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    static bool isWordStart_(char ch);

    static bool isWordChar_(char ch);

    static int parseVariable_(const SwString& text, int start);

    void highlightEchoContent_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isCommand_(const SwString& word);

public:
    ~SwBatchSyntaxHighlighter();
private:
    // What the class keeps (SwBatchSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
