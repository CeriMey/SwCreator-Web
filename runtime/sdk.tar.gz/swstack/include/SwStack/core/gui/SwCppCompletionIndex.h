#pragma once

#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwCoreApplication.h"
#include "SwList.h"
#include "SwMap.h"
#include "SwObject.h"
#include "SwString.h"
#include "SwThreadPool.h"
#include "SwTimer.h"
#include "SwVector.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <functional>
#include <memory>

struct SW_CODEEDITOR_EXPORT SwCppCompletionItem {
    SwString displayText;
    SwString insertText;
    SwString toolTip;
};

class SW_CODEEDITOR_EXPORT SwCppCompletionIndex : public SwObject {
    SW_OBJECT(SwCppCompletionIndex, SwObject)

public:
    struct Stats {
        size_t textLength{0};
        int lineCount{0};
        int scopeCount{0};
        int typeCount{0};
        int symbolCount{0};
        long long lastBuildMs{0};
        bool ready{false};
    };

    explicit SwCppCompletionIndex(SwObject* parent = nullptr);

    void setThreadPool(SwThreadPool* pool);
    SwThreadPool* threadPool() const;

    void setTextProvider(const std::function<SwString()>& provider);
    void setAsyncEnabled(bool on);
    bool asyncEnabled() const;

    void setDebounceInterval(int ms);
    int debounceInterval() const;

    void scheduleRebuild();
    void rebuildNow();
    void rebuildNow(const SwString& text);

    bool isReady() const;
    bool hasPendingBuild() const;
    Stats stats() const;

    SwList<SwCppCompletionItem> completionItems(size_t cursorPos,
                                                const SwString& prefix,
                                                int maxItems = 256) const;
    bool shouldPreferArrowAccess(size_t cursorPos) const;

signals:
    SW_SIGNAL_VOID(indexUpdated)

private:
    struct MemberInfo {
        SwString name;
        bool method{false};
    };

    struct TypeInfo {
        SwString qualifiedName;
        SwString leafName;
        SwList<MemberInfo> members;
    };

    struct VariableInfo {
        SwString typeName;
        bool isPointer{false};
    };

    struct ScopeInfo {
        size_t begin{0};
        size_t end{0};
        int parent{-1};
        SwString className;
        SwMap<SwString, VariableInfo> variables;
    };

    struct AccessInfo {
        bool valid{false};
        bool usesArrow{false};
        size_t operatorPos{static_cast<size_t>(-1)};
        SwString baseName;
        SwString memberPrefix;
    };

    struct Snapshot {
        SwString text;
        SwString sanitized;
        SwList<SwString> globalWords;
        SwList<SwString> typeNames;
        SwMap<SwString, TypeInfo> types;
        SwVector<ScopeInfo> scopes;
        Stats stats;
    };

    static std::shared_ptr<Snapshot> buildSnapshot_(const SwString& text);
    void startAsyncRebuild_();
    void applySnapshot_(const std::shared_ptr<Snapshot>& snapshot);

    static bool isIdentifierStart_(char ch);
    static bool isIdentifierPart_(char ch);
    static bool startsWithKeywordAt_(const SwString& text, size_t pos, const char* keyword);
    static size_t skipSpaces_(const SwString& text, size_t pos);
    static SwString readIdentifier_(const SwString& text, size_t& pos);
    static SwString readQualifiedIdentifier_(const SwString& text, size_t& pos);
    static SwString sanitizeCodeForParsing_(const SwString& text);
    static SwString collapseWhitespace_(const SwString& text);
    static SwString extractIdentifierBefore_(const SwString& text, size_t pos);
    static SwList<SwString> splitTopLevelComma_(const SwString& text);
    static size_t findMatchingBrace_(const SwString& text, size_t openBrace);
    static SwString leafNameOfQualified_(const SwString& qualifiedName);
    static bool matchesPrefix_(const SwString& value, const SwString& prefix);
    static void appendUniqueWord_(SwList<SwString>& words, const SwString& word);
    static void appendUniqueString_(SwList<SwString>& words, const SwString& word);
    static void registerType_(Snapshot& snapshot, const SwString& qualifiedTypeName);
    static void appendTypeMember_(Snapshot& snapshot, const SwString& qualifiedTypeName, const MemberInfo& member);
    static SwString resolveKnownTypeName_(const Snapshot& snapshot, const SwString& candidate);
    static SwString resolveTypeNameAt_(const SwString& statement, const Snapshot& snapshot, size_t& typeEnd);
    static void registerDeclaredVariables_(const SwString& statement,
                                          const Snapshot& snapshot,
                                          SwMap<SwString, VariableInfo>& variables);
    static void registerFunctionParameters_(const SwString& header,
                                            const Snapshot& snapshot,
                                            SwMap<SwString, VariableInfo>& variables);
    static void collectDeclaredTypes_(Snapshot& snapshot,
                                      const SwString& sanitized,
                                      size_t begin,
                                      size_t end,
                                      const SwList<SwString>& scope);
    static void collectScopeSymbols_(const SwString& original,
                                     const SwString& sanitized,
                                     size_t begin,
                                     size_t end,
                                     SwList<SwString>& words);
    static void buildScopeIndex_(Snapshot& snapshot,
                                 const SwString& sanitized,
                                 size_t begin,
                                 size_t end,
                                 int scopeIndex);
    static int innermostScope_(const Snapshot& snapshot, size_t cursorPos);
    static int innermostClassScope_(const Snapshot& snapshot, size_t cursorPos);
    static void collectVisibleVariables_(const Snapshot& snapshot,
                                         size_t cursorPos,
                                         SwMap<SwString, VariableInfo>& variables);
    static AccessInfo accessInfoAt_(const SwString& text, size_t cursorPos);

public:
    ~SwCppCompletionIndex();
private:
    // What the class keeps (SwCppCompletionIndex_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

