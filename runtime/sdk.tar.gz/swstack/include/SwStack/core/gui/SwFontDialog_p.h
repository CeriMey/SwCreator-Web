#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwFontDialog.h"

struct SwFontDialog::Data {
    SwFont m_font;
    SwLabel* m_fontLabel{nullptr};
    SwLabel* m_sizeLabel{nullptr};
    SwComboBox* m_family{nullptr};
    SwSpinBox* m_size{nullptr};
    SwLabel* m_preview{nullptr};
    SwPushButton* m_ok{nullptr};
    SwPushButton* m_cancel{nullptr};
    int m_spacing{10};
};
