#pragma once

#include "SwUiLoader.h"
#include <functional>

namespace swui {

// Bind an existing getter/setter to the common reflection API. Modules can
// expose properties without coupling the designer to their concrete classes.
template<class Owner, class Value, auto Getter, auto Setter>
bool registerWidgetProperty(const char* name) {
    const bool registered = SwObject::registerPropertyAccessor(
        typeid(Owner).name(), name, typeid(Value).name(),
        [](SwObject* object, const void* value) {
            std::invoke(Setter, dynamic_cast<Owner*>(object), *static_cast<const Value*>(value));
        },
        [](const SwObject* object) -> const void* {
            static thread_local Value value;
            value = std::invoke(Getter, dynamic_cast<const Owner*>(object));
            return &value;
        },
        [](const SwObject* object) { return dynamic_cast<const Owner*>(object) != nullptr; });
    (void)swAnyTypeOf<Value>();
    return registered;
}

} // namespace swui
