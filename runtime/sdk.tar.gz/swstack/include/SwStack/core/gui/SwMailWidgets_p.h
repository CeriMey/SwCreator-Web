#pragma once
#include "SwMailWidgets.h"
struct SwMailMessageView::Data {
    SwJsonObject labels, message;
};
struct SwMailComposer::Data {
    SwJsonObject original;
    SwLineEdit *to = nullptr, *cc = nullptr, *bcc = nullptr, *subject = nullptr;
    SwPlainTextEdit* body = nullptr;
};
