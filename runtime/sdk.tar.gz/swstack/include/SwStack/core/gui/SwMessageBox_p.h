#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwMessageBox.h"

#include <map>

struct SwMessageBox::Data {
    Icon m_icon{NoIcon};
    SwString m_text;
    SwString m_informative;
    int m_textHeight{30};
    int m_infoHeight{0};
    int m_buttonsMask{Ok};
    int m_clicked{NoButton};
    IconWidget* m_iconWidget{nullptr};
    SwLabel* m_textLabel{nullptr};
    SwLabel* m_infoLabel{nullptr};
    SwVector<SwPushButton*> m_buttons;
    SwVector<int> m_buttonIds;
    std::map<int, SwString> m_buttonTexts;   // setButtonText()'s, by standard button
};
