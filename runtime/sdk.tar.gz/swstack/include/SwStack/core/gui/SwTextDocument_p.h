#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextDocument.h"

struct SwTextDocument::Data {
    SwList<SwTextBlock> m_blocks;
    SwList<SwTextList*> m_lists;
    SwList<SwTextTable*> m_tables;
    SwMap<std::string, SwImage> m_imageResources;
    int m_pageWidth{595};   // A4 in points (72 dpi)
    int m_pageHeight{842};
    SwFont m_defaultFont;
    SwTextCharFormat m_defaultCharFormat;
    bool m_modified{false};
    bool m_undoRedoEnabled{true};
    bool m_batchEditing{false};
    int m_batchOldBlockCount{0};
    int m_batchContentsChangePos{0};
    int m_batchContentsChangeRemoved{0};
    int m_batchContentsChangeAdded{0};
    bool m_batchHasChanges{false};
    int m_revision{0};
    int m_lastEditBlockHint{-1};
};

struct SwTextBlock::Data : SwSharedData {
    SwList<SwTextFragment> m_fragments;
    SwTextBlockFormat m_blockFormat;
    SwTextList* m_list{nullptr};
    int m_blockNumber{-1};
    int m_userState{-1};
    std::shared_ptr<SwTextBlockUserData> m_userData;
    SwList<SwTextLayoutFormatRange> m_additionalFormats;
    mutable SwString m_textCache;
    mutable bool m_textCacheDirty{true};
};
struct SwTextFragment::Data : SwSharedData {
    SwString m_text;
    SwTextCharFormat m_format;
};
struct SwTextList::Data : SwSharedData {
    SwTextListFormat m_format;
    SwList<int> m_blockIndices;
};
struct SwTextTable::Data : SwSharedData {
    int m_rows{0};
    int m_cols{0};
    SwTextTableFormat m_format;
    std::vector<Cell> m_cells;
    std::vector<SwTextTableCellFormat> m_cellFormats;
    int m_startBlock{-1};
};
