#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwIniSyntaxTheme {
    SwTextCharFormat sectionFormat;
    SwTextCharFormat keyFormat;
    SwTextCharFormat valueFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat equalFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat boolFormat;
};

inline SwTextCharFormat swIniMakeFormat_(const SwColor& color,
                                          FontWeight weight = Normal,
                                          bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) { format.setFontWeight(weight); }
    if (italic) { format.setFontItalic(true); }
    return format;
}

inline SwIniSyntaxTheme swIniSyntaxThemeVsCodeDark() {
    SwIniSyntaxTheme theme;
    theme.sectionFormat = swIniMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.keyFormat     = swIniMakeFormat_(SwColor{156, 220, 254});
    theme.valueFormat   = swIniMakeFormat_(SwColor{206, 145, 120});
    theme.commentFormat = swIniMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.equalFormat   = swIniMakeFormat_(SwColor{212, 212, 212});
    theme.stringFormat  = swIniMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat  = swIniMakeFormat_(SwColor{181, 206, 168});
    theme.boolFormat    = swIniMakeFormat_(SwColor{86, 156, 214});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwIniSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwIniSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwIniSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwIniSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    static bool isNumber_(const SwString& text);

public:
    ~SwIniSyntaxHighlighter();
private:
    // What the class keeps (SwIniSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
