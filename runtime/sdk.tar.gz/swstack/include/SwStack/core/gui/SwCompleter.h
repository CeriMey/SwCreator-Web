#pragma once

#include <memory>
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwListView.h"
#include "SwSortFilterProxyModel.h"
#include "SwStandardItemModel.h"
#include "SwWidgetPlatformAdapter.h"

class SW_WIDGETS_EXPORT SwCompleter : public SwObject {
    SW_OBJECT(SwCompleter, SwObject)

public:
    enum CompletionMode {
        PopupCompletion,
        InlineCompletion,
        UnfilteredPopupCompletion
    };

    enum ModelSorting {
        UnsortedModel,
        CaseSensitivelySortedModel,
        CaseInsensitivelySortedModel
    };

    explicit SwCompleter(SwObject* parent = nullptr);

    void setWidget(SwWidget* widget);

    SwWidget* widget() const;

    void setModel(SwAbstractItemModel* model);

    SwAbstractItemModel* model() const;

    void setStringList(const SwList<SwString>& values);

    void setPopup(SwListView* popup);

    SwListView* popup();

    const SwListView* popup() const;

    void setCompletionPrefix(const SwString& prefix);

    SwString completionPrefix() const;

    void setCompletionMode(CompletionMode mode);
    CompletionMode completionMode() const;

    void setCaseSensitivity(Sw::CaseSensitivity cs);

    Sw::CaseSensitivity caseSensitivity() const;

    void setCompletionRole(SwItemDataRole role);

    SwItemDataRole completionRole() const;

    void setCompletionColumn(int column);

    int completionColumn() const;

    void setMaxVisibleItems(int maxItems);

    int maxVisibleItems() const;

    void setWrapAround(bool on);
    bool wrapAround() const;

    void setModelSorting(ModelSorting sorting);
    ModelSorting modelSorting() const;

    int completionCount() const;

    SwModelIndex currentIndex() const;

    SwString currentCompletion() const;

    bool popupVisible() const;

    void complete(const SwRect& rect = SwRect{0, 0, 0, 0});

    void hidePopup();

    bool handleEditorKeyPress(KeyEvent* event);

    SW_SIGNAL(activated, const SwString&)
    SW_SIGNAL(highlighted, const SwString&)

private:
    SwAbstractItemModel* activeModel_() const;

    void ensurePopup_();

    void ensurePopupParent_();

    void configurePopup_();

    void refreshPopupModel_();

    void updateFiltering_();

    void hidePopup_();

    void activateCurrent_();

    int nextRow_(int currentRow, int delta, int rowCount) const;

    static bool isTabKey_(int keyCode);

    static SwString regexEscape_(const SwString& text);

    static SwWidget* topLevelWidget_(SwWidget* widget);

public:
    ~SwCompleter();
private:
    // What the class keeps (SwCompleter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
