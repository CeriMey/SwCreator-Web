#pragma once

#include <memory>
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextDocument.h"

class SW_GUI_EXPORT SwSyntaxHighlighter : public SwObject {
    SW_OBJECT(SwSyntaxHighlighter, SwObject)

public:
    explicit SwSyntaxHighlighter(SwTextDocument* parent = nullptr);

    virtual ~SwSyntaxHighlighter();

    void setDocument(SwTextDocument* doc);

    SwTextDocument* document() const;

    void rehighlight();

    void rehighlightBlock(int blockIndex);

    SwList<SwTextLayoutFormatRange> formatRanges(int blockIndex) const;

    void setAutoRehighlightSuspended(bool suspended);

    bool autoRehighlightSuspended() const;

    bool hasDeferredRehighlight() const;

    int deferredRehighlightStartBlock() const;

    bool processDeferredRehighlight(int maxBlocks);

    bool processDeferredRehighlightUpTo(int targetBlock);

    void rehighlightWindow(int firstBlock, int lastBlock, int lookBehind = 256);

    void rehighlightFrom(int startBlock);

    SW_SIGNAL_VOID(formattingChanged)

protected:
    virtual void highlightBlock(const SwString& text) = 0;

    void setFormat(int start, int count, const SwTextCharFormat& format);

    int previousBlockState() const;

    int currentBlockState() const;

    void setCurrentBlockState(int newState);

    void setCurrentBlockUserData(SwTextBlockUserData* data);

    SwTextBlockUserData* currentBlockUserData() const;

private:
    int blockIndexForPosition_(int absPos) const;

    void clearDeferredRehighlight_();

    void queueDeferredRehighlight_(int startBlock);

    void rehighlightRangeInternal_(int startBlock, int endBlock, bool allowEarlyStop);

private:
    // What the class keeps (SwSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
