#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwWidget.h"

struct SwWidget::Data {
    FocusPolicyEnum m_FocusPolicy = FocusPolicyEnum::Accept;
    bool m_FocusPolicy_registered_ = sw_register_FocusPolicy_();
    SwString m_ToolTips = "";
    bool m_ToolTips_registered_ = sw_register_ToolTips_();
    bool m_Enable = true;
    bool m_Enable_registered_ = sw_register_Enable_();
    bool m_Focus{false};
    bool m_Focus_registered_ = sw_register_Focus_();
    bool m_Hover = false;
    bool m_Hover_registered_ = sw_register_Hover_();
    bool m_Visible = true;
    bool m_Visible_registered_ = sw_register_Visible_();
    CursorType m_Cursor = CursorType::Default;
    bool m_Cursor_registered_ = sw_register_Cursor_();
    SwFont m_Font = SwFont();
    bool m_Font_registered_ = sw_register_Font_();
    SwString m_StyleSheet = "";
    bool m_StyleSheet_registered_ = sw_register_StyleSheet_();
    int m_width;
    int m_height;
    int m_minWidth;
    int m_minHeight;
    int m_maxWidth;
    int m_maxHeight;
    int m_absX, m_absY;
    SwStyle *m_style;
    SwWidgetPlatformHandle m_nativeWindowHandle;
    SwWidget* m_parentWidgetCached{nullptr};
    SwWidget* m_mouseGrabberWidget{nullptr};
    unsigned int m_mouseGrabButtons{0};
    unsigned int m_nativeModalInputBlocks{0};
    SwList<SwWidget*> m_hoveredPath_;
    bool m_visibilityEventInFlight{false};
    bool m_SuppressImplicitResizeUpdate_{false};
    SwString m_DefaultStyleSheet;
    StyleSheet m_DefaultComplexSheet;
    StyleSheet m_ComplexSheet;
    bool m_StyleSheetInheritanceEnabled{true};
    mutable StyleSheet m_EffectiveSheet;
    mutable bool m_EffectiveSheetDirty{true};
    mutable SwList<SwString> m_StyleSelectorsCache;
    mutable bool m_StyleSelectorsCacheInitialized{false};
    mutable ResolvedStyleSnapshot_ m_ResolvedStyleSnapshot;
    mutable bool m_ResolvedStyleSnapshotDirty{true};
    mutable bool m_cachedVisibleInHierarchy{true};
    mutable bool m_visibleInHierarchyDirty{true};
    bool m_swWidgetChildrenDirty{true};
    SwList<SwWidget*> m_swWidgetChildren;
    SwAbstractLayout* m_layout;
};
