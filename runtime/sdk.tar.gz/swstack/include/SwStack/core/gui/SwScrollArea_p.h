#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwScrollArea.h"

struct SwScrollArea::Data {
    Viewport* m_viewport{nullptr};
    SwWidget* m_widget{nullptr};
    SwScrollBar* m_hBar{nullptr};
    SwScrollBar* m_vBar{nullptr};
    bool m_widgetResizable{false};
    int m_scrollBarThickness{14};
    bool m_inUpdateLayout{false};
    bool m_updateLayoutQueued{false};
};
