﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwListView.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwListView in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the list view interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwListView.
 *
 * View-oriented declarations here mainly describe how underlying state is projected into a visual
 * or interactive surface, including how refresh, selection, or presentation concerns are exposed
 * at the API boundary.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwListView - list view for SwAbstractItemModel.
 *
 * Focus:
 * - Premium default look (web-ish spacing, hover/selection).
 * - Simple single-selection via SwItemSelectionModel.
 * - Delegate-based rendering via SwStyledItemDelegate.
 **************************************************************************************************/

#include "SwAbstractItemModel.h"
#include "SwItemSelectionModel.h"
#include "SwScrollBar.h"
#include "SwScrollBarPolicy.h"
#include "SwStyledItemDelegate.h"
#include "SwWidget.h"
#include "SwWidgetPlatformAdapter.h"
#include "SwDragDrop.h"

#include "core/types/SwVector.h"
#include <algorithm>
#include <cstdlib>

class SW_WIDGETS_EXPORT SwListView : public SwWidget {
    SW_OBJECT(SwListView, SwWidget)

public:
    enum class ViewMode {
        ListMode,
        IconMode,
    };

    /**
     * @brief Constructs a `SwListView` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwListView(SwWidget* parent = nullptr);

    /**
     * @brief Sets the view Mode.
     * @param mode Mode value that controls the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setViewMode(ViewMode mode);

    /**
     * @brief Returns the current view Mode.
     * @return The current view Mode.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    ViewMode viewMode() const;

    // Only used in IconMode. In ListMode it is ignored.
    /**
     * @brief Sets the grid Size.
     * @param size Size value used by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setGridSize(const SwSize& size);

    /**
     * @brief Returns the current grid Size.
     * @return The current grid Size.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSize gridSize() const;

    /**
     * @brief Sets the spacing.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSpacing(int px);

    /**
     * @brief Returns the current spacing.
     * @return The current spacing.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int spacing() const;

    /**
     * @brief Sets the model.
     * @param model Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setModel(SwAbstractItemModel* model);

    /**
     * @brief Returns the current model.
     * @return The current model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwAbstractItemModel* model() const;

    /**
     * @brief Sets the selection Model.
     * @param selectionModel Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSelectionModel(SwItemSelectionModel* selectionModel);

    /**
     * @brief Returns the current selection Model.
     * @return The current selection Model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwItemSelectionModel* selectionModel() const;

    /**
     * @brief Sets the drag Enabled.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDragEnabled(bool on);
    /**
     * @brief Returns the current drag Enabled.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dragEnabled() const;

    /**
     * @brief Sets the accept Drops.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAcceptDrops(bool on);
    /**
     * @brief Returns the current accept Drops.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool acceptDrops() const;

    /**
     * @brief Sets the drop Indicator Shown.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDropIndicatorShown(bool on);
    /**
     * @brief Returns the current drop Indicator Shown.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dropIndicatorShown() const;

    /**
     * @brief Sets the item Delegate.
     * @param delegate Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItemDelegate(SwStyledItemDelegate* delegate);

    /**
     * @brief Returns the current item Delegate.
     * @return The current item Delegate.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStyledItemDelegate* itemDelegate() const;

    /**
     * @brief Sets the uniform Row Heights.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setUniformRowHeights(bool on);

    /**
     * @brief Returns the current uniform Row Heights.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool uniformRowHeights() const;

    /**
     * @brief Sets the viewport Padding.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setViewportPadding(int px);

    /**
     * @brief Returns the current viewport Padding.
     * @return The current viewport Padding.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int viewportPadding() const;

    /**
     * @brief Sets the row Height.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRowHeight(int px);

    /**
     * @brief Returns the current row Height.
     * @return The current row Height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int rowHeight() const;

    /**
     * @brief Sets the scroll Bar Thickness.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setScrollBarThickness(int px);

    /**
     * @brief Returns the current scroll Bar Thickness.
     * @return The current scroll Bar Thickness.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int scrollBarThickness() const;

    /**
     * @brief Sets the alternating Row Colors.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAlternatingRowColors(bool on);

    /**
     * @brief Returns the current alternating Row Colors.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool alternatingRowColors() const;

    /**
     * @brief Sets the vertical Scroll Bar Policy.
     * @param policy Policy value applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setVerticalScrollBarPolicy(SwScrollBarPolicy policy);

    /**
     * @brief Returns the current vertical Scroll Bar Policy.
     * @return The current vertical Scroll Bar Policy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBarPolicy verticalScrollBarPolicy() const;

    /**
     * @brief Returns the current vertical Scroll Bar.
     * @return The current vertical Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBar* verticalScrollBar() const;

    /**
     * @brief Performs the `scrollToTop` operation.
     */
    void scrollToTop();

    /**
     * @brief Performs the `scrollToBottom` operation.
     */
    void scrollToBottom();

    /**
     * @brief Sets the index Widget.
     * @param index Value passed to the method.
     * @param widget Widget associated with the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIndexWidget(const SwModelIndex& index, SwWidget* widget);

    /**
     * @brief Performs the `indexAt` operation.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     * @return The requested index At.
     */
    SwModelIndex indexAt(int px, int py) const;

signals:
    SW_SIGNAL(clicked, const SwModelIndex&);
    SW_SIGNAL(doubleClicked, const SwModelIndex&);
    SW_SIGNAL(activated, const SwModelIndex&);
    SW_SIGNAL(contextMenuRequested, const SwModelIndex&, int, int);
    SW_SIGNAL(dragStarted, const SwModelIndex&);
    SW_SIGNAL(dragMoved, const SwModelIndex&, int, int);
    SW_SIGNAL(dragDropped, const SwModelIndex&, const SwModelIndex&);

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Double Click Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseDoubleClickEvent(MouseEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

private:
    struct IndexWidgetEntry {
        SwModelIndex index;
        SwWidget* widget{nullptr};
    };

    void resetDragDropState_(bool endVisual);

    static bool containsPoint(const SwRect& r, int px, int py);

    static bool rectContains(const SwRect& outer, const SwRect& inner);

    int rowCount() const;

    int contentHeight() const;

    void initDefaults();

    void ensureDefaultDelegate();

    SwRect viewportRect(const SwRect& bounds) const;

    SwRect contentViewportRect(const SwRect& bounds) const;

    void updateLayout();

    void resetScrollBars();

    int rowAt(int px, int py) const;

    void ensureRowVisible(int row);

    void paintRows(SwPainter* painter, const SwRect& viewport);

    void clearIndexWidgets();

    void updateIndexWidgetsGeometry();

    int iconCellW_() const;
    int iconCellH_() const;

    int iconStepX_() const;
    int iconStepY_() const;

    int iconColumns_(const SwRect& viewport) const;

    int iconContentHeightForWidth_(int viewportW) const;

    SwRect iconCellRect_(const SwRect& viewport, int row, int offsetY) const;

    void invalidateRowMetrics_();

    void ensureRowMetrics_() const;
public:
    ~SwListView();
private:
    // What the class keeps (SwListView_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

