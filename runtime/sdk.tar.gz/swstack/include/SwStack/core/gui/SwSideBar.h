#pragma once

#include "SwWidget.h"

class SwVerticalLayout;

/** Responsive navigation container. User content belongs to contentWidget().
 * Compact mode changes button presentation without changing their text/icons.
 * Hidden/compact panels reveal above their siblings, retaining their dock width.
 * All configuration below uses SwObject properties, including the timings in ms.
 */
class SW_WIDGETS_EXPORT SwSideBar : public SwWidget {
    SW_OBJECT(SwSideBar, SwWidget)
public:
    enum class Mode { Expanded, Compact, Hidden, Automatic };
    enum class Edge { Left, Right };

    explicit SwSideBar(SwWidget* parent = nullptr);
    ~SwSideBar() override;

    SW_PROPERTY_D(SwString, Mode);
    SW_PROPERTY_D(SwString, Edge);
    SW_PROPERTY_D(bool, Pinned);
    SW_PROPERTY_D(int, ExpandedWidth);
    SW_PROPERTY_D(int, CompactWidth);
    SW_PROPERTY_D(int, HiddenWidth);
    SW_PROPERTY_D(int, CompactBreakpoint);
    SW_PROPERTY_D(int, HiddenBreakpoint);
    SW_PROPERTY_D(int, BreakpointHysteresis);
    SW_PROPERTY_D(int, RevealDelay);
    SW_PROPERTY_D(int, HideDelay);
    SW_PROPERTY_D(int, AnimationDuration);
    SW_PROPERTY_D(bool, HoverReveal);
    SW_PROPERTY_D(bool, AutoHide);
    SW_PROPERTY_D(bool, CloseOnOutsideClick);
    SW_PROPERTY_D(bool, PinButtonVisible);
    SW_PROPERTY_D(bool, ToggleButtonVisible);
    SW_PROPERTY_D(int, ContentPadding);
    SW_PROPERTY_D(int, ItemSpacing);
    SW_PROPERTY_D(SwString, Title);
    SW_PROPERTY_D(SwString, ColorScheme);

public:
    Mode mode() const;
    void setMode(Mode mode);
    Edge edge() const;
    void setEdge(Edge edge);
    Mode effectiveMode() const;
    bool isRevealed() const;
    bool isPinned() const;
    int dockWidth() const;
    bool isAnimating() const;

    SwWidget* contentWidget() const;
    // Takes ownership, replacing/deleting the old content. nullptr creates empty content.
    void setWidget(SwWidget* content);
    void setLayout(SwAbstractLayout* layout);
    void addWidget(SwWidget* widget, int stretch = 0);
    void addSpacing(int pixels);
    void addStretch(int stretch = 1);
    void refresh();

    // Public slots, usable by UI connections or ordinary SwObject::connect.
    void expand();
    void collapse();
    void minimize();
    void useAutomaticMode();
    void toggle();
    void reveal();
    void dismiss();
    void pin();
    void unpin();
    void togglePinned();

    SW_SIGNAL(effectiveModeChanged, const SwString&);
    SW_SIGNAL(revealedChanged, bool);
    SW_SIGNAL(dockWidthChanged, int);
    SW_SIGNAL_VOID(opened);
    SW_SIGNAL_VOID(closed);
    SW_SIGNAL_VOID(expanded);
    SW_SIGNAL_VOID(collapsed);
    SW_SIGNAL_VOID(minimized);
    SW_SIGNAL_VOID(animationFinished);

    // Editor behavior is transient and is never serialized as a configuration property.
    void setDesignMode(bool enabled);
    bool isDesignMode() const;
    bool isInternalWidget(const SwWidget* widget) const;
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;

protected:
    void resizeEvent(ResizeEvent* event) override;
    void paintEvent(PaintEvent* event) override;
    void mousePressEvent(MouseEvent* event) override;
    void keyPressEvent(KeyEvent* event) override;
    void on_Hover_changed(const bool& hovered) override;
    void on_StyleSheet_changed(const SwString& style) override;
    bool eventFilter(SwObject* watched, SwEvent* event) override;

private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};
