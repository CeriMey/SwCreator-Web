#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwScrollBar.h"

struct SwScrollBar::Data {
    Orientation m_orientation{Orientation::Vertical};
    int m_minimum{0};
    int m_maximum{100};
    int m_value{0};
    int m_pageStep{10};
    int m_singleStep{1};
    bool m_dragging{false};
    int m_dragOffset{0};
};
