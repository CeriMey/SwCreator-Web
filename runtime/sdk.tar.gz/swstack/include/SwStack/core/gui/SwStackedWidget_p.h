#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwStackedWidget.h"

struct SwStackedWidget::Data {
    SwVector<SwWidget*> m_widgets;
    int m_currentIndex{-1};
    int m_padding{0};
};
