/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include <memory>
#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwLayout.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwLayout in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the layout interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwSizePolicy, SwLayoutItem, SwSpacerItem,
 * SwAbstractLayout, SwBoxLayout, SwVerticalLayout, SwHorizontalLayout, SwGridLayout, and
 * SwFormLayout.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

#include <algorithm>
#include <functional>
#include <limits>

#include "SwVector.h"
#include "SwObject.h"

class SwWidget;

enum class SwOrientationFlag {
    Horizontal = 0x1,
    Vertical = 0x2
};

using SwOrientations = SwFlagSet<SwOrientationFlag>;

class SW_WIDGETS_EXPORT SwSizePolicy {
public:
    enum PolicyFlag {
        GrowFlag = 0x1,
        ExpandFlag = 0x2,
        ShrinkFlag = 0x4,
        IgnoreFlag = 0x8
    };

    enum Policy {
        Fixed = 0,
        Minimum = GrowFlag,
        Maximum = ShrinkFlag,
        Preferred = GrowFlag | ShrinkFlag,
        MinimumExpanding = GrowFlag | ExpandFlag,
        Expanding = GrowFlag | ShrinkFlag | ExpandFlag,
        Ignored = GrowFlag | ShrinkFlag | IgnoreFlag
    };

    explicit SwSizePolicy(Policy horizontalPolicy = Preferred, Policy verticalPolicy = Preferred);

    void setHorizontalPolicy(Policy policy);

    void setVerticalPolicy(Policy policy);

    Policy horizontalPolicy() const;

    Policy verticalPolicy() const;

    SwOrientations expandingDirections() const;

    static bool canGrow(Policy policy);

    static bool canShrink(Policy policy);

    static bool hasExpandFlag(Policy policy);

    static bool shouldIgnoreSizeHint(Policy policy);

private:
    Policy m_horizontalPolicy;
    Policy m_verticalPolicy;
};

class SwAbstractLayout;
class SwLayoutItem;
class SwSpacerItem;

class SW_WIDGETS_EXPORT SwLayoutItem {
public:
    explicit SwLayoutItem(int alignment = 0);

    virtual ~SwLayoutItem();

    int alignment() const;

    void setAlignment(int alignment);

    virtual SwOrientations expandingDirections() const = 0;
    virtual SwRect geometry() const = 0;
    virtual bool isEmpty() const = 0;
    virtual SwAbstractLayout* layout();
    virtual SwSize maximumSize() const = 0;
    virtual SwSize minimumSize() const = 0;
    virtual void setGeometry(const SwRect& rect) = 0;
    virtual SwSize sizeHint() const = 0;
    virtual SwSpacerItem* spacerItem();
    virtual SwWidget* widget() const;

private:
    int m_alignment;

protected:
    // Reserved for the virtual functions a later 1.x adds (docs/BINARY_COMPATIBILITY.md): a class
    // that reimplements it handles its own ids and passes the others to its base.
    virtual void virtual_hook(int id, void* data);
};

class SW_WIDGETS_EXPORT SwWidgetItem : public SwLayoutItem {
public:
    explicit SwWidgetItem(SwWidget* widget);

    SwOrientations expandingDirections() const override;

    SwRect geometry() const override;

    bool isEmpty() const override;

    SwSize maximumSize() const override;

    SwSize minimumSize() const override;

    void setGeometry(const SwRect& rect) override;

    SwSize sizeHint() const override;

    SwWidget* widget() const override;

private:
    SwWidget* m_widget{nullptr};
    SwRect m_geometry{0, 0, 0, 0};
};

class SW_WIDGETS_EXPORT SwSpacerItem : public SwLayoutItem {
public:
    explicit SwSpacerItem(int width,
                          int height,
                          SwSizePolicy::Policy horizontalPolicy = SwSizePolicy::Minimum,
                          SwSizePolicy::Policy verticalPolicy = SwSizePolicy::Minimum);

    void changeSize(int width,
                    int height,
                    SwSizePolicy::Policy horizontalPolicy = SwSizePolicy::Minimum,
                    SwSizePolicy::Policy verticalPolicy = SwSizePolicy::Minimum);

    SwSizePolicy sizePolicy() const;

    SwOrientations expandingDirections() const override;

    SwRect geometry() const override;

    bool isEmpty() const override;

    SwSize maximumSize() const override;

    SwSize minimumSize() const override;

    void setGeometry(const SwRect& rect) override;

    SwSize sizeHint() const override;

    SwSpacerItem* spacerItem() override;

private:
    static int minimumForAxis_(int hint, SwSizePolicy::Policy policy);

    static int maximumForAxis_(int hint, SwSizePolicy::Policy policy);

    int m_width{0};
    int m_height{0};
    SwSizePolicy m_sizePolicy;
    SwRect m_geometry{0, 0, 0, 0};
};

class SW_WIDGETS_EXPORT SwAbstractLayout : public SwObject {
public:
    explicit SwAbstractLayout(SwWidget* parent = nullptr);

    virtual ~SwAbstractLayout();

    void setParentWidget(SwWidget* parent);

    SwWidget* parentWidget() const;

    void setSpacing(int spacing);

    int spacing() const;

    void setMargin(int margin);

    int margin() const;

    void setLeftMargin(int margin);

    void setTopMargin(int margin);

    void setRightMargin(int margin);

    void setBottomMargin(int margin);

    int leftMargin() const;

    int topMargin() const;

    int rightMargin() const;

    int bottomMargin() const;

    void setContentsMargins(int left, int top, int right, int bottom);

    virtual SwSize sizeHint() const;

    virtual SwSize minimumSizeHint() const;

    virtual void forEachManagedWidget(const std::function<void(SwWidget*)>& visitor) const;

    void updateGeometry();
    void beginUpdate();
    void endUpdate();

    void invalidateLayout();

protected:
    void adoptWidgetToParent_(SwWidget* widget) const;

    SwRect contentRect() const;

    virtual void applyLayout(const SwRect& rect) = 0;

private:
private:
    // What the class keeps (SwLayout_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwBoxLayout : public SwAbstractLayout {
public:
    struct Item {
        SwLayoutItem* item{nullptr};
        int stretch{0};
        int minSize{-1};
    };

    explicit SwBoxLayout(SwWidget* parent = nullptr);

    virtual ~SwBoxLayout();

    void addItem(SwLayoutItem* item);

    void insertItem(int index, SwLayoutItem* item);

    void addSpacerItem(SwSpacerItem* spacerItem);

    void insertSpacerItem(int index, SwSpacerItem* spacerItem);

    void addSpacing(int size);

    void insertSpacing(int index, int size);

    void addStretch(int stretch = 0);

    void insertStretch(int index, int stretch = 0);

    void addWidget(SwWidget* widget, int stretch = 0, int minSize = -1);

    void insertWidget(int index, SwWidget* widget, int stretch = 0, int minSize = -1);

    void removeWidget(SwWidget* widget);

    void setStretch(int index, int stretch);

    bool setStretchFactor(SwWidget* widget, int stretch);

    int stretch(int index) const;

    void forEachManagedWidget(const std::function<void(SwWidget*)>& visitor) const override;

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    const SwVector<Item>& items() const;

protected:
    virtual SwOrientationFlag primaryOrientation() const = 0;

    void applyBoxLayout_(const SwRect& rect);

private:
    int normalizeIndex_(int index) const;

    bool containsWidget_(SwWidget* widget) const;

    void insertItemInternal_(int index, SwLayoutItem* item, int stretch, int minSize);

    void removeIf_(const std::function<bool(const Item&)>& predicate);

    void clearItems_();

    SwSize layoutSizeHint_(bool minimum) const;

    int primaryPreferredSize_(const Item& item, bool horizontal) const;

    int primaryMinimumSize_(const Item& item, bool horizontal) const;

    int crossPreferredSize_(const Item& item, bool horizontal) const;

    int crossMinimumSize_(const Item& item, bool horizontal) const;

    int resolvedCrossSize_(const Item& item, bool horizontal, int availableCross) const;

    bool spacerCanGrow_(const Item& item, bool horizontal) const;

    SwSpacerItem* makeSpacingItem_(int size) const;

    SwSpacerItem* makeStretchItem_() const;

private:
    // What the class keeps (SwLayout_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwVerticalLayout : public SwBoxLayout {
public:
    explicit SwVerticalLayout(SwWidget* parent = nullptr);

protected:
    SwOrientationFlag primaryOrientation() const override;

    void applyLayout(const SwRect& rect) override;
};

class SW_WIDGETS_EXPORT SwHorizontalLayout : public SwBoxLayout {
public:
    explicit SwHorizontalLayout(SwWidget* parent = nullptr);

protected:
    SwOrientationFlag primaryOrientation() const override;

    void applyLayout(const SwRect& rect) override;
};

class SW_WIDGETS_EXPORT SwGridLayout : public SwAbstractLayout {
public:
    struct Cell {
        SwLayoutItem* item{nullptr};
        int row{0};
        int column{0};
        int rowSpan{1};
        int columnSpan{1};
    };

    explicit SwGridLayout(SwWidget* parent = nullptr);

    ~SwGridLayout() override;

    void setHorizontalSpacing(int value);

    void setVerticalSpacing(int value);

    void setColumnStretch(int column, int stretch);

    void setRowStretch(int row, int stretch);

    int rowCount() const;

    int columnCount() const;

    const SwVector<Cell>& cells() const;

    const Cell* cellForWidget(const SwWidget* widget) const;

    Cell* cellForWidget(SwWidget* widget);

    const Cell* cellAtPosition(int row, int column) const;

    SwWidget* itemAtPosition(int row, int column) const;

    bool isCellRangeAvailable(int row,
                              int column,
                              int rowSpan = 1,
                              int columnSpan = 1,
                              const SwWidget* ignoreWidget = nullptr) const;

    bool setWidgetPosition(SwWidget* widget,
                           int row,
                           int column,
                           int rowSpan = 1,
                           int columnSpan = 1);

    bool moveWidget(SwWidget* widget, int row, int column);

    bool insertRow(int row);

    bool insertColumn(int column);

    bool removeRow(int row);

    bool removeColumn(int column);

    bool cellRect(int row, int column, SwRect* outRect) const;

    // Hit-test all tracks using one metrics pass (coordinates in the parent widget).
    bool nearestCell(int x, int y, int* outRow, int* outColumn, SwRect* outRect) const;
    bool trackRects(SwVector<SwRect>* outRows, SwVector<SwRect>* outColumns) const;

    bool cellRectForContentRect(const SwRect& contentRect, int row, int column, SwRect* outRect) const;

    void addItem(SwLayoutItem* item, int row, int column, int rowSpan = 1, int columnSpan = 1);

    void addWidget(SwWidget* widget, int row, int column, int rowSpan = 1, int columnSpan = 1);

    void removeWidget(SwWidget* widget);

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    void forEachManagedWidget(const std::function<void(SwWidget*)>& visitor) const override;

protected:
    void applyLayout(const SwRect& rect) override;

private:
    struct GridMetrics {
        int rows{0};
        int columns{0};
        SwRect rect{0, 0, 0, 0};
        SwVector<int> rowSizes;
        SwVector<int> columnSizes;
        SwVector<int> rowPositions;
        SwVector<int> columnPositions;
    };

    static int resolveItemExtent_(SwLayoutItem* item, bool horizontal, int availableExtent);

    SwSize layoutSizeHint_(bool minimum) const;

    void computeDimensions_(int& rows, int& columns) const;

    static bool spansOverlap_(int rowA,
                              int columnA,
                              int rowSpanA,
                              int columnSpanA,
                              int rowB,
                              int columnB,
                              int rowSpanB,
                              int columnSpanB);

    const Cell* findCellForWidget_(const SwWidget* widget) const;

    Cell* findCellForWidget_(SwWidget* widget);

    const Cell* findCellAtPosition_(int row, int column, const SwWidget* ignoreWidget) const;

    bool isCellRangeAvailable_(int row,
                               int column,
                               int rowSpan,
                               int columnSpan,
                               const SwWidget* ignoreWidget) const;

    static void ensureSpanMinimum_(SwVector<int>& mins,
                                   const SwVector<bool>& growable,
                                   int start,
                                   int span,
                                   int required);

    static void distributeSizes_(int available,
                                 SwVector<int>& mins,
                                 const SwVector<int>& stretches,
                                 const SwVector<bool>& occupied,
                                 const SwVector<bool>& growable,
                                 int count);

    bool buildMetrics_(const SwRect& rect, GridMetrics* outMetrics) const;

    SwRect spannedCellRect_(const GridMetrics& metrics, const Cell& cell) const;

    bool cellRectForContentRect_(const SwRect& contentRect, int row, int column, SwRect* outRect) const;

    void clearCells_();

private:
    // What the class keeps (SwLayout_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwFormLayout : public SwAbstractLayout {
public:
    struct Row {
        SwLayoutItem* label{nullptr};
        SwLayoutItem* field{nullptr};
    };

    explicit SwFormLayout(SwWidget* parent = nullptr);

    ~SwFormLayout() override;

    const SwVector<Row>& rows() const;

    void addRow(SwWidget* label, SwWidget* field);

    void setItem(int row, int column, SwLayoutItem* item);

    void setCell(int row, int column, SwWidget* widget);

    void addItem(SwLayoutItem* item);

    void addWidget(SwWidget* widget);

    void removeWidget(SwWidget* widget);

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    void forEachManagedWidget(const std::function<void(SwWidget*)>& visitor) const override;

protected:
    void applyLayout(const SwRect& rect) override;

private:
    SwSize layoutSizeHint_(bool minimum) const;

    void addRowItems_(SwLayoutItem* label, SwLayoutItem* field);

    void clearRows_();

private:
    // What the class keeps (SwLayout_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
