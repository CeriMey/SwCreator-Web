#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwWindow.h"

#include <memory>

struct SwWindow::Data {
    std::unique_ptr<SwPlatformWindow> platformWindow;
    SwString title;
    SwPlatformWindowOptions options;
    int width{640};
    int height{480};
    int x{0};
    int y{0};
    bool positioned{false};
    bool visible{false};
    bool fullPaint{true};   // the first paint and the one after a resize cover the whole window
};
