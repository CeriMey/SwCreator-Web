#pragma once

/**
 * @file src/core/gui/SwResponsive.h
 * @ingroup core_gui
 * @brief Declares SwResponsive, property values that follow the width of a window.
 *
 * A responsive form keeps its base values for its widest size. Each breakpoint narrows it: at or
 * below its width the variants recorded for it apply, and narrower breakpoints add theirs on top
 * (desktop first, as CSS media queries written from the widest screen down). Mobile first is the
 * other way round: the base values are the narrowest size's, each breakpoint widens it from its
 * minimum width and wider breakpoints add theirs on top.
 *
 * Targets are widgets, for any registered property ("Visible" hides a widget on small screens),
 * and layouts, for these values:
 * - "direction" of an SwBoxLayout: "Horizontal" or "Vertical", a row turning into a column;
 * - "columns" of an SwGridLayout: the items re-flowed into that many columns, 0 as placed;
 * - "rowWrapPolicy" of an SwFormLayout: "DontWrapRows", "WrapLongRows" or "WrapAllRows";
 * - "spacing" and "margin" of any layout.
 *
 * @code
 * auto* responsive = new SwResponsive(window);
 * responsive->setBreakpoints({{"tablet", 999}, {"phone", 639}});
 * responsive->setVariant("tablet", sideBar, "Visible", SwAny(false));
 * responsive->setVariant("phone", toolbarLayout, "direction", SwAny(SwString("Vertical")));
 * responsive->apply();   // then follows every resize of the window
 * @endcode
 */

#include "SwWidget.h"

#include <vector>

struct SwXmlNode;

class SW_WIDGETS_EXPORT SwResponsive : public SwObject {
    SW_OBJECT(SwResponsive, SwObject)

public:
    struct Breakpoint {
        SwString name;
        int maxWidth{0};    // desktop first: applies while the root is at most this wide
        int minWidth{0};    // mobile first: applies while the root is at least this wide
    };
    enum class Cascade { DesktopFirst, MobileFirst };

    /** Follows @p root, its parent; a root has one controller, find() returns it. */
    explicit SwResponsive(SwWidget* root);
    ~SwResponsive() override;
    static SwResponsive* find(const SwWidget* root);
    SwWidget* root() const;

    /** Desktop first (the default) or mobile first; set it before the breakpoints. */
    void setCascade(Cascade cascade);
    Cascade cascade() const;
    /** Any order: they are kept in cascade order, from the base size outwards (widest first for
     * desktop first, narrowest first for mobile first). */
    void setBreakpoints(const std::vector<Breakpoint>& breakpoints);
    const std::vector<Breakpoint>& breakpoints() const;
    int breakpointIndex(const SwString& name) const;
    /** The breakpoint that contains @p width, the furthest from the base size, or "" for it. */
    SwString breakpointForWidth(int width) const;
    /** A window growing back past a breakpoint keeps it for these extra pixels (no flicker). */
    void setHysteresis(int pixels);
    int hysteresis() const;

    void setVariant(const SwString& breakpoint, SwObject* target, const SwString& property, const SwAny& value);
    bool removeVariant(const SwString& breakpoint, SwObject* target, const SwString& property);
    bool hasVariant(const SwString& breakpoint, SwObject* target, const SwString& property) const;
    SwAny variant(const SwString& breakpoint, SwObject* target, const SwString& property) const;
    /** The properties of @p target that change with the width. */
    SwStringList variantProperties(SwObject* target) const;
    std::vector<SwObject*> targets() const;
    void removeTarget(SwObject* target);
    void clear();

    /** The value at @p breakpoint after the cascade: base, then each wider breakpoint's variant. */
    SwAny valueAt(const SwString& breakpoint, SwObject* target, const SwString& property) const;
    /** The breakpoint whose variant gives that value, "" when it is the base value. */
    SwString definingBreakpoint(const SwString& breakpoint, SwObject* target, const SwString& property) const;
    SwAny baseValue(SwObject* target, const SwString& property) const;
    void setBaseValue(SwObject* target, const SwString& property, const SwAny& value);

    /** Follows the root's width (the default), or holds one breakpoint, as a designer preview does. */
    void setAutomatic(bool automatic);
    bool isAutomatic() const;
    void setActiveBreakpoint(const SwString& breakpoint);
    SwString activeBreakpoint() const;
    /** A designer keeps hidden widgets on its canvas and draws them as ghosts: "Visible" is not applied. */
    void setApplyVisibility(bool apply);
    bool appliesVisibility() const;
    bool isVisibleAt(const SwString& breakpoint, SwWidget* widget) const;
    /** Writes every target's value for the active breakpoint. */
    void apply();

    /**
     * @brief Reads a form file's `<breakpoints>` and every `<variant breakpoint="...">` of its
     * widgets and layouts, whose objects are under @p root; returns null when it has no breakpoint.
     *
     * @code
     * <breakpoints hysteresis="16"><breakpoint name="phone" maxWidth="639"/></breakpoints>
     * <breakpoints cascade="mobile-first"><breakpoint name="desktop" minWidth="1000"/></breakpoints>
     * <widget class="SwWidget" name="sideBar"> ... <variant breakpoint="phone">
     *   <property name="Visible"><bool>false</bool></property></variant></widget>
     * @endcode
     */
    static SwResponsive* fromDocument(SwWidget* root, const SwXmlNode& document);
    /** A form file's property value (`<string>`, `<bool>`, `<number>`, `<double>`, `<enum>`, `<color>`...). */
    static SwAny valueFromXml(const SwXmlNode& property);

    /** A property as SwResponsive reads and writes it, layout values included. */
    static SwAny readValue(SwObject* target, const SwString& property);
    static void writeValue(SwObject* target, const SwString& property, const SwAny& value);

signals:
    SW_SIGNAL(breakpointChanged, const SwString&);

private:
    void followWidth_();
    void forget_(SwObject* target);

    struct Data;
    SwObjectDataPointer<Data> d_;
};
