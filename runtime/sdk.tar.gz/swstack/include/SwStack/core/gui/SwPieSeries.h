
/**
 * @file
 * @ingroup core_gui
 * @brief Declares the pie and donut series type used by the chart subsystem.
 *
 * `SwPieSeries` stores labeled slices, their numeric weights, and per-slice display state
 * such as colors or exploded offsets. Unlike XY series, it models part-of-whole data and
 * exposes aggregate properties like total value, hole size, and start angle.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwAbstractSeries.h"

#include <algorithm>
#include <cmath>

class SW_CHARTS_EXPORT SwPieSeries : public SwAbstractSeries {
    SW_OBJECT(SwPieSeries, SwAbstractSeries)

public:
    struct Slice {
        SwString label{};
        double value{0.0};
        SwColor color{0, 120, 215};
        bool exploded{false};
        double explodeFactor{0.07}; // relative to radius
    };

    /**
     * @brief Constructs a `SwPieSeries` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwPieSeries(SwObject* parent = nullptr);

    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SeriesType type() const override;
    /**
     * @brief Returns whether the object reports xYSeries.
     * @return `true` when the object reports xYSeries; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isXYSeries() const override;

    /**
     * @brief Performs the `append` operation.
     * @param label Value passed to the method.
     * @param value Value passed to the method.
     * @param color Value passed to the method.
     */
    void append(const SwString& label, double value, const SwColor& color);

    /**
     * @brief Performs the `append` operation.
     * @param label Value passed to the method.
     * @param value Value passed to the method.
     */
    void append(const SwString& label, double value);

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const override;

    /**
     * @brief Clears the current object state.
     */
    void clear() override;

    /**
     * @brief Returns the current slices.
     * @return The current slices.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwVector<Slice>& slices() const;

    /**
     * @brief Sets the hole Size.
     * @param ratio Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHoleSize(double ratio);

    /**
     * @brief Returns the current hole Size.
     * @return The current hole Size.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double holeSize() const;

    /**
     * @brief Sets the start Angle Degrees.
     * @param degrees Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStartAngleDegrees(double degrees);

    /**
     * @brief Returns the current angle Degrees.
     * @return The current angle Degrees.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double startAngleDegrees() const;

    /**
     * @brief Sets the exploded.
     * @param index Value passed to the method.
     * @param on Value passed to the method.
     * @param explodeFactor Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setExploded(int index, bool on, double explodeFactor = 0.07);

    /**
     * @brief Returns the current total Value.
     * @return The current total Value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double totalValue() const;

private:
    SwColor nextPaletteColor_();

public:
    ~SwPieSeries();
private:
    // What the class keeps (SwPieSeries_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
