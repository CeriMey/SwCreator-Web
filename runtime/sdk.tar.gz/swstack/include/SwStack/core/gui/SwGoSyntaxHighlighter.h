#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwGoSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat builtinFormat;
    SwTextCharFormat constantFormat;
    SwTextCharFormat packageFormat;
};

inline SwTextCharFormat swGoMakeFormat_(const SwColor& color,
                                        FontWeight weight = Normal,
                                        bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwGoSyntaxTheme swGoSyntaxThemeVsCodeDark() {
    SwGoSyntaxTheme theme;
    theme.keywordFormat  = swGoMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.typeFormat     = swGoMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat  = swGoMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat   = swGoMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat   = swGoMakeFormat_(SwColor{181, 206, 168});
    theme.functionFormat = swGoMakeFormat_(SwColor{220, 220, 170});
    theme.builtinFormat  = swGoMakeFormat_(SwColor{220, 220, 170});
    theme.constantFormat = swGoMakeFormat_(SwColor{79, 193, 255});
    theme.packageFormat  = swGoMakeFormat_(SwColor{78, 201, 176});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwGoSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwGoSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwGoSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwGoSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BlockCommentState = 1
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int findBlockCommentEnd_(const SwString& text, int start);

    static int parseNumber_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isType_(const SwString& word);

    static bool isBuiltin_(const SwString& word);

    static bool isConstant_(const SwString& word);

public:
    ~SwGoSyntaxHighlighter();
private:
    // What the class keeps (SwGoSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
