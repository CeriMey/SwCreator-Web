/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwStyle.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwStyle in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the style interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are WidgetState, WidgetStateHelper, WidgetStyle, and
 * SwStyle.
 *
 * Style-oriented declarations here capture reusable visual parameters so rendering code can stay
 * deterministic while still allowing higher-level customization.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * Platform-agnostic styling helpers.
 **************************************************************************************************/

#include <string>
#include <vector>
#include <algorithm>
#include <algorithm>
#include <sstream>

#include "Sw.h"
#include "SwPainter.h"
#include "SwString.h"
#include "SwObject.h"

class SwWidget;
#include "StyleSheet.h"

enum class WidgetState {
    Normal = 0x00,
    Hovered = 0x01,
    Pressed = 0x02,
    Disabled = 0x04,
    Focused = 0x08,
    Checked = 0x10
};

class SW_WIDGETS_EXPORT WidgetStateHelper {
public:
    /**
     * @brief Returns whether the object reports state.
     * @param state Value passed to the method.
     * @param flag Value passed to the method.
     * @return The requested state.
     *
     * @details This query does not modify the object state.
     */
    static bool isState(WidgetState state, WidgetState flag);

    /**
     * @brief Sets the state.
     * @param state Value passed to the method.
     * @param flag Value passed to the method.
     * @return The requested state.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static WidgetState setState(WidgetState state, WidgetState flag);

    /**
     * @brief Clears the current object state.
     * @param state Value passed to the method.
     * @param flag Value passed to the method.
     * @return The requested state.
     */
    static WidgetState clearState(WidgetState state, WidgetState flag);
};

enum class WidgetStyle {
    WidgetStyle,
    PushButtonStyle,
    LineEditStyle,
    CheckBoxStyle,
    RadioButtonStyle,
    LabelStyle,
    ComboBoxStyle,
    SpinBoxStyle,
    ProgressBarStyle,
    SliderStyle,
    TextEditStyle,
    ScrollBarStyle,
    ToolButtonStyle,
    TabWidgetStyle,
    ListViewStyle,
    TableViewStyle,
    TreeViewStyle,
    DialogStyle,
    MainWindowStyle,
    StatusBarStyle,
    MenuBarStyle,
    ToolBarStyle,
    SplitterStyle,
    ScrollAreaStyle,
    GroupBoxStyle,
    CalendarStyle,
    MessageBoxStyle
};

class SW_WIDGETS_EXPORT SwStyle {
public:
    /**
     * @brief Constructs a `SwStyle` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwStyle();

    /**
     * @brief Performs the `drawControl` operation.
     * @param style Value passed to the method.
     * @param rect Rectangle used by the operation.
     * @param painter Value passed to the method.
     * @param widget Widget associated with the operation.
     * @param state Value passed to the method.
     */
    void drawControl(WidgetStyle style,
                     const SwRect& rect,
                     SwPainter* painter,
                     SwWidget* widget,
                     WidgetState state);

    /**
     * @brief Performs the `drawBackground` operation.
     * @param rect Rectangle used by the operation.
     * @param painter Value passed to the method.
     * @param color Value passed to the method.
     * @param borderless Value passed to the method.
     */
    void drawBackground(const SwRect& rect, SwPainter* painter, const SwColor& color, bool borderless = true);

private:
    static unsigned int toStyleSheetStateFlags(WidgetState state);

    static int pixelSizeToPointSize(int pixelSize);

    SwColor chooseFillColor(WidgetStyle style, WidgetState state) const;

    void overrideColor(const SwString& value, SwColor& target, StyleSheet* sheet, float* alphaOut = nullptr);

    static SwColor lightenColor(const SwColor& color, int amount);

    static SwColor darkenColor(const SwColor& color, int amount);

    static void applyNativePushButtonPalette_(WidgetState state, SwColor& fill, SwColor& border, SwColor& text);

    struct BoxShadow {
        int offsetX{0};
        int offsetY{0};
        int blur{0};
        int spread{0};
        SwColor color{0, 0, 0};
        float alpha{1.0f};
        bool valid{false};
    };

    static SwColor applyAlpha(const SwColor& c, float alpha);

    struct Padding {
        int top{0};
        int right{0};
        int bottom{0};
        int left{0};
    };

    static int parsePixelValue(const SwString& value, int defaultValue);

    static Padding parsePadding(const SwString& value);

    BoxShadow parseBoxShadow(const SwString& value, StyleSheet* sheet) const;

public:
    ~SwStyle();
public:
    SwStyle(const SwStyle& other);
    SwStyle& operator=(const SwStyle& other);
private:
    // What the class keeps (SwStyle_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;

protected:
    // Reserved for the virtual functions a later 1.x adds (docs/BINARY_COMPATIBILITY.md): a class
    // that reimplements it handles its own ids and passes the others to its base.
    virtual void virtual_hook(int id, void* data);
};
