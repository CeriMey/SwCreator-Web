﻿
/**
 * @file
 * @ingroup core_gui
 * @brief Declares `SwPushButton`, the clickable command button widget.
 *
 * The widget provides a command button appearance and a parameterless clicked signal.
 * Shared button state, alignment, and content margins live in SwAbstractButton.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "../SwStackExport.h"
#include "SwAbstractButton.h"

class SW_WIDGETS_EXPORT SwPushButton : public SwAbstractButton {
    SW_OBJECT(SwPushButton, SwAbstractButton)
public:
    /**
     * @brief Constructs a `SwPushButton` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwPushButton(const SwString& text, SwWidget* parent = nullptr);

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested paint Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void paintEvent(PaintEvent* event) override;

    /**
     * @brief Returns the current size Hint.
     * @return The current size Hint.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual SwSize sizeHint() const override;

    /**
     * @brief Returns the current minimum Size Hint.
     * @return The current minimum Size Hint.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual SwSize minimumSizeHint() const override;

signals:
    SW_SIGNAL_VOID(clicked);

protected:
    void emitClicked_() override;

public:
    ~SwPushButton();
private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};

