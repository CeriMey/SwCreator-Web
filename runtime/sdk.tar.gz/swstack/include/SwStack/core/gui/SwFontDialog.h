﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file SwFontDialog.h
 * @ingroup core_gui
 * @brief Declares `SwFontDialog`, a compact modal font chooser for the Sw GUI toolkit.
 *
 * @details
 * `SwFontDialog` provides a self-contained replacement for a native font picker when the toolkit
 * needs a predictable, fully themeable widget hierarchy. The implementation keeps the workflow
 * intentionally narrow:
 * - it exposes font family selection,
 * - it exposes point-size selection,
 * - it keeps an in-memory `SwFont` as the source of truth,
 * - it renders a live preview so the caller can confirm the resulting typography before accepting.
 *
 * The dialog synchronizes the UI in both directions. `setCurrentFont()` pushes a model font into
 * the controls, while `updateFromUi()` reconstructs the current `SwFont` from the edited widgets.
 * On Windows the family list is populated from the system font catalog; on other platforms the
 * dialog falls back to a curated list of common families so the component remains functional even
 * without a platform-specific enumeration backend.
 */

#include "SwDialog.h"
#include "SwComboBox.h"
#include "SwLabel.h"
#include "SwPushButton.h"
#include "SwSpinBox.h"

#include "core/types/SwVector.h"

#include <algorithm>
#include <string>

/**
 * @class SwFontDialog
 * @brief Modal dialog that lets the user choose a font family and point size.
 *
 * @details
 * The class builds its entire interface in-process from regular Sw widgets instead of delegating to
 * an operating-system dialog. This makes it suitable for snapshot testing, custom styling, and
 * cross-platform behavior that stays consistent with the rest of the toolkit.
 *
 * Internally the class follows a simple state flow:
 * - `m_font` stores the authoritative selection.
 * - `syncUiFromFont()` mirrors `m_font` into the combo box and spin box.
 * - `updateFromUi()` rebuilds `m_font` from the current controls.
 * - `updatePreview()` applies the new font to the preview label.
 * - `updateLayout()` keeps the controls aligned with the dialog content and button bar geometry.
 */
class SW_WIDGETS_EXPORT SwFontDialog : public SwDialog {
    SW_OBJECT(SwFontDialog, SwDialog)

public:
    /**
     * @brief Constructs the dialog, builds the widget tree, and installs a default font.
     * @param parent Optional parent widget that owns the dialog.
     *
     * @details
     * The constructor creates the controls, wires their signals, and seeds the dialog with a
     * default `Segoe UI` 10 pt font so the preview area is immediately usable.
     */
    explicit SwFontDialog(SwWidget* parent = nullptr);

    /**
     * @brief Replaces the current dialog selection.
     * @param font Font value to display and preview.
     *
     * @details
     * This method updates the internal model, synchronizes the controls to match the provided
     * family and point size, then refreshes the preview label so the visible sample always reflects
     * the effective selection.
     */
    void setCurrentFont(const SwFont& font);

    /**
     * @brief Returns the font currently selected in the dialog.
     * @return The authoritative `SwFont` built from the current UI state.
     */
    SwFont currentFont() const;

    /**
     * @brief Opens a modal font picker and returns the accepted selection.
     * @param initial Font initially displayed when the dialog opens.
     * @param parent Optional parent widget.
     * @param ok Optional output flag set to `true` only when the user accepts the dialog.
     * @param title Window title shown for the modal dialog.
     * @return The accepted font, or `initial` when the dialog is cancelled.
     *
     * @details
     * This convenience helper mirrors the familiar "static dialog" pattern used by desktop widget
     * toolkits. It creates a temporary dialog instance, seeds it with the caller-provided font,
     * executes it modally, and preserves the original font when the interaction is rejected.
     */
    static SwFont getFont(const SwFont& initial,
                          SwWidget* parent = nullptr,
                          bool* ok = nullptr,
                          const SwString& title = "Select font");

protected:
    /**
     * @brief Recomputes the geometry of the controls when the dialog is resized.
     * @param event Resize event forwarded from the underlying widget system.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    /**
     * @brief Builds the dialog widget tree and installs the initial signal wiring.
     *
     * @details
     * The method creates the labels, editors, preview label, and dialog buttons, applies their
     * default styling, connects accept / reject actions, populates the family list, and computes
     * the initial geometry used by the dialog.
     */
    void buildUi();

    /**
     * @brief Populates the font family combo box from the platform or fallback defaults.
     *
     * @details
     * On Windows the dialog enumerates installed fonts with the native GDI API, removes duplicates,
     * and sorts the result case-insensitively. On non-Windows platforms the method inserts a curated
     * list of common families so the component remains usable without a dedicated font backend.
     */
    void populateFamilies();

    /**
     * @brief Connects control changes back to the internal `SwFont` model.
     *
     * @details
     * Both the family selector and point-size editor forward state changes to `updateFromUi()` so
     * `currentFont()` and the preview label always reflect the visible controls.
     */
    void hookSignals();

    /**
     * @brief Rebuilds the current font value from the active widget state.
     *
     * @details
     * Only the family and point size are edited by this dialog. Other attributes already present in
     * `m_font`, such as weight or underline, are preserved when the updated value is constructed.
     */
    void updateFromUi();

    /**
     * @brief Mirrors the internal font model into the visible controls.
     *
     * @details
     * If the font family is not already present in the combo box, the method appends it so fonts
     * provided by callers remain representable even when they are outside the pre-populated list.
     */
    void syncUiFromFont();

    /**
     * @brief Applies the current font to the preview label and schedules repainting.
     */
    void updatePreview();

    /**
     * @brief Recomputes the geometry of the controls inside the dialog content area.
     *
     * @details
     * `SwFontDialog` lays out its children manually instead of relying on a layout manager. This
     * helper keeps the labels, editors, preview region, and button bar aligned after construction
     * and on every resize event.
     */
    void updateLayout();

public:
    ~SwFontDialog();
private:
    // What the class keeps (SwFontDialog_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
