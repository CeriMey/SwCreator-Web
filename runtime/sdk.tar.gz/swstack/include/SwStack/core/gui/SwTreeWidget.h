#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwTreeWidget.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwTreeWidget in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the tree widget interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwTreeWidget.
 *
 * Widget-oriented declarations here usually capture persistent UI state, input handling, layout
 * participation, and paint-time behavior while keeping platform-specific rendering details behind
 * lower layers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwStandardItemModel.h"
#include "SwTreeView.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwTreeWidget : public SwTreeView {
    SW_OBJECT(SwTreeWidget, SwTreeView)

public:
    /**
     * @brief Constructs a `SwTreeWidget` instance.
     * @param columns Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwTreeWidget(int columns = 1, SwWidget* parent = nullptr);

    /**
     * @brief Returns the current model.
     * @return The current model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStandardItemModel* model() const;

    /**
     * @brief Performs the `invisibleRootItem` operation.
     * @return The requested invisible Root Item.
     */
    SwStandardItem* invisibleRootItem() const;

    /**
     * @brief Sets the column Count.
     * @param columns Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnCount(int columns);

    /**
     * @brief Sets the header Labels.
     * @param labels Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeaderLabels(const SwList<SwString>& labels);

    /**
     * @brief Clears the current object state.
     */
    void clear();

    // Convenience helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    /**
     * @brief Adds the specified top Level Item.
     * @param item Item affected by the operation.
     */
    void addTopLevelItem(SwStandardItem* item);

    /**
     * @brief Performs the `topLevelItem` operation.
     * @param index Value passed to the method.
     * @return The requested top Level Item.
     */
    SwStandardItem* topLevelItem(int index) const;

    /**
     * @brief Returns the current top Level Item Count.
     * @return The current top Level Item Count.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int topLevelItemCount() const;

    /**
     * @brief Returns the current current Item.
     * @return The current current Item.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStandardItem* currentItem() const;

    /**
     * @brief Sets the root Is Decorated.
     * @param show Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRootIsDecorated(bool show);

    using SwTreeView::collapse;
    using SwTreeView::expand;

    // Expand/collapse a specific item
    /**
     * @brief Performs the `expand` operation.
     * @param item Item affected by the operation.
     */
    void expand(SwStandardItem* item);

    /**
     * @brief Performs the `collapse` operation.
     * @param item Item affected by the operation.
     */
    void collapse(SwStandardItem* item);

    // Find a top-level or nested item by path stored in toolTip
    /**
     * @brief Performs the `findItemByPath` operation.
     * @param path Path used by the operation.
     * @return The requested find Item By Path.
     */
    SwStandardItem* findItemByPath(const SwString& path) const;

    // Select the item matching the given path (stored as toolTip)
    /**
     * @brief Sets the active Path.
     * @param path Path used by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setActivePath(const SwString& path);

    // Signals â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    SW_SIGNAL(itemClicked, SwStandardItem*);
    SW_SIGNAL(currentItemChanged, SwStandardItem*, SwStandardItem*);

private:
    // Find the model index for a SwStandardItem
    SwModelIndex indexForItem(SwStandardItem* item) const;

    SwStandardItem* findItemByPathRecursive(SwStandardItem* parent, const SwString& path) const;

    void onClicked_(const SwModelIndex& index);

    void onCurrentChanged_(const SwModelIndex& current, const SwModelIndex& previous);

public:
    ~SwTreeWidget();
private:
    // What the class keeps (SwTreeWidget_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
