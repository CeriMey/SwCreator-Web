#pragma once

/**
 * @file src/core/gui/SwDesktopServices.h
 * @ingroup core_gui
 * @brief Opens a URL or a file with the application the desktop chooses: QDesktopServices.
 *
 * openUrl() hands a web address to the default browser, a mailto: link to the mail client and a
 * local file (SwUrl::fromLocalFile()) to the application that opens its type, as a double click in
 * the file manager would. Windows: ShellExecuteW. Linux and the other Unix desktops: xdg-open,
 * started detached. macOS: open.
 */

#include "../SwStackExport.h"
#include "SwUrl.h"

class SW_GUI_EXPORT SwDesktopServices {
public:
    /// Opens @p url with the desktop's application for it. False when it could not be handed over:
    /// an invalid URL, no application for it (Windows), no xdg-open (Linux).
    static bool openUrl(const SwUrl& url);
};
