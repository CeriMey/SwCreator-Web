#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwComboBox.h"

// The platform, which the public header no longer shows (SwComboBox.h).
#if defined(_WIN32)
#include "core/runtime/SwCoreApplication.h"
#include "platform/win/SwWindows.h"
#endif

struct SwComboBox::Data {
    bool m_Pressed = false;
    bool m_Pressed_registered_ = sw_register_Pressed_();
    SwVector<SwString> m_items;
    int m_currentIndex{-1};
    bool m_popupVisible{false};
    SwColor m_accent{0, 120, 215};
    int m_maxVisibleItems{8};
    int m_itemHeight{28};
    int m_popupPadding{8};
    int m_popupFirstIndex{0};
    int m_popupHighlightedIndex{-1};
    PopupOverlay* m_overlay{nullptr};
    PopupList* m_list{nullptr};
#if defined(_WIN32)
    HWND m_nativePopupHwnd{nullptr};
#endif
#if defined(_WIN32)
    ULONGLONG m_lastNativePopupCloseMs{0};
#endif
#if defined(_WIN32)
    PopupRadii m_nativePopupRadii{10, 10, 10, 10};
#endif
#if defined(_WIN32)
    SwColor m_nativePopupBorderColor{200, 200, 200};
#endif
#if defined(_WIN32)
    SwColor m_nativePopupBg{255, 255, 255};
#endif
#if defined(_WIN32)
    int m_nativePopupBorderWidth{1};
#endif
};
