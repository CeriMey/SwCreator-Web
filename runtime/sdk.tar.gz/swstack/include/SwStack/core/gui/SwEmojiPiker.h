/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwEmojiPiker.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwEmojiPiker in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the emoji piker interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwEmojiPiker.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwEmojiPiker - Emoji picker widget for SwCore GUI.
 *
 * - Header-only, no external GUI dependency.
 * - Uses SwTabWidget + SwListWidget (icon mode).
 **************************************************************************************************/

#include "SwLayout.h"
#include "SwTabWidget.h"
#include "SwWidget.h"
#include "SwListWidget.h"
#include "SwStyledItemDelegate.h"

#include "core/types/SwMap.h"
#include "core/types/SwVector.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwEmojiPiker : public SwWidget {
    SW_OBJECT(SwEmojiPiker, SwWidget)

public:
    using EmojiList = SwVector<SwString>;
    using EmojisByTheme = SwMap<SwString, EmojiList>;

    /**
     * @brief Constructs a `SwEmojiPiker` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwEmojiPiker(SwWidget* parent = nullptr);

    /**
     * @brief Sets the emojis By Theme.
     * @param emojisByTheme Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEmojisByTheme(const EmojisByTheme& emojisByTheme);

    /**
     * @brief Returns the current emojis By Theme.
     * @return The current emojis By Theme.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const EmojisByTheme& emojisByTheme() const;

    SW_SIGNAL(emojiClicked, SwString);

protected:
    void paintEvent(PaintEvent* event) override;

private:
    static int clampInt_(int value, int minValue, int maxValue);

    class SW_WIDGETS_EXPORT EmojiIconDelegate final : public SwStyledItemDelegate {
        SW_OBJECT(EmojiIconDelegate, SwStyledItemDelegate)

    public:
        /**
         * @brief Performs the `EmojiIconDelegate` operation.
         * @param parent Optional parent object that owns this instance.
         * @return The requested emoji Icon Delegate.
         */
        explicit EmojiIconDelegate(SwObject* parent = nullptr);

        /**
         * @brief Performs the `paint` operation.
         * @param painter Value passed to the method.
         * @param option Value passed to the method.
         * @param index Value passed to the method.
         */
        void paint(SwPainter* painter,
                   const SwStyleOptionViewItem& option,
                   const SwModelIndex& index) const override;

        /**
         * @brief Performs the `sizeHint` operation.
         * @param option Value passed to the method.
         * @param index Value passed to the method.
         * @return The requested size Hint.
         */
        SwSize sizeHint(const SwStyleOptionViewItem& option,
                        const SwModelIndex& index) const override;
    };

    static EmojisByTheme defaultThemes_();

    void initDefaults_();

    // Create a styled but empty SwListWidget for a tab.
    SwListWidget* createTabList_();

    // Populate a tab's list on first access (lazy loading).
    void ensureTabPopulated_(int index);

    void rebuildTabs_();

private:

public:
    ~SwEmojiPiker();
private:
    // What the class keeps (SwEmojiPiker_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

// Optional alias (spelling fix without breaking the file name).
using SwEmojiPicker = SwEmojiPiker;
