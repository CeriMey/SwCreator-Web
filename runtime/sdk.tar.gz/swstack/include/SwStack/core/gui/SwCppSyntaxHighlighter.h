#pragma once

#include <memory>
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwSyntaxHighlighter.h"

#include <cctype>

struct SW_CODEEDITOR_EXPORT SwCppSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat preprocessorFormat;
    SwTextCharFormat macroFormat;
    SwTextCharFormat namespaceFormat;
};

inline SwTextCharFormat swCppMakeFormat_(const SwColor& color,
                                         FontWeight weight = Normal,
                                         bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwCppSyntaxTheme swCppSyntaxThemeVsCodeDark() {
    SwCppSyntaxTheme theme;
    theme.keywordFormat = swCppMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.typeFormat = swCppMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat = swCppMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat = swCppMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat = swCppMakeFormat_(SwColor{181, 206, 168});
    theme.functionFormat = swCppMakeFormat_(SwColor{220, 220, 170});
    theme.preprocessorFormat = swCppMakeFormat_(SwColor{197, 134, 192});
    theme.macroFormat = swCppMakeFormat_(SwColor{79, 193, 255});
    theme.namespaceFormat = swCppMakeFormat_(SwColor{78, 201, 176});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwCppSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwCppSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwCppSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwCppSyntaxTheme& theme);

    SwCppSyntaxTheme theme() const;

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        CppNormalBlockState = 0,
        CppBlockCommentState = 1
    };

    static bool isIdentifierStart_(char ch);

    static bool isIdentifierPart_(char ch);

    static int firstNonSpace_(const SwString& text, int start);

    static int nextNonSpace_(const SwString& text, int start);

    static bool equalsAny_(const SwString& word, const char* const* values, int count);

    static bool isKeyword_(const SwString& word);

    static bool isTypeKeyword_(const SwString& word);

    static bool introducesTypeName_(const SwString& word);

    static bool isMacroLike_(const SwString& word);

    static int stringPrefixLength_(const SwString& text, int start);

    static int parseQuotedLiteral_(const SwString& text, int quoteIndex);

    static int parseRawStringLiteral_(const SwString& text, int start);

    static int parseNumberLiteral_(const SwString& text, int start);

    static int findBlockCommentEnd_(const SwString& text, int start);

    int highlightPreprocessor_(const SwString& text, int hashPos);

public:
    ~SwCppSyntaxHighlighter();
private:
    // What the class keeps (SwCppSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
