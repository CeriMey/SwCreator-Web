#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwWidgetPlatformAdapter.h"

#if SW_PLATFORM_WIN32
#include "platform/win/SwWindows.h"
#elif SW_PLATFORM_ANDROID
#include "platform/android/SwAndroidPlatformIntegration.h"
#elif SW_PLATFORM_WEB
#include "platform/web/SwWebPlatformIntegration.h"
#elif SW_PLATFORM_X11
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#endif

#if SW_PLATFORM_X11
struct SwWidgetPlatformAdapter::LinuxExposeTracker {
    struct PendingWindow {
        Display* display{nullptr};
        XRectangle rect{};
        bool hasDamage{false};
        bool queued{false};
        bool inFlight{false};
    };
    std::mutex mutex;
    std::map<std::uintptr_t, PendingWindow> pending;
};
#endif

// The platforms' helpers of the widgets. Those that keep state are defined once, in
// SwWidgetPlatformAdapter.cpp.
inline bool swWidgetPlatformIsUtf8ContinuationByte_(unsigned char byte) {
    return (byte & 0xC0U) == 0x80U;
}

inline size_t swWidgetPlatformClampUtf8Boundary_(const std::string& utf8, size_t offset) {
    if (offset >= utf8.size()) {
        return utf8.size();
    }
    while (offset > 0 && swWidgetPlatformIsUtf8ContinuationByte_(static_cast<unsigned char>(utf8[offset]))) {
        --offset;
    }
    return offset;
}

inline size_t swWidgetPlatformNextUtf8Boundary_(const std::string& utf8, size_t offset) {
    if (offset >= utf8.size()) {
        return utf8.size();
    }
    size_t next = swWidgetPlatformClampUtf8Boundary_(utf8, offset) + 1;
    while (next < utf8.size() && swWidgetPlatformIsUtf8ContinuationByte_(static_cast<unsigned char>(utf8[next]))) {
        ++next;
    }
    return next;
}

#if SW_PLATFORM_WIN32

inline HCURSOR swWidgetCursorHandle_(CursorType cursor) {
    LPCTSTR cursorId = IDC_ARROW;
    switch (cursor) {
    case CursorType::Hand: cursorId = IDC_HAND; break;
    case CursorType::IBeam: cursorId = IDC_IBEAM; break;
    case CursorType::Cross: cursorId = IDC_CROSS; break;
    case CursorType::Wait: cursorId = IDC_WAIT; break;
    case CursorType::SizeAll: cursorId = IDC_SIZEALL; break;
    case CursorType::SizeNS: cursorId = IDC_SIZENS; break;
    case CursorType::SizeWE: cursorId = IDC_SIZEWE; break;
    case CursorType::SizeNWSE: cursorId = IDC_SIZENWSE; break;
    case CursorType::SizeNESW: cursorId = IDC_SIZENESW; break;
    default: cursorId = IDC_ARROW; break;
    }

    return LoadCursor(nullptr, cursorId);
}


SW_GUI_EXPORT std::unordered_set<HWND>& swWidgetMouseLeaveTrackedWindows_();

inline void swWidgetEnsureMouseLeaveTracking_(HWND hwnd) {
    if (!hwnd || !::IsWindow(hwnd)) {
        return;
    }

    std::unordered_set<HWND>& trackedWindows = swWidgetMouseLeaveTrackedWindows_();
    if (trackedWindows.find(hwnd) != trackedWindows.end()) {
        return;
    }

    TRACKMOUSEEVENT tracking{};
    tracking.cbSize = sizeof(TRACKMOUSEEVENT);
    tracking.dwFlags = TME_LEAVE;
    tracking.hwndTrack = hwnd;
    if (::TrackMouseEvent(&tracking)) {
        trackedWindows.insert(hwnd);
    }
}

inline void swWidgetClearMouseLeaveTracking_(HWND hwnd) {
    if (!hwnd) {
        return;
    }
    swWidgetMouseLeaveTrackedWindows_().erase(hwnd);
}

SW_GUI_EXPORT std::map<HWND, int>& swWidgetDamageThrottleSuppressionCounts_();

SW_GUI_EXPORT std::map<HWND, int>& swWidgetInteractiveResizeCounts_();

inline bool swWidgetInteractiveResizeActive_(HWND hwnd) {
    std::map<HWND, int>& activeCounts = swWidgetInteractiveResizeCounts_();
    std::map<HWND, int>::const_iterator it = activeCounts.find(hwnd);
    return it != activeCounts.end() && it->second > 0;
}

// ── Damage-region accumulator ────────────────────────────────────────
// Rectangles in this native accumulator are physical client pixels. Widget
// invalidations are converted once at entry; the paint event returns logical bounds.
// Accumulate up to kMaxDamageRects independent dirty rects per HWND.
// When the limit is exceeded or two rects overlap significantly, they
// are merged.  flushDamage() issues one InvalidateRect per accumulated
// rect, avoiding the whole-window repaint that a single RECT union causes
// when two small widgets at opposite corners are dirtied.
static const size_t kMaxDamageRects = 8;

struct SW_GUI_EXPORT SwDamageRegion_ {
    RECT rects[kMaxDamageRects];
    size_t count{0};

    void addRect(const RECT& r);

    RECT boundingRect() const;

    void clear();

private:
    static bool rectsOverlapOrTouch_(const RECT& a, const RECT& b);
    static void unionRect_(RECT& a, const RECT& b);
    static long long unionAreaCost_(const RECT& a, const RECT& b);
};

SW_GUI_EXPORT std::map<HWND, SwDamageRegion_>& swWidgetPendingDamage_();

SW_GUI_EXPORT std::map<HWND, long long>& swWidgetLastPaintedAtNs_();

SW_GUI_EXPORT int& swWidgetDamageWakeTimerId_();

SW_GUI_EXPORT long long& swWidgetDamageWakeDeadlineNs_();

inline long long swWidgetSteadyNowNs_() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
}

inline bool swWidgetShouldThrottleDamage_(HWND hwnd,
                                          const RECT& damageRect,
                                          long long nowNs,
                                          long long& remainingUsOut) {
    remainingUsOut = 0;
    if (!hwnd || !::IsWindow(hwnd) || !::IsWindowVisible(hwnd) || ::IsIconic(hwnd)) {
        return false;
    }

    RECT clientRect{};
    if (!::GetClientRect(hwnd, &clientRect)) {
        return false;
    }

    const long long clientWidth = std::max(1LL, static_cast<long long>(clientRect.right - clientRect.left));
    const long long clientHeight = std::max(1LL, static_cast<long long>(clientRect.bottom - clientRect.top));
    const long long clientArea = clientWidth * clientHeight;
    if (clientArea <= 0) {
        return false;
    }

    const long long damageWidth = std::max(1LL, static_cast<long long>(damageRect.right - damageRect.left));
    const long long damageHeight = std::max(1LL, static_cast<long long>(damageRect.bottom - damageRect.top));
    const long long damageArea = damageWidth * damageHeight;

    std::map<HWND, int>& suppressionCounts = swWidgetDamageThrottleSuppressionCounts_();
    std::map<HWND, int>::const_iterator suppressionIt = suppressionCounts.find(hwnd);
    if (suppressionIt != suppressionCounts.end() && suppressionIt->second > 0) {
        return false;
    }

    const bool largeDamage = damageArea >= 320000LL || (damageArea * 100LL) >= (clientArea * 35LL);
    if (!largeDamage) {
        return false;
    }

    std::map<HWND, long long>& lastPainted = swWidgetLastPaintedAtNs_();
    const std::map<HWND, long long>::const_iterator lastPaintIt = lastPainted.find(hwnd);
    if (lastPaintIt == lastPainted.end() || lastPaintIt->second <= 0) {
        return false;
    }

    // Cap very large damage bursts to roughly 60 FPS instead of the previous 10 FPS
    // so resize/drag interactions stay fluid while still coalescing redundant repaints.
    static const long long kMinPresentedFrameIntervalUs_ = 16667LL;
    const long long elapsedUs = std::max(0LL, (nowNs - lastPaintIt->second) / 1000LL);
    if (elapsedUs >= kMinPresentedFrameIntervalUs_) {
        return false;
    }

    remainingUsOut = kMinPresentedFrameIntervalUs_ - elapsedUs;
    return remainingUsOut > 0;
}

inline void swWidgetScheduleDamageWake_(long long delayUs) {
    if (delayUs <= 0) {
        return;
    }

    SwCoreApplication* app = SwCoreApplication::instance(false);
    if (!app) {
        return;
    }

    const long long requestedDelayUs = std::max(1000LL, delayUs);
    const long long requestedDeadlineNs = swWidgetSteadyNowNs_() + (requestedDelayUs * 1000LL);

    int& timerId = swWidgetDamageWakeTimerId_();
    long long& deadlineNs = swWidgetDamageWakeDeadlineNs_();
    if (timerId != 0 && deadlineNs != 0 && requestedDeadlineNs >= deadlineNs) {
        return;
    }

    if (timerId != 0) {
        app->removeTimer(timerId);
        timerId = 0;
    }

    deadlineNs = requestedDeadlineNs;
    timerId = app->addTimer([]() {
        swWidgetDamageWakeTimerId_() = 0;
        swWidgetDamageWakeDeadlineNs_() = 0;
        SwWidgetPlatformAdapter::flushDamage();
    }, static_cast<int>(requestedDelayUs), true, SwFiberLane::Control);
}

#elif SW_PLATFORM_ANDROID

#elif SW_PLATFORM_X11

namespace SwLinuxFontCache {
struct SW_GUI_EXPORT Key {
    std::string family;
    int pixelSize{12};
    bool bold{false};
    bool italic{false};
    bool underline{false};

    /**
     * @brief Performs the `operator<` operation.
     * @param other Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator<(const Key& other) const;
};

inline std::string toUtf8(const std::wstring& str) {
    if (str.empty()) {
        return {};
    }
    try {
        std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> conv;
        return conv.to_bytes(str);
    } catch (...) {
        std::string fallback;
        fallback.reserve(str.size());
        for (wchar_t ch : str) {
            fallback.push_back(static_cast<char>((ch >= 0 && ch <= 0x7F) ? ch : '?'));
        }
        return fallback;
    }
}

inline std::string sanitizeFamily(const std::wstring& family) {
    std::string utf8 = toUtf8(family);
    if (utf8.empty()) {
        utf8 = "sans";
    }
    std::string lower;
    lower.reserve(utf8.size());
    for (char c : utf8) {
        char normalized = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if (normalized == '_' || normalized == ' ') {
            normalized = '-';
        }
        lower.push_back(normalized);
    }
    // Windows' faces, as applications name them, read as the free faces Linux ships.
    if (lower == "segoe-ui" || lower == "segoeui") {
        lower = "dejavu-sans";
    } else if (lower == "consolas" || lower == "courier-new" || lower == "lucida-console" ||
               lower == "cascadia-mono" || lower == "cascadia-code") {
        lower = "dejavu-sans-mono";
    }
    return lower;
}

inline int toPixelSize(const SwFont& font) {
    if (font.getPixelSize() > 0) {
        return font.getPixelSize();
    }
    const int point = font.getPointSize() > 0 ? font.getPointSize() : 9;
    constexpr double dpi = 96.0;
    return static_cast<int>(point * dpi / 72.0 + 0.5);
}

inline std::string buildPattern(const Key& key) {
    std::string family = key.family.empty() ? "sans" : key.family;
    std::string weight = key.bold ? "bold" : "medium";
    std::string slant = key.italic ? "i" : "r";
    std::ostringstream oss;
    oss << "-*-" << family << "-" << weight << "-" << slant << "-*-"
        << key.pixelSize << "-*-*-*-*-*-*-*";
    return oss.str();
}

inline XFontStruct* tryLoad(Display* display, const std::string& pattern) {
    if (!display) {
        return nullptr;
    }
    if (pattern.empty()) {
        return nullptr;
    }
    return XLoadQueryFont(display, pattern.c_str());
}

SW_GUI_EXPORT XFontStruct* acquire(Display* display, const SwFont& font);
} // namespace SwLinuxFontCache

#else


#endif
