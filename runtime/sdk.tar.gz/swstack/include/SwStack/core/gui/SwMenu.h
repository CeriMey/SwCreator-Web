﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"
#include "../object/SwPointer.h"

/**
 * @file SwMenu.h
 * @ingroup core_gui
 * @brief Declares `SwMenu`, a popup menu container built from Sw actions and widgets.
 *
 * @details
 * `SwMenu` implements a menu system entirely inside the toolkit instead of deferring to platform
 * menu APIs. The menu owns a list of `SwAction` objects and materializes them into two internal
 * widgets when displayed:
 * - a transparent overlay that captures outside interaction,
 * - a popup list that renders rows, highlights, check marks, icons, and submenu arrows.
 *
 * This structure gives the toolkit full control over painting, keyboard navigation, submenu
 * placement, and event forwarding to root widgets such as menu bars.
 */

#include "SwAction.h"
#include "SwWidget.h"
#include "SwWidgetPlatformAdapter.h"

#include "core/object/SwPointer.h"
#include "core/runtime/SwTimer.h"
#include "core/types/SwVector.h"

#include <algorithm>
#include <functional>

/**
 * @class SwMenu
 * @brief Action container that can show itself as a transient popup menu.
 *
 * @details
 * A `SwMenu` stores actions independently from presentation and only builds the popup widgets on
 * demand. This lazy approach keeps the data model lightweight while still supporting:
 * - regular clickable actions,
 * - separators,
 * - nested submenus,
 * - keyboard navigation,
 * - outside-click dismissal through a transparent overlay,
 * - "hover keep alive" behavior for menu-bar style interactions.
 *
 * `popup()` anchors the menu relative to a root widget, `hide()` collapses the current menu branch,
 * and `hideAll()` dismisses the whole root menu chain. The `triggered` signal is emitted with the
 * originating action when the user activates an entry.
 */
class SW_WIDGETS_EXPORT SwMenu : public SwObject {
    SW_OBJECT(SwMenu, SwObject)

public:
    /**
     * @brief Constructs an empty menu.
     * @param parent Optional owning object or parent menu.
     */
    explicit SwMenu(SwObject* parent = nullptr);

    /**
     * @brief Creates a text-only action, adds it to the menu, and returns it.
     * @param text Visible label shown in the popup row.
     * @return Newly created action owned by the menu.
     */
    SwAction* addAction(const SwString& text);

    /**
     * @brief Creates an action with an icon and adds it to the menu.
     * @param icon Icon painted in the action row.
     * @param text Visible action label.
     * @return Newly created action owned by the menu.
     */
    SwAction* addAction(const SwImage& icon, const SwString& text);

    /**
     * @brief Creates an action and wires a callback to its `triggered` signal.
     * @param text Visible action label.
     * @param callback Function invoked when the action is triggered.
     * @return Newly created action owned by the menu.
     */
    SwAction* addAction(const SwString& text, const std::function<void()>& callback);

    /**
     * @brief Creates an action with both icon and callback.
     * @param icon Icon shown beside the action text.
     * @param text Visible action label.
     * @param callback Function invoked when the action is triggered.
     * @return Newly created action owned by the menu.
     */
    SwAction* addAction(const SwImage& icon, const SwString& text, const std::function<void()>& callback);

    /**
     * @brief Adds an already constructed action to the menu.
     * @param action Action instance to append.
     *
     * @details
     * The method adopts the action when it does not already have a parent and hooks its `changed`
     * signal so the popup geometry and painting stay in sync with runtime updates.
     */
    void addAction(SwAction* action);

    /**
     * @brief Appends a non-interactive separator row.
     * @return Separator action object owned by the menu.
     */
    SwAction* addSeparator();

    /**
     * @brief Creates a submenu entry and returns the nested menu instance.
     * @param text Visible label of the parent row.
     * @return Newly created submenu owned by this menu.
     */
    SwMenu* addMenu(const SwString& text);

    /**
     * @brief Creates a submenu entry with an icon.
     * @param icon Icon displayed for the submenu row.
     * @param text Visible label of the parent row.
     * @return Newly created submenu owned by this menu.
     */
    SwMenu* addMenu(const SwImage& icon, const SwString& text);

    /**
     * @brief Returns the actions currently stored in the menu.
     * @return Snapshot of the action list in insertion order.
     */
    SwVector<SwAction*> actions() const;

    /** Lazily creates the popup surface without showing it, for stylesheet/font customization.
     * The menu owns its lifetime; nullptr when no root widget is available.
     */
    SwWidget* popupWidget();

    /**
     * @brief Shows the menu popup near the provided root-widget coordinates.
     * @param x Horizontal popup origin in the root widget coordinate space.
     * @param y Vertical popup origin in the root widget coordinate space.
     *
     * @details
     * The menu ensures that its overlay and popup widgets exist, clamps the requested geometry to
     * the visible root widget bounds, updates the popup size from the current action list, and then
     * shows both the overlay and popup widgets.
     */
    void popup(int x, int y);

    /**
     * @brief Shows the menu and preserves an additional hover-safe rectangle.
     * @param x Horizontal popup origin in root-widget coordinates.
     * @param y Vertical popup origin in root-widget coordinates.
     * @param hoverKeepAliveRect Rectangle that should not immediately close the menu when crossed.
     *
     * @details
     * This overload is primarily used by menu bars so pointer travel between the source widget and
     * the popup does not collapse the menu chain too aggressively.
     */
    void popup(int x, int y, const SwRect& hoverKeepAliveRect);

    /**
     * @brief Hides this menu and any currently open submenu branch.
     *
     * @details
     * The call clears hover-close state, closes nested submenus, emits `aboutToHide` when the popup
     * was visible, and hides the overlay when this menu owns it.
     */
    void hide();

    /**
     * @brief Hides the entire root menu chain.
     *
     * @details
     * This is the preferred dismissal path when an outside click or Escape key should close all
     * nested menus rather than only the current branch.
     */
    void hideAll();

    /**
     * @brief Returns whether the popup widget for this menu is currently visible.
     * @return `true` when the popup exists and is shown.
     */
    bool isVisible() const;

signals:
    SW_SIGNAL_VOID(aboutToShow);   ///< Emitted just before the popup becomes visible.
    SW_SIGNAL_VOID(aboutToHide);   ///< Emitted just before the popup is hidden.
    SW_SIGNAL(triggered, SwAction*); ///< Emitted when an action from this menu tree is activated.

private:
    class PopupList;

    /**
     * @brief Full-screen transparent widget that dismisses menus and forwards outside events.
     *
     * @details
     * The overlay sits on top of the root widget while a menu is open. It detects clicks outside
     * the visible popup chain, closes the menu hierarchy, and optionally forwards the original event
     * back to the underlying root widget so controls such as menu bars can immediately react.
     */
    class SW_WIDGETS_EXPORT PopupOverlay final : public SwWidget {
        SW_OBJECT(PopupOverlay, SwWidget)

    public:
        /**
         * @brief Constructs the overlay that captures interaction outside the popup.
         * @param owner Menu tree controlled by this overlay.
         * @param root Root widget that receives forwarded outside-click events when needed.
         * @param parent Parent widget, typically the same root widget.
         */
        PopupOverlay(SwMenu* owner, SwWidget* root, SwWidget* parent = nullptr);

        /**
         * @brief Handles outside clicks by closing menus or forwarding the event to the root widget.
         * @param event Mouse press event expressed in root-widget coordinates.
         */
        void mousePressEvent(MouseEvent* event) override;

        /**
         * @brief Reports pointer movement back to the owning menu for hover-close tracking.
         * @param event Mouse move event expressed in root-widget coordinates.
         */
        void mouseMoveEvent(MouseEvent* event) override;

        /**
         * @brief Handles overlay keyboard shortcuts such as Escape-to-close.
         * @param event Key event received by the overlay widget.
         */
        void keyPressEvent(KeyEvent* event) override;

    private:
        SwMenu* owner() const;
        SwPointer<SwObject> m_owner;
        SwPointer<SwWidget> m_root;
    };

    /**
     * @brief Internal popup surface that paints menu rows and handles keyboard or pointer selection.
     *
     * @details
     * `PopupList` is responsible for geometry calculation, row hit testing, hover tracking, and
     * action activation. It stays deliberately focused on presentation and delegates higher-level
     * submenu management back to its owning `SwMenu`.
     */
    class SW_WIDGETS_EXPORT PopupList final : public SwWidget {
        SW_OBJECT(PopupList, SwWidget)

    public:
        /**
         * @brief Constructs the popup list that renders the menu action rows.
         * @param owner Menu whose actions are painted by this popup.
         * @param parent Parent widget, usually the shared overlay.
         */
        explicit PopupList(SwMenu* owner, SwWidget* parent = nullptr);

        /**
         * @brief Recomputes cached popup dimensions from the current action list.
         *
         * @details
         * Text width, action count, icon gutters, checkmark space, and submenu arrow space all
         * contribute to the geometry cached for `sizeHint()` and popup placement.
         */
        void updateGeometryFromActions();

        /**
         * @brief Returns the preferred popup size derived from cached geometry.
         * @return Rectangle whose width and height match the currently measured content.
         */
        SwSize sizeHint() const override;

        /**
         * @brief Paints the popup frame and all visible rows.
         * @param event Paint event providing the active painter.
         */
        void paintEvent(PaintEvent* event) override;

        /**
         * @brief Updates row hover state as the pointer moves inside the popup.
         * @param event Mouse move event in popup coordinates.
         */
        void mouseMoveEvent(MouseEvent* event) override;

        /**
         * @brief Activates the pointed action or opens its submenu.
         * @param event Mouse press event in popup coordinates.
         */
        void mousePressEvent(MouseEvent* event) override;

        /**
         * @brief Handles keyboard navigation and activation within the popup.
         * @param event Key event targeting the popup.
         */
        void keyPressEvent(KeyEvent* event) override;

    private:
        /**
         * @brief Returns the action-row index located at the given popup coordinates.
         * @param px Horizontal coordinate in popup space.
         * @param py Vertical coordinate in popup space.
         * @return Zero-based row index, or `-1` when the point is outside actionable rows.
         */
        int indexAt(int px, int py) const;

        /**
         * @brief Returns the action associated with a row index.
         * @param idx Zero-based row index.
         * @return Matching action, or `nullptr` when the index is invalid.
         */
        SwAction* actionAt(int idx) const;

        /**
         * @brief Moves keyboard / hover selection while skipping separator rows.
         * @param delta Positive to move downward, negative to move upward.
         */
        void moveHover(int delta);

        /**
         * @brief Returns the popup-space rectangle occupied by one row.
         * @param idx Zero-based row index.
         * @return Rectangle covering the requested row.
         */
        SwRect rowRectForIndex_(int idx) const;

        SwMenu* owner() const;
        SwPointer<SwObject> m_owner;
        int m_hoverIndex{-1};
        int m_scrollOffset{0};
        int m_itemHeight{28};
        int m_padding{4};
        int m_minWidth{220};
        int m_textLeftPad{28};
        int m_textRightPad{12};
        int m_cachedWidth{220};
        int m_cachedHeight{0};
    protected:
        void wheelEvent(WheelEvent* event) override;
    };

    /**
     * @brief Clamps an integer value into an inclusive range.
     */
    static int clampInt(int value, int minValue, int maxValue);

    /**
     * @brief Walks up the object hierarchy and returns the last widget ancestor found.
     * @param start Object from which the search begins.
     * @return Top-most widget ancestor, or `nullptr` when none exists.
     */
    static SwWidget* findRootWidget(SwObject* start);

    /**
     * @brief Returns whether a point lies inside a rectangle.
     */
    static bool containsPoint_(const SwRect& r, int px, int py);

    /**
     * @brief Expands a rectangle uniformly in all directions.
     * @param rect Source rectangle.
     * @param margin Margin applied on each side.
     * @return Inflated rectangle clamped to non-negative width and height.
     */
    static SwRect inflate_(SwRect rect, int margin);

    /**
     * @brief Returns the parent menu when this menu is nested inside another menu.
     */
    SwMenu* parentMenu_() const;

    /**
     * @brief Returns the root menu at the top of the current submenu chain.
     */
    SwMenu* rootMenu_() const;

    /**
     * @brief Returns whether the pointer lies inside the configured hover keep-alive rectangle.
     */
    bool isPointInsideHoverKeepAlive_(int px, int py) const;

    /**
     * @brief Recursively tests whether a point lies inside this popup or any open submenu popup.
     */
    bool isPointInsideAnyPopupRecursive_(int px, int py) const;

    /**
     * @brief Tests the full root menu tree for popup containment.
     */
    bool isPointInsideAnyPopup_(int px, int py) const;

    /**
     * @brief Tests the bridge zone between a popup and its currently open submenu chain.
     *
     * @details
     * This helper prevents immediate submenu dismissal while the pointer is traveling from the
     * parent row toward the submenu popup.
     */
    bool isPointInsideOpenSubMenuBridge_(int px, int py) const;

    /**
     * @brief Closes the currently open submenu, if any.
     */
    void closeSubMenu_();

    /**
     * @brief Opens or repositions the submenu associated with an action row.
     * @param action Action owning the submenu.
     * @param row Rectangle occupied by the source row.
     * @param index Index of the hovered or activated row.
     */
    void openSubMenu_(SwAction* action, const SwRect& row, int index);

    /**
     * @brief Reacts to hover changes and decides whether a submenu should remain open.
     * @param idx Hovered row index.
     * @param row Rectangle occupied by the hovered row.
     */
    void onPopupHoverChanged_(int idx, const SwRect& row);

    /**
     * @brief Closes the full menu chain before triggering a leaf action.
     *
     * @details
     * This matches Qt behavior and prevents menus from staying visible while the triggered slot
     * opens a modal dialog or another popup. Lifetime guards cover slots that destroy the action
     * or the owning menu during activation.
     */
    void activateLeafAction_(SwAction* action);

    /**
     * @brief Lazily creates the timer used to close menu trees after hover leaves the safe region.
     */
    void ensureHoverCloseTimer_();

    /**
     * @brief Starts the delayed hover-close timer when hover-close mode is enabled.
     */
    void startHoverCloseTimer_();

    /**
     * @brief Stops the delayed hover-close timer if it is currently running.
     */
    void stopHoverCloseTimer_();

    /**
     * @brief Updates the last known pointer position and hover-close timer state.
     * @param px Horizontal pointer position in root-widget coordinates.
     * @param py Vertical pointer position in root-widget coordinates.
     */
    void onOverlayMouseMove_(int px, int py);

    /**
     * @brief Ensures that the popup and overlay widgets required by this menu exist.
     *
     * @details
     * Root menus own the shared overlay. Submenus reuse that overlay and only create their own
     * popup surface, keeping the whole menu tree within a single transient widget hierarchy.
     */
    void ensurePopup();

public:
    ~SwMenu();
private:
    // What the class keeps (SwMenu_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

