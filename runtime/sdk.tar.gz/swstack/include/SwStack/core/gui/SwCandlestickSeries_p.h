#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwCandlestickSeries.h"

struct SwCandlestickSeries::Data {
    SwVector<Candle> m_candles{};
    double m_candleWidth{0.0};
    SwColor m_increasing{16, 185, 129};
    SwColor m_decreasing{239, 68, 68};
};
