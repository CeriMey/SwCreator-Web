﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file SwHeaderView.h
 * @ingroup core_gui
 * @brief Declares `SwHeaderView`, a custom header widget for model-backed views.
 *
 * @details
 * `SwHeaderView` renders horizontal or vertical section headers using data obtained from
 * `SwAbstractItemModel::headerData()`. It is designed as a lightweight companion for item views
 * that need explicit control over header painting, section metrics, and interaction policy.
 *
 * The implementation supports:
 * - fixed per-section sizes,
 * - optional width redistribution through stretch weights,
 * - optional expansion of the last visible section,
 * - interactive divider dragging,
 * - clickable sections for sorting or custom behaviors,
 * - sort indicator painting managed entirely by the toolkit.
 */

#include "SwAbstractItemModel.h"
#include "SwPainter.h"
#include "SwWidget.h"
#include "SwWidgetPlatformAdapter.h"

#include "core/types/SwList.h"

#include <algorithm>
#include <cstdlib>
#include <sstream>
#include <string>
#include <vector>

/**
 * @class SwHeaderView
 * @brief Paints and manages interactive header sections for a model-backed view.
 *
 * @details
 * The widget keeps enough layout state to answer geometry queries without depending on a specific
 * table or tree implementation. Section count may come from the bound model or from an explicit
 * hint when no model is attached yet. Size calculation follows this order:
 * - explicit per-section sizes when present,
 * - computed stretch sizes when "fit to width" mode is enabled,
 * - optional last-section expansion to consume remaining viewport space.
 *
 * Mouse interaction is also handled locally. Divider hit testing enables manual resizing, while
 * section hit testing emits `sectionClicked` and tracks hover state for richer painting.
 */
class SW_WIDGETS_EXPORT SwHeaderView : public SwWidget {
    SW_OBJECT(SwHeaderView, SwWidget)

public:
    /**
     * @brief Constructs a header view for the requested orientation.
     * @param orientation `Horizontal` for column headers or `Vertical` for row headers.
     * @param parent Optional parent widget.
     */
    explicit SwHeaderView(SwOrientation orientation, SwWidget* parent = nullptr);

    /**
     * @brief Sets a fallback number of sections when no model is attached.
     * @param count Non-negative logical section count hint.
     */
    void setSectionCountHint(int count);

    /**
     * @brief Returns the explicit section-count hint.
     * @return Fallback count used when the widget has no model.
     */
    int sectionCountHint() const;

    /**
     * @brief Binds the header to a model that provides section count and header labels.
     * @param model Model whose row or column metadata should be rendered.
     *
     * @details
     * The header reconnects to `modelReset` so section buffers and cached geometry stay aligned with
     * model structure changes.
     */
    void setModel(SwAbstractItemModel* model);

    /**
     * @brief Returns the currently bound model.
     * @return Model pointer, or `nullptr` when no model is attached.
     */
    SwAbstractItemModel* model() const;

    /**
     * @brief Sets the scroll offset applied when mapping viewport positions to logical sections.
     * @param px Offset in pixels.
     */
    void setOffset(int px);

    /**
     * @brief Returns the current pixel offset.
     * @return Horizontal or vertical header offset depending on orientation.
     */
    int offset() const;

    /**
     * @brief Sets the default size used for sections without an explicit override.
     * @param px Requested section size in pixels.
     */
    void setDefaultSectionSize(int px);

    /**
     * @brief Returns the default section size.
     * @return Default section extent in pixels.
     */
    int defaultSectionSize() const;

    /**
     * @brief Sets the minimum size allowed for any section.
     * @param px Minimum size in pixels.
     */
    void setMinimumSectionSize(int px);

    /**
     * @brief Returns the minimum section size.
     * @return Minimum extent in pixels.
     */
    int minimumSectionSize() const;

    /**
     * @brief Sets the maximum size allowed for any section.
     * @param px Maximum size in pixels.
     */
    void setMaximumSectionSize(int px);

    /**
     * @brief Returns the maximum section size.
     * @return Maximum extent in pixels.
     */
    int maximumSectionSize() const;

    /**
     * @brief Enables or disables grid-line painting between sections.
     * @param on `true` to draw divider lines.
     */
    void setShowGrid(bool on);

    /**
     * @brief Returns whether grid lines are painted.
     * @return `true` when section dividers are drawn as part of the header.
     */
    bool showGrid() const;

    /**
     * @brief Enables or disables click activation on sections.
     * @param on `true` to emit `sectionClicked` when the user clicks a section body.
     */
    void setSectionsClickable(bool on);

    /**
     * @brief Returns whether section clicks are currently enabled.
     * @return `true` when click hit testing on section bodies is active.
     */
    bool sectionsClickable() const;

    /**
     * @brief Enables automatic redistribution of section sizes to fill the viewport length.
     * @param on `true` to compute stretched sizes from the configured weights.
     *
     * @details
     * When enabled, the fixed section-size buffer is treated as the baseline and
     * `updateStretchedSections_()` computes a derived set of visible sizes. Disabling the feature
     * clears the derived cache and returns to fixed sizing.
     */
    void setSectionsFitToWidth(bool on);

    /**
     * @brief Returns whether width-fitting mode is enabled.
     * @return `true` when section sizes are redistributed to match the viewport length.
     */
    bool sectionsFitToWidth() const;

    /**
     * @brief Enables or disables last-section expansion in non-stretched mode.
     * @param on `true` to let the last section absorb leftover viewport space.
     *
     * @details
     * Unlike `setSectionsFitToWidth()`, this does not rescale every section. Only the final visible
     * section grows when the sum of fixed sizes is smaller than the available viewport length.
     */
    void setStretchLastSection(bool on);

    /**
     * @brief Returns whether the last section may expand to fill slack space.
     * @return `true` when last-section stretching is enabled.
     */
    bool stretchLastSection() const;

    /**
     * @brief Sets per-section stretch weights used by width-fitting mode.
     * @param stretches Weight list aligned with logical section indices.
     */
    void setSectionStretches(const SwList<int>& stretches);

    /**
     * @brief Returns the configured stretch weights.
     * @return Weight list used when width-fitting mode is active.
     */
    SwList<int> sectionStretches() const;

    /**
     * @brief Sets the viewport length used for width redistribution calculations.
     * @param px Available viewport size in pixels.
     */
    void setViewportLength(int px);

    /**
     * @brief Returns the cached viewport length.
     * @return Viewport size used by stretch calculations, or a negative value when not preset.
     */
    int viewportLength() const;

    /**
     * @brief Returns the current logical section count.
     * @return Number of columns for a horizontal header, rows for a vertical header, or the fallback
     *         hint when no model is attached.
     */
    int sectionCount() const;

    /**
     * @brief Returns the visible size of one logical section.
     * @param logicalIndex Zero-based section index.
     * @return Section extent in pixels after fixed-size and stretch rules have been applied.
     */
    int sectionSize(int logicalIndex) const;

    /**
     * @brief Assigns an explicit size to one section.
     * @param logicalIndex Zero-based section index.
     * @param px Requested size in pixels.
     *
     * @details
     * In width-fitting mode the stretched cache is first materialized back into the fixed-size
     * buffer so the explicit user resize becomes the new baseline.
     */
    void setSectionSize(int logicalIndex, int px);

    /**
     * @brief Returns the cumulative visible length of all sections.
     * @return Total header length in pixels.
     */
    int length() const;

    /**
     * @brief Returns the starting pixel coordinate of a section.
     * @param logicalIndex Zero-based section index.
     * @return Pixel coordinate relative to the unshifted header content.
     */
    int sectionStart(int logicalIndex) const;

    /**
     * @brief Returns the logical section covering a content-space position.
     * @param position Pixel position relative to the header content.
     * @return Section index, or `-1` when the position is outside all sections.
     */
    int sectionAt(int position) const;

    /**
     * @brief Enables or disables sort-indicator painting.
     * @param on `true` to paint the current sort arrow.
     */
    void setSortIndicatorShown(bool on);

    /**
     * @brief Returns whether the sort indicator is currently visible.
     * @return `true` when sort-arrow painting is enabled.
     */
    bool isSortIndicatorShown() const;

    /**
     * @brief Sets the section and order represented by the sort indicator.
     * @param section Section index that should show the indicator.
     * @param order Sort direction to paint.
     */
    void setSortIndicator(int section, SwSortOrder order);

    /**
     * @brief Returns the section that currently owns the sort indicator.
     * @return Logical section index, or `-1` when no section is selected for sorting.
     */
    int sortIndicatorSection() const;

    /**
     * @brief Returns the direction represented by the sort indicator.
     * @return Current sort order used for arrow painting.
     */
    SwSortOrder sortIndicatorOrder() const;

signals:
    SW_SIGNAL(sectionClicked, int);          ///< Emitted when the user clicks a logical section.
    SW_SIGNAL(sectionResized, int, int, int); ///< Emitted after a user resize with section, old size, and new size.

protected:
    /**
     * @brief Recomputes stretched sizes when the header widget is resized.
     * @param event Resize event forwarded by the widget system.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

private:
    struct SW_WIDGETS_EXPORT Padding {
        int top{0};
        int right{0};
        int bottom{0};
        int left{0};

        /**
         * @brief Constructs a `Padding` instance.
         *
         * @details The instance is initialized and prepared for immediate use.
         */
        Padding();
        /**
         * @brief Constructs a `Padding` instance.
         * @param topValue Value passed to the method.
         * @param rightValue Value passed to the method.
         * @param bottomValue Value passed to the method.
         * @param leftValue Value passed to the method.
         *
         * @details The instance is initialized and prepared for immediate use.
         */
        Padding(int topValue, int rightValue, int bottomValue, int leftValue);
    };

    static Padding parsePadding_(const SwString& value);

    static SwString styleValue_(const StyleSheet* sheet,
                               const SwList<SwString>& hierarchy,
                               const char* propertyName);

    static bool tryParseColor_(const StyleSheet* sheet, const SwString& value, SwColor& out);

    static void paintRoundedRectWithCorners_(SwPainter* painter,
                                            const SwRect& rect,
                                            int tl,
                                            int tr,
                                            int br,
                                            int bl,
                                            const SwColor& fill,
                                            const SwColor& border,
                                            int borderWidth);

    void initDefaults_();

    int contentPos_(int px, int py) const;

    int dividerAt_(int px, int py) const;

    int sectionAtPoint_(int px, int py) const;

    void beginResize_(int section, int px, int py);

    void ensureSectionBuffers_() const;

    void materializeStretchedIntoFixed_();

    void updateStretchedSections_() const;

public:
    ~SwHeaderView();
private:
    // What the class keeps (SwHeaderView_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

