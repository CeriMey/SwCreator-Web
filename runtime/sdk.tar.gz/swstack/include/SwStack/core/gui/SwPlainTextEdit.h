/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwPlainTextEdit.h
 * @ingroup core_gui
 * @brief Multi-line plain text editor backed by a Piece Table.
 */


/***************************************************************************************************
 * SwPlainTextEdit - multi-line plain text editor.
 *
 * Goals:
 * - Plain text storage (no rich text rendering).
 * - Keyboard editing + cursor, suitable for snapshot-based visual validation.
 * - Styling via StyleSheet basics: background-color / border-color / border-width / border-radius /
 *   color / padding.
 *
 * Text storage uses SwPieceTable for O(log P) insert/delete regardless of document size.
 * Line index is maintained incrementally inside the piece table.
 **************************************************************************************************/

#include "SwFrame.h"
#include "SwGuiApplication.h"
#include "SwTimer.h"
#include "SwWidgetPlatformAdapter.h"
#include "SwPieceTable.h"
#include "graphics/SwFontMetrics.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <sstream>
#include <string>

class SW_WIDGETS_EXPORT SwPlainTextEdit : public SwFrame {
    SW_OBJECT(SwPlainTextEdit, SwFrame)

protected:
    struct EditState {
        SwString text;
        size_t cursorPos{0};
        size_t selectionStart{0};
        size_t selectionEnd{0};
        int firstVisibleLine{0};
        std::function<void()> applyExtra;
    };

    enum class UndoMergeKind {
        NoMerge,
        InsertText,
        Backspace,
        DeleteForward
    };

    virtual EditState captureEditState() const;

public:
    explicit SwPlainTextEdit(SwWidget* parent = nullptr);

    void setWordWrapEnabled(bool on);

    bool wordWrapEnabled() const;

    virtual void setPlainText(const SwString& text);

    SwString toPlainText() const;

    virtual void appendPlainText(const SwString& text);

    virtual void clear();

    void setPlaceholderText(const SwString& text);

    SwString placeholderText() const;

    void setReadOnly(bool on);
    bool isReadOnly() const;

    int cursorPosition() const;

    // The number of lines (text blocks), as QPlainTextEdit::blockCount().
    int blockCount() const;

    bool hasSelectedText() const;

    SwString selectedText() const;

    void selectAll();

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    void setUndoRedoEnabled(bool on);

    bool isUndoRedoEnabled() const;
    bool canUndo() const;
    bool canRedo() const;

    void undo();

    void redo();

    void copy();

    void cut();

    void paste();

    SW_SIGNAL_VOID(textChanged);

protected:
    void resizeEvent(ResizeEvent* event) override;

    void paintEvent(PaintEvent* event) override;

    void mousePressEvent(MouseEvent* event) override;

    void mouseMoveEvent(MouseEvent* event) override;

    void mouseReleaseEvent(MouseEvent* event) override;

    void mouseDoubleClickEvent(MouseEvent* event) override;

    void wheelEvent(WheelEvent* event) override;

    void keyPressEvent(KeyEvent* event) override;

protected:
    struct Padding {
        int top{10};
        int right{10};
        int bottom{10};
        int left{10};
    };

    struct CursorInfo {
        int line{0};
        int col{0};
        size_t lineStart{0};
    };

    static bool isUtf8ContinuationByte_(unsigned char byte);

    static size_t clampUtf8BoundaryInText_(const SwString& text, size_t offset);

    static size_t nextUtf8BoundaryInText_(const SwString& text, size_t offset);

    static SwString utf8FromWideChar_(wchar_t wc);

    static Padding parsePaddingShorthand(const SwString& value, Padding current);

    Padding resolvePadding(StyleSheet* sheet) const;

    Padding intrinsicPadding_() const;

    int lineHeightPx() const;

    void ensureBlinkTimer();

    // ─── Line access abstraction ────────────────────────────────────────
    // When word wrap is off, delegates directly to piece table (logical lines).
    // When word wrap is on, uses the visual line cache.

    int effectiveLineCount_() const;

    SwString effectiveLineContent_(int lineIdx) const;

    size_t effectiveLineStart_(int lineIdx) const;

    size_t effectiveLineLength_(int lineIdx) const;

    int effectiveLineForOffset_(size_t pos) const;

    // ─── Visual line cache (only used when word wrap is on) ─────────────
    struct VisualLine {
        size_t offset;
        size_t length;
    };

    void rebuildVisualLines_();

    int resolveInnerWrapWidthPx_();

    // ─── Cursor ─────────────────────────────────────────────────────────

    CursorInfo cursorInfo() const;

    void clampFirstVisibleLine(int visibleLines);

    void ensureCursorVisible();

    virtual void updateCursorFromPosition(int px, int py);

    // ─── Text mutation ──────────────────────────────────────────────────

    virtual void insertTextAt(size_t pos, const SwString& text);

    virtual void eraseTextAt(size_t pos, size_t len);

    virtual void insertChar(char ch);

    virtual void insertText(const SwString& text);

    virtual void backspace();

    virtual void deleteForward();

    void moveCursorLeft();

    void moveCursorRight();

    void moveCursorHome();

    void moveCursorEnd();

    void moveCursorUp();

    void moveCursorDown();

    void initDefaults();

    size_t selectionMin_() const;
    size_t selectionMax_() const;

    size_t clampCursorBoundary_(size_t pos) const;

    size_t previousCursorBoundary_(size_t pos) const;

    size_t nextCursorBoundary_(size_t pos) const;

    void clearUndoRedo_();

    void pushUndoState_(EditState state);

    bool shouldMergeUndoState_(UndoMergeKind kind) const;

    void rememberUndoMergeState_(UndoMergeKind kind);

    void resetUndoMergeState_();

    void recordUndoState_(UndoMergeKind kind = UndoMergeKind::NoMerge);

    void restoreEditState_(const EditState& state);

    void replaceSelectionWithText_(const SwString& text, UndoMergeKind mergeKind = UndoMergeKind::NoMerge);

    void selectWordAtCursor_();

    SwPlatformIntegration* currentPlatformIntegration_() const;
public:
    ~SwPlainTextEdit();
protected:
    // What the class keeps (SwPlainTextEdit_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
