#pragma once

#include "SwUiLoader.h"

namespace swui { namespace detail {
// Existing Designer metadata, migrated without changing classes or presentation.
struct BuiltinWidgetMetadata {
    const char* className;
    const char* module;
    const char* category;
    const char* nameFr;
    const char* nameEn;
    const char* descriptionFr;
    const char* descriptionEn;
    const char* aliases;
    const char* previewKind;
    bool isLayout;
};
static const BuiltinWidgetMetadata builtinWidgetMetadata[] = {
    {"SwPushButton", "Widgets", "Basic", "Bouton", "Button", "Déclenche une action lorsque l'utilisateur appuie dessus.", "Runs an action when pressed.", "push button bouton poussoir action", "SwPushButton", false},
    {"SwToolButton", "Widgets", "Basic", "Bouton d'outil", "Tool button", "Bouton compact pour une commande de barre d'outils.", "Compact button for a toolbar command.", "toolbar bouton outil icone icon", "SwToolButton", false},
    {"SwLabel", "Widgets", "Basic", "Libellé", "Label", "Affiche un texte sans permettre sa modification.", "Displays text that cannot be edited.", "libelle etiquette texte statique caption static text", "SwLabel", false},
    {"SwLineEdit", "Widgets", "Basic", "Champ de texte", "Text field", "Saisie de texte sur une seule ligne.", "Single-line text input.", "line edit input saisie champ entree entry", "SwLineEdit", false},
    {"SwCheckBox", "Widgets", "Basic", "Case à cocher", "Checkbox", "Choix indépendant à cocher ou décocher.", "Independent option that can be checked or unchecked.", "check box case cocher choix option", "SwCheckBox", false},
    {"SwRadioButton", "Widgets", "Basic", "Bouton radio", "Radio button", "Sélectionne une option dans un groupe de choix.", "Selects one option from a group.", "radio choix exclusif selection option", "SwRadioButton", false},
    {"SwProgressBar", "Widgets", "Basic", "Progression", "Progress bar", "Indique l'avancement d'une opération.", "Shows the progress of an operation.", "progress bar barre progression avancement loading chargement", "SwProgressBar", false},
    {"SwComboBox", "Widgets", "Input", "Liste déroulante", "Dropdown", "Choisit une valeur dans une liste déroulante.", "Selects a value from a dropdown list.", "combo box combobox liste deroulante select menu", "SwComboBox", false},
    {"SwSpinBox", "Widgets", "Input", "Nombre entier", "Integer input", "Saisie d'un nombre entier avec boutons d'incrément.", "Integer input with increment buttons.", "spin box integer entier nombre number compteur", "SwSpinBox", false},
    {"SwDoubleSpinBox", "Widgets", "Input", "Nombre décimal", "Decimal input", "Saisie d'un nombre décimal avec boutons d'incrément.", "Decimal input with increment buttons.", "double spin box decimal nombre number float", "SwDoubleSpinBox", false},
    {"SwSlider", "Widgets", "Input", "Curseur", "Slider", "Ajuste une valeur en déplaçant un curseur.", "Adjusts a value by moving a slider.", "slider curseur glissiere range valeur", "SwSlider", false},
    {"SwPlainTextEdit", "Widgets", "Input", "Zone de texte", "Text area", "Éditeur de texte simple sur plusieurs lignes.", "Multi-line plain-text editor.", "plain text edit textarea texte simple multiligne multiline", "SwPlainTextEdit", false},
    {"SwTextEdit", "Widgets", "Input", "Texte enrichi", "Rich text", "Éditeur de texte avec mise en forme.", "Text editor with formatting.", "rich text edit editeur texte enrichi format html", "SwTextEdit", false},
    {"SwFrame", "Widgets", "Containers", "Cadre", "Frame", "Conteneur pour regrouper des widgets dans une zone.", "Container that groups widgets in an area.", "frame cadre panneau panel container conteneur", "SwFrame", false},
    {"SwGroupBox", "Widgets", "Containers", "Groupe", "Group", "Regroupe des widgets sous un titre.", "Groups widgets under a heading.", "group box groupe section titre heading", "SwGroupBox", false},
    {"SwScrollArea", "Widgets", "Containers", "Zone défilante", "Scroll area", "Affiche un contenu plus grand que la zone visible.", "Displays content larger than the visible area.", "scroll area zone defilante defilement scrolling", "SwScrollArea", false},
    {"SwTabWidget", "Widgets", "Containers", "Onglets", "Tabs", "Organise plusieurs pages dans des onglets.", "Organizes pages into tabs.", "tab widget tabs onglet onglets pages", "SwTabWidget", false},
    {"SwStackedWidget", "Widgets", "Containers", "Pages empilées", "Stacked pages", "Conteneur qui affiche une seule page à la fois.", "Container that displays one page at a time.", "stacked widget stack pages empilees pile", "SwStackedWidget", false},
    {"SwSplitter", "Widgets", "Containers", "Séparateur", "Split view", "Sépare des panneaux dont l'utilisateur ajuste la taille.", "Separates panels that the user can resize.", "splitter split view separateur panneaux redimensionner", "SwSplitter", false},
    {"SwListWidget", "Widgets", "Views", "Liste", "List", "Affiche une liste d'éléments sélectionnables.", "Displays a list of selectable items.", "list widget liste elements items", "SwListWidget", false},
    {"SwTableWidget", "Widgets", "Views", "Tableau", "Table", "Affiche des éléments en lignes et colonnes.", "Displays items in rows and columns.", "table widget tableau grille cellules rows columns", "SwTableWidget", false},
    {"SwTreeWidget", "Widgets", "Views", "Arborescence", "Tree", "Affiche des éléments dans une hiérarchie.", "Displays items in a hierarchy.", "tree widget arborescence arbre hierarchy hierarchie", "SwTreeWidget", false},
    {"SwTableView", "Widgets", "Views", "Tableau de modèle", "Model table", "Affiche les données d'un modèle en lignes et colonnes.", "Displays model data in rows and columns.", "table view model tableau modele donnees data", "SwTableView", false},
    {"SwTreeView", "Widgets", "Views", "Arbre de modèle", "Model tree", "Affiche les données hiérarchiques d'un modèle.", "Displays hierarchical model data.", "tree view model arbre modele donnees data", "SwTreeView", false},
    {"SwSetupHeading", "Installer", "Installer", "Titre d'installeur", "Setup heading", "Titre principal d'une page d'installation.", "Main heading of an installer page.", "setup heading installer installeur titre installation", "SwSetupHeading", false},
    {"SwSetupText", "Installer", "Installer", "Texte d'installeur", "Setup text", "Texte explicatif d'une page d'installation.", "Explanatory text on an installer page.", "setup text installer installeur texte notice", "SwSetupText", false},
    {"SwSetupPathEdit", "Installer", "Installer", "Choix de dossier", "Folder picker", "Choisit le dossier où installer l'application.", "Selects the application's installation folder.", "setup path edit folder picker dossier repertoire chemin directory", "SwSetupPathEdit", false},
    {"SwSetupComponentList", "Installer", "Installer", "Composants", "Components", "Liste les composants que l'utilisateur peut installer.", "Lists the components the user can install.", "setup component list composants components packages paquets", "SwSetupComponentList", false},
    {"SwSetupDiskSpace", "Installer", "Installer", "Espace disque", "Disk space", "Affiche les informations d'espace disque pour l'installation.", "Displays installation disk-space information.", "setup disk space espace disque storage stockage", "SwSetupDiskSpace", false},
    {"SwSetupLicenseView", "Installer", "Installer", "Licence", "License text", "Affiche la licence de l'application à installer.", "Displays the license of the application being installed.", "setup license view licence license agreement contrat eula", "SwSetupLicenseView", false},
    {"SwSetupImage", "Installer", "Installer", "Image", "Image", "Affiche une image sur une page d'installation.", "Displays an image on an installer page.", "setup image picture illustration logo", "SwSetupImage", false},
    {"SwSetupChoice", "Installer", "Installer", "Cartes de choix", "Choice cards", "Présente des options sous forme de cartes sélectionnables.", "Presents options as selectable cards.", "setup choice cards cartes choix options selection", "SwSetupChoice", false},
    {"SwSpacer", "Widgets", "Layouts", "Espaceur", "Spacer", "Réserve un espace libre entre des widgets.", "Reserves empty space between widgets.", "spacer espaceur espace libre espacement spring stretch", "SwSpacer", false},
    {"SwVerticalLayout", "Widgets", "Layouts", "Disposition verticale", "Vertical layout", "Aligne les widgets les uns au-dessus des autres.", "Arranges widgets above one another.", "vertical layout disposition verticale colonne column vbox", "SwVerticalLayout", true},
    {"SwHorizontalLayout", "Widgets", "Layouts", "Disposition horizontale", "Horizontal layout", "Aligne les widgets les uns à côté des autres.", "Arranges widgets side by side.", "horizontal layout disposition horizontale ligne row hbox", "SwHorizontalLayout", true},
    {"SwGridLayout", "Widgets", "Layouts", "Grille", "Grid layout", "Dispose les widgets dans une grille de lignes et colonnes.", "Arranges widgets in a grid of rows and columns.", "grid layout grille disposition cellules rows columns", "SwGridLayout", true},
    {"SwFormLayout", "Widgets", "Layouts", "Formulaire", "Form layout", "Associe des libellés à leurs champs de saisie.", "Pairs labels with their input fields.", "form layout formulaire disposition label field champs", "SwFormLayout", true},
};

inline bool applyBuiltinWidgetMetadata(WidgetDescriptor& descriptor) {
    for (const auto& source : builtinWidgetMetadata) {
        if (descriptor.className != source.className) continue;
        descriptor.module = source.module;
        descriptor.category = source.category;
        descriptor.nameFr = SwString::fromUtf8(source.nameFr);
        descriptor.nameEn = SwString::fromUtf8(source.nameEn);
        descriptor.descriptionFr = SwString::fromUtf8(source.descriptionFr);
        descriptor.descriptionEn = SwString::fromUtf8(source.descriptionEn);
        descriptor.aliases = source.aliases;
        descriptor.previewKind = source.previewKind;
        descriptor.isLayout = source.isLayout;
        descriptor.header = descriptor.module == "Installer" ? "core/installer/SwSetupWidgets.h" : descriptor.className + ".h";
        descriptor.cmakePackage = "SwStack";
        descriptor.cmakeTarget = "SwStack::" + descriptor.module;
        descriptor.constructorExpression = "new " + descriptor.className + "({parent})";
        descriptor.baseClass = "SwWidget";
        descriptor.defaultSize = {160,40};
        const auto& name = descriptor.className;
        if (name == "SwLabel") descriptor.defaultSize = {140,28};
        if (name == "SwLineEdit") descriptor.defaultSize = {200,34};
        if (name == "SwComboBox") descriptor.defaultSize = {180,34};
        if (name == "SwCheckBox" || name == "SwRadioButton") descriptor.defaultSize = {180,28};
        if (name == "SwProgressBar") descriptor.defaultSize = {220,20};
        if (name == "SwPlainTextEdit" || name == "SwTextEdit" || name == "SwListWidget") descriptor.defaultSize = {320,180};
        if (name == "SwTabWidget") descriptor.defaultSize = {420,260};
        if (name == "SwSpacer") descriptor.defaultSize = {26,20};
        if (name == "SwTableView" || name == "SwTreeView" || name == "SwTableWidget" || name == "SwTreeWidget") descriptor.defaultSize = {420,240};
        return true;
    }
    return false;
}
} } // namespace swui::detail
