#pragma once

#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextDiagnostics.h"

#include <cctype>

class SW_CODEEDITOR_EXPORT SwCppDiagnosticsProvider : public SwTextDiagnosticsProvider {
    SW_OBJECT(SwCppDiagnosticsProvider, SwTextDiagnosticsProvider)

public:
    explicit SwCppDiagnosticsProvider(SwTextDocument* parent = nullptr);

protected:
    void analyzeDocument(const SwString& text, SwList<SwTextDiagnostic>& diagnostics) override;

private:
    struct QualifiedTypeReference {
        SwString fullName;
        SwString prefix;
        SwString leaf;
        int start{0};
        int length{0};
        int leafStart{0};
        int leafLength{0};
    };

    struct LocalTypeTable {
        SwList<SwString> namespaces;
        SwList<SwString> types;
        SwMap<SwString, SwList<SwString>> typeMembers;
    };

    static bool isBuiltinKnownIdentifier_(const SwString& token);

    static bool isResolvableIdentifier_(const LocalTypeTable& table,
                                        const SwMap<SwString, SwString>& variables,
                                        const SwString& token);

    static SwTextCharFormat unknownMemberFormat_();

    static bool isIdentifierStart_(char ch);

    static bool isIdentifierPart_(char ch);

    static size_t skipSpaces_(const SwString& text, size_t pos);

    static SwString readIdentifierAt_(const SwString& text, size_t& pos);

    static SwString readIdentifier_(const SwString& text, size_t& pos);

    static bool isKeywordBoundary_(const SwString& text, size_t pos, size_t length);

    static bool startsWithKeywordAt_(const SwString& text, size_t pos, const char* keyword);

    static size_t findMatchingBrace_(const SwString& text, size_t openBrace);

    static SwString sanitizeCodeForSemanticParsing_(const SwString& text);

    static void appendUniqueString_(SwList<SwString>& values, const SwString& value);

    static bool containsString_(const SwList<SwString>& values, const SwString& value);

    static SwString collapseWhitespace_(const SwString& text);

    static SwString extractIdentifierBefore_(const SwString& text, size_t pos);

    static SwList<SwString> splitTopLevelComma_(const SwString& text);

    static SwString joinQualifiedName_(const SwList<SwString>& scope, const SwString& leaf);

    static bool isTypeDeclarationHead_(const SwString& text, size_t pos);

    static SwString leafNameOfQualified_(const SwString& qualifiedName);

    static void appendTypeMember_(LocalTypeTable& table, const SwString& typeName, const SwString& memberName);

    static SwString extractDeclaredNameFromDeclarator_(const SwString& declarator);

    static void collectTypeMembersFromBody_(const SwString& sanitizedBody,
                                            const SwString& qualifiedTypeName,
                                            LocalTypeTable& table);

    static void collectDeclaredTypes_(const SwString& sanitized,
                                      size_t begin,
                                      size_t end,
                                      const SwList<SwString>& scope,
                                      LocalTypeTable& table);

    static size_t skipTemplateArguments_(const SwString& text, size_t pos);

    static bool isPostTypeQualifier_(const SwString& token);

    static bool isIgnoredStatementHeadForTypeDiagnostics_(const SwString& token);

    static bool readQualifiedTypeReference_(const SwString& text, size_t& pos, QualifiedTypeReference& reference);

    static bool isPotentialDeclarationForType_(const SwString& statement, const QualifiedTypeReference& reference);

    static SwList<SwString> candidateQualifiedTypesByLeaf_(const LocalTypeTable& table, const SwString& leaf);

    static SwString resolveKnownTypeName_(const LocalTypeTable& table, const SwString& candidate);

    static bool isLeadingDeclarationQualifier_(const SwString& token);

    static SwString resolveTypeNameAt_(const SwString& statement,
                                       const LocalTypeTable& table,
                                       size_t& typeStart,
                                       size_t& typeEnd);

    static void registerDeclaredVariablesInStatement_(const SwString& statement,
                                                      const LocalTypeTable& table,
                                                      SwMap<SwString, SwString>& variables);

    static bool isTypeDeclarationHeaderText_(const SwString& header);

    static void collectDeclaredVariables_(const SwString& sanitized,
                                          size_t begin,
                                          size_t end,
                                          const LocalTypeTable& table,
                                          SwMap<SwString, SwString>& variables);

    static void appendSemanticError_(SwList<SwTextDiagnostic>& diagnostics,
                                     int start,
                                     int length,
                                     const SwString& message,
                                     const SwTextCharFormat& format = SwTextCharFormat());

    static void analyzeQualifiedTypesInStatement_(const SwString& statement,
                                                  int statementOffset,
                                                  const LocalTypeTable& table,
                                                  SwList<SwTextDiagnostic>& diagnostics);

    static void appendUnknownMemberDiagnostics_(const SwString& sanitized,
                                                const LocalTypeTable& table,
                                                const SwMap<SwString, SwString>& variables,
                                                SwList<SwTextDiagnostic>& diagnostics);

    static void appendUnknownObjectDiagnostics_(const SwString& sanitized,
                                                const LocalTypeTable& table,
                                                const SwMap<SwString, SwString>& variables,
                                                SwList<SwTextDiagnostic>& diagnostics);

    static void collectStatementTypeDiagnostics_(const SwString& text,
                                                 const SwString& sanitized,
                                                 size_t begin,
                                                 size_t end,
                                                 const LocalTypeTable& table,
                                                 SwList<SwTextDiagnostic>& diagnostics);

    static void appendUnresolvedQualifiedTypeDiagnostics_(const SwString& text,
                                                          SwList<SwTextDiagnostic>& diagnostics);

    static size_t skipSpacesBackward_(const SwString& text, size_t pos);
};
