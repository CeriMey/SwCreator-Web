#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwInteractiveConsoleApplication.h"

// The platform, which the public header no longer shows (SwInteractiveConsoleApplication.h).
#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include "platform/win/SwWindows.h"
#else
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/select.h>
#endif

struct SwInteractiveConsoleApplication::Data {
    // Given by the constructor: m_config.
    explicit Data(SwJsonDocument& config)
        : m_config(config) {}

    SwJsonDocument &m_config;                                     ///< Reference to the JSON document being manipulated.
    SwMap<SwString, std::function<void(const SwString &)>> m_commands; ///< Map of custom commands associated with JSON paths.
    SwMap<SwString, SwString> m_comments;                        ///< Map of comments associated with specific paths.
    SwTimer m_timer;                                             ///< Internal timer for polling user input.
    SwString m_currentPath;                                      ///< Current path in the JSON hierarchy.
    bool m_singleLineMode;                                       ///< Indicates whether single-line mode is active.
    NonBlockingReader m_nonBlockingReader;
};

struct NonBlockingReader::Data : SwSharedData {
#if defined(_WIN32)
    HANDLE hStdin;
#endif
#if defined(_WIN32)
#else
    int hStdin;
#endif
#if defined(_WIN32)
#else
    termios origTermios;
#endif
    std::string m_buffer;
};
