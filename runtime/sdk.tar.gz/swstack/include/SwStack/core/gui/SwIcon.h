#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwIcon.h
 * @brief Multi-resolution icon container (QIcon equivalent).
 *
 * Supports .ico files (Windows icon format with multiple embedded sizes),
 * .bmp (32-bit ARGB via SwImage), and raw SwImage data.
 *
 * Usage:
 * @code
 *   SwIcon icon("app.ico");              // load .ico with all resolutions
 *   SwIcon icon2(SwImage(myPixels));      // from single SwImage
 *
 *   SwImage img = icon.pixmap(16);        // best match for 16x16
 *   HICON hicon = icon.toHICON(32);       // native Win32 handle
 * @endcode
 */

#include "graphics/SwImage.h"
#include "SwString.h"

#include <vector>
#include <algorithm>
#include <fstream>
#include <cstring>


class SW_GUI_EXPORT SwIcon {
public:
    SwIcon();

    explicit SwIcon(const SwString& filePath);

    explicit SwIcon(const SwImage& image);

    // -- Loading --

    /**
     * @brief Load from file. Auto-detects .ico vs .bmp by extension and magic bytes.
     */
    bool load(const SwString& filePath);

    /**
     * @brief Add an image for a specific size.
     */
    void addImage(const SwImage& image, int size = 0);

    // -- Query --

    bool isNull() const;

    /** @brief Number of available resolutions. */
    int availableSizeCount() const;

    /** @brief Get the available sizes. */
    std::vector<int> availableSizes() const;

    /**
     * @brief Get the best-matching image for the requested size.
     * Returns the closest match (prefers larger over smaller).
     */
    SwImage pixmap(int requestedSize = 0) const;

    /** @brief Original file path (empty if constructed from SwImage). */
    SwString filePath() const;

    // -- Native handles --

#ifdef _WIN32
    /**
     * @brief Create a Win32 HICON from the best-matching resolution.
     * Caller does NOT own the handle — it is cached internally.
     */
    HICON toHICON(int size = 0) const;
#endif

    // -- Static constructors --

    static SwIcon fromImage(const SwImage& img);

    static SwIcon applicationIcon();

    /**
     * @brief Icon from a named ICON resource of the running executable
     *        (RC script entry: `MY_ICON ICON "file.ico"` → fromApplicationResource("MY_ICON")).
     *
     * Resolved lazily by toHICON() at the requested size; on non-Windows platforms the
     * returned icon is null.
     */
    static SwIcon fromApplicationResource(const SwString& resourceName);

private:
    struct Entry {
        SwImage image;
        int size = 0;
    };


    // -- ICO format parser --

    bool loadIco_(std::ifstream& in);

    SwImage loadIcoDib_(std::ifstream& in, int expectedW, int expectedH, uint32_t dataSize);

#ifdef _WIN32
    static HICON loadApplicationHIcon_(int size);

    static HICON createHIconFromImage_(const SwImage& img);
#endif

    // -- Binary readers --
    static uint8_t  readU8_(std::ifstream& in);
    static uint16_t readU16_(std::ifstream& in);
    static uint32_t readU32_(std::ifstream& in);
public:
    ~SwIcon();
public:
    SwIcon(const SwIcon& other);
    SwIcon& operator=(const SwIcon& other);
private:
    // What the class keeps (SwIcon_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
