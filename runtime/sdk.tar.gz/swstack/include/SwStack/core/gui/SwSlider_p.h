#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSlider.h"

struct SwSlider::Data {
    Orientation m_orientation;
    int m_minimum;
    int m_maximum;
    int m_value;
    int m_step;
    bool m_dragging;
    int m_handleSize;
};
