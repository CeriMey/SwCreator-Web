#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSortFilterProxyModel.h"

struct SwSortFilterProxyModel::Data {
    SwAbstractItemModel* m_sourceModel{nullptr};
    bool m_useRegex{false};
    SwString m_filterFixedString;
    SwRegularExpression m_filterRegularExpression;
    Sw::CaseSensitivity m_filterCaseSensitivity{Sw::CaseInsensitive};
    int m_filterKeyColumn{-1};
    SwItemDataRole m_filterRole{SwItemDataRole::DisplayRole};
    int m_sortColumn{-1};
    SwSortOrder m_sortOrder{SwSortOrder::AscendingOrder};
    SwItemDataRole m_sortRole{SwItemDataRole::DisplayRole};
    Sw::CaseSensitivity m_sortCaseSensitivity{Sw::CaseInsensitive};
    mutable bool m_cacheValid{false};
    mutable std::unordered_map<void*, SwModelIndex> m_sourceIndexByPtr;
    mutable SwList<Node> m_nodes;
};
