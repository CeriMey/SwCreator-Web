#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwFileExplorer.h"
#include "core/runtime/SwTimer.h"

#include <atomic>
#include <condition_variable>
#include <deque>
#include <map>
#include <mutex>
#include <set>
#include <thread>

namespace swFileExplorerDetail {
struct DirectoryLoad {
    SwString path;
    SwStringList filters;
    SwStringList directories;
    SwStringList files;
    std::atomic<bool> cancelled{false};
    std::atomic<bool> ready{false};
    bool failed{false};
    bool started{false};
    size_t nextDirectory{0};
    size_t nextFile{0};
};

struct DirectoryWorker {
    std::mutex mutex;
    std::condition_variable wake;
    std::deque<std::shared_ptr<DirectoryLoad>> queue;
    bool stopping{false};
};
} // namespace swFileExplorerDetail

// The platform, which the public header no longer shows (SwFileExplorer.h).
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#include <shellapi.h>
#include <shlobj.h>
#include <shlwapi.h>
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "shlwapi.lib")
#endif

struct SwFileExplorer::Data {
    SwLabel* m_titleLabel{nullptr};
    SwWidget* m_headerRow{nullptr};
    bool m_compactMode{false};
    SwLabel* m_rootLabel{nullptr};
    SwToolButton* m_workspaceButton{nullptr};
    FileTreeWidget* m_tree{nullptr};
    SwString m_title;
    SwString m_rootPath;
    SwString m_currentPath;
    SwStringList m_nameFilters;
    SwMap<SwString, bool> m_markedPaths;
    SwMap<SwString, SwStandardItem*> m_itemsByPath;
    SwMap<SwString, bool> m_populatedDirectories;
    swFileExplorerDetail::SystemIconCache m_iconCache;
    bool m_syncingSelection{false};
    bool m_doubleClickActivationEnabled{false};
    bool m_associationIcons{false};
    bool m_asyncLoading{false};
    SwTimer* m_loadTimer{nullptr};
    std::shared_ptr<swFileExplorerDetail::DirectoryWorker> m_worker;
    std::map<std::string, std::shared_ptr<swFileExplorerDetail::DirectoryLoad>> m_loads;
    std::set<std::string> m_directoryPaths;
    SwString m_renderedRootPath;
    std::set<std::string> m_reloadExpandedPaths;
    std::uint64_t m_treeGeneration{0};
};

struct swFileExplorerDetail::SystemIconCache::Data : SwSharedData {
    std::unordered_map<std::string, SwImage> m_cache;
    bool m_fileAssociationMode{false};
};
