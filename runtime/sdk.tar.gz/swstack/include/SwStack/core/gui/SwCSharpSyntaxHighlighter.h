#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwCSharpSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat attributeFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat preprocessorFormat;
    SwTextCharFormat constantFormat;
};

inline SwTextCharFormat swCSharpMakeFormat_(const SwColor& color,
                                             FontWeight weight = Normal,
                                             bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) { format.setFontWeight(weight); }
    if (italic) { format.setFontItalic(true); }
    return format;
}

inline SwCSharpSyntaxTheme swCSharpSyntaxThemeVsCodeDark() {
    SwCSharpSyntaxTheme theme;
    theme.keywordFormat      = swCSharpMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.typeFormat         = swCSharpMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat      = swCSharpMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat       = swCSharpMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat       = swCSharpMakeFormat_(SwColor{181, 206, 168});
    theme.attributeFormat    = swCSharpMakeFormat_(SwColor{220, 220, 170});
    theme.functionFormat     = swCSharpMakeFormat_(SwColor{220, 220, 170});
    theme.preprocessorFormat = swCSharpMakeFormat_(SwColor{197, 134, 192});
    theme.constantFormat     = swCSharpMakeFormat_(SwColor{79, 193, 255});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwCSharpSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwCSharpSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwCSharpSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwCSharpSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BlockCommentState = 1
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int findBlockCommentEnd_(const SwString& text, int start);

    static int parseNumber_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isType_(const SwString& word);

public:
    ~SwCSharpSyntaxHighlighter();
private:
    // What the class keeps (SwCSharpSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
