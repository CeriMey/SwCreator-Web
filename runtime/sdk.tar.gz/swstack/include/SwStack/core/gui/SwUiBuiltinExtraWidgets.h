// Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0
#pragma once

#include "SwUiLoader.h"
#include "SwUiWidgetRegistration.h"
#include "SwDockWidget.h"
#include "SwEmojiPicker.h"
#include "SwFileExplorer.h"
#include "SwMenuBar.h"
#include "SwScrollBar.h"
#include "SwStatusBar.h"
#include "SwToolBar.h"
#include "chatbubble/SwChatBubble.h"

#include <initializer_list>

namespace swui { namespace detail {

inline WidgetDescriptor builtinExtraDescriptor(const char* name, const char* category,
    const char* french, const char* english, const char* descriptionFr,
    const char* descriptionEn, const char* aliases, SwSize size, const char* header = nullptr) {
    WidgetDescriptor entry;
    entry.className = name;
    entry.module = "Widgets";
    entry.category = category;
    entry.nameFr = SwString::fromUtf8(french);
    entry.nameEn = english;
    entry.descriptionFr = SwString::fromUtf8(descriptionFr);
    entry.descriptionEn = descriptionEn;
    entry.aliases = aliases;
    entry.previewKind = name;
    entry.header = header ? SwString(header) : SwString(name) + ".h";
    entry.cmakePackage = "SwStack";
    entry.cmakeTarget = "SwStack::Widgets";
    entry.constructorExpression = "new " + entry.className + "({parent})";
    entry.baseClass = "SwWidget";
    entry.defaultSize = size;
    return entry;
}

inline SwString scrollBarOrientationName(const SwScrollBar* scroll) {
    return scroll->orientation() == SwScrollBar::Orientation::Horizontal ? "Horizontal" : "Vertical";
}
inline void setScrollBarOrientationName(SwScrollBar* scroll, const SwString& value) {
    scroll->setOrientation(value == "Horizontal" ? SwScrollBar::Orientation::Horizontal
                                               : SwScrollBar::Orientation::Vertical);
}

// Called by UiFactory's constructor with that factory. Using instance() here
// would recursively initialize the singleton.
inline void registerBuiltinExtraWidgets(UiFactory& factory) {
    auto emoji = builtinExtraDescriptor("SwEmojiPicker", "Input", "Sélecteur d’emoji", "Emoji picker",
        "Choisit un emoji parmi des catégories configurables.", "Selects an emoji from configurable categories.",
        "emoji emoticon smiley smile sélecteur picker SwEmojiPiker", {320, 240});
    emoji.signalSignatures.append("emojiClicked(SwString)");
    factory.registerWidget(emoji, [](SwWidget* parent) -> SwWidget* { return new SwEmojiPicker(parent); });
    // The spelling alias still reports SwEmojiPiker through SW_OBJECT. Retain
    // that runtime identity for saved forms without duplicating the palette card.
    emoji.className = "SwEmojiPiker";
    emoji.designerVisible = false;
    factory.registerWidget(emoji, [](SwWidget* parent) -> SwWidget* { return new SwEmojiPiker(parent); });

    auto chat = builtinExtraDescriptor("SwChatBubble", "Views", "Bulle de conversation", "Chat bubble",
        "Affiche un message de conversation ; le contenu est fourni par l’application.",
        "Displays a chat message; application code supplies the content.",
        "chat conversation message bubble bulle texte discussion", {320, 100}, "core/gui/chatbubble/SwChatBubble.h");
    chat.properties.push_back({"TextSelectable", "setTextSelectable", "bool", {}});
    factory.registerWidget(chat, [](SwWidget* parent) -> SwWidget* { return new SwChatBubble(parent); });
    registerWidgetProperty<SwChatBubble, bool, &SwChatBubble::textSelectable,
        &SwChatBubble::setTextSelectable>("TextSelectable");

    auto toolbar = builtinExtraDescriptor("SwToolBar", "Containers", "Barre d’outils", "Tool bar",
        "Barre horizontale dont les actions sont ajoutées dans le code de l’application.",
        "Horizontal bar whose actions are added in application code.",
        "toolbar tool bar barre outils actions boutons", {320, 52});
    toolbar.baseClass = "SwFrame";
    factory.registerWidget(toolbar, [](SwWidget* parent) -> SwWidget* { return new SwToolBar(parent); });

    auto menu = builtinExtraDescriptor("SwMenuBar", "Containers", "Barre de menus", "Menu bar",
        "Barre de menus ; les menus et leurs actions sont configurés dans l’application.",
        "Menu bar; application code configures its menus and actions.",
        "menubar menu bar barre menus actions navigation", {320, 32});
    menu.baseClass = "SwFrame";
    factory.registerWidget(menu, [](SwWidget* parent) -> SwWidget* { return new SwMenuBar(parent); });

    auto status = builtinExtraDescriptor("SwStatusBar", "Containers", "Barre d’état", "Status bar",
        "Présente un message d’état et des widgets permanents fournis par l’application.",
        "Presents a status message and permanent widgets supplied by application code.",
        "statusbar status bar barre état statut message footer pied", {320, 30});
    status.baseClass = "SwFrame";
    factory.registerWidget(status, [](SwWidget* parent) -> SwWidget* { return new SwStatusBar(parent); });

    auto dock = builtinExtraDescriptor("SwDockWidget", "Containers", "Panneau détachable", "Dock panel",
        "Panneau avec titre ; son contenu et ses cibles d’ancrage sont fournis par l’application.",
        "Titled panel; application code supplies its content and docking targets.",
        "dock docking panel panneau détachable ancrage flottant fenêtre", {320, 240});
    dock.constructorExpression = "new SwDockWidget(SwString(), {parent})";
    dock.properties.push_back({"Title", "setTitle", "string", {}});
    for (const char* signature : {"presentationAboutToChange()", "floatingChanged(bool)", "floatingActiveChanged(bool)"})
        dock.signalSignatures.append(signature);
    factory.registerWidget(dock, [](SwWidget* parent) -> SwWidget* { return new SwDockWidget(SwString(), parent); });
    registerWidgetProperty<SwDockWidget, SwString, &SwDockWidget::title, &SwDockWidget::setTitle>("Title");

    auto scroll = builtinExtraDescriptor("SwScrollBar", "Input", "Barre de défilement", "Scroll bar",
        "Règle une valeur entière avec une poignée horizontale ou verticale.",
        "Adjusts an integer value with a horizontal or vertical thumb.",
        "scrollbar scroll bar barre défilement ascenseur vertical horizontal", {220, 22});
    scroll.constructorExpression = "new SwScrollBar(SwScrollBar::Orientation::Horizontal, {parent})";
    scroll.properties.push_back({"Orientation", "setOrientation", "enum", {
        {"Horizontal", "SwScrollBar::Orientation::Horizontal"}, {"Vertical", "SwScrollBar::Orientation::Vertical"}}});
    for (const auto& property : std::initializer_list<WidgetProperty>{
            {"Minimum", "setMinimum", "int", {}}, {"Maximum", "setMaximum", "int", {}},
            {"PageStep", "setPageStep", "int", {}}, {"SingleStep", "setSingleStep", "int", {}},
            {"Value", "setValue", "int", {}}}) scroll.properties.push_back(property);
    for (const char* signature : {"valueChanged(int)", "rangeChanged(int,int)", "sliderPressed(int)",
            "sliderMoved(int)", "sliderReleased(int)"}) scroll.signalSignatures.append(signature);
    factory.registerWidget(scroll, [](SwWidget* parent) -> SwWidget* {
        return new SwScrollBar(SwScrollBar::Orientation::Horizontal, parent);
    });
    registerWidgetProperty<SwScrollBar, SwString, &scrollBarOrientationName, &setScrollBarOrientationName>("Orientation");
    registerWidgetProperty<SwScrollBar, int, &SwScrollBar::minimum, &SwScrollBar::setMinimum>("Minimum");
    registerWidgetProperty<SwScrollBar, int, &SwScrollBar::maximum, &SwScrollBar::setMaximum>("Maximum");
    registerWidgetProperty<SwScrollBar, int, &SwScrollBar::pageStep, &SwScrollBar::setPageStep>("PageStep");
    registerWidgetProperty<SwScrollBar, int, &SwScrollBar::singleStep, &SwScrollBar::setSingleStep>("SingleStep");
    registerWidgetProperty<SwScrollBar, int, &SwScrollBar::value, &SwScrollBar::setValue>("Value");

    auto files = builtinExtraDescriptor("SwFileExplorer", "Views", "Explorateur de fichiers", "File explorer",
        "Affiche l’arborescence d’un dossier ; dans le navigateur, utilise le système de fichiers virtuel.",
        "Displays a folder tree; uses the virtual filesystem in the browser.",
        "file explorer files folder dossier fichiers arborescence répertoire browser", {320, 240});
    for (const auto& property : std::initializer_list<WidgetProperty>{
            {"Title", "setTitle", "string", {}}, {"RootPath", "setRootPath", "string", {}},
            {"CurrentPath", "setCurrentPath", "string", {}},
            {"DoubleClickActivationEnabled", "setDoubleClickActivationEnabled", "bool", {}},
            {"FileAssociationIconsEnabled", "setFileAssociationIconsEnabled", "bool", {}},
            {"AsynchronousLoadingEnabled", "setAsynchronousLoadingEnabled", "bool", {}}}) files.properties.push_back(property);
    for (const char* signature : {"pathActivated(const SwString&)", "currentPathChanged(const SwString&)",
            "pathContextMenuRequested(const SwString&,int,int)", "workspaceBrowseRequested()", "loadingChanged(bool)",
            "directoryLoading(const SwString&)", "directoryLoaded(const SwString&)"}) files.signalSignatures.append(signature);
    factory.registerWidget(files, [](SwWidget* parent) -> SwWidget* { return new SwFileExplorer(parent); });
    registerWidgetProperty<SwFileExplorer, SwString, &SwFileExplorer::title, &SwFileExplorer::setTitle>("Title");
    registerWidgetProperty<SwFileExplorer, SwString, &SwFileExplorer::rootPath, &SwFileExplorer::setRootPath>("RootPath");
    registerWidgetProperty<SwFileExplorer, SwString, &SwFileExplorer::currentPath, &SwFileExplorer::setCurrentPath>("CurrentPath");
    registerWidgetProperty<SwFileExplorer, bool, &SwFileExplorer::doubleClickActivationEnabled,
        &SwFileExplorer::setDoubleClickActivationEnabled>("DoubleClickActivationEnabled");
    registerWidgetProperty<SwFileExplorer, bool, &SwFileExplorer::fileAssociationIconsEnabled,
        &SwFileExplorer::setFileAssociationIconsEnabled>("FileAssociationIconsEnabled");
    registerWidgetProperty<SwFileExplorer, bool, &SwFileExplorer::asynchronousLoadingEnabled,
        &SwFileExplorer::setAsynchronousLoadingEnabled>("AsynchronousLoadingEnabled");
}

} } // namespace swui::detail
