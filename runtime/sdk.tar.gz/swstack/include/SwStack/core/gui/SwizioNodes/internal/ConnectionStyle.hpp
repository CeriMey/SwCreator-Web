#pragma once

/**
 * @file src/core/gui/SwizioNodes/internal/ConnectionStyle.hpp
 * @ingroup core_swizio_nodes
 * @brief Declares the public interface exposed by ConnectionStyle in the CoreSw node-editor
 * layer.
 *
 * This header belongs to the CoreSw node-editor layer. It contains the graph, geometry, style,
 * and scene infrastructure used by the embedded node editor.
 *
 * Within that layer, this file focuses on the connection style interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * This header mainly contributes module-level utilities, helper declarations, or namespaced types
 * that are consumed by the surrounding subsystem.
 *
 * Style-oriented declarations here capture reusable visual parameters so rendering code can stay
 * deterministic while still allowing higher-level customization.
 *
 * Most declarations here are extension points or internal contracts that coordinate graph
 * editing, visualization, and interaction.
 *
 */


#include "SwSharedData.h"
#include "Export.hpp"
#include "Style.hpp"

#include "ColorUtils.hpp"

#include "core/types/Sw.h"
#include "core/types/SwString.h"

namespace SwizioNodes {

class SW_NODES_EXPORT ConnectionStyle : public Style
{
public:
    /**
     * @brief Constructs a `ConnectionStyle` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    ConnectionStyle();

    /**
     * @brief Constructs a `ConnectionStyle` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit ConnectionStyle(SwString jsonText);

    /**
     * @brief Destroys the `ConnectionStyle` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~ConnectionStyle() override;

public:
    /**
     * @brief Sets the connection Style.
     * @param jsonText Value passed to the method.
     * @return The requested connection Style.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setConnectionStyle(SwString jsonText);

public:
    /**
     * @brief Performs the `loadJson` operation on the associated resource.
     * @param json Value passed to the method.
     */
    void loadJson(SwJsonObject const& json) override;

    /**
     * @brief Returns the current to Json.
     * @return The current to Json.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwJsonObject toJson() const override;

public:
    /**
     * @brief Returns the current construction Color.
     * @return The current construction Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor constructionColor() const;
    /**
     * @brief Returns the current normal Color.
     * @return The current normal Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor normalColor() const;
    /**
     * @brief Performs the `normalColor` operation.
     * @param SwString Value passed to the method.
     * @return The requested normal Color.
     */
    SwColor normalColor(SwString /*typeId*/) const;
    /**
     * @brief Returns the current selected Color.
     * @return The current selected Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor selectedColor() const;
    /**
     * @brief Returns the current selected Halo Color.
     * @return The current selected Halo Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor selectedHaloColor() const;
    /**
     * @brief Returns the current hovered Color.
     * @return The current hovered Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor hoveredColor() const;

    /**
     * @brief Returns the current line Width.
     * @return The current line Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float lineWidth() const;
    /**
     * @brief Returns the current construction Line Width.
     * @return The current construction Line Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float constructionLineWidth() const;
    /**
     * @brief Returns the current point Diameter.
     * @return The current point Diameter.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float pointDiameter() const;

    /**
     * @brief Returns the current use Data Defined Colors.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool useDataDefinedColors() const;

private:


public:
    ConnectionStyle(const ConnectionStyle& other);
    ConnectionStyle& operator=(const ConnectionStyle& other);
private:
    // What the class keeps (ConnectionStyle_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace SwizioNodes
