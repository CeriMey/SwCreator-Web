#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwizioNodes/internal/ConnectionGraphicsObject.hpp"

struct SwizioNodes::ConnectionGraphicsObject::Data {
    ConnectionId m_connectionId{};
    BasicGraphicsScene* m_scene{nullptr};
    NodeGraphicsObject* m_outNode{nullptr};
    NodeGraphicsObject* m_inNode{nullptr};
    int m_outPort{0};
    int m_inPort{0};
    SwPointF m_sceneEndPoint{};
    bool m_hasSceneEndPoint{false};
    bool m_hovered{false};
    int m_flowPulseDurationMs{300};
    bool m_flowActive{false};
    std::chrono::steady_clock::time_point m_flowStart{};
    std::chrono::steady_clock::time_point m_flowLast{};
};
