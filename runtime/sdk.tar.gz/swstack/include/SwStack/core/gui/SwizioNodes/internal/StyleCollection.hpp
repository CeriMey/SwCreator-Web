#pragma once

/**
 * @file
 * @ingroup core_swizio_nodes
 * @brief Declares the singleton-style repository for node-editor visual styles.
 *
 * `StyleCollection` stores the active node, connection, and view style objects used by
 * the embedded node-editor module. It gives rendering code a central place to read or
 * override the current theme without threading style instances through every object.
 */

#include <memory>
#include "Export.hpp"

#include "ConnectionStyle.hpp"
#include "GraphicsViewStyle.hpp"
#include "NodeStyle.hpp"

#include "core/types/SwString.h"

namespace SwizioNodes {

class SW_NODES_EXPORT StyleCollection
{
public:
    /**
     * @brief Returns the current node Style.
     * @return The current node Style.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static NodeStyle const& nodeStyle();

    /**
     * @brief Returns the current connection Style.
     * @return The current connection Style.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static ConnectionStyle const& connectionStyle();

    /**
     * @brief Returns the current flow View Style.
     * @return The current flow View Style.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static GraphicsViewStyle const& flowViewStyle();

    /**
     * @brief Returns the current widget Node Style.
     * @return The current widget Node Style.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwString const& widgetNodeStyle();

public:
    /**
     * @brief Sets the node Style.
     * @param NodeStyle Value passed to the method.
     * @return The requested node Style.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setNodeStyle(NodeStyle);

    /**
     * @brief Sets the connection Style.
     * @param ConnectionStyle Value passed to the method.
     * @return The requested connection Style.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setConnectionStyle(ConnectionStyle);

    /**
     * @brief Sets the graphics View Style.
     * @param GraphicsViewStyle Value passed to the method.
     * @return The requested graphics View Style.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setGraphicsViewStyle(GraphicsViewStyle);

    /**
     * @brief Sets the widget Node Style.
     * @return The requested widget Node Style.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setWidgetNodeStyle(const SwString&);

private:
    StyleCollection();
    StyleCollection(StyleCollection const&) = delete;
    StyleCollection& operator=(StyleCollection const&) = delete;

    static StyleCollection& instance();

private:
public:
    ~StyleCollection();
private:
    // What the class keeps (StyleCollection_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

inline void NodeStyle::setNodeStyle(SwString jsonText)
{
    NodeStyle style(std::move(jsonText));
    StyleCollection::setNodeStyle(std::move(style));
}

inline void NodeStyle::setWidgetStyle(SwString jsonText) { StyleCollection::setWidgetNodeStyle(jsonText); }

inline void ConnectionStyle::setConnectionStyle(SwString jsonText)
{
    ConnectionStyle style(std::move(jsonText));
    StyleCollection::setConnectionStyle(std::move(style));
}

inline void GraphicsViewStyle::setStyle(SwString jsonText)
{
    GraphicsViewStyle style(std::move(jsonText));
    StyleCollection::setGraphicsViewStyle(std::move(style));
}

} // namespace SwizioNodes
