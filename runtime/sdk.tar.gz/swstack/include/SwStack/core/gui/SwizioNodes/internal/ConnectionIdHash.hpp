#pragma once

#include "../../../SwStackExport.h"

/**
 * @file
 * @ingroup core_swizio_nodes
 * @brief Declares hashing helpers for node-editor connection identifiers.
 *
 * The utilities in this header make `ConnectionId` usable in hash-based containers by
 * providing both a project-local hash functor and a `std::hash` specialization. That
 * keeps lookup code efficient without spreading ad-hoc hashing logic through the editor.
 */




#include "Definitions.hpp"

#include <cstddef>

namespace SwizioNodes {

struct SW_NODES_EXPORT ConnectionIdHash
{
    /**
     * @brief Performs the `operator` operation.
     * @param c Value passed to the method.
     * @return The requested operator.
     */
    std::size_t operator()(ConnectionId const& c) const noexcept;
};

} // namespace SwizioNodes

namespace std {
template <>
struct hash<SwizioNodes::ConnectionId> {
    /**
     * @brief Performs the `operator` operation.
     * @param c Value passed to the method.
     * @return The requested operator.
     */
    std::size_t operator()(SwizioNodes::ConnectionId const& c) const noexcept
    {
        return SwizioNodes::ConnectionIdHash{}(c);
    }
};
} // namespace std
