#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwizioNodes/internal/DataFlowGraphModel.hpp"

struct SwizioNodes::DataFlowGraphModel::Data {
    std::shared_ptr<NodeDelegateModelRegistry> m_registry;
    NodeId m_nextNodeId{1};
    std::unordered_map<NodeId, std::unique_ptr<NodeDelegateModel>> m_models;
    std::unordered_set<ConnectionId> m_connectivity;
    mutable std::unordered_map<NodeId, NodeGeometryData> m_nodeGeometryData;
    SwString m_nodesContext;
    std::shared_ptr<int> m_lifeToken{std::make_shared<int>(0)};
};
