#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwizioNodes/internal/StyleCollection.hpp"

struct SwizioNodes::StyleCollection::Data {
    NodeStyle m_nodeStyle;
    ConnectionStyle m_connectionStyle;
    GraphicsViewStyle m_flowViewStyle;
    SwString m_widgetNodeViewStyle;
};
