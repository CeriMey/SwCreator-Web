#pragma once

/**
 * @file
 * @ingroup core_swizio_nodes
 * @brief Declares the scene item responsible for visualizing a node-editor connection.
 *
 * This graphics object tracks one logical edge from the graph model and turns it into a
 * selectable, paintable scene primitive. It sits between the abstract connection state and
 * the `SwGraphicsScene`, handling geometry refresh, hit testing, and repaint requests.
 */

#include <memory>
#include "Export.hpp"

#include "SwizioNodes/internal/ConnectionPainter.hpp"
#include "SwizioNodes/internal/Definitions.hpp"
#include "SwizioNodes/internal/NodeGraphicsObject.hpp"

#include "graphics/SwGraphicsItem.h"
#include "graphics/SwGraphicsRenderContext.h"
#include "graphics/SwGraphicsTypes.h"

#include <algorithm>
#include <chrono>
#include <cmath>

namespace SwizioNodes {

class BasicGraphicsScene;

class SW_NODES_EXPORT ConnectionGraphicsObject : public SwGraphicsItem
{
public:
    /**
     * @brief Constructs a `ConnectionGraphicsObject` instance.
     * @param scene Value passed to the method.
     * @param scene Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    ConnectionGraphicsObject(BasicGraphicsScene& scene, ConnectionId const connectionId);

    /**
     * @brief Destroys the `ConnectionGraphicsObject` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~ConnectionGraphicsObject() override;

    /**
     * @brief Returns the current connection Id.
     * @return The current connection Id.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    ConnectionId const& connectionId() const;

    /**
     * @brief Returns the current node Scene.
     * @return The current node Scene.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    BasicGraphicsScene* nodeScene() const;

    /**
     * @brief Sets the out Endpoint.
     * @param node Value passed to the method.
     * @param port Local port used by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOutEndpoint(NodeGraphicsObject* node, int port);

    /**
     * @brief Sets the in Endpoint.
     * @param node Value passed to the method.
     * @param port Local port used by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setInEndpoint(NodeGraphicsObject* node, int port);

    /**
     * @brief Sets the scene End Point.
     * @param scenePos Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSceneEndPoint(const SwPointF& scenePos);

    /**
     * @brief Returns whether the object reports complete.
     * @return `true` when the object reports complete; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isComplete() const;

    /**
     * @brief Returns the current out Node.
     * @return The current out Node.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    NodeGraphicsObject* outNode() const;
    /**
     * @brief Returns the current in Node.
     * @return The current in Node.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    NodeGraphicsObject* inNode() const;
    /**
     * @brief Returns the current out Port.
     * @return The current out Port.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int outPort() const;
    /**
     * @brief Returns the current in Port.
     * @return The current in Port.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int inPort() const;

    /**
     * @brief Sets the hovered.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHovered(bool on);

    /**
     * @brief Returns whether the object reports hovered.
     * @return `true` when the object reports hovered; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isHovered() const;

    /**
     * @brief Sets the flow Pulse Duration Ms.
     * @param ms Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFlowPulseDurationMs(int ms);

    /**
     * @brief Returns the current flow Pulse Duration Ms.
     * @return The current flow Pulse Duration Ms.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int flowPulseDurationMs() const;

    /**
     * @brief Performs the `notifyDataFlow` operation.
     */
    void notifyDataFlow();

    /**
     * @brief Clears the current object state.
     */
    void clearFlow();

    /**
     * @brief Performs the `tickFlow` operation.
     * @param now Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool tickFlow(const std::chrono::steady_clock::time_point& now);

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
    SwPointF startScene_() const;

    SwPointF endScene_() const;

private:
    // What the class keeps (ConnectionGraphicsObject_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

} // namespace SwizioNodes
