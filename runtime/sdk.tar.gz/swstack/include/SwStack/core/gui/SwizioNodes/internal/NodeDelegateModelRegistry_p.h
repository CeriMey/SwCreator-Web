#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwizioNodes/internal/NodeDelegateModelRegistry.h"

struct SwizioNodes::NodeDelegateModelRegistry::Data {
    RegisteredModelsCategoryMap m_registeredModelsCategory;
    CategoriesSet m_categories;
    RegisteredModelCreatorsMap m_registeredItemCreators;
};
