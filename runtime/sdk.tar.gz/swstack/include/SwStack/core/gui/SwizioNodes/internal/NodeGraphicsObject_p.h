#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwizioNodes/internal/NodeGraphicsObject.hpp"

struct SwizioNodes::NodeGraphicsObject::Data {
    BasicGraphicsScene* m_scene{nullptr};
    NodeId m_nodeId{InvalidNodeId};
    SwString m_typeKey;
    SwString m_title;
    std::vector<SwString> m_inputs;
    std::vector<SwString> m_outputs;
    SwColor m_accent{0, 139, 139};
    SwString m_bodyText;
    PortHit m_hoverPort{};
    std::vector<bool> m_multiIn;
    std::vector<bool> m_multiOut;
    SwGraphicsProxyWidget* m_proxyWidget{nullptr};
};
