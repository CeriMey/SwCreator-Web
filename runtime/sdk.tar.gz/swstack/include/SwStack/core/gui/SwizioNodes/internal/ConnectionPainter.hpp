#pragma once

/**
 * @file
 * @ingroup core_swizio_nodes
 * @brief Declares the helper that paints node-editor connections.
 *
 * `ConnectionPainter` centralizes how connection curves, end points, and styling rules are
 * drawn so the scene items do not duplicate low-level painting code. It is the rendering
 * policy layer between connection geometry and the underlying `SwPainter` API.
 */




#include "Export.hpp"
#include "StyleCollection.hpp"

#include "SwPainter.h"
#include "graphics/SwGraphicsRenderContext.h"

#include <algorithm>
#include <cmath>

class SwPainter;

namespace SwizioNodes {

class SW_NODES_EXPORT ConnectionPainter
{
public:
    struct PaintData
    {
        SwPointF startScene{};
        SwPointF endScene{};

        // When set, overrides ConnectionStyle colors for the main stroke.
        bool useCustomColor{false};
        SwColor customColor{0, 0, 0};

        bool hovered{false};
        bool selected{false};
        bool complete{true};

        bool flowActive{false};
        double flowPhase{0.0}; // [0..1)
    };

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     * @param data Value passed to the method.
     * @return The requested paint.
     */
    static void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx, const PaintData& data);

private:
    static int roundToInt_(double v);

    static int clampInt_(int v, int lo, int hi);

    static SwPointF cubicBezier_(const SwPointF& p0,
                                 const SwPointF& p1,
                                 const SwPointF& p2,
                                 const SwPointF& p3,
                                 double t);

    static SwColor clampColorOffset_(const SwColor& c, int dr, int dg, int db);
};


} // namespace SwizioNodes
