#pragma once

/**
 * @file src/core/gui/SwizioNodes/internal/AbstractNodeGeometry.hpp
 * @ingroup core_swizio_nodes
 * @brief Declares the public interface exposed by AbstractNodeGeometry in the CoreSw node-editor
 * layer.
 *
 * This header belongs to the CoreSw node-editor layer. It contains the graph, geometry, style,
 * and scene infrastructure used by the embedded node editor.
 *
 * Within that layer, this file focuses on the abstract node geometry interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * This header mainly contributes module-level utilities, helper declarations, or namespaced types
 * that are consumed by the surrounding subsystem.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Most declarations here are extension points or internal contracts that coordinate graph
 * editing, visualization, and interaction.
 *
 */


#include "SwSharedData.h"
#include "Export.hpp"

#include "SwizioNodes/internal/AbstractGraphModel.hpp"
#include "SwizioNodes/internal/StyleCollection.hpp"

#include "core/types/Sw.h"
#include "graphics/SwGraphicsTypes.h" // SwTransform lives here

#include <cmath>

// X11 defines None as a macro, and PortType::None needs the name: the X11 headers may come
// in after Definitions.hpp has removed it. Restored at the end of this file.
#pragma push_macro("None")
#undef None

namespace SwizioNodes {

class SW_NODES_EXPORT AbstractNodeGeometry
{
public:
    /**
     * @brief Constructs a `AbstractNodeGeometry` instance.
     * @param graphModel Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit AbstractNodeGeometry(AbstractGraphModel& graphModel);

    /**
     * @brief Destroys the `AbstractNodeGeometry` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    virtual ~AbstractNodeGeometry();

    /**
     * The node's size plus some additional margin around it to account for drawing
     * effects (for example shadows) or node's parts outside the size rectangle
     * (for example port points).
     */
    virtual SwRectF boundingRect(NodeId const nodeId) const;

    /// A direct rectangle defining the borders of the node's rectangle.
    virtual SwSize size(NodeId const nodeId) const = 0;

    /// Recompute cached size when ports or embedded widgets change.
    virtual void recomputeSize(NodeId const nodeId) const = 0;

    /// Port position in node's coordinate system.
    virtual SwPointF portPosition(NodeId const nodeId,
                                  PortType const portType,
                                  PortIndex const index) const
        = 0;

    /// A convenience function using the `portPosition` and a given transformation.
    virtual SwPointF portScenePosition(NodeId const nodeId,
                                       PortType const portType,
                                       PortIndex const index,
                                       SwTransform const& t) const;

    /// Defines where to draw port label. The point corresponds to a font baseline.
    virtual SwPointF portTextPosition(NodeId const nodeId,
                                      PortType const portType,
                                      PortIndex const portIndex) const
        = 0;

    /// Defines where to start drawing the caption. The point corresponds to a font baseline.
    virtual SwPointF captionPosition(NodeId const nodeId) const = 0;

    /// Caption rect is needed for estimating the total node size.
    virtual SwRectF captionRect(NodeId const nodeId) const = 0;

    /// Position for an embedded widget. Return any value if you don't embed.
    virtual SwPointF widgetPosition(NodeId const nodeId) const = 0;

    /**
     * @brief Performs the `checkPortHit` operation.
     * @param nodeId Value passed to the method.
     * @param portType Value passed to the method.
     * @param nodePoint Value passed to the method.
     * @return The requested check Port Hit.
     */
    virtual PortIndex checkPortHit(NodeId const nodeId,
                                   PortType const portType,
                                   SwPointF const nodePoint) const;

    /**
     * @brief Performs the `resizeHandleRect` operation.
     * @param nodeId Value passed to the method.
     * @return The requested resize Handle Rect.
     */
    virtual SwRect resizeHandleRect(NodeId const nodeId) const = 0;

protected:
public:
    AbstractNodeGeometry(const AbstractNodeGeometry& other);
    AbstractNodeGeometry& operator=(const AbstractNodeGeometry& other);
protected:
    // What the class keeps (AbstractNodeGeometry_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

} // namespace SwizioNodes

#pragma pop_macro("None")
