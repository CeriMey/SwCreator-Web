#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwizioNodes/internal/BasicGraphicsScene.hpp"

struct SwizioNodes::BasicGraphicsScene::Data {
    // Given by the constructor: m_graphModel.
    explicit Data(AbstractGraphModel& graphModel)
        : m_graphModel(graphModel) {}

    AbstractGraphModel& m_graphModel;
    std::unordered_map<NodeId, NodeGraphicsObject*> m_nodes;
    std::unordered_map<ConnectionId, ConnectionGraphicsObject*, ConnectionIdHash> m_connections;
};
