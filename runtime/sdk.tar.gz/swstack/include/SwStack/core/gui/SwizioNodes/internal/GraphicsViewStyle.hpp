#pragma once

/**
 * @file src/core/gui/SwizioNodes/internal/GraphicsViewStyle.hpp
 * @ingroup core_swizio_nodes
 * @brief Declares the public interface exposed by GraphicsViewStyle in the CoreSw node-editor
 * layer.
 *
 * This header belongs to the CoreSw node-editor layer. It contains the graph, geometry, style,
 * and scene infrastructure used by the embedded node editor.
 *
 * Within that layer, this file focuses on the graphics view style interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * This header mainly contributes module-level utilities, helper declarations, or namespaced types
 * that are consumed by the surrounding subsystem.
 *
 * View-oriented declarations here mainly describe how underlying state is projected into a visual
 * or interactive surface, including how refresh, selection, or presentation concerns are exposed
 * at the API boundary.
 *
 * Most declarations here are extension points or internal contracts that coordinate graph
 * editing, visualization, and interaction.
 *
 */


#include "Export.hpp"
#include "Style.hpp"

#include "ColorUtils.hpp"

#include "core/types/Sw.h"
#include "core/types/SwString.h"

namespace SwizioNodes {

class SW_NODES_EXPORT GraphicsViewStyle : public Style
{
public:
    /**
     * @brief Constructs a `GraphicsViewStyle` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    GraphicsViewStyle();

    /**
     * @brief Constructs a `GraphicsViewStyle` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit GraphicsViewStyle(SwString jsonText);

    /**
     * @brief Destroys the `GraphicsViewStyle` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~GraphicsViewStyle() override;

public:
    /**
     * @brief Sets the style.
     * @param jsonText Value passed to the method.
     * @return The requested style.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setStyle(SwString jsonText);

private:
    void loadJson(SwJsonObject const& json) override;

    SwJsonObject toJson() const override;

public:
    SwColor BackgroundColor;
    SwColor FineGridColor;
    SwColor CoarseGridColor;
};



} // namespace SwizioNodes
