#pragma once

/**
 * @file
 * @ingroup core_swizio_nodes
 * @brief Declares the scene item that renders and interacts with a node instance.
 *
 * `NodeGraphicsObject` is the view-side wrapper for one node in the graph model. It owns
 * the node visual, synchronizes geometry with the model, and translates user interaction
 * such as selection, movement, and embedded-widget placement into scene updates.
 */

#include <memory>
#include "Export.hpp"

#include "SwizioNodes/internal/AbstractGraphModel.hpp"
#include "SwizioNodes/internal/Definitions.hpp"
#include "SwizioNodes/internal/StyleCollection.hpp"

#include "graphics/SwGraphicsItem.h"
#include "graphics/SwGraphicsItems.h"
#include "graphics/SwGraphicsRenderContext.h"
#include "graphics/SwGraphicsScene.h"
#include "graphics/SwGraphicsTypes.h"

#include "SwFont.h"
#include "SwPainter.h"
#include "SwString.h"
#include "SwWidget.h"

#include <algorithm>
#include <cmath>
#include <vector>

// X11 defines None as a macro, and PortType::None needs the name: the X11 headers may come
// in after Definitions.hpp has removed it. Restored at the end of this file.
#pragma push_macro("None")
#undef None

namespace SwizioNodes {

class BasicGraphicsScene;
class AbstractGraphModel;

class SW_NODES_EXPORT NodeGraphicsObject : public SwGraphicsItem
{
public:
    struct PortHit {
        bool hit{false};
        PortType type{PortType::None};
        int index{-1};
    };

    /**
     * @brief Constructs a `NodeGraphicsObject` instance.
     * @param scene Value passed to the method.
     * @param nodeId Value passed to the method.
     * @param title Title text applied by the operation.
     * @param inputs Value passed to the method.
     * @param outputs Output value filled by the method.
     * @param accent Value passed to the method.
     * @param typeKey Value passed to the method.
     * @param true Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    NodeGraphicsObject(BasicGraphicsScene& scene,
                       NodeId nodeId,
                       const SwString& title = SwString(),
                       const std::vector<SwString>& inputs = {},
                       const std::vector<SwString>& outputs = {},
                       const SwColor& accent = SwColor{0, 139, 139},
                       const SwString& typeKey = SwString());

    /**
     * @brief Destroys the `NodeGraphicsObject` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~NodeGraphicsObject() override;

    /**
     * @brief Returns the current node Id.
     * @return The current node Id.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    NodeId nodeId() const;

    /**
     * @brief Returns the current type Key.
     * @return The current type Key.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString typeKey() const;
    /**
     * @brief Returns the current title.
     * @return The current title.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString title() const;

    /**
     * @brief Performs the `inputCount` operation.
     * @return The requested input Count.
     */
    int inputCount() const;
    /**
     * @brief Performs the `outputCount` operation.
     * @return The requested output Count.
     */
    int outputCount() const;

    /**
     * @brief Returns the current inputs.
     * @return The current inputs.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const std::vector<SwString>& inputs() const;
    /**
     * @brief Returns the current outputs.
     * @return The current outputs.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const std::vector<SwString>& outputs() const;

    /**
     * @brief Performs the `inputName` operation.
     * @param index Value passed to the method.
     * @return The requested input Name.
     */
    SwString inputName(int index) const;

    /**
     * @brief Performs the `outputName` operation.
     * @param index Value passed to the method.
     * @return The requested output Name.
     */
    SwString outputName(int index) const;

    /**
     * @brief Returns the current accent Color.
     * @return The current accent Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor accentColor() const;

    /**
     * @brief Returns the current body Text.
     * @return The current body Text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString bodyText() const;

    /**
     * @brief Sets the body Text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBodyText(const SwString& text);

    /**
     * @brief Sets the definition.
     * @param title Title text applied by the operation.
     * @param inputs Value passed to the method.
     * @param outputs Output value filled by the method.
     * @param accent Value passed to the method.
     * @param typeKey Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDefinition(const SwString& title,
                       const std::vector<SwString>& inputs,
                       const std::vector<SwString>& outputs,
                       const SwColor& accent,
                       const SwString& typeKey);

    // By default, both input and output ports accept multiple connections.
    /**
     * @brief Performs the `allowsMultipleConnections` operation.
     * @param type Value passed to the method.
     * @param index Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool allowsMultipleConnections(PortType type, int index) const;

    /**
     * @brief Sets the allows Multiple Connections.
     * @param type Value passed to the method.
     * @param index Value passed to the method.
     * @param allow Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAllowsMultipleConnections(PortType type, int index, bool allow);

    /**
     * @brief Performs the `inputPortScenePos` operation.
     * @param index Value passed to the method.
     * @return The requested input Port Scene Pos.
     */
    SwPointF inputPortScenePos(int index) const;

    /**
     * @brief Performs the `outputPortScenePos` operation.
     * @param index Value passed to the method.
     * @return The requested output Port Scene Pos.
     */
    SwPointF outputPortScenePos(int index) const;

    /**
     * @brief Performs the `hitTestPort` operation.
     * @param scenePoint Value passed to the method.
     * @return The requested hit Test Port.
     */
    PortHit hitTestPort(const SwPointF& scenePoint) const;

    /**
     * @brief Clears the current object state.
     */
    void clearHoveredPort();

    /**
     * @brief Sets the hovered Port.
     * @param port Local port used by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHoveredPort(const PortHit& port);

    /**
     * @brief Returns whether the object reports port Hovered.
     * @param type Value passed to the method.
     * @param index Value passed to the method.
     * @return `true` when the object reports port Hovered; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isPortHovered(PortType type, int index) const;

    /**
     * @brief Sets the embedded Widget.
     * @param widget Widget associated with the operation.
     * @param width Width value.
     * @param height Height value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEmbeddedWidget(SwWidget* widget, int width = 0, int height = 0);

    /**
     * @brief Returns the current embedded Proxy.
     * @return The current embedded Proxy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsProxyWidget* embeddedProxy() const;

    /**
     * @brief Performs the `syncFromModel` operation.
     * @param graphModel Value passed to the method.
     */
    void syncFromModel(AbstractGraphModel& graphModel);

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
    struct LayoutMetrics {
        int width{0};
        int height{0};
        int portRows{0};
        int widgetWidth{0};
        int widgetHeight{0};
        int widgetTop{0};
    };

    LayoutMetrics layoutMetrics_() const;

    void updateEmbeddedWidgetLayout_();

    SwPointF inputPortLocalPos_(int index) const;

    SwPointF outputPortLocalPos_(int index) const;

    static const int kWidth = 320;
    static const int kHeaderHeight = 34;
    static const int kRadius = 12;
    static const int kPortSpacing = 26;
    static const int kBodyPaddingY = 12;
    static const int kPortMarginX = 16;
    static const int kPortRadius = 6;
    static const int kFooterHeight = 30;
    static const int kWidgetPaddingX = 16;
    static const int kWidgetPaddingY = 10;

private:
    // What the class keeps (NodeGraphicsObject_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};


} // namespace SwizioNodes

#pragma pop_macro("None")
