#pragma once

/**
 * @file src/core/gui/SwizioNodes/internal/DataFlowGraphModel.hpp
 * @ingroup core_swizio_nodes
 * @brief Declares the public interface exposed by DataFlowGraphModel in the CoreSw node-editor
 * layer.
 *
 * This header belongs to the CoreSw node-editor layer. It contains the graph, geometry, style,
 * and scene infrastructure used by the embedded node editor.
 *
 * Within that layer, this file focuses on the data flow graph model interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * This header mainly contributes module-level utilities, helper declarations, or namespaced types
 * that are consumed by the surrounding subsystem.
 *
 * Model-oriented declarations here define the data contract consumed by views, delegates, or
 * algorithms, with an emphasis on stable roles, ownership, and update flow rather than on
 * presentation details.
 *
 * Most declarations here are extension points or internal contracts that coordinate graph
 * editing, visualization, and interaction.
 *
 */


#include "AbstractGraphModel.hpp"
#include "ConnectionIdUtils.hpp"
#include "NodeDelegateModelRegistry.hpp"
#include "Serializable.hpp"
#include "StyleCollection.hpp"

#include "core/types/SwJsonObject.h"
#include "core/types/SwJsonArray.h"

#include "graphics/SwGraphicsTypes.h"

#include "core/runtime/SwCoreApplication.h"

#include <algorithm>
#include <iterator>
#include <stdexcept>

#include <memory>
#include <unordered_map>
#include <unordered_set>

class SwWidget;

namespace SwizioNodes {

class SW_NODES_EXPORT DataFlowGraphModel : public AbstractGraphModel, public Serializable
{
    SW_OBJECT(DataFlowGraphModel, AbstractGraphModel)

public:
    struct NodeGeometryData
    {
        SwSize size{};
        SwPointF pos{};
    };

public:
    /**
     * @brief Constructs a `DataFlowGraphModel` instance.
     * @param context Value passed to the method.
     * @param registry Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    DataFlowGraphModel(const SwString& context, std::shared_ptr<NodeDelegateModelRegistry> registry);

    /**
     * @brief Destroys the `DataFlowGraphModel` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~DataFlowGraphModel() override;

    /**
     * @brief Returns the current data Model Registry.
     * @return The current data Model Registry.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    std::shared_ptr<NodeDelegateModelRegistry> dataModelRegistry();

public:
    /**
     * @brief Returns the current all Node Ids.
     * @return The current all Node Ids.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    std::unordered_set<NodeId> allNodeIds() const override;

    /**
     * @brief Performs the `allConnectionIds` operation.
     * @param nodeId Value passed to the method.
     * @return The requested all Connection Ids.
     */
    std::unordered_set<ConnectionId> allConnectionIds(NodeId const nodeId) const override;

    /**
     * @brief Performs the `connections` operation.
     * @param nodeId Value passed to the method.
     * @param portType Value passed to the method.
     * @param portIndex Value passed to the method.
     * @return The requested connections.
     */
    std::unordered_set<ConnectionId> connections(NodeId nodeId,
                                                 PortType portType,
                                                 PortIndex portIndex) const override;

    /**
     * @brief Performs the `connectionExists` operation.
     * @param connectionId Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool connectionExists(ConnectionId const connectionId) const override;

    /**
     * @brief Adds the specified node.
     * @param nodeType Value passed to the method.
     * @return The requested node.
     */
    NodeId addNode(SwString const nodeType) override;

    /**
     * @brief Performs the `connectionPossible` operation.
     * @param connectionId Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool connectionPossible(ConnectionId const connectionId) const override;

    /**
     * @brief Adds the specified connection.
     * @param connectionId Value passed to the method.
     */
    void addConnection(ConnectionId const connectionId) override;

    /**
     * @brief Performs the `nodeExists` operation.
     * @param nodeId Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool nodeExists(NodeId const nodeId) const override;

    /**
     * @brief Performs the `nodeData` operation.
     * @param nodeId Value passed to the method.
     * @param role Value passed to the method.
     * @return The requested node Data.
     */
    SwAny nodeData(NodeId nodeId, NodeRole role) const override;

    /**
     * @brief Performs the `nodeFlags` operation.
     * @param nodeId Value passed to the method.
     * @return The requested node Flags.
     */
    NodeFlags nodeFlags(NodeId nodeId) const override;

    /**
     * @brief Sets the node Data.
     * @param nodeId Value passed to the method.
     * @param role Value passed to the method.
     * @param value Value passed to the method.
     * @return `true` on success; otherwise `false`.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    bool setNodeData(NodeId nodeId, NodeRole role, SwAny value) override;

    /**
     * @brief Performs the `portData` operation.
     * @param nodeId Value passed to the method.
     * @param portType Value passed to the method.
     * @param portIndex Value passed to the method.
     * @param role Value passed to the method.
     * @return The requested port Data.
     */
    SwAny portData(NodeId nodeId,
                   PortType portType,
                   PortIndex portIndex,
                   PortRole role) const override;

    /**
     * @brief Sets the port Data.
     * @param nodeId Value passed to the method.
     * @param portType Value passed to the method.
     * @param portIndex Value passed to the method.
     * @param value Value passed to the method.
     * @param role Value passed to the method.
     * @return `true` on success; otherwise `false`.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    bool setPortData(NodeId nodeId,
                     PortType portType,
                     PortIndex portIndex,
                     SwAny const& value,
                     PortRole role = PortRole::Data) override;

    /**
     * @brief Performs the `deleteConnection` operation.
     * @param connectionId Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool deleteConnection(ConnectionId const connectionId) override;

    /**
     * @brief Performs the `deleteNode` operation.
     * @param nodeId Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool deleteNode(NodeId const nodeId) override;

    /**
     * @brief Performs the `saveNode` operation on the associated resource.
     * @return The requested node.
     */
    SwJsonObject saveNode(NodeId const) const override;

    /**
     * @brief Returns the current save.
     * @return The current save.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwJsonObject save() const override;

    /**
     * @brief Performs the `loadNode` operation on the associated resource.
     * @param nodeJson Value passed to the method.
     */
    void loadNode(SwJsonObject const& nodeJson) override;

    /**
     * @brief Performs the `load` operation on the associated resource.
     * @param json Value passed to the method.
     */
    void load(SwJsonObject const& json) override;

    // The node's model, whatever its type (delegateModel() casts it).
    NodeDelegateModel* delegateModelOf_(NodeId nodeId) const;

    /**
     * Fetches the NodeDelegateModel for the given `nodeId` and tries to cast the
     * stored pointer to the given type.
     */
    template<typename NodeDelegateModelType>
    /**
     * @brief Performs the `delegateModel` operation.
     * @param nodeId Value passed to the method.
     * @return The requested delegate Model.
     */
    NodeDelegateModelType* delegateModel(NodeId const nodeId)
    {
        return dynamic_cast<NodeDelegateModelType*>(delegateModelOf_(nodeId));
    }

    /**
     * @brief Performs the `delegateModel` operation.
     * @param nodeId Value passed to the method.
     * @return The requested delegate Model.
     */
    NodeDelegateModel* delegateModel(NodeId const nodeId);

    /**
     * @brief Performs the `delegateModel` operation.
     * @param nodeId Value passed to the method.
     * @return The requested delegate Model.
     */
    NodeDelegateModel const* delegateModel(NodeId const nodeId) const;

    /**
     * @brief Sets the registry.
     * @param newRegistry Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRegistry(const std::shared_ptr<NodeDelegateModelRegistry>& newRegistry);

signals:
    SW_SIGNAL(inPortDataWasSet, NodeId const, PortType const, PortIndex const);
    SW_SIGNAL(outPortDataUpdated, NodeId const, PortIndex const);

private:
    NodeId newNodeId() override;

    void sendConnectionCreation(ConnectionId const connectionId);
    void sendConnectionDeletion(ConnectionId const connectionId);

private:
    void onOutPortDataUpdated_(NodeId const nodeId, PortIndex const portIndex);

    /// Function is called after detaching a connection.
    void propagateEmptyDataTo_(NodeId const nodeId, PortIndex const portIndex);

private:

private:
    // What the class keeps (DataFlowGraphModel_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

SW_NODES_EXPORT void registerDataFlowGraphModelAnyTypesOnce_();

} // namespace SwizioNodes
