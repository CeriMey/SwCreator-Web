#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwUiLoader.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwUiLoader in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the ui loader interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * This header mainly contributes module-level utilities, helper declarations, or namespaced types
 * that are consumed by the surrounding subsystem.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwWidget.h"
#include "SwLayout.h"

#include "SwCheckBox.h"
#include "SwComboBox.h"
#include "SwDoubleSpinBox.h"
#include "SwFrame.h"
#include "SwGroupBox.h"
#include "SwLabel.h"
#include "SwLoadingOverlay.h"
#include "SwLineEdit.h"
#include "SwPlainTextEdit.h"
#include "SwProgressBar.h"
#include "SwPushButton.h"
#include "SwRadioButton.h"
#include "SwScrollArea.h"
#include "SwSlider.h"
#include "SwSpinBox.h"
#include "SwSplitter.h"
#include "SwStackedWidget.h"
#include "SwSpacer.h"
#include "SwTabWidget.h"
#include "SwTableView.h"
#include "SwTableWidget.h"
#include "SwTextEdit.h"
#include "SwToolButton.h"
#include "SwToolBox.h"
#include "SwTreeView.h"
#include "SwTreeWidget.h"
#include "SwMainWindow.h"

#include "core/io/SwFile.h"
#include "SwXmlDocument.h"
#include "SwUiLoaderConnections.h"
#include <vector>

namespace swui {

using XmlNode = SwXmlNode;

enum WidgetPlatform : unsigned {
    WindowsPlatform = 1u, LinuxPlatform = 2u, MacPlatform = 4u,
    AndroidPlatform = 8u, WebPlatform = 16u, AllPlatforms = 31u
};

struct WidgetProperty {
    SwString name;
    SwString setter;
    SwString valueType;
    SwMap<SwString, SwString> enumValues;
};

// A module supplies this once. Loading, the designer and C++ generation read
// the same declaration instead of maintaining their own lists of classes.
struct WidgetDescriptor {
    SwString className, module, category, nameFr, nameEn;
    SwString descriptionFr, descriptionEn, aliases, previewKind;
    SwString header, cmakePackage, cmakeTarget, constructorExpression, baseClass;
    SwString unavailableReason;
    bool isLayout{false};
    bool designerVisible{true};
    bool available{true};
    unsigned supportedPlatforms{AllPlatforms};
    SwSize defaultSize{120, 32};
    std::vector<WidgetProperty> properties;
    SwStringList signalSignatures;
};

inline unsigned currentWidgetPlatform() {
#if defined(__EMSCRIPTEN__)
    return WebPlatform;
#elif defined(_WIN32)
    return WindowsPlatform;
#elif defined(__ANDROID__)
    return AndroidPlatform;
#elif defined(__APPLE__)
    return MacPlatform;
#else
    return LinuxPlatform;
#endif
}

class SW_UITOOLS_EXPORT UiFactory {
public:
    using WidgetCtor = SwWidget* (*)(SwWidget* parent);

    /**
     * @brief Returns the current instance.
     * @return The current instance.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static UiFactory& instance();
    /**
     * @brief Performs the `registerWidget` operation.
     * @param className Value passed to the method.
     * @param ctor Value passed to the method.
     */
    void registerWidget(const SwString& className, WidgetCtor ctor);
    void registerWidget(const WidgetDescriptor& descriptor, WidgetCtor ctor);
    void registerDescriptor(const WidgetDescriptor& descriptor);
    const WidgetDescriptor* descriptor(const SwString& className) const;
    std::vector<WidgetDescriptor> widgetDescriptors() const;
    bool isAvailable(const SwString& className) const;
    /**
     * @brief Creates the requested widget.
     * @param className Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @return The resulting widget.
     */
    SwWidget* createWidget(const SwString& className, SwWidget* parent) const;

private:
    UiFactory();
    static SwString qtAliasToSw_(const SwString& qtClass);

public:
    ~UiFactory();
public:
    UiFactory(const UiFactory& other);
    UiFactory& operator=(const UiFactory& other);
private:
    // What the class keeps (SwUiLoader_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

class SW_UITOOLS_EXPORT UiLoader {
public:
    struct LoadResult {
        SwWidget* root{nullptr};
        SwString error;
        bool ok{false};
    };

    /**
     * @brief Performs the `loadFromString` operation on the associated resource.
     * @param xml Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @return The resulting from String.
     */
    static LoadResult loadFromString(const SwString& xml, SwWidget* parent = nullptr);
    /**
     * @brief Performs the `loadFromFile` operation on the associated resource.
     * @param filePath Path of the target file.
     * @param parent Optional parent object that owns this instance.
     * @return The resulting from File.
     */
    static LoadResult loadFromFile(const SwString& filePath, SwWidget* parent = nullptr);

private:
    static int toInt_(const SwString& s, int def = 0);
    static double toDouble_(const SwString& s, double def = 0.0);
    static bool toBool_(SwString s, bool def = false);

    static SwString propertyNameToSw_(const SwString& name);
    static SwString childText_(const XmlNode& node, const char* childName);
    static SwString textValue_(const XmlNode& propNode);
    static SwString attributeValue_(const XmlNode& widgetNode, const char* attributeName);
    static SwMap<SwString, SwString> parseCustomWidgets_(const XmlNode& uiRoot);
    static DrawTextFormats alignmentFromQtSet_(SwString value);

    static void applyCommonProperty_(SwWidget* w, const SwString& rawName, const XmlNode& propNode);

    static bool attachChildToContainer_(SwWidget* parent, SwWidget* child, const XmlNode& childWidgetNode, SwString& outError);

    static SwAbstractLayout* createLayout_(const SwString& className, SwWidget* parent, SwString& outError);
    static SwSizePolicy::Policy spacerPolicyFromString_(SwString value);
    static SwSpacerItem* loadSpacerItem_(const XmlNode& spacerNode);
    static bool applyLayout_(SwWidget* parentWidget,
                            const XmlNode& widgetNode,
                            SwString& outError,
                            const SwMap<SwString, SwString>& customWidgetExtends);

    static SwWidget* loadWidget_(const XmlNode& widgetNode,
                                 SwWidget* parent,
                                 SwString& outError,
                                 const SwMap<SwString, SwString>& customWidgetExtends);

    static bool loadIntoExistingWidget_(SwWidget* target,
                                       const XmlNode& widgetNode,
                                       SwString& outError,
                                       const SwMap<SwString, SwString>& customWidgetExtends);

    static bool loadQtMainWindowCentralWidgetInto_(SwWidget* target,
                                                  const XmlNode& mainWindowNode,
                                                  SwString& outError,
                                                  const SwMap<SwString, SwString>& customWidgetExtends);

    static SwMainWindow* loadQtMainWindow_(const XmlNode& mainWindowNode,
                                          const SwMap<SwString, SwString>& customWidgetExtends,
                                          SwString& outError);
};

} // namespace swui
