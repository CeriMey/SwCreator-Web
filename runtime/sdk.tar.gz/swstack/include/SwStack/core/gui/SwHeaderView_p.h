#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwHeaderView.h"

struct SwHeaderView::Data {
    SwOrientation m_orientation{SwOrientation::Horizontal};
    SwAbstractItemModel* m_model{nullptr};
    bool m_showGrid{true};
    bool m_sectionsClickable{true};
    int m_offset{0};
    int m_defaultSectionSize{160};
    int m_minSectionSize{24};
    int m_maxSectionSize{10000};
    bool m_sectionsFitToWidth{false};
    bool m_stretchLastSection{true};
    mutable int m_cachedViewportLength{-1};
    mutable SwList<int> m_sectionSizes;
    SwList<int> m_sectionStretches;
    mutable SwList<int> m_stretchedSectionSizes;
    int m_sectionCountHint{0};
    bool m_sortIndicatorShown{false};
    int m_sortSection{-1};
    SwSortOrder m_sortOrder{SwSortOrder::AscendingOrder};
    bool m_resizing{false};
    int m_resizeSection{-1};
    int m_resizeStartPos{0};
    int m_resizeStartSize{0};
    int m_hoverSection{-1};
};
