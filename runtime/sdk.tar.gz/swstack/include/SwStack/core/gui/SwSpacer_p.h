#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSpacer.h"

struct SwSpacer::Data {
    SwString m_Orientation = SwString("Horizontal");
    bool m_Orientation_registered_ = sw_register_Orientation_();
    SwString m_HorizontalPolicy = SwString("Expanding");
    bool m_HorizontalPolicy_registered_ = sw_register_HorizontalPolicy_();
    SwString m_VerticalPolicy = SwString("Minimum");
    bool m_VerticalPolicy_registered_ = sw_register_VerticalPolicy_();
    int m_SizeHintWidth = 26;
    bool m_SizeHintWidth_registered_ = sw_register_SizeHintWidth_();
    int m_SizeHintHeight = 20;
    bool m_SizeHintHeight_registered_ = sw_register_SizeHintHeight_();
};
