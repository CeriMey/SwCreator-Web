﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwColorDialog.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwColorDialog in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the color dialog interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwColorDialog.
 *
 * Dialog-oriented declarations here usually describe a bounded modal interaction: configuration
 * enters through setters or constructor state, the user edits the state through child widgets,
 * and the caller retrieves the accepted result through the public API.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwColorDialog - color dialog.
 *
 * V3 scope:
 * - Snapshot-friendly color dialog UI.
 * - Standard-ish round color picker (Hue ring + SV disk) + preview.
 **************************************************************************************************/

#include "SwDialog.h"
#include "SwLineEdit.h"
#include "SwPushButton.h"
#include "SwRoundColorPicker.h"

#include "Sw.h"

#include "core/types/SwVector.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

class SW_WIDGETS_EXPORT SwColorDialog : public SwDialog {
    SW_OBJECT(SwColorDialog, SwDialog)

public:
    /**
     * @brief Constructs a `SwColorDialog` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwColorDialog(SwWidget* parent = nullptr);

    /**
     * @brief Sets the current Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCurrentColor(const SwColor& color);

    /**
     * @brief Returns the current current Color.
     * @return The current current Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor currentColor() const;

    /**
     * @brief Performs the `getColor` operation.
     * @param initial Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param ok Optional flag updated to report success.
     * @param title Title text applied by the operation.
     * @return The requested color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwColor getColor(const SwColor& initial,
                            SwWidget* parent = nullptr,
                            bool* ok = nullptr,
                            const SwString& title = "Select color");

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    class SW_WIDGETS_EXPORT PreviewWidget final : public SwWidget {
        SW_OBJECT(PreviewWidget, SwWidget)

    public:
        /**
         * @brief Performs the `PreviewWidget` operation.
         * @param owner Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @param owner Value passed to the method.
         * @return The requested preview Widget.
         */
        explicit PreviewWidget(SwColorDialog* owner, SwWidget* parent = nullptr);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

    private:
        SwColorDialog* m_owner{nullptr};
    };

    class SW_WIDGETS_EXPORT ColorSwatch final : public SwWidget {
        SW_OBJECT(ColorSwatch, SwWidget)

    public:
        /**
         * @brief Performs the `ColorSwatch` operation.
         * @param c Value passed to the method.
         * @param valid Value passed to the method.
         * @param owner Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @param owner Value passed to the method.
         */
        ColorSwatch(const SwColor& c, bool valid, SwColorDialog* owner, SwWidget* parent = nullptr);

        /**
         * @brief Sets the color.
         * @param c Value passed to the method.
         *
         * @details Call this method to replace the currently stored value with the caller-provided one.
         */
        void setColor(const SwColor& c);

        /**
         * @brief Sets the valid.
         * @param valid Value passed to the method.
         *
         * @details Call this method to replace the currently stored value with the caller-provided one.
         */
        void setValid(bool valid);

        /**
         * @brief Returns the current color.
         * @return The current color.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        SwColor color() const;
        /**
         * @brief Returns whether the object reports valid.
         * @return `true` when the object reports valid; otherwise `false`.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        bool isValid() const;

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

        /**
         * @brief Handles the mouse Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mousePressEvent(MouseEvent* event) override;

    private:
        SwColor m_color{0, 0, 0};
        bool m_valid{false};
        SwColorDialog* m_owner{nullptr};
    };

    static bool colorsEqual(const SwColor& a, const SwColor& b);

    static SwColor* recentColors_();

    static bool* recentValid_();

    static void pushRecentColor_(const SwColor& color);

    static int hexNibble_(char c);

    static bool parseHexColor_(const SwString& text, SwColor& out);

    static char hexDigit_(int v);

    static SwString colorToHex_(const SwColor& c);

    void buildUi();

    void buildPalette(SwWidget* parent);

    void buildRecent(SwWidget* parent);

    void refreshRecentSwatches_();

    void updatePreview();

    void updateLayout();

    void setCurrentColorInternal(const SwColor& color, bool syncPicker);

public:
    ~SwColorDialog();
private:
    // What the class keeps (SwColorDialog_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

