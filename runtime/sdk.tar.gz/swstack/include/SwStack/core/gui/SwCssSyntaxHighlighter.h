#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwCssSyntaxTheme {
    SwTextCharFormat selectorFormat;
    SwTextCharFormat propertyFormat;
    SwTextCharFormat valueFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat unitFormat;
    SwTextCharFormat colorFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat atRuleFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat importantFormat;
    SwTextCharFormat variableFormat;
};

inline SwTextCharFormat swCssMakeFormat_(const SwColor& color,
                                          FontWeight weight = Normal,
                                          bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwCssSyntaxTheme swCssSyntaxThemeVsCodeDark() {
    SwCssSyntaxTheme theme;
    theme.selectorFormat  = swCssMakeFormat_(SwColor{215, 186, 125});
    theme.propertyFormat  = swCssMakeFormat_(SwColor{156, 220, 254});
    theme.valueFormat     = swCssMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat    = swCssMakeFormat_(SwColor{181, 206, 168});
    theme.unitFormat      = swCssMakeFormat_(SwColor{181, 206, 168});
    theme.colorFormat     = swCssMakeFormat_(SwColor{206, 145, 120});
    theme.stringFormat    = swCssMakeFormat_(SwColor{206, 145, 120});
    theme.commentFormat   = swCssMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.atRuleFormat    = swCssMakeFormat_(SwColor{197, 134, 192});
    theme.functionFormat  = swCssMakeFormat_(SwColor{220, 220, 170});
    theme.importantFormat = swCssMakeFormat_(SwColor{197, 134, 192}, Medium);
    theme.variableFormat  = swCssMakeFormat_(SwColor{156, 220, 254});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwCssSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwCssSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwCssSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwCssSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        SelectorState = 0,
        PropertyState = 1,
        ValueState = 2,
        CommentState = 3
    };

    static bool isIdentStart_(char ch);

    static bool isIdentChar_(char ch);

    static int findCommentEnd_(const SwString& text, int start);

    int previousContextState_() const;

public:
    ~SwCssSyntaxHighlighter();
private:
    // What the class keeps (SwCssSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
