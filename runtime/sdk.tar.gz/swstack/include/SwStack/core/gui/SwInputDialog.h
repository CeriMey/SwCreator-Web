/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwInputDialog.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwInputDialog in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the input dialog interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwInputDialog.
 *
 * Dialog-oriented declarations here usually describe a bounded modal interaction: configuration
 * enters through setters or constructor state, the user edits the state through child widgets,
 * and the caller retrieves the accepted result through the public API.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/**
 * @file SwInputDialog.h
 * @brief Declares `SwInputDialog`, a compact modal dialog for one-off user input.
 *
 * @details
 * `SwInputDialog` exposes a small, toolkit-native alternative to the classic input helpers found in
 * desktop UI frameworks. A single dialog instance can switch between text, integer, floating-point,
 * and item-selection modes, while the static helper functions provide a simple call pattern for
 * common application code.
 */

#include "SwDialog.h"
#include "SwLabel.h"
#include "SwLineEdit.h"
#include "SwSpinBox.h"
#include "SwDoubleSpinBox.h"
#include "SwComboBox.h"
#include "SwPushButton.h"

#include <algorithm>

/**
 * @class SwInputDialog
 * @brief Modal dialog that captures a single value from the user.
 *
 * @details
 * The dialog owns one label and four mutually exclusive editor widgets:
 * - `SwLineEdit` for free-form text,
 * - `SwSpinBox` for integers,
 * - `SwDoubleSpinBox` for floating-point values,
 * - `SwComboBox` for choosing from a predefined list.
 *
 * `setInputMode()` toggles which editor is visible, while the static helpers construct a temporary
 * dialog, configure it, run it modally, and return either the accepted value or the original input.
 */
class SW_WIDGETS_EXPORT SwInputDialog : public SwDialog {
    SW_OBJECT(SwInputDialog, SwDialog)

public:
    /**
     * @enum InputMode
     * @brief Selects which editor widget is active inside the dialog.
     */
    enum InputMode {
        TextInput,   ///< Use the line edit for free-form text entry.
        IntInput,    ///< Use the integer spin box.
        DoubleInput, ///< Use the floating-point spin box.
        ItemInput    ///< Use the combo box for predefined choices.
    };

    /**
     * @brief Constructs the dialog and creates all editor widgets.
     * @param parent Optional parent widget.
     */
    explicit SwInputDialog(SwWidget* parent = nullptr);

    /**
     * @brief Sets the descriptive label shown above the active editor.
     * @param text Prompt text displayed to the user.
     */
    void setLabelText(const SwString& text);

    /**
     * @brief Switches the dialog to a different input widget type.
     * @param mode New editor mode.
     *
     * @details
     * Only the editor associated with `mode` remains visible after this call. The dialog then
     * recomputes the input field geometry so the active control fills the available content area.
     */
    void setInputMode(InputMode mode);

    /**
     * @brief Sets the current text value.
     * @param text Text pushed into the line edit.
     */
    void setTextValue(const SwString& text);

    /**
     * @brief Returns the text currently stored in the line edit.
     * @return Current text value, or an empty string when the line edit is unavailable.
     */
    SwString textValue() const;

    /**
     * @brief Sets the valid integer range for integer mode.
     * @param min Minimum accepted integer.
     * @param max Maximum accepted integer.
     */
    void setIntRange(int min, int max);

    /**
     * @brief Sets the current integer value.
     * @param val Integer pushed into the spin box.
     */
    void setIntValue(int val);

    /**
     * @brief Returns the integer currently shown by the spin box.
     * @return Current integer value, or `0` when the spin box is unavailable.
     */
    int intValue() const;

    /**
     * @brief Sets the valid floating-point range for double mode.
     * @param min Minimum accepted value.
     * @param max Maximum accepted value.
     */
    void setDoubleRange(double min, double max);

    /**
     * @brief Sets the current floating-point value.
     * @param val Floating-point value pushed into the editor.
     */
    void setDoubleValue(double val);

    /**
     * @brief Returns the value currently shown by the floating-point editor.
     * @return Current floating-point value, or `0.0` when the editor is unavailable.
     */
    double doubleValue() const;

    /**
     * @brief Replaces the items available in combo-box mode.
     * @param items List of labels to append to the combo box.
     */
    void setComboBoxItems(const SwVector<SwString>& items);

    /**
     * @brief Returns the currently selected combo-box label.
     * @return Current item text, or an empty string when the combo box is unavailable.
     */
    SwString itemText() const;

    /**
     * @brief Opens a modal text-input dialog.
     * @param parent Optional parent widget.
     * @param title Window title.
     * @param label Prompt shown inside the dialog.
     * @param text Initial text value.
     * @param ok Optional output flag set to `true` only when the dialog is accepted.
     * @return Accepted text, or `text` when the dialog is cancelled.
     */

    static SwString getText(SwWidget* parent,
                            const SwString& title,
                            const SwString& label,
                            const SwString& text = SwString(),
                            bool* ok = nullptr);

    /**
     * @brief Opens a modal integer-input dialog.
     * @param parent Optional parent widget.
     * @param title Window title.
     * @param label Prompt shown inside the dialog.
     * @param value Initial integer value.
     * @param min Minimum accepted integer.
     * @param max Maximum accepted integer.
     * @param ok Optional output flag set to `true` only when the dialog is accepted.
     * @return Accepted value, or `value` when the dialog is cancelled.
     */
    static int getInt(SwWidget* parent,
                      const SwString& title,
                      const SwString& label,
                      int value = 0,
                      int min = -2147483647,
                      int max = 2147483647,
                      bool* ok = nullptr);

    /**
     * @brief Opens a modal floating-point input dialog.
     * @param parent Optional parent widget.
     * @param title Window title.
     * @param label Prompt shown inside the dialog.
     * @param value Initial value.
     * @param min Minimum accepted value.
     * @param max Maximum accepted value.
     * @param ok Optional output flag set to `true` only when the dialog is accepted.
     * @return Accepted value, or `value` when the dialog is cancelled.
     */
    static double getDouble(SwWidget* parent,
                            const SwString& title,
                            const SwString& label,
                            double value = 0.0,
                            double min = -2147483647.0,
                            double max = 2147483647.0,
                            bool* ok = nullptr);

    /**
     * @brief Opens a modal item-selection dialog.
     * @param parent Optional parent widget.
     * @param title Window title.
     * @param label Prompt shown inside the dialog.
     * @param items Candidate item labels.
     * @param current Initially selected item index.
     * @param ok Optional output flag set to `true` only when the dialog is accepted.
     * @return Accepted item label, or an empty string when the dialog is cancelled.
     */
    static SwString getItem(SwWidget* parent,
                            const SwString& title,
                            const SwString& label,
                            const SwVector<SwString>& items,
                            int current = 0,
                            bool* ok = nullptr);

protected:
    /**
     * @brief Updates the editor and button geometry after a resize.
     * @param event Resize event forwarded by the base dialog.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    void buildUi();

    void updateInputLayout();

    void layoutButtons();

public:
    ~SwInputDialog();
private:
    // What the class keeps (SwInputDialog_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
