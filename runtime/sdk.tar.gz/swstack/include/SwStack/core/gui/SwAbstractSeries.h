/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwAbstractSeries.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwAbstractSeries in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the abstract series interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwAbstractSeries.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwAbstractSeries - minimal XY series base.
 **************************************************************************************************/

#include "SwObject.h"
#include "SwString.h"
#include "SwVector.h"

#include "Sw.h"
#include "graphics/SwGraphicsTypes.h"

#include <algorithm>
#include <cmath>
#include <iterator>

class SW_CHARTS_EXPORT SwAbstractSeries : public SwObject {
    SW_OBJECT(SwAbstractSeries, SwObject)

public:
    enum class SeriesType {
        Line,
        Scatter,
        StepLine,
        Spline,
        Area,
        Bar,
        Candlestick,
        Pie
    };

    /**
     * @brief Constructs a `SwAbstractSeries` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwAbstractSeries(SwObject* parent = nullptr);

    /**
     * @brief Destroys the `SwAbstractSeries` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    virtual ~SwAbstractSeries();

    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual SeriesType type() const = 0;
    /**
     * @brief Returns whether the object reports xYSeries.
     * @return The current xYSeries.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual bool isXYSeries() const;

    /**
     * @brief Sets the name.
     * @param name Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setName(const SwString& name);

    /**
     * @brief Returns the current name.
     * @return The current name.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString name() const;

    /**
     * @brief Sets the color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColor(const SwColor& color);

    /**
     * @brief Returns the current color.
     * @return The current color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor color() const;

    /**
     * @brief Sets the visible.
     * @param on Value passed to the method.
     * @return The requested visible.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    virtual void setVisible(bool on);

    /**
     * @brief Returns whether the object reports visible.
     * @return `true` when the object reports visible; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isVisible() const;

    /**
     * @brief Sets the max Points.
     * @param maxPoints Value passed to the method.
     * @return The requested max Points.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    virtual void setMaxPoints(int maxPoints);

    /**
     * @brief Returns the current max Points.
     * @return The current max Points.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int maxPoints() const;

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    virtual int count() const;

    /**
     * @brief Returns the current points.
     * @return The current points.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual const SwVector<SwPointF>& points() const;

    /**
     * @brief Performs the `append` operation.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @return The requested append.
     */
    virtual void append(double x, double y);

    /**
     * @brief Returns the current clear.
     * @return The current clear.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual void clear();

    /**
     * @brief Performs the `computeBounds` operation.
     * @param minX Value passed to the method.
     * @param maxX Value passed to the method.
     * @param minY Value passed to the method.
     * @param maxY Value passed to the method.
     * @param hasPoint Value passed to the method.
     * @return The requested compute Bounds.
     */
    virtual void computeBounds(double& minX,
                               double& maxX,
                               double& minY,
                               double& maxY,
                               bool& hasPoint) const;

    /**
     * @brief Performs the `lastX` operation.
     * @param outX Output value filled by the method.
     * @return The requested last X.
     */
    virtual bool lastX(double& outX) const;

    SW_SIGNAL(pointAdded, int);
    SW_SIGNAL_VOID(updated);

protected:
    /**
     * @brief Performs the `clampInt_` operation.
     * @param value Value passed to the method.
     * @param minValue Value passed to the method.
     * @param maxValue Value passed to the method.
     * @return The requested clamp Int.
     */
    static int clampInt_(int value, int minValue, int maxValue);

    /**
     * @brief Performs the `clampColor_` operation.
     * @param c Value passed to the method.
     * @return The requested clamp Color.
     */
    static SwColor clampColor_(const SwColor& c);

    /**
     * @brief Returns the current trim To Max.
     * @return The current trim To Max.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual void trimToMax_();

protected:
    // What the class keeps (SwAbstractSeries_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
