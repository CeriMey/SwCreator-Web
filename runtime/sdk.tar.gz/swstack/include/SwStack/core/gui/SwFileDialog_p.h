#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwFileDialog.h"

// The platform, which the public header no longer shows (SwFileDialog.h).
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#include <shellapi.h>
#include <shlobj.h>
#include <shlwapi.h>
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "shlwapi.lib")
#endif

struct SwFileDialog::Data {
    SwString m_directory;
    SwString m_filter;
    SwString m_selectedFile;
    FileMode m_fileMode{ExistingFile};
    AcceptMode m_acceptMode{AcceptOpen};
    SwToolButton* m_back{nullptr};
    SwToolButton* m_forward{nullptr};
    SwToolButton* m_up{nullptr};
    SwToolButton* m_home{nullptr};
    SwToolButton* m_refresh{nullptr};
    SwToolButton* m_go{nullptr};
    SwLineEdit* m_dirEdit{nullptr};
    FileListView* m_view{nullptr};
    SwLabel* m_pathLabel{nullptr};
    SwLineEdit* m_pathEdit{nullptr};
    SwLabel* m_filterLabel{nullptr};
    SwComboBox* m_filterCombo{nullptr};
    SwPushButton* m_ok{nullptr};
    SwPushButton* m_cancel{nullptr};
    int m_spacing{10};
    SwTreeWidget* m_sidebar{nullptr};
    SystemIconCache m_iconCache;
    int m_iconSizePx{20};
    SwVector<FilterOption> m_filterOptions;
    SwStringList m_activePatterns;
    int m_activeFilterIndex{0};
    SwVector<SwString> m_backHistory;
    SwVector<SwString> m_forwardHistory;
    SortKey m_sortKey{SortByName};
    bool m_sortAscending{true};
};
