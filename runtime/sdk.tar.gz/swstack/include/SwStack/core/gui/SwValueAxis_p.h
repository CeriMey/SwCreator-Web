#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwValueAxis.h"

struct SwValueAxis::Data {
    double m_minimum{0.0};
    double m_maximum{1.0};
    int m_tickCount{5};
    bool m_autoRange{true};
    SwString m_titleText{};
};
