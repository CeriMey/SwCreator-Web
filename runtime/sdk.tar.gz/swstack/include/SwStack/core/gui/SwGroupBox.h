﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwGroupBox.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwGroupBox in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the group box interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwGroupBox.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwGroupBox - group box.
 *
 * Notes:
 * - Optional checkable header.
 * - Does not automatically manage child layout margins; use a layout margin if needed.
 **************************************************************************************************/

#include "SwFrame.h"
#include "SwWidgetPlatformAdapter.h"

class SW_WIDGETS_EXPORT SwGroupBox : public SwFrame {
    SW_OBJECT(SwGroupBox, SwFrame)

public:
    /**
     * @brief Constructs a `SwGroupBox` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGroupBox(SwWidget* parent = nullptr);

    /**
     * @brief Constructs a `SwGroupBox` instance.
     * @param title Title text applied by the operation.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGroupBox(const SwString& title, SwWidget* parent = nullptr);

    /**
     * @brief Sets the title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTitle(const SwString& title);
    /**
     * @brief Performs the `title` operation.
     * @return The requested title.
     */
    SwString title() const;

    /**
     * @brief Sets the checkable.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCheckable(bool on);

    /**
     * @brief Returns whether the object reports checkable.
     * @return `true` when the object reports checkable; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isCheckable() const;

    /**
     * @brief Sets the checked.
     * @param checked Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setChecked(bool checked);

    /**
     * @brief Returns whether the object reports checked.
     * @return `true` when the object reports checked; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isChecked() const;

    /**
     * @brief Sets the accent Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAccentColor(const SwColor& color);

    /**
     * @brief Returns the current accent Color.
     * @return The current accent Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor accentColor() const;

    /**
     * @brief Returns the current contents Rect.
     * @return The current contents Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRect clientRect() const override;

    SwRect contentsRect() const;

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    SW_SIGNAL(toggled, bool);

protected:
    SW_PROPERTY_D(SwString, Text);
private:
protected:
    SW_PROPERTY_D(bool, Pressed);
private:
protected:

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

private:
    static bool containsPoint(const SwRect& r, int px, int py);

    int titleHeight() const;

    int contentTopInset_() const;

    int titleTextWidthEstimate(const SwString& text) const;

    int titleMinimumOuterWidth_() const;

    int contentInset_() const;

    bool usesNativeFrameFallback_(const ResolvedStyleSnapshot_& snapshot) const;

    void paintNativeFrame_(SwPainter* painter,
                           const SwRect& rect,
                           const SwRect& indicator,
                           const SwRect& titleRect) const;

    SwRect checkIndicatorRect(const SwRect& rect) const;

    SwRect titleTextRect(const SwRect& rect) const;

    void paintCheckIndicator(SwPainter* painter, const SwRect& indicator) const;

    void updateEnabledState();

    void initDefaults();

public:
    ~SwGroupBox();
private:
    // What the class keeps (SwGroupBox_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

