﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwWizard.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwWizard in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the wizard interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwWizardPage and SwWizard.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwWizard - modern multi-page wizard dialog.
 *
 * Focus:
 * - Horizontal stepper bar at top (circles + connector lines + labels).
 * - addPage() with title and content widget.
 * - Back / Next / Finish / Cancel buttons.
 **************************************************************************************************/

#include "SwDialog.h"
#include "SwLabel.h"
#include "SwPushButton.h"
#include "SwStackedWidget.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwWizardPage : public SwWidget {
    SW_OBJECT(SwWizardPage, SwWidget)
public:
    /**
     * @brief Constructs a `SwWizardPage` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwWizardPage(SwWidget* parent = nullptr);

    /**
     * @brief Sets the title.
     * @param t Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTitle(const SwString& t);
    /**
     * @brief Returns the current title.
     * @return The current title.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString title() const;

    /**
     * @brief Sets the sub Title.
     * @param t Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSubTitle(const SwString& t);
    /**
     * @brief Returns the current sub Title.
     * @return The current sub Title.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString subTitle() const;

private:
public:
    ~SwWizardPage();
private:
    // What the class keeps (SwWizard_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwWizard : public SwDialog {
    SW_OBJECT(SwWizard, SwDialog)

public:
    /**
     * @brief Constructs a `SwWizard` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwWizard(SwWidget* parent = nullptr);

    /**
     * @brief Adds the specified page.
     * @param page Value passed to the method.
     * @return The requested page.
     */
    int addPage(SwWizardPage* page);

    /**
     * @brief Returns the current current Id.
     * @return The current current Id.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int currentId() const;

    /**
     * @brief Returns the current current Page.
     * @return The current current Page.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWizardPage* currentPage() const;

    /**
     * @brief Performs the `next` operation.
     */
    void next();

    /**
     * @brief Performs the `back` operation.
     */
    void back();

signals:
    SW_SIGNAL(currentIdChanged, int);

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    static constexpr int kStepperHeight = 90;
    static constexpr int kDotSize = 24;
    static constexpr int kSmallDot = 8;
#if defined(_WIN32)
    static constexpr const wchar_t* kFontFamily = L"Segoe UI";
#else
    static constexpr const wchar_t* kFontFamily = L"Sans";
#endif

    // ---- Horizontal stepper bar ----
    class SW_WIDGETS_EXPORT StepperWidget final : public SwWidget {
        SW_OBJECT(StepperWidget, SwWidget)
    public:
        /**
         * @brief Performs the `StepperWidget` operation.
         * @param parent Optional parent object that owns this instance.
         * @return The requested stepper Widget.
         */
        explicit StepperWidget(SwWidget* parent = nullptr);

        /**
         * @brief Sets the steps.
         * @param titles Value passed to the method.
         * @param current Value passed to the method.
         *
         * @details Call this method to replace the currently stored value with the caller-provided one.
         */
        void setSteps(const SwVector<SwString>& titles, int current);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

    private:
        SwVector<SwString> m_titles;
        int m_current{0};
    };

    void buildUi();

    void updateButtons();

    void updateStepper();

    void updateWizardLayout();

    void layoutWizardButtons();

public:
    ~SwWizard();
private:
    // What the class keeps (SwWizard_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

