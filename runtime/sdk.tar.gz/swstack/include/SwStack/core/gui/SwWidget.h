﻿#pragma once

#include "../SwStackExport.h"
/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwObject.h"
#include "SwFont.h"
#include "StyleSheet.h"
#include "Sw.h"
#include "SwLayout.h"
#include <vector>
#include <algorithm>
#include <memory>
#include <limits>
#include <exception>
#include "SwFont.h"
#include "SwStyle.h"
#include "StyleSheet.h"
#include "SwString.h"
#include "Sw.h"
#include "SwPainter.h"
#include "SwGuiEvent.h"
#include "SwGuiApplication.h"
#include "SwWidgetPlatformAdapter.h"
#include "SwWidgetPerfTrace.h"
#include "core/types/SwMap.h"

class SwStyle;


// Classe SwWidget hÃ©ritant de SwObject, representant un widget de base
class SW_WIDGETS_EXPORT SwWidget : public SwObject {

    /**
     * @brief Macro to declare the inheritance hierarchy for the SwWidget class.
     *
     * Specifies that `SwWidget` is derived from `SwObject` class.
     */
    SW_OBJECT(SwWidget, SwObject)
    friend class SwStyle;
    friend class SwDialog;

    /**
     * @brief Property for the SwWidget's focus policy.
     *
     * Determines how the SwWidget handles focus events.
     *
     * @param FocusPolicy The focus policy as a `FocusPolicyEnum` value. Default is `FocusPolicyEnum::Accept`.
     */
    SW_PROPERTY_D(FocusPolicyEnum, FocusPolicy);
private:
protected:

    /**
     * @brief Property for the SwWidget's tooltip text.
     *
     * Sets or retrieves the tooltip text displayed when the user hovers over the SwWidget.
     *
     * @param ToolTips The tooltip text as an `SwString`.
     */
    SW_PROPERTY_D(SwString, ToolTips);
private:
protected:

    /**
     * @brief Custom property for the SwWidget's enabled state.
     *
     * Sets the enabled state of the SwWidget and triggers an update to apply any visual changes.
     *
     * @param Enable The new enabled state (`true` if the SwWidget is enabled, `false` otherwise).
     */
    SW_PROPERTY_D(bool, Enable);
private:
protected:

    /**
     * @brief Custom property for the SwWidget's focus state.
     *
     * Sets the focus state of the SwWidget and triggers an update to apply any visual changes.
     *
     * @param Focus The new focus state (`true` if the SwWidget is focused, `false` otherwise).
     */
    // Focus: its setter (SwWidget.cpp) takes or releases the focus of the window.
    SW_PROPERTY_D(bool, Focus);
private:
protected:

    /**
     * @brief Custom property for the SwWidget's hover state.
     *
     * Sets the hover state of the SwWidget and triggers an update to apply any visual changes.
     *
     * @param Hover The new hover state (`true` if the SwWidget is hovered, `false` otherwise).
     */
    SW_PROPERTY_D(bool, Hover);
private:
protected:

    /**
     * @brief Custom property for the SwWidget's visibility.
     *
     * Sets the visibility state of the SwWidget and invalidates its rectangular area to trigger a redraw.
     *
     * @param Visible The new visibility state (`true` for visible, `false` for hidden).
     */
    SW_PROPERTY_D(bool, Visible);
private:
protected:

    /**
     * @brief Custom property for the SwWidget's cursor type.
     *
     * Sets the cursor type for the SwWidget and loads the corresponding Windows cursor resource.
     * If the cursor type is not recognized, no default cursor is assigned.
     *
     * @param Cursor The new cursor type as a `CursorType` enumeration value.
     */
    SW_PROPERTY_D(CursorType, Cursor);
private:
protected:

    /**
     * @brief Custom override property for the SwWidget's font.
     *
     * Sets the SwWidget's font and triggers an update to apply the changes.
     *
     * @param Font The new font as an `SwFont` object.
     */
    SW_PROPERTY_D(SwFont, Font);
private:
protected:

    /**
     * @brief Custom property for the SwWidget's style sheet.
     *
     * Sets the SwWidget's style sheet and triggers its parsing.
     * After parsing, the SwWidget is updated to apply the new style.
     *
     * @param StyleSheet The new style sheet as an `SwString`.
     */
    SW_PROPERTY_D(SwString, StyleSheet);
private:
protected:

public:
    void setDefaultStyleSheet(const SwString& styleSheet);

    SwString defaultStyleSheet() const;

    // An isolated subtree keeps its own widget defaults and local styles,
    // without inheriting ancestor or application styles. Enabled by default.
    void setStyleSheetInheritanceEnabled(bool enabled);
    bool styleSheetInheritanceEnabled() const;

    /**
     * @brief Constructor for the SwWidget class.
     *
     * Initializes a SwWidget with default dimensions, registered properties, and a default style.
     * If a parent is specified, the SwWidget will be linked to it, and a new parent event will be triggered.
     *
     * @param parent Pointer to the parent SwWidget. If nullptr, the SwWidget is standalone.
     */
    SwWidget(SwWidget* parent = nullptr);

    /**
     * @brief Destructor for the SwWidget class.
     *
     * Cleans up the SwWidget by deleting all its child SwWidgets to ensure proper memory management.
     */
    virtual ~SwWidget();

    /**
     * @brief Adds a child SwWidget to the current SwWidget.
     *
     * Links the specified SwWidget as a child of this SwWidget using the base `SwObject` implementation.
     *
     * @param child Pointer to the child SwWidget to be added.
     */
    virtual void addChild(SwObject* child) override;

    virtual void removeChild(SwObject* child) override;

    void setLayout(SwAbstractLayout* layout);

    SwAbstractLayout* layout() const;

private:
    struct SavedLocalGeometry_ {
        SwWidget* widget{nullptr};
        SwRect geometry{0, 0, 0, 0};
    };

    static void collectDescendantLocalGeometry_(SwWidget* root, std::vector<SavedLocalGeometry_>& out);

    static void restoreSavedLocalGeometry_(const std::vector<SavedLocalGeometry_>& saved);

    void adoptLayoutWidgets_(const SwAbstractLayout* layout);

public:

    /**
     * @brief Displays the SwWidget by setting its visibility to true.
     *
     * Overrides the base implementation to make the SwWidget visible.
     */
    virtual void show();

    /**
     * @brief Hides the SwWidget by setting its visibility to false.
     *
     * Overrides the base implementation to make the SwWidget invisible.
     * Outputs a message to the console indicating that the SwWidget has been hidden.
     */
    virtual void hide();

    /// Puts the widget above its siblings, as QWidget::raise(): painted over them, first to receive
    /// the mouse. A widget shown in a native window of its own raises that window above the others.
    void raise();

    /// Puts the widget below its siblings, as QWidget::lower(); a native window of its own goes
    /// below the others.
    void lower();

    /**
     * @brief Marks the widget's area as dirty so the next paint cycle redraws it.
     *
     * A single InvalidateRect on the native window is sufficient: the paint
     * handler already walks the full widget tree and repaints every child that
     * intersects the dirty region.  Recursing into children here was causing
     * O(N) InvalidateRect + PostMessage calls for a tree of N widgets, which
     * flooded the Win32 message queue on every keystroke or property change.
     *
     */
    virtual void update();

    // GUI-thread APIs. The application sheet participates in every widget's
    // cascade, including independent native dialogs and widgets created later.
    // Explicit local sheets retain precedence over the application theme.
    static void setApplicationStyleSheet(const SwString& styleSheet);
    static SwString applicationStyleSheet();
    static std::vector<SwWidget*> allWidgets();
    static void repaintAllWidgets();
    // Custom native surfaces may refresh cached palette resources here.
    virtual void applicationStyleChangeEvent() {}

    /**
     * @brief Moves the SwWidget to a new position and propagates the move event to its children.
     *
     * Updates the SwWidget's position, emits the `moved` signal, and triggers a redraw if the SwWidget is visible.
     * The movement is also propagated to all child SwWidgets relative to the new position.
     *
     * @param newX The new X-coordinate of the SwWidget.
     * @param newY The new Y-coordinate of the SwWidget.
     */
    // move() takes coordinates relative to the parent's top-left corner.
    // Internally converts to absolute window coordinates and propagates to children.
    virtual void move(int newX, int newY);

    void move(const SwPoint& point);

    /**
     * @brief Resizes the SwWidget and triggers the resize event.
     *
     * Updates the SwWidget's width and height, emits the `resized` signal,
     * and calls the `resizeEvent` to handle the resize logic.
     *
     * @param newWidth The new width of the SwWidget.
     * @param newHeight The new height of the SwWidget.
     */
    virtual void resize(int newWidth, int newHeight);

    void resize(const SwSize& sizeVal);

    /**
     * @brief Returns the current width of the widget.
     */
    int width() const;

    /**
     * @brief Returns the current height of the widget.
     */
    int height() const;

    int x() const;

    int y() const;

    SwSize size() const;

    void setMinimumSize(int minW, int minH);

    void setMaximumSize(int maxW, int maxH);

    SwSize minimumSize() const;

    SwSize maximumSize() const;

    virtual void setGeometry(int newX, int newY, int newWidth, int newHeight);

    virtual void setGeometry(const SwRect& geometryRect);

    /**
     * @brief Returns the widget frame geometry, matching QWidget::frameGeometry().
     */
    virtual SwRect frameGeometry() const;

    /**
     * @brief Returns the widget's client area dimensions (excluding frame borders).
     */
    virtual SwSize clientSize() const;

    virtual SwRect clientRect() const;

    /**
     * @brief Returns the widget-local rectangle, matching QWidget::rect().
     */
    SwRect rect() const;

    /**
     * @brief Returns the widget geometry relative to its parent (Qt-compatible).
     *
     * geometry() returns coordinates relative to the parent widget, matching QWidget::geometry().
     */
    SwRect geometry() const;

    /**
     * @brief Returns the widget position relative to its parent (Qt-compatible).
     */
    SwPoint pos() const;

    SwRect contentsRect() const;

    SwSize frameSize() const;

    SwRect normalGeometry() const;

    /**
     * @brief Converts a point from widget-local coordinates to screen coordinates.
     *
     * Matches QWidget::mapToGlobal().
     */
    SwPoint mapToGlobal(const SwPoint& localPt) const;

    /**
     * @brief Converts a point from screen coordinates to widget-local coordinates.
     *
     * Matches QWidget::mapFromGlobal().
     */
    SwPoint mapFromGlobal(const SwPoint& globalPt) const;

    /**
     * @brief Converts a point from widget-local coordinates to parent coordinates, matching QWidget::mapToParent().
     */
    SwPoint mapToParent(const SwPoint& localPt) const;

    /**
     * @brief Converts a point from parent coordinates to widget-local coordinates, matching QWidget::mapFromParent().
     */
    SwPoint mapFromParent(const SwPoint& parentPt) const;

    /**
     * @brief Converts a point from this widget's coordinate space to another widget's.
     *
     * Matches QWidget::mapTo().
     */
    SwPoint mapTo(const SwWidget* target, const SwPoint& localPt) const;

    /**
     * @brief Converts a point from another widget's coordinates to this widget's, matching QWidget::mapFrom().
     */
    SwPoint mapFrom(const SwWidget* source, const SwPoint& sourcePt) const;

    SwWidgetPlatformHandle platformHandle() const;

    bool isVisibleInHierarchy() const;

    virtual SwSize sizeHint() const;

    virtual SwSize minimumSizeHint() const;

    /**
     * @brief Retrieves the deepest child SwWidget located under the given cursor position.
     *
     * Iterates through the SwWidget's children to determine which one contains the specified coordinates.
     * If multiple nested children match, the method returns the deepest child.
     *
     * @param x The X-coordinate of the cursor.
     * @param y The Y-coordinate of the cursor.
     * @return A pointer to the deepest child SwWidget under the cursor, or nullptr if none is found.
     */
    SwWidget* getChildUnderCursor(int x, int y, SwWidget* ignore = nullptr);

    SwWidget* childAt(int x, int y);

    const SwWidget* childAt(int x, int y) const;

    /**
     * @brief Retrieves the stylesheet associated with the SwWidget.
     *
     * Returns a pointer to the internal `StyleSheet` object used by the SwWidget.
     *
     * @return A pointer to the `StyleSheet` object.
     */
    virtual StyleSheet* getToolSheet();

    virtual bool resolveStyledBackground(unsigned int stateFlags, SwColor& color, float& alpha, bool& paint) const;

    virtual bool resolveStyledBorder(unsigned int stateFlags, SwColor& color, int& width, int& radius) const;

    virtual void resolveStyledBorderCorners(unsigned int stateFlags,
                                    int& topLeft,
                                    int& topRight,
                                    int& bottomRight,
                                    int& bottomLeft) const;

    virtual SwColor resolveStyledTextColor(unsigned int stateFlags, const SwColor& fallback) const;

    virtual StyleSheet::BoxEdges resolveStyledPadding(unsigned int stateFlags) const;

    virtual SwFont resolveStyledFont(unsigned int stateFlags) const;

    virtual SwString resolveStyledBoxShadow(unsigned int stateFlags) const;

    virtual bool hasExplicitStyledStateProperty(unsigned int stateFlags, const SwString& property) const;

signals:
    /**
     * @brief Signal emitted when the SwWidget is resized.
     *
     * Parameters:
     * - `int newWidth`: The new width of the SwWidget.
     * - `int newHeight`: The new height of the SwWidget.
     */
    SW_SIGNAL(resized, int, int);

    /**
     * @brief Signal emitted when the SwWidget is moved.
     *
     * Parameters:
     * - `int newX`: The new X-coordinate of the SwWidget.
     * - `int newY`: The new Y-coordinate of the SwWidget.
     */
    SW_SIGNAL(moved, int, int);

    /**
     * @brief Signal emitted when the visibility of the SwWidget changes.
     *
     * Parameters:
     * - `bool isVisible`: The new visibility state of the SwWidget.
     */
    SW_SIGNAL_VOID(visibilityChanged);

/**
     * @brief Sends every mouse event of this widget's window to it, until releaseMouse().
     *
     * Moves, presses and releases go to this widget wherever the pointer is in the window, as they
     * do on their own while a button pressed on it is held.
     */
    void grabMouse();

    /**
     * @brief Ends this widget's hold on the mouse: a grabMouse(), or the hold a button pressed on
     * it gives it until released, the native capture included. It does nothing for another widget.
     */
    void releaseMouse();

    /// The widget the mouse events of this widget's window go to, or null.
    SwWidget* mouseGrabber() const;

    bool dispatchMouseEventFromRoot(const MouseEvent& rootEvent);

    bool dispatchWheelEventFromRoot(const WheelEvent& rootEvent);

    bool dispatchKeyPressEventFromRoot(const KeyEvent& rootEvent);

    bool dispatchKeyReleaseEventFromRoot(const KeyEvent& rootEvent);

    SwWidget* focusedWidgetInHierarchy();

    SwWidget* hoveredWidgetFromRoot() const;

    void bindToNativeWindowRecursive(const SwWidgetPlatformHandle& handle);

    void unbindFromNativeWindowRecursive();


protected:

    /**
     * @brief Handles the event when the SwWidget gets a new parent.
     *
     * Updates the SwWidget's platform window handle and visibility state based on the new parent.
     * Calls the base `SwObject::newParentEvent` to ensure proper propagation.
     *
     * @param parent Pointer to the new parent object.
     */
    virtual void newParentEvent(SwObject* parent) override;

    // Internal: set absolute window position and propagate delta to all children.
    void setAbsolutePos_(int absX, int absY);

    SwPoint currentLocalPos_() const;

    void translateAbsolutePosRecursive_(int deltaX, int deltaY);

    static SwRect inflateForGeometryInvalidate_(SwRect rect);

    void invalidateGeometryChange_(const SwRect& oldRect);

    SwPoint rootClientOriginOnScreen_() const;

    SwPoint topLevelClientPosOnScreen_() const;

    SwPoint topLevelFramePosOnScreen_() const;

    SwRect absoluteRect_() const;

    /**
     * @brief Handles the paint event for the SwWidget.
     *
     * Draws the SwWidget's background using a specified color and propagates the paint event
     * to visible child SwWidgets whose rectangles intersect the paint area.
     *
     * @param event Pointer to the `PaintEvent` containing the context and paint area.
     */
    virtual void paintEvent(PaintEvent* event);

    /**
     * @brief Utility function to check if two Windows RECT structures intersect.
     *
     * Determines whether the rectangles `r1` and `r2` overlap by evaluating their boundaries.
     *
     * @param r1 The first RECT structure.
     * @param r2 The second RECT structure.
     * @return `true` if the rectangles intersect, `false` otherwise.
     */
    bool rectsIntersect(const SwRect& r1, const SwRect& r2);

    static SwRect intersectRect_(const SwRect& a, const SwRect& b);

    static bool rectContainsRect_(const SwRect& outer, const SwRect& inner);

    struct NormalizedPaintEvent_ {
        SwPainter* painter{nullptr};
        SwRect paintRect{0, 0, 0, 0};
        std::unique_ptr<SwOffsetPainter> ownedPainter;
    };

    NormalizedPaintEvent_ normalizePaintEvent_(PaintEvent* event);

    void paintChild_(PaintEvent* event, SwWidget* child);

    virtual bool event(SwEvent* event) override;

    bool dispatchMouseEventFromRoot_(const MouseEvent& rootEvent);

    bool dispatchWheelEventFromRoot_(const WheelEvent& rootEvent);

    bool dispatchKeyPressEventFromRoot_(const KeyEvent& rootEvent);

    bool dispatchKeyReleaseEventFromRoot_(const KeyEvent& rootEvent);

    bool isInputBlockedByNativeModal_() const;

    /**
     * @brief Handles the key press event for the SwWidget.
     *
     * Root-level key dispatch is handled by `dispatchKeyPressEventFromRoot_()`. The base widget does
     * not perform legacy child recursion anymore.
     *
     * @param event Pointer to the `KeyEvent` containing information about the key press.
     */
    virtual void keyPressEvent(KeyEvent* event);

    virtual void keyReleaseEvent(KeyEvent* event);

    /**
     * @brief Handles the resize event for the SwWidget.
     *
     * Triggers an update to redraw the SwWidget after a resize.
     * Optionally, a mechanism could be added to notify child SwWidgets of the parent's size change.
     *
     * @param event Pointer to the `ResizeEvent` containing the new dimensions of the SwWidget.
     */
    virtual void resizeEvent(ResizeEvent* event);

    virtual void moveEvent(MoveEvent* event);

    /**
     * @brief Called when the window receives a close request (e.g. user clicks X).
     *
     * Override this to prevent closing (call event->ignore()) or to minimize to
     * system tray instead. Default implementation accepts the event.
     */
    virtual void closeEvent(CloseEvent* event);

    virtual void showEvent(Event* event);

    virtual void hideEvent(Event* event);

    /**
     * @brief Called when the top-level window gains (true) or loses (false) activation.
     *
     * Only delivered to window-owning widgets (SwMainWindow). Popup-style windows override
     * this and hide themselves on the deactivation edge.
     */
    virtual void activationChangeEvent(bool active);

    /**
     * @brief Handles the mouse press event for the SwWidget.
     *
     * Root-level mouse dispatch is handled by `dispatchMouseEventFromRoot_()`. The base widget does
     * not perform legacy child recursion anymore.
     *
     * @param event Pointer to the `MouseEvent` containing the mouse press details.
     */
    virtual void mousePressEvent(MouseEvent* event);

    /**
     * @brief Handles the mouse release event for the SwWidget.
     *
     * Root-level mouse dispatch is handled by `dispatchMouseEventFromRoot_()`. The base widget does
     * not perform legacy child recursion anymore.
     *
     * @param event Pointer to the `MouseEvent` containing the mouse release details.
     */
    virtual void mouseReleaseEvent(MouseEvent* event);

    /**
     * @brief Handles the mouse double-click event for the SwWidget.
     *
     * Root-level mouse dispatch is handled by `dispatchMouseEventFromRoot_()`. The base widget does
     * not perform legacy child recursion anymore.
     *
     * @param event Pointer to the `MouseEvent` containing the double-click details.
     */
    virtual void mouseDoubleClickEvent(MouseEvent* event);

    /**
     * @brief Handles the mouse move event for the SwWidget.
     *
     * Root-level mouse dispatch is handled by `dispatchMouseEventFromRoot_()`. The base widget only
     * updates its own hover/cursor state for kernel-delivered events.
     *
     * @param event Pointer to the `MouseEvent` containing the mouse move details.
     */
    virtual void mouseMoveEvent(MouseEvent* event);

    virtual void wheelEvent(WheelEvent* event);

protected:

    // ─── Style-resolution utilities (shared by all widgets) ───────────────

    struct ResolvedStyleSnapshot_ {
        bool valid{false};
        unsigned int stateFlags{StyleSheet::StateNone};
        SwFont baseFont{};
        SwString objectName;
        bool hasBackgroundColor{false};
        SwColor backgroundColor{0, 0, 0};
        float backgroundAlpha{1.0f};
        bool paintBackground{true};
        bool hasBorderColor{false};
        SwColor borderColor{0, 0, 0};
        bool hasBorderWidth{false};
        int borderWidth{0};
        bool borderStyleNone{false};
        bool hasBorderRadius{false};
        int borderRadius{0};
        bool hasBorderTopLeftRadius{false};
        int borderTopLeftRadius{0};
        bool hasBorderTopRightRadius{false};
        int borderTopRightRadius{0};
        bool hasBorderBottomRightRadius{false};
        int borderBottomRightRadius{0};
        bool hasBorderBottomLeftRadius{false};
        int borderBottomLeftRadius{0};
        bool hasTextColor{false};
        SwColor textColor{0, 0, 0};
        StyleSheet::BoxEdges padding{};
        SwSize minSize{0, 0};
        SwSize maxSize{std::numeric_limits<int>::max(), std::numeric_limits<int>::max()};
        SwFont font{};
        bool explicitStateBackground{false};
        SwString boxShadow;
    };

    static int clampInt(int value, int minValue, int maxValue);

    static double clampDouble(double value, double minValue, double maxValue);

    static SwColor clampColor(const SwColor& c);

    static int parsePixelValue(const SwString& value, int defaultValue);

    const SwList<SwString>& styleSelectors_() const;

    unsigned int styleStateFlags_() const;

    SwString resolveStyleProperty_(const StyleSheet* sheet,
                                   const SwString& property,
                                   unsigned int stateFlags) const;

    const ResolvedStyleSnapshot_& resolvedStyleSnapshot_(unsigned int stateFlags = std::numeric_limits<unsigned int>::max()) const;

    SwSize resolvedStyleMinimumSize_() const;

    SwSize resolvedStyleMaximumSize_() const;

    SwFont resolvedStyledFont_(const StyleSheet* sheet = nullptr, unsigned int stateFlags = std::numeric_limits<unsigned int>::max()) const;

    StyleSheet::BoxEdges resolvePaddingEdges_(const StyleSheet* sheet = nullptr,
                                              unsigned int stateFlags = std::numeric_limits<unsigned int>::max()) const;

    void updateStyleTree_();

    void invalidateEffectiveStyleCacheRecursive_();

    void invalidateResolvedStyleSnapshot_();

    void resolveBackground(const StyleSheet* sheet,
                           SwColor& outColor,
                           float& outAlpha,
                           bool& outPaint) const;

    void resolveBorder(const StyleSheet* sheet,
                       SwColor& outColor,
                       int& outWidth,
                       int& outRadius) const;

    void resolveBorderCornerRadii(const StyleSheet* sheet,
                                  int& outTopLeft,
                                  int& outTopRight,
                                  int& outBottomRight,
                                  int& outBottomLeft) const;

    SwColor resolveTextColor(const StyleSheet* sheet, const SwColor& fallback) const;

    // ─── End style-resolution utilities ───────────────────────────────────

    /**
     * @brief Checks if a given point is inside the SwWidget's boundaries.
     *
     * Determines whether the point specified by its X and Y coordinates lies within the SwWidget's rectangle.
     *
     * @param px The X-coordinate of the point.
     * @param py The Y-coordinate of the point.
     * @return `true` if the point is inside the SwWidget, `false` otherwise.
     */
    bool isPointInside(int px, int py) const;

    /**
     * @brief Invalidates the SwWidget's rectangular area, marking it for redrawing.
     *
     * Computes the SwWidget's rectangle based on its position and size, then requests a redraw
     * through the active platform adapter.
     */
    virtual void invalidateRect();

private:
    void ensureSwWidgetChildren_();

    void acquireNativeModalInputBlock_();
    void releaseNativeModalInputBlock_();

    void invalidateVisibilityCache_();


protected:
    static bool sharesNativeWindow_(const SwWidget* left, const SwWidget* right);

    SwWidget* mouseGrabScopeRoot_();

    const SwWidget* mouseGrabScopeRoot_() const;

    SwWidget*& mouseGrabberWidget_();

    unsigned int& mouseGrabButtons_();

    void releaseMouseGrabForHiddenHierarchy_();

    static unsigned int mouseButtonMask_(SwMouseButton button);

    bool belongsToHierarchy_(const SwWidget* widget) const;

    SwWidget* findFocusedDescendantByState_();

    SwWidget* findFocusedWidgetInHierarchy_();

    void updateFocusForDispatch_(SwWidget* targetWidget);

    void clearHoverPathOnRoot_();

    void clearHoverRecursive_();

    SwWidget* buildHoverPathToPoint_(const SwPoint& pointInThis, SwList<SwWidget*>& pathOut);

    SwWidget* updateHoverStateFromRoot_(const SwPoint& pointInThis);

    bool deliverMouseEventToChain_(SwWidget* target, const MouseEvent& rootEvent, SwWidget** acceptedBy = nullptr);

    bool deliverWheelEventToChain_(SwWidget* target, const WheelEvent& rootEvent);

    bool deliverKeyEventToChain_(SwWidget* target, const KeyEvent& rootEvent);

    static MouseEvent mapMouseEventToChild_(const MouseEvent& event,
                                            const SwWidget* source,
                                            const SwWidget* child);

    static WheelEvent mapWheelEventToChild_(const WheelEvent& event,
                                            const SwWidget* source,
                                            const SwWidget* child);

    void setFocusState_(bool value);

    void requestFocusOwnership_();

    void releaseFocusOwnership_();

    bool isFocusEligible_() const;

    void clearFocusInHierarchy_();

    struct SW_WIDGETS_EXPORT FocusScopeKey_ {
        const void* nativeHandle{nullptr};
        const void* nativeDisplay{nullptr};
        const SwWidget* logicalRoot{nullptr};

        FocusScopeKey_();

        FocusScopeKey_(const void* handle, const void* display, const SwWidget* root);

        bool operator==(const FocusScopeKey_& other) const;

        bool operator!=(const FocusScopeKey_& other) const;

        bool operator<(const FocusScopeKey_& other) const;
    };

    FocusScopeKey_ focusScopeKey_() const;

    SwWidget* focusScopeRoot_() const;

    static SwMap<FocusScopeKey_, SwWidget*>& focusOwnerMap_();

    static void removeFocusOwnerEntriesForWidget_(const SwWidget* widget);

    static SwWidget* validatedFocusOwnerForKey_(const FocusScopeKey_& scopeKey);

    SwWidget* currentFocusOwnerInScope_();

    void rebindFocusOwnership_();

    void setNativeWindowHandle(const SwWidgetPlatformHandle& handle);

    void setNativeWindowHandleRecursive(const SwWidgetPlatformHandle& handle);

    const SwWidgetPlatformHandle& nativeWindowHandle() const;
protected:
    // What the class keeps (SwWidget_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

