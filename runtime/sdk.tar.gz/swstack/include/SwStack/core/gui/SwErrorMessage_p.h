#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwErrorMessage.h"

struct SwErrorMessage::Data {
    SwString m_currentMessage;
    SwMap<SwString, bool> m_suppressed;
    ErrorIconWidget* m_iconWidget{nullptr};
    SwLabel* m_textLabel{nullptr};
    SwCheckBox* m_checkBox{nullptr};
    SwPushButton* m_okBtn{nullptr};
};
