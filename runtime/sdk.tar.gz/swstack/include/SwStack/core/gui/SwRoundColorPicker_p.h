#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwRoundColorPicker.h"

struct SwRoundColorPicker::Data {
    SwColor m_color{0, 0, 0};
    double m_hue{0.0};
    double m_saturation{1.0};
    double m_value{1.0};
    bool m_draggingHue{false};
    bool m_draggingSv{false};
    int m_wheelSize{0};
    int m_outerRadius{0};
    int m_ringThickness{0};
    int m_margin{0};
    int m_svRadius{0};
    SwImage m_hueImage;
    SwImage m_svImage;
};
