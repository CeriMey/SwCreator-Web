#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextFormat.h"

struct SwTextBlockFormat::Data : SwSharedData {
    Alignment m_alignment{AlignLeft};
    int m_indent{0};
    int m_headingLevel{0};
    int m_topMargin{0};
    int m_bottomMargin{0};
    int m_leftMargin{0};
    int m_rightMargin{0};
    int m_lineHeight{0};   // 0 = auto
    int m_textIndent{0};
    SwColor m_background{255, 255, 255};
    bool m_hasBackground{false};
    bool m_pageBreakBefore{false};
    bool m_pageBreakAfter{false};
};
struct SwTextCharFormat::Data : SwSharedData {
    SwString m_fontFamily;
    int m_fontPointSize{0};
    FontWeight m_fontWeight{Normal};
    bool m_italic{false};
    UnderlineStyle m_underlineStyle{NoUnderline};
    SwColor m_underlineColor{0, 0, 0};
    bool m_strikeOut{false};
    SwColor m_foreground{0, 0, 0};
    SwColor m_background{255, 255, 255};
    SwString m_href;
    SwString m_anchorName;
    SwString m_toolTip;
    VerticalAlignment m_vertAlign{AlignNormal};
    SwMap<int, SwAny> m_properties;
    bool m_hasFontFamily{false};
    bool m_hasFontPointSize{false};
    bool m_hasFontWeight{false};
    bool m_hasItalic{false};
    bool m_hasUnderlineStyle{false};
    bool m_hasUnderlineColor{false};
    bool m_hasStrikeOut{false};
    bool m_hasForeground{false};
    bool m_hasBackground{false};
};
struct SwTextImageFormat::Data : SwSharedData {
    SwString m_name;
    int m_width{0};   // 0 = natural size
    int m_height{0};
    SwImage m_image;
};
struct SwTextListFormat::Data : SwSharedData {
    Style m_style{ListDisc};
    int m_indent{1};
    SwString m_prefix;
    SwString m_suffix{"."};
    int m_start{1};
};
struct SwTextTableCellFormat::Data : SwSharedData {
    SwColor m_background{255, 255, 255};
    bool m_hasBackground{false};
    int m_topPad{2};
    int m_bottomPad{2};
    int m_leftPad{2};
    int m_rightPad{2};
    VerticalAlignment m_vertAlign{AlignTop};
};
struct SwTextTableFormat::Data : SwSharedData {
    int m_borderWidth{1};
    SwColor m_borderColor{0, 0, 0};
    int m_cellPadding{2};
    int m_cellSpacing{2};
    int m_width{0};
    bool m_widthIsPercent{true};
    SwTextBlockFormat::Alignment m_alignment{SwTextBlockFormat::AlignLeft};
    SwColor m_background{255, 255, 255};
    bool m_hasBackground{false};
    SwList<int> m_colWidths;
};
