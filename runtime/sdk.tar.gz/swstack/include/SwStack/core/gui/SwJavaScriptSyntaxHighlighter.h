#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwJavaScriptSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat templateStringFormat;
    SwTextCharFormat templateExprFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat regexFormat;
    SwTextCharFormat constantFormat;
};

inline SwTextCharFormat swJsMakeFormat_(const SwColor& color,
                                        FontWeight weight = Normal,
                                        bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwJavaScriptSyntaxTheme swJsSyntaxThemeVsCodeDark() {
    SwJavaScriptSyntaxTheme theme;
    theme.keywordFormat        = swJsMakeFormat_(SwColor{197, 134, 192}, Medium);
    theme.typeFormat           = swJsMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat        = swJsMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat         = swJsMakeFormat_(SwColor{206, 145, 120});
    theme.templateStringFormat = swJsMakeFormat_(SwColor{206, 145, 120});
    theme.templateExprFormat   = swJsMakeFormat_(SwColor{156, 220, 254});
    theme.numberFormat         = swJsMakeFormat_(SwColor{181, 206, 168});
    theme.functionFormat       = swJsMakeFormat_(SwColor{220, 220, 170});
    theme.regexFormat          = swJsMakeFormat_(SwColor{209, 105, 105});
    theme.constantFormat       = swJsMakeFormat_(SwColor{86, 156, 214});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwJavaScriptSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwJavaScriptSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwJavaScriptSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwJavaScriptSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BlockCommentState = 1,
        TemplateLiteralState = 2
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int findClosingQuote_(const SwString& text, int start, char quote);

    static int findBlockCommentEnd_(const SwString& text, int start);

    int highlightTemplateLiteral_(const SwString& text, int start, bool skipOpening);

    static int parseNumber_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isType_(const SwString& word);

    static bool isConstant_(const SwString& word);

public:
    ~SwJavaScriptSyntaxHighlighter();
private:
    // What the class keeps (SwJavaScriptSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
