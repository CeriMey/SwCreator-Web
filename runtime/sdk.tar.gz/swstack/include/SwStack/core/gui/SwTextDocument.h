#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextFormat.h"
#include "SwTextBlockUserData.h"
#include "../object/SwObject.h"
#include "../types/SwList.h"
#include "../types/SwMap.h"
#include "../types/SwString.h"

#include <algorithm>
#include <cstring>
#include <functional>
#include <memory>
#include <iomanip>
#include <limits>
#include <sstream>
#include <vector>

class SwTextDocument;
class SwTextCursor;
class SwTextDocumentLayout;

namespace swTextDocumentDetail {
inline int sizeToInt(size_t value) {
    return value <= static_cast<size_t>(std::numeric_limits<int>::max())
        ? static_cast<int>(value)
        : std::numeric_limits<int>::max();
}

inline bool parseCssRgbTriplet(const std::string& text, int& r, int& g, int& b) {
    std::istringstream stream(text);
    char firstComma = '\0';
    char secondComma = '\0';
    stream >> std::ws >> r >> std::ws >> firstComma
           >> std::ws >> g >> std::ws >> secondComma
           >> std::ws >> b >> std::ws;
    return stream && firstComma == ',' && secondComma == ',' && stream.eof();
}
}

struct SW_GUI_EXPORT SwTextLayoutFormatRange {
    int start{0};
    int length{0};
    SwTextCharFormat format;

    bool operator==(const SwTextLayoutFormatRange& other) const;

    bool operator!=(const SwTextLayoutFormatRange& other) const;
};

// ---------------------------------------------------------------------------
// SwTextFragment — a run of text with uniform character format
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextFragment {
public:
    SwTextFragment();
    SwTextFragment(const SwString& text, const SwTextCharFormat& fmt);

    SwString text() const;
    void setText(const SwString& t);

    SwTextCharFormat charFormat() const;
    void setCharFormat(const SwTextCharFormat& fmt);

    int length() const;
    bool isEmpty() const;

private:
public:
    ~SwTextFragment();
public:
    SwTextFragment(const SwTextFragment& other);
    SwTextFragment& operator=(const SwTextFragment& other);
private:
    // What the class keeps (SwTextDocument_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextBlock — a paragraph (list of fragments + block format)
// ---------------------------------------------------------------------------

class SwTextList;

class SW_GUI_EXPORT SwTextBlock {
public:
    SwTextBlock();

    // --- Text content ---
    SwString text() const;

    int length() const;

    // --- Fragments ---
    int fragmentCount() const;
    const SwTextFragment& fragmentAt(int index) const;
    SwTextFragment& fragmentAt(int index);

    void appendFragment(const SwTextFragment& frag);
    void insertFragment(int index, const SwTextFragment& frag);
    void removeFragment(int index);
    void clearFragments();

    // --- Block format ---
    SwTextBlockFormat blockFormat() const;
    void setBlockFormat(const SwTextBlockFormat& fmt);

    // --- Character format at a position within the block ---
    SwTextCharFormat charFormatAt(int pos) const;

    // --- List association ---
    SwTextList* list() const;
    void setList(SwTextList* list);

    // --- Block number (set by document) ---
    int blockNumber() const;
    void setBlockNumber(int n);

    bool isValid() const;

    int userState() const;
    void setUserState(int state);

    SwTextBlockUserData* userData() const;
    void setUserData(SwTextBlockUserData* data);
    void clearUserData();

    const SwList<SwTextLayoutFormatRange>& additionalFormats() const;
    void setAdditionalFormats(const SwList<SwTextLayoutFormatRange>& formats);
    void clearAdditionalFormats();

    // --- Insert text at position within block ---
    void insertText(int pos, const SwString& text, const SwTextCharFormat& fmt);

    // --- Remove text range within block ---
    void removeText(int pos, int count);

    // --- Set char format on a range ---
    void setCharFormat(int pos, int count, const SwTextCharFormat& fmt);

    void mergeCharFormat(int pos, int count, const SwTextCharFormat& fmt);

private:

    void splitAt(int pos);

    void normalize();
public:
    ~SwTextBlock();
public:
    SwTextBlock(const SwTextBlock& other);
    SwTextBlock& operator=(const SwTextBlock& other);
private:
    // What the class keeps (SwTextDocument_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextList — groups blocks that form a list
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextList {
public:
    SwTextList();
    explicit SwTextList(const SwTextListFormat& fmt);

    SwTextListFormat format() const;
    void setFormat(const SwTextListFormat& fmt);

    int count() const;
    void addBlockIndex(int idx);
    int blockIndex(int i) const;
    void removeBlockIndex(int idx);

    int itemNumber(int blockIndex) const;

private:
public:
    ~SwTextList();
public:
    SwTextList(const SwTextList& other);
    SwTextList& operator=(const SwTextList& other);
private:
    // What the class keeps (SwTextDocument_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextTable — table within the document
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextTable {
public:
    SwTextTable();
    SwTextTable(int rows, int cols);

    void resize(int rows, int cols);

    int rows() const;
    int columns() const;

    SwTextTableFormat tableFormat() const;
    void setTableFormat(const SwTextTableFormat& fmt);

    // --- Cell access ---
    struct Cell {
        SwList<SwTextBlock> blocks;
    };

    Cell& cellAt(int row, int col);
    const Cell& cellAt(int row, int col) const;

    SwTextTableCellFormat cellFormat(int row, int col) const;
    void setCellFormat(int row, int col, const SwTextTableCellFormat& fmt);

    // --- Row/column manipulation ---
    void insertRow(int before);

    void insertColumn(int before);

    void removeRow(int index);

    void removeColumn(int index);

    // Position in document (block index where this table starts)
    int startBlock() const;
    void setStartBlock(int b);

private:
public:
    ~SwTextTable();
public:
    SwTextTable(const SwTextTable& other);
    SwTextTable& operator=(const SwTextTable& other);
private:
    // What the class keeps (SwTextDocument_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextDocument — the top-level document model (Qt6 QTextDocument equivalent)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextDocument : public SwObject {
    SW_OBJECT(SwTextDocument, SwObject)
public:
    explicit SwTextDocument(SwObject* parent = nullptr);

    ~SwTextDocument();

    // --- Block access ---
    int blockCount() const;

    SwTextBlock& blockAt(int index);
    const SwTextBlock& blockAt(int index) const;

    SwTextBlock& firstBlock();
    const SwTextBlock& firstBlock() const;

    SwTextBlock& lastBlock();
    const SwTextBlock& lastBlock() const;

    // --- Total character count (including block separators) ---
    int characterCount() const;

    int revision() const;
    int lastEditBlockHint() const;
    void clearEditBlockHint();

    void beginBatchEdit();

    void endBatchEdit();

    // --- Position mapping: absolute position <-> (block, offset) ---
    struct SW_GUI_EXPORT BlockPosition {
        int blockIndex{-1};
        int offset{0};

        BlockPosition();

        BlockPosition(int index, int blockOffset);
    };

    BlockPosition blockPositionFromAbsolute(int absPos) const;

    int absolutePosition(int blockIndex, int offset) const;

    // --- Plain text ---
    SwString toPlainText() const;

    void setPlainText(const SwString& text);

    // --- HTML import/export ---
    void setHtml(const SwString& html);
    SwString toHtml() const;

    // --- Modification API (used by SwTextCursor) ---
    void insertBlock(int absPos, const SwTextBlockFormat& blockFmt, const SwTextCharFormat& charFmt);

    void insertBlockDirect(int blockIndex,
                           int offset,
                           const SwTextBlockFormat& blockFmt,
                           const SwTextCharFormat& charFmt);

    void insertText(int absPos, const SwString& text, const SwTextCharFormat& fmt);

    void insertTextDirect(int blockIndex, int offset, const SwString& text, const SwTextCharFormat& fmt);

    void removeTextDirect(int blockIndex, int offset, int count);

    void removeText(int absPos, int count);

    void setCharFormat(int absPos, int count, const SwTextCharFormat& fmt);

    void mergeCharFormat(int absPos, int count, const SwTextCharFormat& fmt);

    void setBlockFormat(int blockIndex, const SwTextBlockFormat& fmt);

    // --- Lists ---
    SwTextList* createList(const SwTextListFormat& fmt);

    int listCount() const;
    SwTextList* listAt(int index) const;

    // --- Tables ---
    SwTextTable* insertTable(int absPos, int rows, int cols, const SwTextTableFormat& fmt = SwTextTableFormat());

    int tableCount() const;
    SwTextTable* tableAt(int index) const;

    // Find table at a given block
    SwTextTable* tableForBlock(int blockIndex) const;

    // --- Image resources ---
    void addResource(const SwString& name, const SwImage& image);

    SwImage resource(const SwString& name) const;

    // --- Document properties ---
    void setPageSize(int widthPt, int heightPt);
    int pageWidth() const;
    int pageHeight() const;

    void setDefaultFont(const SwFont& font);
    SwFont defaultFont() const;

    void setDefaultCharFormat(const SwTextCharFormat& fmt);
    SwTextCharFormat defaultCharFormat() const;

    bool isModified() const;
    void setModified(bool m);

    // --- Undo/Redo support (simplified) ---
    void setUndoRedoEnabled(bool on);
    bool isUndoRedoEnabled() const;

    // --- Clear ---
    void clear();

    // --- Signals ---
    SW_SIGNAL_VOID(contentsChanged)
    SW_SIGNAL(contentsChange, int, int, int)
    SW_SIGNAL_VOID(blockCountChanged)

private:


    void recordBatchChange_(int pos, int removed, int added, int blockHint);

    void renumberBlocks();

    void renumberBlocksFrom(int startIndex);

    void mergeBlockWithNext(int blockIndex);
private:
    // What the class keeps (SwTextDocument_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextDocument — HTML import / export (inline implementations)
// ---------------------------------------------------------------------------


