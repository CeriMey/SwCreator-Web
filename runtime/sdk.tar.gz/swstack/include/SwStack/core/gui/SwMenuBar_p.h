#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwMenuBar.h"

struct SwMenuBar::Data {
    int m_HoverIndex = -1;
    bool m_HoverIndex_registered_ = sw_register_HoverIndex_();
    SwVector<MenuEntry> m_leftMenus;
    SwVector<MenuEntry> m_rightMenus;
    SwVector<SwRect> m_menuRects;
    int m_margin{8};
    int m_spacing{6};
    int m_activeIndex{-1};
};
