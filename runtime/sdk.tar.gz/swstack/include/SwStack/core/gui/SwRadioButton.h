﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwRadioButton.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwRadioButton in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the radio button interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwRadioButton.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwRadioButton - radio button widget.
 *
 * Notes:
 * - Auto-exclusive behaviour is implemented at the parent level (siblings under the same parent).
 **************************************************************************************************/

#include "SwWidget.h"
#include "graphics/SwFontMetrics.h"

class SW_WIDGETS_EXPORT SwRadioButton : public SwWidget {
    SW_OBJECT(SwRadioButton, SwWidget)

public:
    /**
     * @brief Constructs a `SwRadioButton` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwRadioButton(SwWidget* parent = nullptr);

    /**
     * @brief Constructs a `SwRadioButton` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwRadioButton(const SwString& text, SwWidget* parent = nullptr);

    /**
     * @brief Sets the accent Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAccentColor(const SwColor& color);

    /** Indicator and label colours; the defaults are the light theme. */
    struct RadioColors {
        SwColor border{156, 163, 175};
        SwColor fill{255, 255, 255};
        SwColor text{24, 28, 36};
        SwColor hoverBorder{107, 114, 128};
        SwColor hoverFill{250, 252, 255};
        SwColor disabledText{150, 150, 150};
    };
    void setRadioColors(const RadioColors& colors);
    RadioColors radioColors() const;

    /**
     * @brief Returns the current accent Color.
     * @return The current accent Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor accentColor() const;

    /**
     * @brief Sets the auto Exclusive.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAutoExclusive(bool on);
    /**
     * @brief Returns the current auto Exclusive.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool autoExclusive() const;

    /**
     * @brief Sets the checked.
     * @param checked Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setChecked(bool checked);

    /**
     * @brief Returns whether the object reports checked.
     * @return `true` when the object reports checked; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isChecked() const;

    /**
     * @brief Performs the `text` operation.
     * @return The requested text.
     */
    SwString text() const;

    SW_SIGNAL(toggled, bool);
    SW_SIGNAL(clicked, bool);

protected:
    SW_PROPERTY_D(SwString, Text);
private:
protected:

    SW_PROPERTY_D(bool, Pressed);
private:
protected:

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

private:
    static SwColor mixColor_(const SwColor& lhs, const SwColor& rhs, int rhsWeight0To100);

    void initDefaults();

    void uncheckSiblings();

public:
    ~SwRadioButton();
private:
    // What the class keeps (SwRadioButton_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

