/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwPainter.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwPainter in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the painter interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwPainter.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * Platform-agnostic painter interface used by widgets and styles.
 **************************************************************************************************/

#include "Sw.h"
#include "SwString.h"
#include "SwFont.h"

#include <algorithm>
#include <vector>

class SwImage;
class SwPainterPath;

class SW_GUI_EXPORT SwPainter {
public:
    /**
     * @brief Destroys the `SwPainter` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    virtual ~SwPainter();

    /**
     * @brief Clears the current object state.
     * @param color Value passed to the method.
     * @return The requested clear.
     */
    virtual void clear(const SwColor& color) = 0;
    /**
     * @brief Performs the `fillRect` operation.
     * @param rect Rectangle used by the operation.
     * @param fillColor Value passed to the method.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested fill Rect.
     */
    virtual void fillRect(const SwRect& rect,
                          const SwColor& fillColor,
                          const SwColor& borderColor,
                          int borderWidth) = 0;
    /**
     * @brief Performs the `fillRoundedRect` operation.
     * @param rect Rectangle used by the operation.
     * @param radius Value passed to the method.
     * @param fillColor Value passed to the method.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested fill Rounded Rect.
     */
    virtual void fillRoundedRect(const SwRect& rect,
                                 int radius,
                                 const SwColor& fillColor,
                                 const SwColor& borderColor,
                                 int borderWidth) = 0;

    // Per-corner variant: radii are top-left, top-right, bottom-right, bottom-left.
    /**
     * @brief Performs the `fillRoundedRect` operation.
     * @param rect Rectangle used by the operation.
     * @param radiusTL Value passed to the method.
     * @param radiusTR Value passed to the method.
     * @param radiusBR Value passed to the method.
     * @param radiusBL Value passed to the method.
     * @param fillColor Value passed to the method.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested fill Rounded Rect.
     */
    virtual void fillRoundedRect(const SwRect& rect,
                                 int radiusTL, int radiusTR, int radiusBR, int radiusBL,
                                 const SwColor& fillColor,
                                 const SwColor& borderColor,
                                 int borderWidth);

    /**
     * @brief Performs the `drawRect` operation.
     * @param rect Rectangle used by the operation.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested draw Rect.
     */
    virtual void drawRect(const SwRect& rect,
                          const SwColor& borderColor,
                          int borderWidth) = 0;

    // Dashed rectangle outline. Default implementation uses drawLine segments.
    /**
     * @brief Performs the `drawDashedRect` operation.
     * @param rect Rectangle used by the operation.
     * @param color Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @param dashLen Value passed to the method.
     * @param gapLen Value passed to the method.
     * @return The requested draw Dashed Rect.
     */
    virtual void drawDashedRect(const SwRect& rect,
                                const SwColor& color,
                                int borderWidth = 1,
                                int dashLen = 4,
                                int gapLen = 4);

    /**
     * @brief Performs the `drawLine` operation.
     * @param x1 Value passed to the method.
     * @param y1 Value passed to the method.
     * @param x2 Value passed to the method.
     * @param y2 Value passed to the method.
     * @param color Value passed to the method.
     * @param width Width value.
     * @return The requested draw Line.
     */
    virtual void drawLine(int x1,
                          int y1,
                          int x2,
                          int y2,
                          const SwColor& color,
                          int width) = 0;

    /**
     * @brief Draws connected line segments through the points, as one stroke.
     *
     * A curve is one call, not one per segment: a painter that sets up a pen or a device context
     * per line pays that once. The default joins the segments with drawLine().
     */
    virtual void drawPolyline(const SwPoint* points,
                              int count,
                              const SwColor& color,
                              int width);

    /// Strokes a vector path in device coordinates, preserving fractional control points.
    void drawPath(const SwPainterPath& path, const SwColor& color, int width);

    /**
     * @brief Strokes a vector path anti-aliased, @p width device pixels wide, at @p opacity.
     *
     * The width may be fractional; joins and caps are round. @p opacity goes from 0 (nothing drawn)
     * to 1 (opaque) and applies to the stroke as a whole: where the path crosses itself, the pixels
     * are painted once. A painter that cannot draw it natively renders its coverage on the CPU and
     * hands it to drawImage(), so every backend draws it.
     */
    void drawPath(const SwPainterPath& path, const SwColor& color, double width, double opacity);

    /**
     * @brief Fills a vector path anti-aliased, following its fill rule, at @p opacity.
     *
     * Every subpath is closed for the fill. @p opacity goes from 0 (nothing drawn) to 1 (opaque).
     * A painter that cannot fill it natively renders its coverage on the CPU and hands it to
     * drawImage(), so every backend draws it.
     */
    void fillPath(const SwPainterPath& path, const SwColor& color, double opacity = 1.0);

    /**
     * @brief Performs the `fillPolygon` operation.
     * @param points Value passed to the method.
     * @param count Value passed to the method.
     * @param fillColor Value passed to the method.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested fill Polygon.
     */
    virtual void fillPolygon(const SwPoint* points,
                             int count,
                             const SwColor& fillColor,
                             const SwColor& borderColor,
                             int borderWidth);

    /**
     * @brief Performs the `pushClipRect` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested push Clip Rect.
     */
    virtual void pushClipRect(const SwRect& rect);
    /**
     * @brief Returns the current pop Clip Rect.
     * @return The current pop Clip Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual void popClipRect();

    /**
     * @brief Performs the `fillEllipse` operation.
     * @param rect Rectangle used by the operation.
     * @param fillColor Value passed to the method.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested fill Ellipse.
     */
    virtual void fillEllipse(const SwRect& rect,
                             const SwColor& fillColor,
                             const SwColor& borderColor,
                             int borderWidth);

    /**
     * @brief Performs the `drawEllipse` operation.
     * @param rect Rectangle used by the operation.
     * @param borderColor Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested draw Ellipse.
     */
    virtual void drawEllipse(const SwRect& rect,
                             const SwColor& borderColor,
                             int borderWidth);

    // Minimal image hook for the graphics module (ARGB32).
    /**
     * @brief Performs the `drawImage` operation.
     * @param targetRect Value passed to the method.
     * @param image Value passed to the method.
     * @param sourceRect Value passed to the method.
     * @return The requested draw Image.
     */
    virtual void drawImage(const SwRect& targetRect,
                           const SwImage& image,
                           const SwRect* sourceRect = nullptr);

    /**
     * @brief Uploads a tightly packed BGRA32 frame to the native paint target.
     * @param targetRect Destination rectangle in painter coordinates.
     * @param pixels Pointer to the first BGRA pixel.
     * @param width Source width in pixels.
     * @param height Source height in pixels.
     * @param stride Source stride in bytes.
     * @return `true` when the native backend consumed the frame; otherwise `false`.
     */
    virtual bool drawBgra32(const SwRect& targetRect,
                            const uint8_t* pixels,
                            int width,
                            int height,
                            int stride);

    /**
     * @brief Draws a platform-native image when the painter can consume it directly.
     * @param targetRect Destination rectangle in painter coordinates.
     * @param frame Native frame to present.
     * @return `true` when the native backend presented the frame; otherwise `false`.
     */
    virtual bool drawNativeImage(const SwRect& targetRect,
                                 const SwImage& frame);

    /**
     * @brief Performs the `drawText` operation.
     * @param rect Rectangle used by the operation.
     * @param text Value passed to the method.
     * @param alignment Value passed to the method.
     * @param color Value passed to the method.
     * @param font Font value used by the operation.
     * @return The requested draw Text.
     */
    virtual void drawText(const SwRect& rect,
                          const SwString& text,
                          DrawTextFormats alignment,
                          const SwColor& color,
                          const SwFont& font) = 0;

    /**
     * @brief Draws one line of @p text turned by @p angle degrees around @p origin, as QPainter's
     * rotate() followed by drawText(): a positive angle turns clockwise on screen, -90 reads from
     * bottom to top.
     *
     * @p origin is the top-left corner of the line before it turns. A painter that cannot turn text
     * draws it unturned from @p origin.
     */
    void drawRotatedText(const SwPoint& origin,
                         const SwString& text,
                         double angle,
                         const SwColor& color,
                         const SwFont& font);
    /**
     * @brief Returns the current finalize.
     * @return The current finalize.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual void finalize();
    /**
     * @brief Maps a widget-local rectangle to native/device coordinates.
     * @param rect Rectangle used by the operation.
     * @return The mapped rectangle.
     */
    virtual SwRect mapToDevice(const SwRect& rect) const;
    /**
     * @brief Maps a widget-local point to native/device coordinates.
     * @param point Value passed to the method.
     * @return The mapped point.
     */
    virtual SwPoint mapToDevice(const SwPoint& point) const;
    /**
     * @brief Returns the current native Handle.
     * @return The current native Handle.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual void* nativeHandle();

protected:
    // Reserved for the virtual functions a later 1.x adds (docs/BINARY_COMPATIBILITY.md): a class
    // that reimplements it handles its own ids and passes the others to its base.
    virtual void virtual_hook(int id, void* data);
};

class SW_GUI_EXPORT SwOffsetPainter final : public SwPainter {
public:
    SwOffsetPainter(SwPainter* base, int dx, int dy);

    void clear(const SwColor& color) override;

    void fillRect(const SwRect& rect,
                  const SwColor& fillColor,
                  const SwColor& borderColor,
                  int borderWidth) override;

    void fillRoundedRect(const SwRect& rect,
                         int radius,
                         const SwColor& fillColor,
                         const SwColor& borderColor,
                         int borderWidth) override;

    // Forwards the four radii: child widgets keep per-corner rounding (1.x reimplementation).
    void fillRoundedRect(const SwRect& rect,
                         int radiusTL, int radiusTR, int radiusBR, int radiusBL,
                         const SwColor& fillColor,
                         const SwColor& borderColor,
                         int borderWidth) override;

    void drawRect(const SwRect& rect,
                  const SwColor& borderColor,
                  int borderWidth) override;

    void drawDashedRect(const SwRect& rect,
                        const SwColor& color,
                        int borderWidth,
                        int dashLen,
                        int gapLen) override;

    void drawLine(int x1,
                  int y1,
                  int x2,
                  int y2,
                  const SwColor& color,
                  int width) override;

    void drawPolyline(const SwPoint* points,
                      int count,
                      const SwColor& color,
                      int width) override;

    void fillPolygon(const SwPoint* points,
                     int count,
                     const SwColor& fillColor,
                     const SwColor& borderColor,
                     int borderWidth) override;

    void pushClipRect(const SwRect& rect) override;

    void popClipRect() override;

    void fillEllipse(const SwRect& rect,
                     const SwColor& fillColor,
                     const SwColor& borderColor,
                     int borderWidth) override;

    void drawEllipse(const SwRect& rect,
                     const SwColor& borderColor,
                     int borderWidth) override;

    void drawImage(const SwRect& targetRect,
                   const SwImage& image,
                   const SwRect* sourceRect = nullptr) override;

    bool drawBgra32(const SwRect& targetRect,
                    const uint8_t* pixels,
                    int width,
                    int height,
                    int stride) override;

    bool drawNativeImage(const SwRect& targetRect,
                         const SwImage& frame) override;

    void drawText(const SwRect& rect,
                  const SwString& text,
                  DrawTextFormats alignment,
                  const SwColor& color,
                  const SwFont& font) override;

    void finalize() override;

    SwRect mapToDevice(const SwRect& rect) const override;

    SwPoint mapToDevice(const SwPoint& point) const override;

    void* nativeHandle() override;

private:
public:
    ~SwOffsetPainter();
public:
    SwOffsetPainter(const SwOffsetPainter& other);
    SwOffsetPainter& operator=(const SwOffsetPainter& other);
protected:
    void virtual_hook(int id, void* data) override;
private:
    // What the class keeps (SwPainter_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
