
/**
 * @file
 * @ingroup core_gui
 * @brief Declares the filled area series type used by the chart subsystem.
 *
 * `SwAreaSeries` extends the generic series base with properties specific to area plots,
 * such as the baseline, fill color, and border width. Chart views read those settings to
 * render a line series with a filled region down to a configurable reference value.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwAbstractSeries.h"

#include <algorithm>
#include <cmath>

class SW_CHARTS_EXPORT SwAreaSeries : public SwAbstractSeries {
    SW_OBJECT(SwAreaSeries, SwAbstractSeries)

public:
    /**
     * @brief Constructs a `SwAreaSeries` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwAreaSeries(SwObject* parent = nullptr);

    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SeriesType type() const override;

    /**
     * @brief Sets the baseline.
     * @param baseline Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBaseline(double baseline);

    /**
     * @brief Returns the current baseline.
     * @return The current baseline.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double baseline() const;

    /**
     * @brief Sets the fill Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFillColor(const SwColor& color);

    /**
     * @brief Returns whether the object reports fill Color.
     * @return `true` when the object reports fill Color; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasFillColor() const;
    /**
     * @brief Returns the current fill Color.
     * @return The current fill Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor fillColor() const;

    /**
     * @brief Sets the border Width.
     * @param width Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBorderWidth(int width);

    /**
     * @brief Returns the current border Width.
     * @return The current border Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int borderWidth() const;

private:
public:
    ~SwAreaSeries();
private:
    // What the class keeps (SwAreaSeries_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
