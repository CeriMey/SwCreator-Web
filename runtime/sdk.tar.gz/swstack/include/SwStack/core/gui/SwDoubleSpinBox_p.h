#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwDoubleSpinBox.h"

struct SwDoubleSpinBox::Data {
    SwLineEdit* m_edit{nullptr};
    ArrowButton* m_up{nullptr};
    ArrowButton* m_down{nullptr};
    double m_minimum{0.0};
    double m_maximum{100.0};
    double m_value{0.0};
    double m_singleStep{0.1};
    int m_decimals{2};
    int m_arrowWidth{28};
    bool m_internalTextUpdate{false};
    SwColor m_focusAccent{59, 130, 246};
};
