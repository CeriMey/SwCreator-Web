#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwUndoStack.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwUndoStack in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the undo stack interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwUndoStack.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "core/object/SwObject.h"
#include "core/types/Sw.h"
#include "core/types/SwString.h"

#include "SwUndoCommand.h"

#include <vector>

class SW_GUI_EXPORT SwUndoStack : public SwObject {
    SW_OBJECT(SwUndoStack, SwObject)

public:
    /**
     * @brief Constructs a `SwUndoStack` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwUndoStack(SwObject* parent = nullptr);

    /**
     * @brief Destroys the `SwUndoStack` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwUndoStack() override;

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const;
    /**
     * @brief Performs the `index` operation.
     * @param m_index Value passed to the method.
     * @return The requested index.
     */
    int index() const;

    /**
     * @brief Returns whether the object reports undo.
     * @return `true` when the object reports undo; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool canUndo() const;
    /**
     * @brief Returns whether the object reports redo.
     * @return `true` when the object reports redo; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool canRedo() const;

    /**
     * @brief Returns whether the object reports executing.
     * @return `true` when the object reports executing; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isExecuting() const;
    // Zero means unlimited. Trimming changes retained history, never current state.
    // A command larger than the byte budget is applied but is not retained.
    void setUndoLimit(std::size_t commands);
    void setMemoryLimit(std::size_t bytes);
    std::size_t undoLimit() const;
    std::size_t memoryLimit() const;
    std::size_t retainedBytes() const;

    // Keep the next successfully executed pushed command separate from its
    // predecessor, without adding a history entry. Useful for external saves
    // or snapshots whose clean-state tracking lives outside this stack.
    // Successful undo/redo also end the current merge group.
    void breakMerge();

    /**
     * @brief Performs the `push` operation.
     * @param cmd Value passed to the method.
     */
    void push(SwUndoCommand* cmd);

    /**
     * @brief Performs the `undo` operation.
     */
    void undo();

    /**
     * @brief Performs the `redo` operation.
     */
    void redo();

private:
    void truncateRedo_();
    void recountBytes_();
    void enforceLimits_();

    bool tryMergeWithPrevious_(SwUndoCommand* cmd);

private:
    // What the class keeps (SwUndoStack_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
