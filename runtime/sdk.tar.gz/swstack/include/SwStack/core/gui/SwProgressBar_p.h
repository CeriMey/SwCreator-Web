#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwProgressBar.h"

struct SwProgressBar::Data {
    int m_minimum{0};
    int m_maximum{100};
    int m_value{25};
    bool m_textVisible{true};
    SwString m_format{"%p%"};
    Orientation m_orientation{Orientation::Horizontal};
    SwColor m_accent{59, 130, 246};
    SwProgressBar::ProgressColors m_colors;
    SwTimer* m_shimmerTimer{nullptr};
    int m_shimmerPhase{-120};
};
