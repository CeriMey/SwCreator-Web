﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwMenuBar.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwMenuBar in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the menu bar interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwMenuBar.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwMenuBar - menu bar widget.
 *
 * Focus:
 * - Lightweight in-client menu bar (not OS-native).
 * - Works with SwMenu popups + snapshot-based validation.
 **************************************************************************************************/

#include "SwFrame.h"
#include "SwMenu.h"
#include "SwWidgetPlatformAdapter.h"

#include "core/types/SwVector.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwMenuBar : public SwFrame {
    SW_OBJECT(SwMenuBar, SwFrame)

public:
    /**
     * @brief Constructs a `SwMenuBar` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwMenuBar(SwWidget* parent = nullptr);

    /**
     * @brief Adds the specified menu.
     * @param title Title text applied by the operation.
     * @return The requested menu.
     */
    SwMenu* addMenu(const SwString& title);

    /**
     * @brief Adds the specified menu Right.
     * @param title Title text applied by the operation.
     * @return The requested menu Right.
     */
    SwMenu* addMenuRight(const SwString& title);

    /**
     * @brief Performs the `menuCount` operation.
     * @return The requested menu Count.
     */
    int menuCount() const;

    // Width needed to display every menu, independent of the current geometry.
    int preferredWidth() const;

    /**
     * @brief Performs the `menuAt` operation.
     * @param index Value passed to the method.
     * @return The requested menu At.
     */
    SwMenu* menuAt(int index) const;

    /**
     * @brief Performs the `menuRect` operation.
     * @param index Value passed to the method.
     * @return The requested menu Rect.
     */
    SwRect menuRect(int index) const;

    /**
     * @brief Closes the active Menu handled by the object.
     *
     * @details The call affects the runtime state associated with the underlying resource or service.
     */
    void closeActiveMenu();

protected:
    SW_PROPERTY_D(int, HoverIndex);
private:
protected:

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

private:
    struct MenuEntry {
        SwString title;
        SwMenu* menu{nullptr};
    };

    void initDefaults();

    int indexAt(int px, int py) const;

    void updateGeometryCache();

    void openMenu(int index);

    const MenuEntry* entryAt_(int index) const;

    void hookMenuLifecycle_(SwMenu* menu);

public:
    ~SwMenuBar();
private:
    // What the class keeps (SwMenuBar_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

