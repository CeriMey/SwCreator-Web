#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextDiagnostics.h"

struct SwTextDiagnosticsProvider::Data {
    SwTextDocument* m_document;
    SwList<SwTextDiagnostic> m_diagnostics;
    SwTimer* m_reanalysisTimer{nullptr};
    int m_debounceIntervalMs{90};
    int m_maxDiagnostics{256};
    bool m_reanalyzing{false};
    bool m_reanalysisPending{false};
};
