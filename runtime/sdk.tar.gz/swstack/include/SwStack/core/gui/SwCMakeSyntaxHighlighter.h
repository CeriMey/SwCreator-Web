#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwCMakeSyntaxTheme {
    SwTextCharFormat commandFormat;
    SwTextCharFormat keywordFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat variableFormat;
    SwTextCharFormat generatorExprFormat;
    SwTextCharFormat propertyFormat;
};

inline SwTextCharFormat swCMakeMakeFormat_(const SwColor& color,
                                            FontWeight weight = Normal,
                                            bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwCMakeSyntaxTheme swCMakeSyntaxThemeVsCodeDark() {
    SwCMakeSyntaxTheme theme;
    theme.commandFormat       = swCMakeMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.keywordFormat       = swCMakeMakeFormat_(SwColor{197, 134, 192});
    theme.commentFormat       = swCMakeMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat        = swCMakeMakeFormat_(SwColor{206, 145, 120});
    theme.variableFormat      = swCMakeMakeFormat_(SwColor{156, 220, 254});
    theme.generatorExprFormat = swCMakeMakeFormat_(SwColor{78, 201, 176});
    theme.propertyFormat      = swCMakeMakeFormat_(SwColor{79, 193, 255});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwCMakeSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwCMakeSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwCMakeSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwCMakeSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BracketCommentState = 1
    };

    static bool isWordStart_(char ch);

    static bool isWordChar_(char ch);

    static int parseVariable_(const SwString& text, int start);

    static int findBracketCommentEnd_(const SwString& text, int start);

    static bool isCommand_(const SwString& word);

    static bool isKeywordArg_(const SwString& word);

    static bool isProperty_(const SwString& word);

public:
    ~SwCMakeSyntaxHighlighter();
private:
    // What the class keeps (SwCMakeSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
