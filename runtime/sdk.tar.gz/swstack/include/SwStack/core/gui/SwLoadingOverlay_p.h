#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwLoadingOverlay.h"

struct SwLoadingOverlay::Data {
    bool m_Active = false;
    bool m_Active_registered_ = sw_register_Active_();
    bool m_AutoFillParent = true;
    bool m_AutoFillParent_registered_ = sw_register_AutoFillParent_();
    bool m_BlockInput = true;
    bool m_BlockInput_registered_ = sw_register_BlockInput_();
    bool m_ShowBackdrop = true;
    bool m_ShowBackdrop_registered_ = sw_register_ShowBackdrop_();
    bool m_ShowPanel = true;
    bool m_ShowPanel_registered_ = sw_register_ShowPanel_();
    SwString m_Text = "Loading...";
    bool m_Text_registered_ = sw_register_Text_();
    SwString m_OverlayColor = "rgba(7, 11, 19, 0.42)";
    bool m_OverlayColor_registered_ = sw_register_OverlayColor_();
    SwString m_PanelColor = "rgba(15, 23, 42, 0.92)";
    bool m_PanelColor_registered_ = sw_register_PanelColor_();
    SwString m_PanelBorderColor = "rgba(148, 163, 184, 0.28)";
    bool m_PanelBorderColor_registered_ = sw_register_PanelBorderColor_();
    SwString m_PanelShadowColor = "rgba(2, 6, 23, 0.40)";
    bool m_PanelShadowColor_registered_ = sw_register_PanelShadowColor_();
    SwString m_SpinnerColor = "rgb(125, 211, 252)";
    bool m_SpinnerColor_registered_ = sw_register_SpinnerColor_();
    SwString m_SpinnerTrailColor = "rgba(148, 163, 184, 0.18)";
    bool m_SpinnerTrailColor_registered_ = sw_register_SpinnerTrailColor_();
    SwString m_SpinnerGlowColor = "rgba(56, 189, 248, 0.34)";
    bool m_SpinnerGlowColor_registered_ = sw_register_SpinnerGlowColor_();
    SwString m_SpinnerStyle = "segments";
    bool m_SpinnerStyle_registered_ = sw_register_SpinnerStyle_();
    SwString m_TextColor = "rgb(241, 245, 249)";
    bool m_TextColor_registered_ = sw_register_TextColor_();
    int m_SpinnerSize = 68;
    bool m_SpinnerSize_registered_ = sw_register_SpinnerSize_();
    int m_SpinnerThickness = 6;
    bool m_SpinnerThickness_registered_ = sw_register_SpinnerThickness_();
    int m_SegmentCount = 12;
    bool m_SegmentCount_registered_ = sw_register_SegmentCount_();
    int m_SegmentLength = 18;
    bool m_SegmentLength_registered_ = sw_register_SegmentLength_();
    int m_SpinnerSweepDegrees = 220;
    bool m_SpinnerSweepDegrees_registered_ = sw_register_SpinnerSweepDegrees_();
    int m_AnimationInterval = 28;
    bool m_AnimationInterval_registered_ = sw_register_AnimationInterval_();
    int m_AnimationStep = 1;
    bool m_AnimationStep_registered_ = sw_register_AnimationStep_();
    int m_BoxWidth = 178;
    bool m_BoxWidth_registered_ = sw_register_BoxWidth_();
    int m_BoxMinHeight = 154;
    bool m_BoxMinHeight_registered_ = sw_register_BoxMinHeight_();
    int m_BoxPadding = 26;
    bool m_BoxPadding_registered_ = sw_register_BoxPadding_();
    int m_BoxSpacing = 16;
    bool m_BoxSpacing_registered_ = sw_register_BoxSpacing_();
    int m_BoxRadius = 26;
    bool m_BoxRadius_registered_ = sw_register_BoxRadius_();
    SwTimer* m_animationTimer{nullptr};
    int m_animationFrame{0};
    SwPointer<SwWidget> m_observedParent;
    SwPointer<SwWidget> m_previousFocus;
};
