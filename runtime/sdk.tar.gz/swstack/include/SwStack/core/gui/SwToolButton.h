﻿#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwToolButton.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwToolButton in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the tool button interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwToolButton.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAbstractButton.h"
#include "graphics/SwFontMetrics.h"

class SW_WIDGETS_EXPORT SwToolButton : public SwAbstractButton {
    SW_OBJECT(SwToolButton, SwAbstractButton)

public:
    /**
     * @brief Constructs a `SwToolButton` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwToolButton(SwWidget* parent = nullptr);

    /**
     * @brief Constructs a `SwToolButton` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwToolButton(const SwString& text, SwWidget* parent = nullptr);

    SW_SIGNAL(clicked, bool);

protected:
    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    void emitClicked_() override;
    bool toggleBeforeClicked_() const override { return true; }

private:
    void initDefaults();

public:
    ~SwToolButton();
private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};

