﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwComboBox.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwComboBox in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the combo box interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwComboBox.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwComboBox - combo box widget.
 *
 * Focus:
 * - Same core API (addItem, count, currentIndex/currentText, signals).
 * - Premium-ish look with a popup list (usable in snapshot via showPopup()).
 **************************************************************************************************/

#include "SwWidget.h"
#include "core/object/SwPointer.h"
#include "core/types/SwVector.h"


class SW_WIDGETS_EXPORT SwComboBox : public SwWidget {
    SW_OBJECT(SwComboBox, SwWidget)

public:
    /**
     * @brief Constructs a `SwComboBox` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwComboBox(SwWidget* parent = nullptr);

    /**
     * @brief Destroys the `SwComboBox` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwComboBox();

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const;

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Adds the specified item.
     * @param text Value passed to the method.
     */
    void addItem(const SwString& text);

    /**
     * @brief Performs the `insertItem` operation.
     * @param index Value passed to the method.
     * @param text Value passed to the method.
     */
    void insertItem(int index, const SwString& text);

    /**
     * @brief Performs the `itemText` operation.
     * @param index Value passed to the method.
     * @return The requested item Text.
     */
    SwString itemText(int index) const;

    /**
     * @brief Returns the current current Index.
     * @return The current current Index.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int currentIndex() const;

    /**
     * @brief Returns the current current Text.
     * @return The current current Text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString currentText() const;

    /**
     * @brief Sets the current Index.
     * @param index Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCurrentIndex(int index);

    /**
     * @brief Sets the max Visible Items.
     * @param count Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMaxVisibleItems(int count);

    /**
     * @brief Returns the current max Visible Items.
     * @return The current max Visible Items.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int maxVisibleItems() const;

    /**
     * @brief Sets the accent Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAccentColor(const SwColor& color);

    /**
     * @brief Returns the current accent Color.
     * @return The current accent Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor accentColor() const;

    /**
     * @brief Performs the `showPopup` operation.
     * @param true Value passed to the method.
     */
    void showPopup();
    /**
     * @brief Performs the `hidePopup` operation.
     * @param false Value passed to the method.
     */
    void hidePopup();
    /**
     * @brief Returns whether the object reports popup Visible.
     * @return `true` when the object reports popup Visible; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isPopupVisible() const;

    SW_SIGNAL(currentIndexChanged, int);
    SW_SIGNAL(currentTextChanged, SwString);
    SW_SIGNAL(activated, int);
    SW_SIGNAL(highlighted, int);

protected:
    SW_PROPERTY_D(bool, Pressed);
private:
protected:

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;
    void applicationStyleChangeEvent() override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    class PopupList;

    class SW_WIDGETS_EXPORT PopupOverlay : public SwWidget {
        SW_OBJECT(PopupOverlay, SwWidget)

    public:
        /**
         * @brief Constructs a `PopupOverlay` instance.
         * @param owner Value passed to the method.
         * @param root Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @param root Value passed to the method.
         *
         * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
         */
        PopupOverlay(SwComboBox* owner, SwWidget* root, SwWidget* parent = nullptr);

        /**
         * @brief Sets the list.
         * @param list Value passed to the method.
         *
         * @details Call this method to replace the currently stored value with the caller-provided one.
         */
        void setList(PopupList* list);

        /**
         * @brief Handles the mouse Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mousePressEvent(MouseEvent* event) override;

    private:
        static bool containsPoint(const SwRect& r, int px, int py);

        SwComboBox* m_owner{nullptr};
        SwWidget* m_root{nullptr};
        PopupList* m_list{nullptr};
    };

    class SW_WIDGETS_EXPORT PopupList : public SwWidget {
        SW_OBJECT(PopupList, SwWidget)

    public:
        /**
         * @brief Constructs a `PopupList` instance.
         * @param owner Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @param owner Value passed to the method.
         *
         * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
         */
        explicit PopupList(SwComboBox* owner, SwWidget* parent = nullptr);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

        /**
         * @brief Handles the mouse Move Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mouseMoveEvent(MouseEvent* event) override;

        /**
         * @brief Handles the mouse Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mousePressEvent(MouseEvent* event) override;

        /**
         * @brief Handles the wheel Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void wheelEvent(WheelEvent* event) override;

    private:
        int indexAt(int px, int py) const;

        SwComboBox* m_owner{nullptr};
    };

    static int wheelSteps_(int delta);

    static bool tryParseColor_(const StyleSheet* sheet, const SwString& value, SwColor& outColor);

    static SwString getStyleValue_(const StyleSheet* sheet,
                                  const SwList<SwString>& hierarchy,
                                  const char* propertyName);

    static SwWidget* findRootWidget(SwObject* start);

    SwColor resolvedAccentColor_() const;

    int popupVisibleCount_() const;

    void clampPopupFirstIndex_();

    void ensurePopupHighlightVisible_();

    void syncPopupToCurrentIndex_();

    void setPopupHighlightedIndex_(int index);

    void movePopupHighlightBy_(int delta);

    void commitPopupHighlighted_();

    void stepCurrentIndexBy_(int delta);

    int findNextByFirstChar_(char ch, int fromIndex) const;

    void setPopupVisible(bool on);

    void ensurePopup();

    void updatePopupGeometry();

    struct PopupRadii { int tl, tr, br, bl; };

    PopupRadii popupBorderRadii_();

    int popupOffset_();
    int popupMinimumWidth_();

    SwColor popupBorderColor_();

    SwColor resolvedBorderColor_();

    SwColor popupBackgroundColor_();

    int popupBorderWidth_();

    // â”€â”€ Native popup window (Windows) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
#if defined(_WIN32)
    static constexpr const wchar_t* popupClassName_() { return L"SwComboBoxPopup"; }

    static void postGuardedPopupAction_(SwComboBox* comboBox, std::function<void(SwComboBox*)> fn);

    static void ensurePopupClassRegistered_();

    static LRESULT __stdcall popupWndProc_(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

    void nativePopupPaint_(HDC hdc);

    int nativePopupIndexAt_(int y) const;

    void nativePopupMouseMove_(int /*x*/, int y);

    bool openNativePopup_();

    void closeNativePopup_();
#endif

    void initDefaults();

private:
    // What the class keeps (SwComboBox_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
