﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file SwFileDialog.h
 * @ingroup core_gui
 * @brief Declares `SwFileDialog`, a custom modal file-system browser for the Sw GUI toolkit.
 *
 * @details
 * This dialog provides a toolkit-native alternative to operating-system file choosers when the
 * application needs deterministic rendering, snapshot testing, or styling consistency with the rest
 * of the Sw widget set. The implementation combines several responsibilities in a single reusable
 * component:
 * - a navigation toolbar with back, forward, up, home, refresh, and editable path entry,
 * - a sidebar for well-known locations and drive shortcuts,
 * - a custom-painted central file list optimized for toolkit-controlled rendering,
 * - optional filter parsing compatible with common desktop dialog patterns,
 * - platform-aware icon lookup with caching to avoid repeated shell queries.
 *
 * The class keeps the public API intentionally close to conventional desktop file dialogs through
 * `FileMode`, `AcceptMode`, and the static convenience helpers such as `getOpenFileName()`.
 */

#include "SwDialog.h"
#include "SwComboBox.h"
#include "SwLabel.h"
#include "SwLineEdit.h"
#include "SwPushButton.h"
#include "SwScrollBar.h"
#include "SwToolButton.h"
#include "SwTreeWidget.h"

#include "platform/SwPlatformSelector.h"
#include "core/types/SwDateTime.h"
#include "core/types/SwVector.h"

#include "graphics/SwImage.h"

#include <algorithm>
#include <cstring>
#include <cwchar>
#include <string>
#include <unordered_map>


/**
 * @class SwFileDialog
 * @brief Modal file dialog that browses directories and returns a file or directory selection.
 *
 * @details
 * `SwFileDialog` owns its full browsing experience. Rather than delegating to a native dialog, it
 * composes ordinary Sw widgets and a custom list view to provide predictable behavior across
 * platforms. Its internal workflow is organized around these steps:
 * - navigation methods update `m_directory` and optional history stacks,
 * - `refreshEntries()` enumerates directories and files for the active location,
 * - filter expressions are parsed into explicit wildcard patterns,
 * - the custom `FileListView` paints the current directory content and exposes activation signals,
 * - `acceptSelection()` normalizes the final path according to the selected mode.
 *
 * This makes the class suitable for both interactive desktop usage and environments where a fully
 * native dialog would be difficult to theme or capture reliably.
 */
class SW_WIDGETS_EXPORT SwFileDialog : public SwDialog {
    SW_OBJECT(SwFileDialog, SwDialog)

public:
    /**
     * @enum FileMode
     * @brief Describes what kind of selection the dialog is expected to return.
     */
    enum FileMode {
        AnyFile,       ///< Accept any file path, including a path that does not yet exist.
        ExistingFile,  ///< Restrict selection to an existing file.
        Directory,     ///< Restrict selection to a directory.
        ExistingFiles  ///< Reserved for multi-file workflows; the current API still exposes one path.
    };

    /**
     * @enum AcceptMode
     * @brief Controls the user-facing intent of the confirmation action.
     */
    enum AcceptMode {
        AcceptOpen, ///< Dialog confirms an "open" workflow.
        AcceptSave  ///< Dialog confirms a "save" workflow.
    };

    // SystemLanguage keeps the platform locale. Applications with a fixed UI
    // language can override it before constructing their file dialogs.
    enum UiLanguage { SystemLanguage, English, French };
    static void setDefaultUiLanguage(UiLanguage language);
    static UiLanguage defaultUiLanguage();
    void applicationStyleChangeEvent() override;

    /**
     * @brief Constructs the dialog and builds its browsing UI.
     * @param parent Optional parent widget.
     *
     * @details
     * The constructor initializes the non-native widget layout, enables modal behavior, requests a
     * native host window when available, and focuses the file list or path editor when the dialog is
     * shown so keyboard navigation works immediately.
     */
    explicit SwFileDialog(SwWidget* parent = nullptr);

    /** The same cached file-type icon used by the file dialog, for document trees and lists.
     *  Resolves file associations by extension even when the file does not exist yet. */
    static SwImage fileIcon(const SwString& path, bool directory = false, int sizePx = 16);

    /**
     * @brief Navigates the dialog to a new directory without recording a history entry.
     * @param dir Target directory or synthetic location token such as `"Computer"`.
     */
    void setDirectory(const SwString& dir);

    /**
     * @brief Returns the directory currently displayed by the dialog.
     * @return Active browsing location.
     */
    SwString directory() const;

    /**
     * @brief Installs the name-filter expression used to reduce visible files.
     * @param filter Human-readable filter string such as `"Images (*.png *.jpg);;All Files (*)"`.
     *
     * @details
     * The dialog parses the provided string into filter entries and immediately refreshes the file
     * list so only matching file names remain visible for file-selection modes.
     */
    void setNameFilter(const SwString& filter);

    /**
     * @brief Returns the original filter expression configured for the dialog.
     * @return Filter string previously supplied through `setNameFilter()`.
     */
    SwString nameFilter() const;

    /**
     * @brief Changes the semantic type of the selection expected from the user.
     * @param mode New file mode.
     *
     * @details
     * The mode updates labels, button text, and selection validation rules, then refreshes the
     * directory listing so file-only filters can be applied or relaxed as needed.
     */
    void setFileMode(FileMode mode);

    /**
     * @brief Returns the current file mode.
     * @return Active `FileMode` value.
     */
    FileMode fileMode() const;

    /**
     * @brief Changes whether the dialog behaves like an open or save dialog.
     * @param mode New accept mode.
     */
    void setAcceptMode(AcceptMode mode);

    /**
     * @brief Returns the current accept mode.
     * @return Active `AcceptMode` value.
     */
    AcceptMode acceptMode() const;

    /**
     * @brief Preselects a path in the file-name editor.
     * @param file File or directory path to expose as the current selection.
     *
     * @details
     * This method does not force navigation on its own; it updates the selection model and mirrors
     * the provided text into the editable path field when present.
     */
    void selectFile(const SwString& file);

    /**
     * @brief Returns the path currently stored as the dialog result.
     * @return Normalized selection path.
     */
    SwString selectedFile() const;

    /** In a browser, select a local input file or name a downloadable output.
     * Input bytes are copied into the virtual filesystem before returning Accepted.
     * After writing an output, call downloadFile() to deliver it to the computer.
     * Desktop dialogs retain their existing filesystem behavior.
     */
    int exec() override;

    /** Download a completed file from the browser's virtual filesystem.
     * Call only after the writer has closed/committed the file. Each call downloads
     * the current bytes, including subsequent saves of an opened document.
     * On desktop this is a successful no-op. Errors are returned through error.
     */
    static bool downloadFile(const SwString& path, SwString* error = nullptr);

    /**
     * @brief Opens a modal dialog configured for choosing an existing file.
     * @param parent Optional parent widget.
     * @param caption Dialog title.
     * @param dir Initial directory.
     * @param filter Optional name-filter expression.
     * @return Selected file path, or an empty string when cancelled.
     */
    static SwString getOpenFileName(SwWidget* parent,
                                    const SwString& caption = "Open file",
                                    const SwString& dir = SwString(),
                                    const SwString& filter = SwString());

    /**
     * @brief Opens a modal dialog configured for save-style file selection.
     * @param parent Optional parent widget.
     * @param caption Dialog title.
     * @param dir Initial directory.
     * @param filter Optional name-filter expression.
     * @return Selected output path, or an empty string when cancelled.
     */
    static SwString getSaveFileName(SwWidget* parent,
                                    const SwString& caption = "Save file",
                                    const SwString& dir = SwString(),
                                    const SwString& filter = SwString());

    /**
     * @brief Opens a modal dialog restricted to directory selection.
     * @param parent Optional parent widget.
     * @param caption Dialog title.
     * @param dir Initial directory.
     * @return Selected directory path, or an empty string when cancelled.
     */
    static SwString getExistingDirectory(SwWidget* parent,
                                         const SwString& caption = "Select directory",
                                         const SwString& dir = SwString());

protected:
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Recomputes the layout of toolbar, sidebar, list view, and footer controls.
     * @param event Resize event forwarded by the base dialog.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    enum SortKey {
        SortByName = 0,
        SortByType = 1,
        SortByModified = 2,
        SortBySize = 3
    };

    /**
     * @brief Internal representation of one visible row in the browser.
     *
     * @details
     * Each entry contains the display name, resolved path, type information, optional size, and a
     * precomputed icon so the custom list view can paint rows without re-querying the file system.
     */
    struct BrowserEntry {
        SwString name;
        SwString path;
        bool isDir{false};
        bool isDrive{false};
        SwString typeName;
        size_t size{0};
        SwDateTime modifiedAt{static_cast<std::time_t>(0)};
        bool hasModifiedAt{false};
        SwImage icon;
    };

    /**
     * @brief Parsed form of one user-selectable filter combo-box entry.
     *
     * @details
     * The label is the human-readable caption shown to the user, while `patterns` stores the
     * wildcard expressions that `refreshEntries()` applies when listing files.
     */
    struct FilterOption {
        SwString label;
        SwStringList patterns; // ex: "*.png", "*.jpg" (empty => all)
    };

    /**
     * @brief Small cache that resolves platform-specific icons for files, folders, and drives.
     *
     * @details
     * On Windows the cache asks the shell for real icons and memoizes the resulting `SwImage`
     * objects by semantic key. On other platforms it falls back to generated placeholder graphics so
     * the dialog remains usable without native shell integration.
     */
    class SW_WIDGETS_EXPORT SystemIconCache {
    public:
        /**
         * @brief Performs the `iconFor` operation.
         * @param isDir Value passed to the method.
         * @param isDrive Value passed to the method.
         * @param name Value passed to the method.
         * @param path Path used by the operation.
         * @param sizePx Value passed to the method.
         * @return The requested icon For.
         */
        SwImage iconFor(bool isDir,
                        bool isDrive,
                        const SwString& name,
                        const SwString& path,
                        int sizePx);

        /**
         * @brief Clears the current object state.
         */
        void clear();

        // Load the shell icon for the actual path (gives specific icons for Desktop, Documentsâ€¦)
        /**
         * @brief Performs the `iconForActualPath` operation.
         * @param path Path used by the operation.
         * @param sizePx Value passed to the method.
         * @return The requested icon For Actual Path.
         */
        SwImage iconForActualPath(const SwString& path, int sizePx);

        // Load the house icon for the user home folder
        /**
         * @brief Performs the `iconForHome` operation.
         * @param sizePx Value passed to the method.
         * @return The requested icon For Home.
         */
        SwImage iconForHome(int sizePx);

        // Load the icon for "This PC" (Computer)
        /**
         * @brief Performs the `iconForComputer` operation.
         * @param sizePx Value passed to the method.
         * @return The requested icon For Computer.
         */
        SwImage iconForComputer(int sizePx);

    private:
        static SwString cacheKey(bool isDir,
                                 bool isDrive,
                                 const SwString& name,
                                 const SwString& path,
                                 int sizePx);

        static SwString extensionLower(const SwString& name);

#if defined(_WIN32)
        static SwImage loadShellIconForAttributes(const SwString& pseudoPath, DWORD attrs, int sizePx);

        static SwImage loadShellIconForPath(const SwString& path, int sizePx);

        static SwImage iconToImage(HICON icon, int sizePx);
#endif

        static SwImage makeFallbackIcon(bool isDir, int sizePx);

        std::unordered_map<std::string, SwImage> m_cache;
    };

    /**
     * @brief Custom-painted list view used by the dialog to display directory contents.
     *
     * @details
     * The widget owns row selection, hover tracking, wheel scrolling, and double-click activation.
     * It deliberately avoids a heavier general-purpose item view so the file dialog can keep tight
     * control over visuals, sizing, and interactions.
     */
    class SW_WIDGETS_EXPORT FileListView final : public SwWidget {
        SW_OBJECT(FileListView, SwWidget)

    public:
        /**
         * @brief Constructs the list view with default row sizing and scroll-bar wiring.
         * @param parent Optional parent widget.
         */
        explicit FileListView(SwWidget* parent = nullptr);

        /**
         * @brief Replaces the visible row set and resets transient state.
         * @param entries New directory entries to display.
         * @param statusMessage Optional placeholder message shown when no rows are available.
         */
        void setEntries(const SwVector<BrowserEntry>& entries, const SwString& statusMessage = SwString());

        /**
         * @brief Returns the currently selected row index.
         * @return Zero-based row index, or `-1` when nothing is selected.
         */
        int currentIndex() const;

        /**
         * @brief Returns the number of visible entries.
         * @return Entry count currently held by the list.
         */
        int entryCount() const;

        /**
         * @brief Returns the currently selected entry.
         * @return Pointer to the selected entry, or `nullptr` when the selection is invalid.
         */
        const BrowserEntry* currentEntry() const;

        /**
         * @brief Returns the entry stored at a given row index.
         * @param index Row index to inspect.
         * @return Pointer to the entry, or `nullptr` when the index is out of range.
         */
        const BrowserEntry* entryAt(int index) const;

        /**
         * @brief Changes the selected row.
         * @param index Target row index, clamped to the current entry range.
         */
        void setCurrentIndex(int index);

        /**
         * @brief Returns the vertical scroll bar used for the list viewport.
         * @return Internal scroll bar widget.
         */
        SwScrollBar* verticalScrollBar() const;

        /**
         * @brief Returns the horizontal scroll bar used for the list viewport.
         * @return Internal scroll bar widget.
         */
        SwScrollBar* horizontalScrollBar() const;

        /**
         * @brief Sets the pixel size used when painting entry icons.
         * @param px Requested icon size in pixels.
         */
        void setIconSize(int px);

        /**
         * @brief Returns the current icon size.
         * @return Icon size in pixels.
         */
        int iconSize() const;

        /**
         * @brief Updates the header sort indicator shown by the list.
         * @param key Active sort key.
         * @param ascending `true` for ascending order, `false` for descending order.
         */
        void setSortState(SortKey key, bool ascending);

        SW_SIGNAL(currentChanged, int); ///< Emitted when the current row selection changes.
        SW_SIGNAL(activated, int);      ///< Emitted when the user activates a row, typically by double click.
        SW_SIGNAL(sortRequested, int);  ///< Emitted when the user clicks one of the header columns.

    protected:
        /**
         * @brief Handles the resize Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void resizeEvent(ResizeEvent* event) override;

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

        /**
         * @brief Handles the mouse Move Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mouseMoveEvent(MouseEvent* event) override;

        /**
         * @brief Handles the mouse Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mousePressEvent(MouseEvent* event) override;

        /**
         * @brief Handles the mouse Double Click Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mouseDoubleClickEvent(MouseEvent* event) override;

        /**
         * @brief Handles the mouse Release Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mouseReleaseEvent(MouseEvent* event) override;

        /**
         * @brief Handles the wheel Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void wheelEvent(WheelEvent* event) override;

    private:
        struct ColumnLayout {
            int iconX{0};
            SwRect nameCell;
            SwRect typeCell;
            SwRect modifiedCell;
            SwRect sizeCell;
            SwRect nameRect;
            SwRect typeRect;
            SwRect modifiedRect;
            SwRect sizeRect;
        };

        static SwString humanSize(size_t bytes);

        SwRect viewportRect(const SwRect& bounds) const;

        SwRect contentViewportRect(const SwRect& bounds) const;

        SwRect headerViewportRect(const SwRect& bounds) const;

        SwRect bodyViewportRect(const SwRect& bounds) const;

        SwRect dataViewportRect(const SwRect& bounds) const;

        SwRect verticalScrollBarRect(const SwRect& bounds) const;

        SwRect horizontalScrollBarRect(const SwRect& bounds) const;

        int horizontalOffset() const;

        SwRect headerContentRect(const SwRect& headerRect) const;

        int minimumContentWidth() const;

        ColumnLayout columnLayout(const SwRect& row) const;

        SwString modifiedText(const BrowserEntry& entry) const;

        SwString headerText(const SwString& label, SortKey) const;

        SwString headerSortIndicator(SortKey key) const;

        void paintHeader(SwPainter* painter, const SwRect& headerRect);

        int headerSectionAt(int x, int y) const;

        void initDefaults();

        void updateLayout();

        void resetScroll();

        int rowAt(int y) const;

        void ensureCurrentVisible();

        bool hasVisibleScrollBars_() const;

        SwVector<BrowserEntry> m_entries;
        SwString m_statusMessage;
        int m_current{-1};
        int m_hover{-1};
        SwScrollBar* m_vBar{nullptr};
        SwScrollBar* m_hBar{nullptr};
        SwWidget* m_pressedChild{nullptr};
        int m_rowHeight{34};
        int m_iconSize{20};
        int m_contentWidth{0};
        int m_headerHeight{32};
        int m_scrollBarThickness{14};
        SortKey m_sortKey{SortByName};
        bool m_sortAscending{true};
    };

    // â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    void buildUi();

    void buildSidebarItems();

    void updateUiTexts();

    SwString okButtonText() const;

    void acceptSelection();

    static SwString normalizeDirString(SwString dir);

    static bool isWindowsDriveRoot(const SwString& path);

    static SwString parentDirectory(const SwString& path);

    static SwString joinPath(const SwString& dir, const SwString& name);

    void navigateTo(const SwString& dir, bool recordHistory);

    void syncDirEdit();

    void updateNavButtons();

    void goBack();

    void goForward();

    void goUp();

    void goHome();

    void goToPathFromEdit();

    void syncFileNameFromSelection();

    void activateEntry(int idx);

    void rebuildFilterOptions();

    void rebuildActiveFilterPatterns();

    void applySortRequest(SortKey key);

    static bool defaultSortAscending(SortKey key);

    static bool nameLess(const BrowserEntry& a, const BrowserEntry& b, bool ascending = true);

    static SwString extensionLower(const SwString& name);

    static SwString fallbackTypeName(const BrowserEntry& entry);

    static SwString systemTypeName(const BrowserEntry& entry);

    void sortEntries(SwVector<BrowserEntry>& entries) const;

    void populateEntryMetadata(BrowserEntry& entry) const;

    void restoreSelectionByPath(const SwString& path);

    void refreshEntries();

    void listComputerEntries(SwVector<BrowserEntry>& out);

    SwString normalizeSelection(SwString raw) const;

    static bool isAbsolutePath(const SwString& path);

    void updateLayout();

public:
    ~SwFileDialog();
private:
    // What the class keeps (SwFileDialog_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

