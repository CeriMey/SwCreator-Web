#pragma once
// Private implementation; not part of the SwStack API.
#include "SwMarkingMenu.h"
#include "core/object/SwPointer.h"
#include "core/types/SwMap.h"
#include <array>

struct SwMarkingMenu::Data {
    std::array<SwPointer<SwAction>, 8> actions;
    std::array<SwPointer<SwMarkingMenu>, 8> menus;
    SwVector<SwPointer<SwAction>> context;
    SwMap<SwAction *, SwString> shortcuts;
    SwVector<SwPointer<SwAction>> watched;
    SwPointer<SwWidget> root, previousFocus;
    SwPointer<Overlay> overlay;
    SwPointer<Surface> surface;
    SwPointer<SwMarkingMenu> page;
    struct Level {
        SwPointer<SwMarkingMenu> page;
        SwPoint center;
    };
    SwVector<Level> levels;
    std::array<SwRect, 8> buttons;
    SwVector<SwRect> rows;
    SwRect list, back;
    SwPoint center, gestureOrigin;
    SwPointer<SwAction> hovered;
    int hoverDirection{-1};
    bool visible{false}, gesture{false}, moved{false};
    SwColor accent{0, 157, 220};
    Appearance look;
    bool contextOpen{false};
    SwRect hub;
};
