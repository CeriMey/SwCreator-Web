/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 ***************************************************************************************************/

#pragma once

#include "../SwStackExport.h"

#include <algorithm>
#include <cctype>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "Sw.h"
#include "SwMap.h"
#include "SwString.h"

class SW_WIDGETS_EXPORT StyleSheet {
public:
    enum StateFlag {
        StateNone = 0x00,
        StateHovered = 0x01,
        StatePressed = 0x02,
        StateDisabled = 0x04,
        StateFocused = 0x08,
        StateChecked = 0x10
    };

    struct BoxEdges {
        int top{0};
        int right{0};
        int bottom{0};
        int left{0};
    };

    struct Rule {
        SwString selector;
        SwString typeSelector;
        SwString objectName;
        unsigned int stateMask{StateNone};
        int order{0};
        SwMap<SwString, SwString> properties;
    };

    SwMap<SwString, SwMap<SwString, SwString>> styles;

    StyleSheet();

    void clear();

    void mergeFrom(const StyleSheet& other);

    void parseStyleSheet(const SwString& css);

    SwString getStyleProperty(const SwString& selector, const SwString& property) const;

    SwString resolveStyleProperty(const SwList<SwString>& selectors,
                                  const SwString& objectName,
                                  unsigned int stateMask,
                                  const SwString& property) const;

    bool hasExplicitStateProperty(const SwList<SwString>& selectors,
                                  const SwString& objectName,
                                  unsigned int stateMask,
                                  const SwString& property) const;

    SwColor parseColor(const SwString& color, float* alphaOut = nullptr);

    static int parsePixelValue(const SwString& value, int defaultValue);

    static BoxEdges parseBoxEdges(const SwString& value, const BoxEdges& defaults);

    static BoxEdges parseBoxEdges(const SwString& value);

    static FontWeight parseFontWeightValue(const SwString& value, FontWeight fallback);

    static SwString normalizeFontFamily(const SwString& value);

private:
    struct ParsedSelector_ {
        SwString selector;
        SwString typeSelector;
        SwString objectName;
        unsigned int stateMask{StateNone};
    };

    void parseBlock_(const std::string& selectorsText, const std::string& block);

    void appendDecl_(Rule& rule, const std::string& propertyName, const std::string& value);

    static void normalizeDecl_(Rule& rule, const std::string& property, const std::string& value);

    static void borderShorthand_(Rule& rule, const std::string& value);

    static void borderSideShorthand_(Rule& rule, const std::string& property, const std::string& value);

    SwString resolveProperty_(const SwList<SwString>& selectors,
                              const SwString& objectName,
                              unsigned int stateMask,
                              const SwString& property,
                              bool* matchedState) const;

    static bool matches_(const Rule& rule, const std::vector<SwString>& selectors, const SwString& objectName);

    static int specificity_(const Rule& rule, const std::vector<SwString>& selectors);

    static ParsedSelector_ parseSelector_(const std::string& text);

    static std::vector<std::pair<std::string, std::string>> parseDecls_(const std::string& block);

    static void appendDeclChunk_(std::vector<std::pair<std::string, std::string>>& out, const std::string& chunk);

    static size_t findColon_(const std::string& text);

    static std::vector<std::string> splitSelectors_(const std::string& text);

    static std::vector<std::string> splitSpace_(const std::string& text);

    static std::vector<SwString> expandSelectors_(const SwList<SwString>& selectors);

    static void addUnique_(std::vector<SwString>& values, const SwString& value);

    static bool legacyStateAlias_(std::string& property, unsigned int& stateMask);

    static void mergeProps_(Rule& target, const Rule& source);

    static SwString aliasSelector_(const SwString& selector);

    static SwString canonicalSelector_(const SwString& selector);

    static bool looksLikeLength_(const std::string& token);

    static std::string stripComments_(const std::string& input);

    static std::string trim_(const std::string& value);

    static std::string lower_(std::string value);

    static SwColor makeColor(int r, int g, int b);

    SwMap<SwString, SwColor> colorNames;
    std::vector<Rule> rules_;
    int nextOrder_{0};
};
