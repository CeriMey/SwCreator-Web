#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwToolBox.h"

struct SwToolBox::Data {
    SwVector<Item> m_items;
    int m_currentIndex{-1};
    int m_headerHeight{24};
    bool m_exclusive{true};
    bool m_contentBasedLayout{false};
    int m_cachedContentHeight{-1};
    SwString m_headerStyleSheet;
    bool m_headerStyleSheetExplicit{false};
    int m_contentsMargin{8};
    int m_spacing{6};
};
