/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

#include "SwAction.h"
#include "SwWidget.h"
#include "core/types/SwVector.h"
#include "SwFont.h"
#include <functional>

/** Reusable eight-direction marking menu and contextual action list.
 *
 * The model remains owned by parent. Popup surfaces are transient children of the
 * top-level widget; no native window, CAD dependency or external library is used.
 * Coordinates passed to popup/beginGesture/updateGesture/endGesture are relative
 * to that top-level widget. Existing SwAction objects can be shared with toolbars.
 * Connect actions' triggered signals using a receiver to respect its lifetime.
 */
class SW_WIDGETS_EXPORT SwMarkingMenu : public SwWidget {
    SW_OBJECT(SwMarkingMenu, SwWidget)
  public:
    enum Direction { North, NorthEast, East, SouthEast, South, SouthWest, West, NorthWest };
    explicit SwMarkingMenu(SwWidget *parent = nullptr);
    ~SwMarkingMenu() override;

    SwAction *addAction(Direction direction, const SwString &text);
    void setAction(Direction direction, SwAction *action);
    SwAction *action(Direction direction) const;
    SwMarkingMenu *addMenu(Direction direction, const SwString &text);
    SwMarkingMenu *menu(Direction direction) const;
    SwAction *addContextAction(const SwString &text);
    void addContextAction(SwAction *action);
    SwAction *addSeparator();
    SwVector<SwAction *> contextActions() const;
    void setActionShortcut(SwAction *action, const SwString &shortcut);
    void setAccentColor(const SwColor &color);

    /** Optional look of the popup (ABI 1.x addition). Disabled: the historic rectangular
     *  buttons and list. Enabled: pills on an ellipse around a hub, the contextual list in a
     *  rounded panel, opened from the hub when contextOnHub is set. Applies to sub-menus too. */
    struct Appearance {
        bool enabled{false};
        SwColor itemFill{247, 247, 247}, itemBorder{188, 190, 192}, itemText{55, 58, 59};
        SwColor disabledText{174, 177, 179};
        SwColor selectedFill{0, 157, 220}, selectedBorder{0, 157, 220}, selectedText{255, 255, 255};
        SwColor hubFill{255, 255, 255}, hubBorder{0, 157, 220}, hubDots{174, 177, 179};
        SwColor listFill{255, 255, 255}, listBorder{188, 190, 192}, listSelectedFill{204, 218, 235};
        SwColor listText{55, 58, 59}, listShortcut{174, 177, 179};
        SwColor shadow{0, 0, 0};
        double shadowOpacity{.25};
        SwFont font{L"Segoe UI", 9};
        int radiusX{122}, radiusY{92}, itemHeight{34}, hubDiameter{44}, rowHeight{28};
        bool contextOnHub{true};
        // Paints an action's icon in @p rect (the action's own image otherwise).
        std::function<void(SwPainter *, const SwRect &, SwAction *, bool selected)> iconPainter;
    };
    void setAppearance(const Appearance &appearance);
    const Appearance &appearance() const;
    // With contextOnHub: whether the contextual list is open.
    bool isContextListOpen() const;
    void setContextListOpen(bool open);

    void popup(int rootX, int rootY);
    void dismiss();
    bool isPopupVisible() const;
    // A press originating in another widget retains that widget's mouse capture.
    // Forward its subsequent movement/release here to enable marking gestures.
    void beginGesture(int rootX, int rootY);
    void updateGesture(int rootX, int rootY);
    void endGesture(int rootX, int rootY);

    SwMarkingMenu *activeMenu() const;
    SwAction *hoveredAction() const;
    SwPoint popupCenter() const;
    SwRect actionGeometry(Direction direction) const;
    SwRect contextActionGeometry(int index) const;

    SW_SIGNAL_VOID(aboutToShow);
    SW_SIGNAL_VOID(aboutToHide);
    SW_SIGNAL(triggered, SwAction *);

  private:
    class Overlay;
    class Surface;
    struct Data;
    SwObjectDataPointer<Data> d_;
    void watchAction(SwAction *action);
    void layoutPopup(SwPoint center);
    void movePointer(SwPoint rootPoint, bool gesture);
    void activate(SwAction *action);
    void enterMenu(Direction direction, SwPoint rootPoint);
    void goBack();
    void paintPopup(PaintEvent *event);
    void paintStyledPopup(SwPainter *painter);
    void keyInput(KeyEvent *event);
    bool hubPressed(SwPoint rootPoint);
};
