#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwCompleter.h"

struct SwCompleter::Data {
    SwWidget* m_widget{nullptr};
    SwAbstractItemModel* m_sourceModel{nullptr};
    SwSortFilterProxyModel* m_proxyModel{nullptr};
    SwStandardItemModel* m_ownedModel{nullptr};
    SwListView* m_popup{nullptr};
    SwString m_completionPrefix;
    CompletionMode m_completionMode{PopupCompletion};
    ModelSorting m_modelSorting{UnsortedModel};
    Sw::CaseSensitivity m_caseSensitivity{Sw::CaseInsensitive};
    SwItemDataRole m_completionRole{SwItemDataRole::DisplayRole};
    int m_completionColumn{0};
    int m_maxVisibleItems{8};
    bool m_wrapAround{true};
    bool m_popupOwnedByCompleter{false};
};
