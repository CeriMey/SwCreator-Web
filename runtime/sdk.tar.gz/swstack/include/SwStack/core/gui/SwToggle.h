#pragma once
#include "SwToggleSwitch.h"
// Short public name; existing SwToggleSwitch forms and code remain valid.
using SwToggle = SwToggleSwitch;
