﻿#pragma once
#include <functional>

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwTreeView.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwTreeView in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the tree view interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwTreeView.
 *
 * View-oriented declarations here mainly describe how underlying state is projected into a visual
 * or interactive surface, including how refresh, selection, or presentation concerns are exposed
 * at the API boundary.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAbstractItemModel.h"
#include "SwHeaderView.h"
#include "SwItemSelectionModel.h"
#include "SwScrollBar.h"
#include "SwScrollBarPolicy.h"
#include "SwWidget.h"
#include "SwWidgetPlatformAdapter.h"
#include "SwDragDrop.h"

#include "SwList.h"
#include <algorithm>
#include <cstdint>
#include <cstdlib>

class SW_WIDGETS_EXPORT SwTreeView : public SwWidget {
    SW_OBJECT(SwTreeView, SwWidget)

public:
    /**
     * @brief Constructs a `SwTreeView` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwTreeView(SwWidget* parent = nullptr);

    SwSize minimumSizeHint() const override;

    /**
     * @brief Sets the model.
     * @param model Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setModel(SwAbstractItemModel* model);

    /**
     * @brief Returns the current model.
     * @return The current model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwAbstractItemModel* model() const;

    /**
     * @brief Sets the selection Model.
     * @param selectionModel Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSelectionModel(SwItemSelectionModel* selectionModel);

    /**
     * @brief Returns the current selection Model.
     * @return The current selection Model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwItemSelectionModel* selectionModel() const;

    /**
     * @brief Sets the drag Enabled.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDragEnabled(bool on);
    /**
     * @brief Returns the current drag Enabled.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dragEnabled() const;

    /**
     * @brief Sets the accept Drops.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAcceptDrops(bool on);
    /**
     * @brief Returns the current accept Drops.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool acceptDrops() const;

    /**
     * @brief Sets the drop Indicator Shown.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDropIndicatorShown(bool on);
    /**
     * @brief Returns the current drop Indicator Shown.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool dropIndicatorShown() const;

    /**
     * @brief Sets the index Widget.
     * @param index Value passed to the method.
     * @param widget Widget associated with the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIndexWidget(const SwModelIndex& index, SwWidget* widget);

    /**
     * @brief Performs the `indexWidget` operation.
     * @param index Value passed to the method.
     * @return The requested index Widget.
     */
    SwWidget* indexWidget(const SwModelIndex& index) const;

    /**
     * @brief Clears the current object state.
     */
    void clearIndexWidgets();

    /**
     * @brief Sets the icon Size.
     * @param m_iconSize Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIconSize(int px);
    /**
     * @brief Returns the current icon Size.
     * @return The current icon Size.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int  iconSize() const;

signals:
    SW_SIGNAL(clicked, const SwModelIndex&);
    SW_SIGNAL(contextMenuRequested, const SwModelIndex&, int, int);
    SW_SIGNAL(dragStarted, const SwModelIndex&);
    SW_SIGNAL(dragMoved, const SwModelIndex&, int, int);
    SW_SIGNAL(dragDropped, const SwModelIndex&, const SwModelIndex&);

    /**
     * @brief Performs the `expand` operation.
     * @param index Value passed to the method.
     */
    void expand(const SwModelIndex& index);

    /**
     * @brief Performs the `collapse` operation.
     * @param index Value passed to the method.
     */
    void collapse(const SwModelIndex& index);

    /**
     * @brief Returns whether the object reports expanded.
     * @param index Value passed to the method.
     * @return `true` when the object reports expanded; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isExpanded(const SwModelIndex& index) const;

    /**
     * @brief Sets the indentation.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIndentation(int px);

    /**
     * @brief Returns the current indentation.
     * @return The current indentation.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int indentation() const;

    // Override the fixed left padding before item text/icon (default 0 = use built-in toggle area size).
    /**
     * @brief Sets the content Left Pad.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setContentLeftPad(int px);
    /**
     * @brief Returns the current content Left Pad.
     * @return The current content Left Pad.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int contentLeftPad() const;

    /**
     * @brief Sets the row Height.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRowHeight(int px);

    /**
     * @brief Returns the current row Height.
     * @return The current row Height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int rowHeight() const;

    /**
     * @brief Sets the alternating Row Colors.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAlternatingRowColors(bool on);

    /**
     * @brief Returns the current alternating Row Colors.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool alternatingRowColors() const;

    // If false, hide expand arrows even for items with children
    /**
     * @brief Sets the root Is Decorated.
     * @param show Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRootIsDecorated(bool show);
    /**
     * @brief Returns the current root Is Decorated.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool rootIsDecorated() const;

    /**
     * @brief Sets the show Grid.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setShowGrid(bool on);

    /**
     * @brief Returns the current show Grid.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool showGrid() const;

    /**
     * @brief Sets the horizontal Scroll Bar Policy.
     * @param policy Policy value applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHorizontalScrollBarPolicy(SwScrollBarPolicy policy);

    /**
     * @brief Returns the current horizontal Scroll Bar Policy.
     * @return The current horizontal Scroll Bar Policy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBarPolicy horizontalScrollBarPolicy() const;

    /**
     * @brief Sets the vertical Scroll Bar Policy.
     * @param policy Policy value applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setVerticalScrollBarPolicy(SwScrollBarPolicy policy);

    /**
     * @brief Returns the current vertical Scroll Bar Policy.
     * @return The current vertical Scroll Bar Policy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBarPolicy verticalScrollBarPolicy() const;

    /**
     * @brief Sets the header Hidden.
     * @param hidden Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeaderHidden(bool hidden);

    /**
     * @brief Returns whether the object reports header Hidden.
     * @return `true` when the object reports header Hidden; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isHeaderHidden() const;

    /**
     * @brief Sets the header Height.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeaderHeight(int px);

    /**
     * @brief Returns the current header Height.
     * @return The current header Height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int headerHeight() const;

    // Header accessor.
    /**
     * @brief Returns the current header.
     * @return The current header.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwHeaderView* header() const;

    /**
     * @brief Sets the column Width.
     * @param column Value passed to the method.
     * @param px Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnWidth(int column, int px);

    /**
     * @brief Performs the `columnWidth` operation.
     * @param column Value passed to the method.
     * @return The requested column Width.
     */
    int columnWidth(int column) const;

    /**
     * @brief Sets the columns Fit To Width.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnsFitToWidth(bool on);

    /**
     * @brief Performs the `columnsFitToWidth` operation.
     * @return `true` on success; otherwise `false`.
     */
    bool columnsFitToWidth() const;

    /**
     * @brief Sets the column Stretch.
     * @param column Value passed to the method.
     * @param stretch Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnStretch(int column, int stretch);

    /**
     * @brief Performs the `columnStretch` operation.
     * @param column Value passed to the method.
     * @return The requested column Stretch.
     */
    int columnStretch(int column) const;

    /**
     * @brief Sets the column Stretches.
     * @param stretches Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnStretches(const SwList<int>& stretches);

    /**
     * @brief Performs the `resizeColumnToContents` operation.
     * @param column Value passed to the method.
     */
    void resizeColumnToContents(int column);

    /**
     * @brief Performs the `resizeColumnsToContents` operation.
     */
    void resizeColumnsToContents();

    /**
     * @brief Returns the current vertical Scroll Bar.
     * @return The current vertical Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBar* verticalScrollBar() const;
    /**
     * @brief Returns the current horizontal Scroll Bar.
     * @return The current horizontal Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBar* horizontalScrollBar() const;

    // Widget-local hit testing and row geometry, including header and scroll offsets.
    SwModelIndex indexAt(const SwPoint& point) const;
    SwRect visualRect(const SwModelIndex& index) const;

private:

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

private:
    struct VisibleRow {
        SwModelIndex index;
        int depth{0};
        bool hasChildren{false};
    };

    static bool containsPoint(const SwRect& r, int px, int py);

    static bool rectContains(const SwRect& outer, const SwRect& inner);

    static bool rectIntersects(const SwRect& a, const SwRect& b);

    static SwRect rectIntersection(const SwRect& a, const SwRect& b);

    void updateHeaderGeometry_();

    bool hitRowResizeHandle_(int px, int py) const;

    int visibleRowAt_(int px, int py) const;

    int visibleRowIndexForInternalPointer_(void* ptr) const;

    SwModelIndex findIndexForInternalPointer_(void* ptr, int columnHint) const;

    void initDefaults();

    SwRect viewportRect(const SwRect& bounds) const;

    SwRect contentViewportRect(const SwRect& bounds) const;

    void updateLayout();

    void resetScrollBars();

    int columnCount() const;

    int contentHeight() const;

    int contentWidth() const;

    int defaultColumnWidth() const;

    void rebuildVisible();

    void appendVisibleChildren(const SwModelIndex& parent, int depth);

    int indexKey(const SwModelIndex& index) const;

    bool isExpandedInternal(const SwModelIndex& index) const;

    void setExpandedInternal(const SwModelIndex& index, bool on);

    void toggleExpanded(const SwModelIndex& index);

    void paintRows(SwPainter* painter, const SwRect& viewport, int headerH);

    void ensureRowVisible(int row);

    void updateIndexWidgetsGeometry();

    int columnWidthInternal(int column) const;

    int columnsWidth() const;

    int columnStartX(int column) const;

    int columnAtX(int x) const;

    int textWidthPx(const SwString& text, const SwFont& font) const;

    struct IndexWidgetEntry {
        SwModelIndex index;
        SwWidget* widget{nullptr};
        SwSize hint;
    };

    void resetDragDropState_(bool endVisual);

public:
    // ── Theming ─────────────────────────────────────────────────────────
    struct TreeColors {
        SwColor background      {255, 255, 255};
        SwColor backgroundBorder{220, 224, 232};
        SwColor altFill         {249, 249, 249};
        SwColor selFill         {204, 228, 247};
        SwColor selBorder       {  0, 103, 192};
        SwColor hoverFill       {229, 229, 229};
        SwColor text            { 32,  32,  32};
        SwColor toggleStroke    { 96,  96,  96};
        SwColor gridLine        {226, 232, 240};
        int     bgRadius        {12};
        int     selRadius       { 6};
    };

    void setTreeColors(const TreeColors& colors);
    const TreeColors& treeColors() const;

    void setTreeFont(const SwFont& f);

    /** A row as the view lays it out, given to the row painter. */
    struct RowPaint {
        SwModelIndex index;
        SwRect rect;          // the whole row, in view coordinates
        int depth{0};
        int indent{0};        // depth * indentation(), horizontal scroll applied
        bool hasChildren{false};
        bool expanded{false};
        bool selected{false};
        bool hovered{false};
    };
    /** Paints rows instead of the view (highlight, toggle, icon, text) when @p painter returns true
     * for a row; the expand toggle keeps its place and its hit area. An empty function restores the
     * default painting. */
    void setRowPainter(std::function<bool(SwPainter*, const RowPaint&)> painter);

private:
public:
    ~SwTreeView();
private:
    // What the class keeps (SwTreeView_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

