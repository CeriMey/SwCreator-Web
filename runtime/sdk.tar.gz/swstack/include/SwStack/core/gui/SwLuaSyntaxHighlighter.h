#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwLuaSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat builtinFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat constantFormat;
    SwTextCharFormat selfFormat;
};

inline SwTextCharFormat swLuaMakeFormat_(const SwColor& color,
                                          FontWeight weight = Normal,
                                          bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) { format.setFontWeight(weight); }
    if (italic) { format.setFontItalic(true); }
    return format;
}

inline SwLuaSyntaxTheme swLuaSyntaxThemeVsCodeDark() {
    SwLuaSyntaxTheme theme;
    theme.keywordFormat  = swLuaMakeFormat_(SwColor{197, 134, 192}, Medium);
    theme.builtinFormat  = swLuaMakeFormat_(SwColor{220, 220, 170});
    theme.commentFormat  = swLuaMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat   = swLuaMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat   = swLuaMakeFormat_(SwColor{181, 206, 168});
    theme.functionFormat = swLuaMakeFormat_(SwColor{220, 220, 170});
    theme.constantFormat = swLuaMakeFormat_(SwColor{86, 156, 214});
    theme.selfFormat     = swLuaMakeFormat_(SwColor{86, 156, 214}, Normal, true);
    return theme;
}

class SW_CODEEDITOR_EXPORT SwLuaSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwLuaSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwLuaSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwLuaSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        LongCommentState = 1,
        LongStringState = 2
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int longBracketLevel_(const SwString& text, int pos);

    static int findLongBracketEnd_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isConstant_(const SwString& word);

    static bool isBuiltin_(const SwString& word);

public:
    ~SwLuaSyntaxHighlighter();
private:
    // What the class keeps (SwLuaSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
