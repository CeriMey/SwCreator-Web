#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSyntaxHighlighter.h"

struct SwSyntaxHighlighter::Data {
    SwTextDocument* m_document{nullptr};
    int m_currentBlockIndex{-1};
    SwList<SwTextLayoutFormatRange> m_pendingFormats;
    int m_pendingUserState{-1};
    SwTextBlockUserData* m_pendingUserData{nullptr};
    bool m_hasPendingUserState{false};
    bool m_hasPendingUserData{false};
    bool m_rehighlighting{false};
    int m_pendingRehighlightStartBlock{0};
    bool m_hasPendingRehighlight{false};
    bool m_autoRehighlightSuspended{false};
    int m_deferredRehighlightStartBlock{0};
    bool m_hasDeferredRehighlight{false};
};
