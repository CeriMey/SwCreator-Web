#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSplitter.h"

struct SwSplitter::Data {
    bool m_ChildrenCollapsible = false;
    bool m_ChildrenCollapsible_registered_ = sw_register_ChildrenCollapsible_();
    SwVector<SwWidget*> m_widgets;
    SwVector<int> m_collapsibleStates;
    SwVector<int> m_sizes;
    Orientation m_orientation{Orientation::Horizontal};
    int m_handleWidth{10};
    int m_hoverHandle{-1};
    int m_dragHandle{-1};
    int m_dragOffset{0};
    bool m_opaqueResize{true};
    int m_hoverResetTimerId{-1};
    unsigned long long m_hoverResetGeneration{0};
};
