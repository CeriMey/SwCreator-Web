#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwCodeEditor.h"
#include <map>
#include <set>
#include "core/gui/graphics/SwTextLayout_p.h"

struct SwCodeEditor::Data {
    mutable swTextLayout::LineCache m_lineGeometry;
    SwTextDocument* m_document{nullptr};
    SwSyntaxHighlighter* m_highlighter{nullptr};
    SwTextDiagnosticsProvider* m_diagnosticsProvider{nullptr};
    SwCompleter* m_completer{nullptr};
    std::function<SwList<CompletionEntry>(SwCodeEditor*, const SwString&, size_t, bool)> m_completionProvider;
    std::function<SwString(const SwString&, size_t)> m_wordToolTipProvider;
    std::function<bool(const SwString&)> m_completionInsertHandler;
    SwList<SwTextLayoutFormatRange> m_semanticFormats;
    std::map<int, SwList<SwTextLayoutFormatRange>> m_semanticFormatsByBlock;
    SwTimer* m_foldTimer{nullptr};
    SwTimer* m_deferredHighlightTimer{nullptr};
    SwTimer* m_selectionScrollTimer{nullptr};
    SwScrollBar* m_vScrollBar{nullptr};
    SwScrollBar* m_hScrollBar{nullptr};
    bool m_syncingScrollBar{false};
    int m_horizontalScrollPx{0};
    SwList<SwTextDiagnostic> m_diagnostics;
    SwList<SwTextExtraSelection> m_extraSelections;
    SwVector<FoldRegion> m_foldRegions;
    SwVector<int> m_visibleLineIndices;
    SwVector<int> m_visibleRowByLine;
    bool m_identityVisibleLines{true};
    bool m_lineNumbersVisible{true};
    bool m_codeFoldingEnabled{true};
    bool m_highlightCurrentLine{true};
    bool m_syncingToDocument{false};
    bool m_syncingFromDocument{false};
    bool m_ownsDocument{false};
    bool m_autoCompletionEnabled{true};
    bool m_foldDirty{false};
    bool m_suppressFoldRefresh{false};
    mutable bool m_maxLineWidthDirty{true};
    mutable int m_cachedMaxLineWidthPx{0};
    int m_autoCompletionMinPrefixLength{2};
    int m_indentSize{4};
    int m_hoveredFoldStartLine{-1};
    int m_lastKnownLineCount{0};
    mutable int m_cachedCharWidth{0};
    mutable SwFont m_cachedCharWidthFont;
    SwPoint m_lastSelectionMousePos{0, 0};
    SwCodeEditorTheme m_theme{swCodeEditorDefaultTheme()};
    bool m_breakpointMargin{false};
    bool m_lineChangeMargin{false};
    bool m_foldMarkersOnHover{false};
    std::set<int> m_breakpointLines;
    std::map<int, LineChangeKind> m_lineChanges;
    SwColor m_breakpointColor{229, 83, 75};
    SwColor m_addedColor{63, 185, 80};
    SwColor m_modifiedColor{74, 140, 240};
    SwColor m_deletedColor{255, 123, 114};
    int m_hoveredBreakpointLine{-1};
    // The viewport last reported by viewportChanged().
    int m_reportedFirstRow{-1};
    int m_reportedHorizontalScroll{-1};
    int m_reportedRows{-1};
};
