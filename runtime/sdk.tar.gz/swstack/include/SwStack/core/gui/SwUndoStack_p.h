#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwUndoStack.h"

struct SwUndoStack::Data {
    std::vector<SwUndoCommand*> m_stack;
    size_t m_index{0}; // points to next command to redo
    bool m_executing{false};
};
