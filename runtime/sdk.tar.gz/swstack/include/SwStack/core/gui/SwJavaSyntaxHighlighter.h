#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwJavaSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat annotationFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat constantFormat;
};

inline SwTextCharFormat swJavaMakeFormat_(const SwColor& color,
                                           FontWeight weight = Normal,
                                           bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwJavaSyntaxTheme swJavaSyntaxThemeVsCodeDark() {
    SwJavaSyntaxTheme theme;
    theme.keywordFormat    = swJavaMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.typeFormat       = swJavaMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat    = swJavaMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat     = swJavaMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat     = swJavaMakeFormat_(SwColor{181, 206, 168});
    theme.annotationFormat = swJavaMakeFormat_(SwColor{220, 220, 170});
    theme.functionFormat   = swJavaMakeFormat_(SwColor{220, 220, 170});
    theme.constantFormat   = swJavaMakeFormat_(SwColor{79, 193, 255});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwJavaSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwJavaSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwJavaSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwJavaSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BlockCommentState = 1
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int findBlockCommentEnd_(const SwString& text, int start);

    static int parseNumber_(const SwString& text, int start);

    static bool isAllUpperCase_(const SwString& word);

    static bool isKeyword_(const SwString& word);

    static bool isType_(const SwString& word);

public:
    ~SwJavaSyntaxHighlighter();
private:
    // What the class keeps (SwJavaSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
