/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

#include "core/SwStackExport.h"
#include "core/object/SwObject.h"
#include <cstdint>

class SwRemoteObject;
class SwWidget;

/** Serves snapshots of a widget through an asynchronous node RPC and shared memory.
 * Construct the node, widget and publisher on the same GUI thread. The publisher
 * observes their lifetime; it never owns or changes the source widget.
 */
class SW_REMOTEWIDGETS_EXPORT SwRemoteWidgetPublisher : public SwObject {
    SW_OBJECT(SwRemoteWidgetPublisher, SwObject)
public:
    SwRemoteWidgetPublisher(SwRemoteObject* node, SwWidget* source,
                            const SwString& method = "requestPreview", SwObject* parent = nullptr);
    ~SwRemoteWidgetPublisher() override;
    bool isActive() const;

private:
    SwString request_(std::uint32_t clientPid, const SwString& sessionId, int width, int height);
    void pruneSessions_();
    struct Data;
    SwObjectDataPointer<Data> d_;
};
