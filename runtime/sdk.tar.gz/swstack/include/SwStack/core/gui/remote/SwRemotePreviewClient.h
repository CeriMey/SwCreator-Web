/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

#include "core/SwStackExport.h"
#include "core/object/SwObject.h"
#include "core/gui/graphics/SwImage.h"

/** Requests widget snapshots without blocking the calling event loop.
 * All methods must be called on the object's affinity thread. One RPC is in
 * flight at a time; further requests coalesce to the latest requested size.
 */
class SW_REMOTEWIDGETS_EXPORT SwRemotePreviewClient : public SwObject {
    SW_OBJECT(SwRemotePreviewClient, SwObject)
public:
    explicit SwRemotePreviewClient(SwObject* parent = nullptr);
    ~SwRemotePreviewClient() override;

    /** object is the node's fully qualified namespace/name within sys. */
    void setTarget(const SwString& sys, const SwString& object,
                   const SwString& method = "requestPreview");
    void requestFrame(int width, int height);
    /** Cancels pending work and ignores any response already queued. */
    void stop();
    bool isRequestPending() const;
    /** The last completed frame owns its pixels independently of shared memory. */
    const SwImage& frame() const;

signals:
    SW_SIGNAL(frameReady, const SwImage&)
    SW_SIGNAL(errorOccurred, const SwString&)

private:
    void submit_();
    void complete_(unsigned long long generation, int width, int height,
                   bool ok, const SwString& response, const SwString& error);
    struct Data;
    SwObjectDataPointer<Data> d_;
};
