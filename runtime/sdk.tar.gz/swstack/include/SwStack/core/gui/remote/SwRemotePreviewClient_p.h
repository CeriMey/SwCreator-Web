/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

// Private implementation; not part of the public API.
#include "SwRemotePreviewClient.h"
#include "SwRemotePreviewProtocol_p.h"
#include "core/remote/SwIpcRpc.h"

struct SwRemotePreviewClient::Data {
    using Rpc = sw::ipc::RpcMethodClient<SwString, SwString, int, int>;
    std::unique_ptr<Rpc> rpc;
    SwString sys, object, method, sessionId;
    SwImage frame;
    std::uint64_t generation{0}, callId{0};
    int desiredWidth{0}, desiredHeight{0};
    bool pending{false}, queued{false};
};
