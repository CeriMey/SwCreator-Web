/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

// Private wire protocol. Keep native handles and platform headers out of it.
#include "core/remote/SwIpcNoCopyRingBuffer.h"
#include "core/types/SwJsonDocument.h"
#include <limits>

namespace sw { namespace preview {
constexpr std::uint32_t kVersion = 1;
constexpr int kMaxDimension = 4096;
constexpr std::uint32_t kMaxFrameBytes = 64u * 1024u * 1024u;
constexpr std::uint32_t kRingCapacity = 3;
constexpr std::size_t kMaxSessions = 8;
constexpr std::uint64_t kMemoryBudget = 256ull * 1024ull * 1024ull;
constexpr std::uint64_t kSessionTtlMs = 10000;

struct FrameMeta {
    static constexpr const char* kTypeName = "SwRemoteWidgetFrameV1";
    std::uint32_t version{0};
    std::uint32_t width{0}, height{0}, stride{0}, bytes{0};
    std::uint64_t generation{0}, sessionHash{0};
};
using Ring = sw::ipc::NoCopyRingBuffer<FrameMeta>;

inline bool frameLayout(int width, int height, std::uint32_t& stride, std::uint32_t& bytes) {
    if (width <= 0 || height <= 0 || width > kMaxDimension || height > kMaxDimension) return false;
    const std::uint64_t row = static_cast<std::uint64_t>(width) * 4;
    const std::uint64_t total = row * static_cast<std::uint64_t>(height);
    if (total > kMaxFrameBytes) return false;
    stride = static_cast<std::uint32_t>(row);
    bytes = static_cast<std::uint32_t>(total);
    return true;
}
inline std::uint64_t sessionHash(const SwString& id) {
    return sw::ipc::detail::fnv1a64(id.toStdString());
}
inline bool validSessionId(const SwString& id) {
    if (id.isEmpty() || id.size() > 96) return false;
    for (const char ch : id.toStdString()) {
        if (!((ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'Z') ||
              (ch >= 'a' && ch <= 'z') || ch == '-' || ch == '_')) return false;
    }
    return true;
}
inline SwString uint64String(std::uint64_t value) {
    return SwString(std::to_string(value));
}
inline bool parseUint64(const SwJsonValue& value, std::uint64_t& out) {
    if (!value.isString()) return false;
    const std::string text = value.toString().toStdString();
    if (text.empty() || text.size() > 20) return false;
    out = 0;
    for (const char ch : text) {
        if (ch < '0' || ch > '9') return false;
        const unsigned digit = static_cast<unsigned>(ch - '0');
        if (out > ((std::numeric_limits<std::uint64_t>::max)() - digit) / 10) return false;
        out = out * 10 + digit;
    }
    return true;
}
inline bool integerField(const SwJsonObject& object, const char* field, std::uint32_t expected) {
    const SwJsonValue value = object[field];
    return value.isDouble() && value.toDouble(-1) == static_cast<double>(expected);
}

}} // namespace sw::preview
