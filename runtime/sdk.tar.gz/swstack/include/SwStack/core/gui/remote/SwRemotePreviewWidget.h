#pragma once

#include "core/gui/SwWidget.h"
#include "core/gui/graphics/SwImage.h"

/** Displays a widget captured by a SwRemoteWidgetPublisher in another local process.
 * Start/stop and all configuration calls belong to the GUI thread. Each request
 * carries the desired output size; the source widget keeps its own geometry.
 */
class SW_REMOTEWIDGETS_EXPORT SwRemotePreviewWidget : public SwWidget {
    SW_OBJECT(SwRemotePreviewWidget, SwWidget)
public:
    explicit SwRemotePreviewWidget(SwWidget* parent = nullptr);
    ~SwRemotePreviewWidget() override;

    void setTarget(const SwString& sys, const SwString& object,
                   const SwString& method = "requestPreview");
    /** (0, 0) follows this widget's size. Otherwise both dimensions must be positive. */
    void setPreviewSize(int width, int height);
    SwSize previewSize() const;
    /** Requested cadence in milliseconds (50 by default, minimum 16). */
    void setFrameInterval(int milliseconds);
    int frameInterval() const;
    void start();
    void stop();
    bool isActive() const;
    /** Requests one frame, also usable without starting the periodic preview. */
    void requestFrame();
    const SwImage& image() const;

    SW_SIGNAL(frameReady, const SwImage&)
    SW_SIGNAL(errorOccurred, const SwString&)

protected:
    void paintEvent(PaintEvent* event) override;
    void resizeEvent(ResizeEvent* event) override;

private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};
