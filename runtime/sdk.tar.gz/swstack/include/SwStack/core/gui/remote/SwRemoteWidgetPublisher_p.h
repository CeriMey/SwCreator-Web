/* Copyright (c) 2025-2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

// Private implementation; not part of the public API.
#include "SwRemoteWidgetPublisher.h"
#include "SwRemotePreviewProtocol_p.h"
#include "core/remote/SwRemoteObject.h"
#include "core/gui/SwWidget.h"
#include "core/object/SwPointer.h"
#include "core/runtime/SwTimer.h"
#include <array>

struct SwRemoteWidgetPublisher::Data {
    struct Session {
        std::uint32_t clientPid{0};
        SwString id, stream;
        std::uint64_t lastSeen{0}, generation{0};
        std::unique_ptr<sw::preview::Ring> ring;
    };
    SwPointer<SwRemoteObject> node;
    SwPointer<SwWidget> source;
    SwTimer* cleanupTimer{nullptr};
    SwString sys, object, streamPrefix;
    std::size_t rpcToken{0};
    bool capturing{false};
    std::unique_ptr<sw::ipc::Registry> registry;
    std::array<Session, sw::preview::kMaxSessions> sessions;
};
