#pragma once

// Private implementation, not part of the installed API.
#include "SwRemotePreviewWidget.h"
#include "SwRemotePreviewClient.h"
#include "core/runtime/SwTimer.h"

struct SwRemotePreviewWidget::Data {
    SwRemotePreviewClient* client = nullptr;
    SwTimer* timer = nullptr;
    SwImage image;
    SwSize size{0, 0};
    bool active = false;
    bool configured = false;
};
