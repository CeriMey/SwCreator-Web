#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwIcon.h"

// The platform, which the public header no longer shows (SwIcon.h).
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif

struct SwIcon::Data : SwSharedData {
    std::vector<Entry> m_entries;
    SwString m_filePath;
    SwString m_resourceName;
    bool m_exeIcon = false;
};
