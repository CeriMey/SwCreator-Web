/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwValueAxis.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwValueAxis in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the value axis interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwValueAxis.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwValueAxis - minimal numeric axis.
 **************************************************************************************************/

#include "SwObject.h"
#include "SwString.h"

#include <algorithm>
#include <cmath>

class SW_CHARTS_EXPORT SwValueAxis : public SwObject {
    SW_OBJECT(SwValueAxis, SwObject)

public:
    /**
     * @brief Constructs a `SwValueAxis` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwValueAxis(SwObject* parent = nullptr);

    /**
     * @brief Sets the range.
     * @param minimum Value passed to the method.
     * @param maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRange(double minimum, double maximum);

    /**
     * @brief Sets the minimum.
     * @param m_maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMinimum(double minimum);
    /**
     * @brief Sets the maximum.
     * @param maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMaximum(double maximum);

    /**
     * @brief Returns the current min.
     * @return The current min.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double min() const;
    /**
     * @brief Returns the current max.
     * @return The current max.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double max() const;

    /**
     * @brief Sets the auto Range.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAutoRange(bool on);

    /**
     * @brief Returns whether the object reports auto Range.
     * @return `true` when the object reports auto Range; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isAutoRange() const;

    /**
     * @brief Sets the tick Count.
     * @param count Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTickCount(int count);

    /**
     * @brief Returns the current tick Count.
     * @return The current tick Count.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int tickCount() const;

    /**
     * @brief Sets the title Text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTitleText(const SwString& text);

    /**
     * @brief Returns the current title Text.
     * @return The current title Text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString titleText() const;

    /**
     * @brief Performs the `applyNiceNumbers` operation.
     */
    void applyNiceNumbers();

    SW_SIGNAL_VOID(changed);

private:
    static double niceNumber_(double value, bool round);

public:
    ~SwValueAxis();
private:
    // What the class keeps (SwValueAxis_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
