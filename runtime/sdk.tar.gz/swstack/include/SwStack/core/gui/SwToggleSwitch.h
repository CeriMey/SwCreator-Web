/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwToggleSwitch.h
 * @ingroup core_gui
 * @brief iOS / Material-style toggle switch widget.
 *
 * A pill-shaped track with a sliding circular knob. The switch is either ON or OFF.
 * Clicking anywhere on the widget toggles the state.
 *
 * Styleable properties (via SwCheckBox-like stylesheet selectors on "SwToggleSwitch"):
 *   - background-color        : track colour when ON   (default: rgb(76, 154, 230))
 *   - background-color-off    : track colour when OFF  (default: rgb(140, 140, 140))
 *   - color                   : knob colour            (default: white)
 *   - border-color            : track border when ON
 *   - border-color-off        : track border when OFF
 *
 * The widget reports a fixed sizeHint of trackWidth x trackHeight and paints a rounded
 * pill track with a circular knob that snaps left (OFF) or right (ON).
 */

#include "SwWidget.h"

class SW_WIDGETS_EXPORT SwToggleSwitch : public SwWidget {
    SW_OBJECT(SwToggleSwitch, SwWidget)

public:
    explicit SwToggleSwitch(SwWidget* parent = nullptr);

    bool isChecked() const;

    void setChecked(bool on);

    void toggle();

    void setTrackSize(int w, int h);

    int trackWidth() const;
    int trackHeight() const;

    SW_SIGNAL(toggled, bool);

protected:
    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    void mouseReleaseEvent(MouseEvent* event) override;

    void paintEvent(PaintEvent* event) override;

private:
public:
    ~SwToggleSwitch();
private:
    // What the class keeps (SwToggleSwitch_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
