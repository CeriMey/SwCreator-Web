/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once
#include "SwWidget.h"

/** Two-state toggle, with classic or square thumb and three independent icon positions.
 * Icon sources accept PNG/BMP/ICO paths. The checked thumb asset is optional.
 * Radius -1 selects the presentation's default. Colors follow ColorScheme unless
 * UseCustomColors is true. Stylesheets override individual visual settings.
 */
class SW_WIDGETS_EXPORT SwToggleSwitch : public SwWidget {
    SW_OBJECT(SwToggleSwitch, SwWidget)
public:
    explicit SwToggleSwitch(SwWidget* parent = nullptr);
    ~SwToggleSwitch() override;
    void setChecked(bool value);
    bool getChecked() const;
    SW_SIGNAL(CheckedChanged, const bool&);
private:
    static bool sw_register_Checked_();
protected:
    virtual void on_Checked_changed(const bool& value);
    SW_PROPERTY_D(SwString, Appearance);
    SW_PROPERTY_D(SwString, ColorScheme);
    SW_PROPERTY_D(int, TrackWidth);
    SW_PROPERTY_D(int, TrackHeight);
    SW_PROPERTY_D(int, TrackRadius);
    SW_PROPERTY_D(int, ThumbRadius);
    SW_PROPERTY_D(int, ThumbPadding);
    SW_PROPERTY_D(int, BorderWidth);
    SW_PROPERTY_D(int, ReliefDepth);
    SW_PROPERTY_D(int, IconExtent);
    SW_PROPERTY_D(int, AnimationDuration);
    SW_PROPERTY_D(SwString, LeftIconSource);
    SW_PROPERTY_D(SwString, RightIconSource);
    SW_PROPERTY_D(SwString, ThumbIconSource);
    SW_PROPERTY_D(SwString, CheckedThumbIconSource);
    SW_PROPERTY_D(bool, TintIcons);
    SW_PROPERTY_D(bool, UseCustomColors);
    SW_PROPERTY_D(SwColor, OnColor);
    SW_PROPERTY_D(SwColor, OffColor);
    SW_PROPERTY_D(SwColor, ThumbColor);
    SW_PROPERTY_D(SwColor, BorderColor);
    SW_PROPERTY_D(SwColor, HoverColor);
    SW_PROPERTY_D(SwColor, IconColor);
    SW_PROPERTY_D(SwColor, ThumbIconColor);
    SW_PROPERTY_D(SwColor, ShadowColor);
    SW_PROPERTY_D(SwString, OnToolTip);
    SW_PROPERTY_D(SwString, OffToolTip);

public:
    bool isChecked() const;
    void toggle();
    void check();
    void uncheck();
    void setTrackSize(int width, int height);
    int trackWidth() const;
    int trackHeight() const;
    bool isAnimating() const;
    SwSize sizeHint() const override;
    SwSize minimumSizeHint() const override;
    SW_SIGNAL(toggled, bool);
    SW_SIGNAL(clicked, bool);
    SW_SIGNAL_VOID(pressed);
    SW_SIGNAL_VOID(released);
    SW_SIGNAL_VOID(animationFinished);
protected:
    void mousePressEvent(MouseEvent* event) override;
    void mouseReleaseEvent(MouseEvent* event) override;
    void keyPressEvent(KeyEvent* event) override;
    void keyReleaseEvent(KeyEvent* event) override;
    void on_Enable_changed(const bool& enabled) override;
    void on_Focus_changed(const bool& focused) override;
    void on_Hover_changed(const bool& hovered) override;
    void on_StyleSheet_changed(const SwString& style) override;
    void paintEvent(PaintEvent* event) override;
private:
    void visualChanged_();
    void tick_();
    struct Data;
    SwObjectDataPointer<Data> d_;
};
