﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwToolBar.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwToolBar in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the tool bar interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwToolBar.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAction.h"
#include "SwFrame.h"
#include "SwToolButton.h"

#include "core/types/SwVector.h"

#include <algorithm>
#include <functional>

class SW_WIDGETS_EXPORT SwToolBar : public SwFrame {
    SW_OBJECT(SwToolBar, SwFrame)

public:
    /**
     * @brief Constructs a `SwToolBar` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwToolBar(SwWidget* parent = nullptr);

    /**
     * @brief Adds the specified action.
     * @param text Value passed to the method.
     * @param callback Callback invoked by the operation.
     * @return The requested action.
     */
    SwAction* addAction(const SwString& text, const std::function<void()>& callback = {});

    /**
     * @brief Adds the specified action.
     * @param action Value passed to the method.
     */
    void addAction(SwAction* action);

    /**
     * @brief Adds the specified separator.
     */
    void addSeparator();

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

private:
    class SW_WIDGETS_EXPORT Separator final : public SwWidget {
        SW_OBJECT(Separator, SwWidget)

    public:
        /**
         * @brief Performs the `Separator` operation.
         * @param parent Optional parent object that owns this instance.
         * @return The requested separator.
         */
        explicit Separator(SwWidget* parent = nullptr);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;
    };

    struct Item {
        SwAction* action{nullptr};
        SwWidget* widget{nullptr};
        bool separator{false};
    };

    void initDefaults();

    void updateButtonsFromActions();

    void updateLayout();

public:
    ~SwToolBar();
private:
    // What the class keeps (SwToolBar_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

