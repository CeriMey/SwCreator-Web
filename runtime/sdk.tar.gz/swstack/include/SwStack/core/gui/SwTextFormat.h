#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwFont.h"
#include "graphics/SwImage.h"
#include "../types/Sw.h"
#include "../types/SwString.h"
#include "../types/SwList.h"
#include "../types/SwMap.h"
#include "../types/SwAny.h"

#include <string>

// ---------------------------------------------------------------------------
// SwTextCharFormat — character-level formatting (Qt6 QTextCharFormat equivalent)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextCharFormat {
public:
    enum UnderlineStyle {
        NoUnderline,
        SingleUnderline,
        WaveUnderline,
        SpellCheckUnderline
    };

    SwTextCharFormat();

    // --- Font properties ---
    void setFontFamily(const SwString& family);
    SwString fontFamily() const;
    bool hasFontFamily() const;

    void setFontPointSize(int size);
    int fontPointSize() const;
    bool hasFontPointSize() const;

    void setFontWeight(FontWeight w);
    FontWeight fontWeight() const;
    bool hasFontWeight() const;

    void setFontItalic(bool on);
    bool fontItalic() const;
    bool hasFontItalic() const;

    void setFontUnderline(bool on);
    bool fontUnderline() const;
    bool hasFontUnderline() const;

    void setUnderlineStyle(UnderlineStyle style);
    UnderlineStyle underlineStyle() const;
    bool hasUnderlineStyle() const;

    void setUnderlineColor(const SwColor& c);
    SwColor underlineColor() const;
    bool hasUnderlineColor() const;

    void setFontStrikeOut(bool on);
    bool fontStrikeOut() const;
    bool hasFontStrikeOut() const;

    // --- Colors ---
    void setForeground(const SwColor& c);
    SwColor foreground() const;
    bool hasForeground() const;

    void setBackground(const SwColor& c);
    SwColor background() const;
    bool hasBackground() const;

    // --- Link ---
    void setAnchorHref(const SwString& href);
    SwString anchorHref() const;
    bool isAnchor() const;

    void setAnchorName(const SwString& name);
    SwString anchorName() const;

    // --- Vertical alignment ---
    enum VerticalAlignment { AlignNormal, AlignSuperScript, AlignSubScript };
    void setVerticalAlignment(VerticalAlignment a);
    VerticalAlignment verticalAlignment() const;

    // --- Tooltip ---
    void setToolTip(const SwString& tip);
    SwString toolTip() const;

    // --- Custom properties (extensible, like Qt) ---
    void setProperty(int id, const SwAny& value);
    SwAny property(int id) const;

    // --- Build a SwFont from this format ---
    SwFont toFont(const SwFont& base = SwFont()) const;

    // --- Merge another format into this one (only set fields override) ---
    void merge(const SwTextCharFormat& other);

    bool operator==(const SwTextCharFormat& o) const;
    bool operator!=(const SwTextCharFormat& o) const;

private:

public:
    ~SwTextCharFormat();
public:
    SwTextCharFormat(const SwTextCharFormat& other);
    SwTextCharFormat& operator=(const SwTextCharFormat& other);
private:
    // What the class keeps (SwTextFormat_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextBlockFormat — block/paragraph-level formatting (Qt6 QTextBlockFormat)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextBlockFormat {
public:
    SwTextBlockFormat();

    enum Alignment { AlignLeft = 0, AlignCenter = 1, AlignRight = 2, AlignJustify = 3 };

    void setAlignment(Alignment a);
    Alignment alignment() const;

    void setIndent(int level);
    int indent() const;

    void setHeadingLevel(int level); // 0=normal, 1-6
    int headingLevel() const;

    void setTopMargin(int m);
    int topMargin() const;

    void setBottomMargin(int m);
    int bottomMargin() const;

    void setLeftMargin(int m);
    int leftMargin() const;

    void setRightMargin(int m);
    int rightMargin() const;

    void setLineHeight(int h);
    int lineHeight() const;

    void setTextIndent(int px);
    int textIndent() const;

    void setBackground(const SwColor& c);
    SwColor background() const;
    bool hasBackground() const;

    // Page break control (for PDF/print)
    void setPageBreakBefore(bool on);
    bool pageBreakBefore() const;

    void setPageBreakAfter(bool on);
    bool pageBreakAfter() const;

    bool operator==(const SwTextBlockFormat& o) const;
    bool operator!=(const SwTextBlockFormat& o) const;

private:
public:
    ~SwTextBlockFormat();
public:
    SwTextBlockFormat(const SwTextBlockFormat& other);
    SwTextBlockFormat& operator=(const SwTextBlockFormat& other);
private:
    // What the class keeps (SwTextFormat_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextListFormat — list formatting (Qt6 QTextListFormat)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextListFormat {
public:
    SwTextListFormat();

    enum Style {
        ListDisc,           // •
        ListCircle,         // ○
        ListSquare,         // ■
        ListDecimal,        // 1. 2. 3.
        ListLowerAlpha,     // a. b. c.
        ListUpperAlpha,     // A. B. C.
        ListLowerRoman,     // i. ii. iii.
        ListUpperRoman      // I. II. III.
    };

    void setStyle(Style s);
    Style style() const;

    void setIndent(int level);
    int indent() const;

    void setPrefix(const SwString& p);
    SwString prefix() const;

    void setSuffix(const SwString& s);
    SwString suffix() const;

    void setStart(int n);
    int start() const;

    bool isOrdered() const;

    SwString bulletText(int index) const;

private:

    static SwString toRoman(int value, bool upper);
public:
    ~SwTextListFormat();
public:
    SwTextListFormat(const SwTextListFormat& other);
    SwTextListFormat& operator=(const SwTextListFormat& other);
private:
    // What the class keeps (SwTextFormat_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextTableFormat — table formatting (Qt6 QTextTableFormat)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextTableFormat {
public:
    SwTextTableFormat();

    void setBorderWidth(int w);
    int borderWidth() const;

    void setBorderColor(const SwColor& c);
    SwColor borderColor() const;

    void setCellPadding(int p);
    int cellPadding() const;

    void setCellSpacing(int s);
    int cellSpacing() const;

    void setWidth(int w);
    void setWidthPercent(int pct);
    int width() const;
    bool widthIsPercent() const;

    void setAlignment(SwTextBlockFormat::Alignment a);
    SwTextBlockFormat::Alignment alignment() const;

    void setBackground(const SwColor& c);
    SwColor background() const;
    bool hasBackground() const;

    void setColumnWidthConstraints(const SwList<int>& widths);
    SwList<int> columnWidthConstraints() const;

private:
public:
    ~SwTextTableFormat();
public:
    SwTextTableFormat(const SwTextTableFormat& other);
    SwTextTableFormat& operator=(const SwTextTableFormat& other);
private:
    // What the class keeps (SwTextFormat_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextTableCellFormat — table cell formatting (Qt6 QTextTableCellFormat)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextTableCellFormat {
public:
    SwTextTableCellFormat();

    void setBackground(const SwColor& c);
    SwColor background() const;
    bool hasBackground() const;

    void setPadding(int p);
    void setTopPadding(int p);
    void setBottomPadding(int p);
    void setLeftPadding(int p);
    void setRightPadding(int p);
    int topPadding() const;
    int bottomPadding() const;
    int leftPadding() const;
    int rightPadding() const;

    enum VerticalAlignment { AlignTop, AlignMiddle, AlignBottom };
    void setVerticalAlignment(VerticalAlignment a);
    VerticalAlignment verticalAlignment() const;

private:
public:
    ~SwTextTableCellFormat();
public:
    SwTextTableCellFormat(const SwTextTableCellFormat& other);
    SwTextTableCellFormat& operator=(const SwTextTableCellFormat& other);
private:
    // What the class keeps (SwTextFormat_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextImageFormat — inline image formatting (Qt6 QTextImageFormat)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextImageFormat {
public:
    SwTextImageFormat();

    void setName(const SwString& name);
    SwString name() const;

    void setWidth(int w);
    int width() const;

    void setHeight(int h);
    int height() const;

    void setImage(const SwImage& img);
    SwImage image() const;
    bool hasImage() const;

private:
public:
    ~SwTextImageFormat();
public:
    SwTextImageFormat(const SwTextImageFormat& other);
    SwTextImageFormat& operator=(const SwTextImageFormat& other);
private:
    // What the class keeps (SwTextFormat_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
