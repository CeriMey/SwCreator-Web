#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwListView.h"

struct SwListView::Data {
    SwAbstractItemModel* m_model{nullptr};
    SwItemSelectionModel* m_selectionModel{nullptr};
    SwStyledItemDelegate* m_delegate{nullptr};
    SwScrollBar* m_vBar{nullptr};
    SwScrollBarPolicy m_vPolicy{SwScrollBarPolicy::ScrollBarAsNeeded};
    SwVector<IndexWidgetEntry> m_indexWidgets;
    ViewMode m_viewMode{ViewMode::ListMode};
    SwSize m_gridSize{72, 72};
    int m_spacing{6};
    int m_viewportPadding{6};
    int m_rowHeight{34};
    int m_scrollBarThickness{14};
    bool m_uniformRowHeights{true};
    mutable bool m_rowMetricsValid{false};
    mutable SwVector<int> m_rowOffsets; // prefix sums: size = rows + 1
    mutable int m_contentHeight{0};
    bool m_alternating{false};
    int m_hoverRow{-1};
    bool m_dragEnabled{false};
    bool m_acceptDrops{false};
    bool m_dropIndicatorShown{false};
    bool m_pressed{false};
    bool m_dragging{false};
    int m_pressX{0};
    int m_pressY{0};
    SwModelIndex m_pressIndex;
    SwModelIndex m_dragIndex;
    SwModelIndex m_dropIndex;
    int m_dropRow{-1};
};
