#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTabWidget.h"

struct SwTabWidget::Data {
    bool m_TabsClosable = false;
    bool m_TabsClosable_registered_ = sw_register_TabsClosable_();
    bool m_Movable = false;
    bool m_Movable_registered_ = sw_register_Movable_();
    SwVector<Tab> m_tabs;
    int m_currentIndex{-1};
    int m_hoverIndex{-1};
    int m_pressedIndex{-1};
    int m_closeHoverIndex{-1};
    int m_closePressedIndex{-1};
    int m_pressX{0};
    int m_pressY{0};
    int m_dragIndex{-1};
    bool m_dragging{false};
    TabPosition m_tabPosition{TabPosition::Top};
    TabStyle m_tabStyle{TabStyle::Underline};
    bool m_tabsFillSpace{true};
    bool m_tabBarFullBleed{true};
    SwColor m_surfaceColor{255, 255, 255};
    SwColor m_borderColor{226, 232, 240};
    SwColor m_tabBarColor{243, 244, 246};
    float m_tabBarAlpha{1.0f};
    SwColor m_accentColor{59, 130, 246};
    SwColor m_textColor{17, 24, 39};
    SwColor m_mutedTextColor{107, 114, 128};
    SwColor m_shadowColor1{226, 230, 238};
    SwColor m_shadowColor2{214, 219, 230};
    int m_frameTopBorderWidth{0};
    int m_frameRightBorderWidth{0};
    int m_frameBottomBorderWidth{0};
    int m_frameLeftBorderWidth{0};
    SwColor m_frameTopBorderColor{226, 232, 240};
    SwColor m_frameRightBorderColor{226, 232, 240};
    SwColor m_frameBottomBorderColor{226, 232, 240};
    SwColor m_frameLeftBorderColor{226, 232, 240};
    int m_outerPadding{0};
    int m_pagePadding{0};
    int m_tabToContentGap{0};
    int m_cornerRadius{0};
    int m_tabBarRadius{0};
    int m_tabItemRadius{6};
    int m_indicatorThickness{3};
    int m_indicatorPadding{0};
    int m_tabBarHeight{25}; // horizontal
    int m_tabBarWidth{180}; // vertical
    int m_barPadding{0};
    int m_tabPaddingX{12};
    int m_tabTextIndent{10};
    int m_tabSpacing{0};
    int m_tabItemHeight{24};
    int m_minTabWidth{68};
    int m_minTabHeight{24};
    bool m_usesScrollButtons{true};
    bool m_scrollButtonsVisible{false};
    int m_tabScrollOffset{0};
    int m_tabScrollMax{0};
    SwRect m_tabViewportRect{0, 0, 0, 0};
    SwRect m_scrollPrevRect{0, 0, 0, 0};
    SwRect m_scrollNextRect{0, 0, 0, 0};
    bool m_scrollPrevHovered{false};
    bool m_scrollNextHovered{false};
    bool m_scrollPrevPressed{false};
    bool m_scrollNextPressed{false};
};
