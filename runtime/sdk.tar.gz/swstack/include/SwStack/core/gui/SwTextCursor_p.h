#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextCursor.h"

struct SwTextCursor::Data : SwSharedData {
    SwTextDocument* m_document;
    int m_position;
    int m_anchor;
    SwTextCharFormat m_charFormat;
    SwTextBlockFormat m_blockFormat;
};
