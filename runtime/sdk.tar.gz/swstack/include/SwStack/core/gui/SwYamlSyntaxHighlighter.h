#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwYamlSyntaxTheme {
    SwTextCharFormat keyFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat boolNullFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat anchorFormat;
    SwTextCharFormat tagFormat;
    SwTextCharFormat separatorFormat;
};

inline SwTextCharFormat swYamlMakeFormat_(const SwColor& color,
                                           FontWeight weight = Normal,
                                           bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwYamlSyntaxTheme swYamlSyntaxThemeVsCodeDark() {
    SwYamlSyntaxTheme theme;
    theme.keyFormat       = swYamlMakeFormat_(SwColor{156, 220, 254});
    theme.stringFormat    = swYamlMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat    = swYamlMakeFormat_(SwColor{181, 206, 168});
    theme.boolNullFormat  = swYamlMakeFormat_(SwColor{86, 156, 214});
    theme.commentFormat   = swYamlMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.anchorFormat    = swYamlMakeFormat_(SwColor{78, 201, 176});
    theme.tagFormat       = swYamlMakeFormat_(SwColor{78, 201, 176});
    theme.separatorFormat = swYamlMakeFormat_(SwColor{197, 134, 192});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwYamlSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwYamlSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwYamlSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwYamlSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    static bool isAnchorChar_(char ch);

    static int findClosingQuote_(const SwString& text, int start, char quote);

    static bool isKeyStart_(const SwString& text, int pos);

    void highlightValue_(const SwString& text, int start);

    static bool isBoolOrNull_(const SwString& value);

    static bool isNumber_(const SwString& value);

public:
    ~SwYamlSyntaxHighlighter();
private:
    // What the class keeps (SwYamlSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
