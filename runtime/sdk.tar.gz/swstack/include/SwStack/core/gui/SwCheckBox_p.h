#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwCheckBox.h"

struct SwCheckBox::Data {
    SwString m_Text = "CheckBox";
    bool m_Text_registered_ = sw_register_Text_();
    bool m_Pressed = false;
    bool m_Pressed_registered_ = sw_register_Pressed_();
    CheckState m_state{Unchecked};
    bool m_tristate{false};
    SwColor m_accent{0, 120, 215};
    int m_indicatorSize{18};
    int m_textSpacing{10};
};
