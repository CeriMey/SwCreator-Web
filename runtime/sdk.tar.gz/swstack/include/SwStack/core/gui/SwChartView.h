﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwChartView.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwChartView in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the chart view interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwChartView.
 *
 * View-oriented declarations here mainly describe how underlying state is projected into a visual
 * or interactive surface, including how refresh, selection, or presentation concerns are exposed
 * at the API boundary.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAreaSeries.h"
#include "SwBarSeries.h"
#include "SwCandlestickSeries.h"
#include "SwChart.h"
#include "SwFont.h"
#include "SwPainter.h"
#include "SwPieSeries.h"
#include "SwScatterSeries.h"
#include "SwStepLineSeries.h"
#include "SwSplineSeries.h"
#include "SwWidget.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <limits>
#include <string>
#include <utility>
#include <vector>

class SW_CHARTS_EXPORT SwChartView : public SwWidget {
    SW_OBJECT(SwChartView, SwWidget)

public:
    /**
     * @brief Constructs a `SwChartView` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwChartView(SwWidget* parent = nullptr);

    /**
     * @brief Returns the current chart.
     * @return The current chart.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwChart* chart() const;

    /**
     * @brief Sets the chart.
     * @param chart Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setChart(SwChart* chart);

    /**
     * @brief Returns whether the object reports mouse Zoom Enabled.
     * @return `true` when the object reports mouse Zoom Enabled; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isMouseZoomEnabled() const;
    /**
     * @brief Sets the enable Mouse Zoom.
     * @param enable Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEnableMouseZoom(bool enable);

    /**
     * @brief Returns whether the object reports mouse Pan Enabled.
     * @return `true` when the object reports mouse Pan Enabled; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isMousePanEnabled() const;
    /**
     * @brief Sets the enable Mouse Pan.
     * @param enable Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEnableMousePan(bool enable);

    /**
     * @brief Sets the enable Play Mode.
     * @param enable Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEnablePlayMode(bool enable);
    /**
     * @brief Returns whether the object reports play Mode Enabled.
     * @return `true` when the object reports play Mode Enabled; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isPlayModeEnabled() const;

    // Convenience wrappers.
    /**
     * @brief Sets the title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTitle(const SwString& title);

    /**
     * @brief Adds the specified series.
     * @param serie Value passed to the method.
     */
    void addSeries(SwAbstractSeries* serie);

    /**
     * @brief Removes the specified series.
     * @param serie Value passed to the method.
     */
    void removeSeries(SwAbstractSeries* serie);

    /**
     * @brief Creates the requested default Axes.
     */
    void createDefaultAxes();

    /**
     * @brief Performs the `centerView` operation.
     */
    void centerView();

    /**
     * @brief Sets the xRange.
     * @param start Value passed to the method.
     * @param end Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setXRange(double start, double end);

    /**
     * @brief Sets the yRange.
     * @param start Value passed to the method.
     * @param end Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setYRange(double start, double end);

    /**
     * @brief Performs the `zoomIn` operation.
     */
    void zoomIn();
    /**
     * @brief Performs the `zoomOut` operation.
     */
    void zoomOut();

protected:
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Double Click Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseDoubleClickEvent(MouseEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

private:
    void onChartChanged_();

    static bool pointInRect_(int px, int py, const SwRect& r);

    SwRect plotRect_() const;

    SwRect pieRect_() const;

    bool hasTitle_() const;

    int legendHeight_() const;

    int effectiveTickCount_(SwValueAxis* axis) const;

    SwColor resolveColor_(const std::string& property, const SwColor& fallback);

    int resolveInt_(const std::string& property, int fallback);

    void computeRanges_(double& xMin, double& xMax, double& yMin, double& yMax) const;

    void drawGrid_(SwPainter* painter, const SwRect& plot, int xTicks, int yTicks, const SwColor& gridColor) const;

    void drawAxes_(SwPainter* painter, const SwRect& plot, const SwColor& axisColor) const;

    void drawAxisLabels_(SwPainter* painter,
                         const SwRect& plot,
                         double xMin,
                         double xMax,
                         double yMin,
                         double yMax,
                         int xTicks,
                         int yTicks,
                         const SwColor& textColor) const;

    void drawTitle_(SwPainter* painter, const SwRect& bounds, const SwColor& textColor) const;

    void drawLegend_(SwPainter* painter, const SwRect& bounds, const SwColor& textColor) const;

    void drawSeries_(SwPainter* painter,
                     const SwRect& plot,
                     double xMin,
                     double xMax,
                     double yMin,
                     double yMax) const;

    void applyPlayMode_();

    double lastVisibleX_() const;

    bool shouldRenderPie_() const;

    static SwColor lighten_(const SwColor& c, double amount);

    static SwColor darken_(const SwColor& c, double amount);

    static double clampBaseline_(double baseline, double yMin, double yMax);

    static double autoBandWidthFromXs_(std::vector<double> xs, double fallbackSpan);

    static double autoBandWidthFromPoints_(const SwVector<SwPointF>& pts, double fallbackSpan);

    static void drawBars_(SwPainter* painter,
                          const SwRect& plot,
                          double xMin,
                          double xMax,
                          double yMin,
                          double yMax,
                          const SwVector<SwPointF>& pts,
                          double widthX,
                          double baseline,
                          const SwColor& fill);

    static void drawArea_(SwPainter* painter,
                          const SwRect& plot,
                          double xMin,
                          double xMax,
                          double yMin,
                          double yMax,
                          const SwVector<SwPointF>& pts,
                          double baseline,
                          const SwColor& fill,
                          const SwColor& stroke,
                          int strokeWidth);

    static void drawStepLine_(SwPainter* painter,
                              const SwRect& plot,
                              double xMin,
                              double xMax,
                              double yMin,
                              double yMax,
                              const SwVector<SwPointF>& pts,
                              const SwColor& color,
                              int width);

    static void drawSpline_(SwPainter* painter,
                            const SwRect& plot,
                            double xMin,
                            double xMax,
                            double yMin,
                            double yMax,
                            const SwVector<SwPointF>& pts,
                            const SwColor& color,
                            int width);

    static void drawCandlesticks_(SwPainter* painter,
                                  const SwRect& plot,
                                  double xMin,
                                  double xMax,
                                  double yMin,
                                  double yMax,
                                  const SwCandlestickSeries& series);

    void drawPie_(SwPainter* painter, const SwRect& rect, const SwColor& background, const SwColor& textColor) const;

    void panByPixels_(int dx, int dy, const SwRect& plot);

    void zoom_(double factor);

    void zoomAt_(double factor, int anchorX, int anchorY, const SwRect& plot);

public:
    ~SwChartView();
private:
    // What the class keeps (SwChartView_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

