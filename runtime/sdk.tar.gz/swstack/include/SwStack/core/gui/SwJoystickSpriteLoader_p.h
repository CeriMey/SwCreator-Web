#pragma once

#include "core/gui/SwJoystick.h"
#include "core/gui/graphics/SwImage.h"
#include "core/gui/assets/SwJoystickSprites_p.h"

#include <cstdint>
#include <vector>

namespace sw_joystick_sprites {

inline SwImage decode(const char* const* chunks) {
    if (!chunks) return SwImage();
    std::vector<std::uint8_t> bytes;
    std::uint32_t chunk = 0;
    int bits = 0;
    for (const char* const* text = chunks; *text; ++text) {
        for (const unsigned char* p = reinterpret_cast<const unsigned char*>(*text); *p; ++p) {
            const unsigned char c = *p;
            int value = -1;
            if (c >= 'A' && c <= 'Z') value = c - 'A';
            else if (c >= 'a' && c <= 'z') value = c - 'a' + 26;
            else if (c >= '0' && c <= '9') value = c - '0' + 52;
            else if (c == '+') value = 62;
            else if (c == '/') value = 63;
            else if (c == '=') break;
            if (value < 0) continue;
            chunk = (chunk << 6) | static_cast<std::uint32_t>(value);
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                bytes.push_back(static_cast<std::uint8_t>((chunk >> bits) & 255u));
            }
        }
    }
    return bytes.empty() ? SwImage() : SwImage::fromData(bytes.data(), bytes.size());
}

inline const SwImage& image(SwJoystick::Type type) {
    switch (type) {
    case SwJoystick::Type::Gamepad: {
        static const SwImage sprite = decode(kGamepadCap);
        return sprite;
    }
    case SwJoystick::Type::FlightStick: {
        static const SwImage sprite = decode(kFlightGrip);
        return sprite;
    }
    case SwJoystick::Type::Arcade: {
        static const SwImage sprite = decode(kArcadeBall);
        return sprite;
    }
    }
    static const SwImage empty;
    return empty;
}

inline const SwImage& socketImage(SwJoystick::Type type) {
    switch (type) {
    case SwJoystick::Type::Gamepad: {
        static const SwImage empty;
        return empty;
    }
    case SwJoystick::Type::FlightStick: {
        static const SwImage sprite = decode(kFlightSocket);
        return sprite;
    }
    case SwJoystick::Type::Arcade: {
        static const SwImage sprite = decode(kArcadeSocket);
        return sprite;
    }
    }
    static const SwImage empty;
    return empty;
}

inline SwRect socketSourceRect(SwJoystick::Type type) {
    switch (type) {
    case SwJoystick::Type::Gamepad: return SwRect{0, 0, 0, 0};
    case SwJoystick::Type::FlightStick: return SwRect{250, 370, 755, 600};
    case SwJoystick::Type::Arcade: return SwRect{390, 510, 475, 275};
    }
    return SwRect{0, 0, 0, 0};
}

inline SwRect sourceRect(SwJoystick::Type type) {
    switch (type) {
    case SwJoystick::Type::Gamepad: return SwRect{94, 91, 1066, 1062};
    case SwJoystick::Type::FlightStick: return SwRect{215, 0, 620, 1536};
    case SwJoystick::Type::Arcade: return SwRect{190, 40, 645, 1020};
    }
    return SwRect{0, 0, 0, 0};
}

} // namespace sw_joystick_sprites
