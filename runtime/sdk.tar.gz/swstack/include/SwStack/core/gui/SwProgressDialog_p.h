#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwProgressDialog.h"

struct SwProgressDialog::Data {
    int m_min{0};
    int m_max{100};
    int m_value{0};
    bool m_canceled{false};
    SwLabel* m_label{nullptr};
    SwProgressBar* m_progressBar{nullptr};
    SwPushButton* m_cancelBtn{nullptr};
};
