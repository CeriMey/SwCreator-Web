#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwPathDialog.h
 * @ingroup core_gui
 * @brief Declares `SwPathDialog`, a thin directory picker facade that normalizes paths for Sw.
 */

#include "SwDir.h"
#include "SwFileDialog.h"

class SW_WIDGETS_EXPORT SwPathDialog {
public:
    static SwString normalizePath(SwString path);

    static SwString getExistingDirectory(SwWidget* parent,
                                         const SwString& caption = "Select directory",
                                         const SwString& dir = SwString());

private:
    static void stripWindowsExtendedPrefix_(SwString& path);
};
