/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwAction.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwAction in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the action interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwAction.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwAction - action object.
 *
 * Goal:
 * - Reusable action model for menus, toolbars, shortcuts, etc.
 * - Lightweight, signal-based, and Sw*-friendly types.
 **************************************************************************************************/

#include "core/object/SwObject.h"
#include "core/types/SwString.h"

#include "graphics/SwImage.h"

class SwMenu;

class SW_GUI_EXPORT SwAction : public SwObject {
    SW_OBJECT(SwAction, SwObject)

    SW_PROPERTY_D(SwString, Text);
private:
protected:
    SW_PROPERTY_D(bool, Enabled);
private:
protected:
    SW_PROPERTY_D(bool, Checkable);
private:
protected:
    SW_PROPERTY_D(bool, Checked);
private:
protected:
    SW_PROPERTY_D(bool, Separator);
private:
protected:

public:
    /**
     * @brief Constructs a `SwAction` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwAction(const SwString& text = SwString(), SwObject* parent = nullptr);

    /**
     * @brief Sets the icon.
     * @param icon Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIcon(const SwImage& icon);

    /**
     * @brief Returns the current icon.
     * @return The current icon.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwImage& icon() const;
    /**
     * @brief Returns whether the object reports icon.
     * @return `true` when the object reports icon; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool hasIcon() const;

    /**
     * @brief Sets the menu.
     * @param menu Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMenu(SwMenu* menu);

    /**
     * @brief Returns the current menu.
     * @return The current menu.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwMenu* menu() const;
    /**
     * @brief Returns whether the object reports menu.
     * @return `true` when the object reports menu; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasMenu() const;

    /**
     * @brief Performs the `trigger` operation.
     */
    void trigger();

signals:
    SW_SIGNAL(triggered, bool);
    SW_SIGNAL_VOID(changed);

private:
public:
    ~SwAction();
private:
    // What the class keeps (SwAction_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
