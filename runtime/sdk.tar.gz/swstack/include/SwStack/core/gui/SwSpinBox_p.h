#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSpinBox.h"

struct SwSpinBox::Data {
    SwLineEdit* m_edit{nullptr};
    ArrowButton* m_up{nullptr};
    ArrowButton* m_down{nullptr};
    int m_minimum{0};
    int m_maximum{99};
    int m_value{0};
    int m_singleStep{1};
    int m_arrowWidth{28};
    bool m_internalTextUpdate{false};
    SwColor m_focusAccent{59, 130, 246};
};
