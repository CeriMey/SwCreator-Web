#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwToggleSwitch.h"

struct SwToggleSwitch::Data {
    bool m_checked = false;
    int m_trackW = 44;
    int m_trackH = 24;
};
