#pragma once
// Private implementation; not a public API.
#include "SwToggleSwitch.h"
#include "SwTimer.h"
#include <chrono>
#include <map>
struct SwToggleSwitch::Data {
    bool m_Checked{false};
    bool registered_Checked = sw_register_Checked_();
    SwString m_Appearance{"Switch"};
    bool registered_Appearance = sw_register_Appearance_();
    SwString m_ColorScheme{"Light"};
    bool registered_ColorScheme = sw_register_ColorScheme_();
    int m_TrackWidth{44};
    bool registered_TrackWidth = sw_register_TrackWidth_();
    int m_TrackHeight{24};
    bool registered_TrackHeight = sw_register_TrackHeight_();
    int m_TrackRadius{-1};
    bool registered_TrackRadius = sw_register_TrackRadius_();
    int m_ThumbRadius{-1};
    bool registered_ThumbRadius = sw_register_ThumbRadius_();
    int m_ThumbPadding{2};
    bool registered_ThumbPadding = sw_register_ThumbPadding_();
    int m_BorderWidth{1};
    bool registered_BorderWidth = sw_register_BorderWidth_();
    int m_ReliefDepth{0};
    bool registered_ReliefDepth = sw_register_ReliefDepth_();
    int m_IconExtent{18};
    bool registered_IconExtent = sw_register_IconExtent_();
    int m_AnimationDuration{160};
    bool registered_AnimationDuration = sw_register_AnimationDuration_();
    SwString m_LeftIconSource{""};
    bool registered_LeftIconSource = sw_register_LeftIconSource_();
    SwString m_RightIconSource{""};
    bool registered_RightIconSource = sw_register_RightIconSource_();
    SwString m_ThumbIconSource{""};
    bool registered_ThumbIconSource = sw_register_ThumbIconSource_();
    SwString m_CheckedThumbIconSource{""};
    bool registered_CheckedThumbIconSource = sw_register_CheckedThumbIconSource_();
    bool m_TintIcons{true};
    bool registered_TintIcons = sw_register_TintIcons_();
    bool m_UseCustomColors{false};
    bool registered_UseCustomColors = sw_register_UseCustomColors_();
    SwColor m_OnColor{76,154,230};
    bool registered_OnColor = sw_register_OnColor_();
    SwColor m_OffColor{90,100,108};
    bool registered_OffColor = sw_register_OffColor_();
    SwColor m_ThumbColor{255,255,255};
    bool registered_ThumbColor = sw_register_ThumbColor_();
    SwColor m_BorderColor{70,80,86};
    bool registered_BorderColor = sw_register_BorderColor_();
    SwColor m_HoverColor{114,180,240};
    bool registered_HoverColor = sw_register_HoverColor_();
    SwColor m_IconColor{100,116,139};
    bool registered_IconColor = sw_register_IconColor_();
    SwColor m_ThumbIconColor{67,83,125};
    bool registered_ThumbIconColor = sw_register_ThumbIconColor_();
    SwColor m_ShadowColor{15,23,42};
    bool registered_ShadowColor = sw_register_ShadowColor_();
    SwString m_OnToolTip{""};
    bool registered_OnToolTip = sw_register_OnToolTip_();
    SwString m_OffToolTip{""};
    bool registered_OffToolTip = sw_register_OffToolTip_();
    SwTimer* timer{nullptr};
    double position{0}, start{0}, target{0};
    std::chrono::steady_clock::time_point started;
    bool down{false}, keyboard{false};
    int key{0};
    std::map<std::string, SwImage> images;
};
