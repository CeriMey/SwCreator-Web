#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextDocument.h"
#include "SwTextDocumentLayout.h"
#include "SwPdfWriter.h"

#include <fstream>

// ---------------------------------------------------------------------------
// SwTextDocumentWriter — high-level document export (PDF, HTML, plain text)
//
// Usage:
//   SwTextDocumentWriter writer;
//   writer.writePdf(document, "output.pdf");
//   writer.writeHtml(document, "output.html");
//   writer.writePlainText(document, "output.txt");
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextDocumentWriter {
public:
    SwTextDocumentWriter();

    // --- Page setup (for PDF) ---
    void setPageSize(int widthPt, int heightPt);

    void setPageSizeA4();
    void setPageSizeLetter();

    void setMargins(int top, int right, int bottom, int left);

    void setDefaultFont(const SwFont& font);

    // --- PDF export ---
    bool writePdf(SwTextDocument* doc, const SwString& filename);

    // --- HTML export ---
    bool writeHtml(SwTextDocument* doc, const SwString& filename);

    // --- Plain text export ---
    bool writePlainText(SwTextDocument* doc, const SwString& filename);

    // --- Static convenience ---
    static bool exportToPdf(SwTextDocument* doc, const SwString& filename,
                            const SwFont& font = SwFont());

    static bool exportToHtml(SwTextDocument* doc, const SwString& filename);

private:

    void renderPageToPdf(SwTextDocument* doc, SwTextDocumentLayout& layout,
                         SwPdfWriter& pdf, int page);

    void renderTableToPdf(SwTextTable* tbl, const SwRect& blockRect, SwPdfWriter& pdf);

    // Helvetica glyph widths (per 1000 units, standard AFM data)
    static int helveticaCharWidth(unsigned char ch);

    static int courierCharWidth(unsigned char /*ch*/);

    static int timesCharWidth(unsigned char ch);

    int measureText(const SwString& text, int fontSize, const std::string& fontName = "Helvetica") const;

    int estimateTextWidth(const SwString& text, int fontSize) const;

    int estimateFragWidth(const SwTextFragment& frag, int fontSize) const;

    int estimateBlockWidth(const SwTextBlock& block) const;
public:
    ~SwTextDocumentWriter();
public:
    SwTextDocumentWriter(const SwTextDocumentWriter& other);
    SwTextDocumentWriter& operator=(const SwTextDocumentWriter& other);
private:
    // What the class keeps (SwTextDocumentWriter_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
