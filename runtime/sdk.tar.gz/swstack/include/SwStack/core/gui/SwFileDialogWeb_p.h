// Browser implementation of SwFileDialog. Local files never leave the browser.
#pragma once

#include <emscripten.h>

EM_JS_DEPS(swFileDialogWebDeps, "$stringToNewUTF8,$UTF8ToString,$FS");

EM_JS(int, sw_file_dialog_web_begin,
      (int save, const char* captionPtr, const char* initialPtr, const char* filterPtr, int french), {
    const state = Module["swFileDialogs"] ||= {next: 0, pending: new Map()};
    const token = ++state.next;
    const request = {ready: false, path: ""};
    state.pending.set(token, request);
    const text = (en, fr) => french ? fr : en;
    // Avoid raw backslashes in regex literals: EM_JS stringification follows C escaping.
    const leaf = value => value.split(String.fromCharCode(92)).join("/").split("/").pop();
    const forbidden = String.fromCharCode(47, 92, 58, 60, 62, 34, 124, 63, 42);
    const safeName = value => Array.from(value.trim(), character =>
        character.charCodeAt(0) < 32 || forbidden.includes(character) ? "_" : character).join("");
    const filter = UTF8ToString(filterPtr);
    const extensions = [...new Set((filter.match(/[*][.][a-zA-Z0-9.]+/g) || []).map(v => v.slice(1)))];
    const directory = "/tmp/swstack-files/" + token;
    const previousFocus = document.activeElement;
    const panel = document.createElement("dialog");
    panel.className = "swstack-file-dialog";
    panel.style.cssText = "box-sizing:border-box;width:min(480px,calc(100vw - 32px));padding:24px;border:1px solid #65708a;border-radius:12px;background:#181d28;color:#f1f4fb;font:14px system-ui,sans-serif;box-shadow:0 16px 80px #0008;";
    const heading = document.createElement("h2");
    heading.style.cssText = "margin:0 0 16px;font-size:18px;";
    heading.textContent = UTF8ToString(captionPtr);
    const description = document.createElement("p");
    description.style.cssText = "line-height:1.5;color:#b8c5dc;";
    description.textContent = save
        ? text("The file will be downloaded to your computer. Choose its location in your browser's download settings.",
               "Le fichier sera téléchargé sur votre ordinateur. Son emplacement dépend des réglages de téléchargement du navigateur.")
        : text("Choose a file on your computer.", "Choisissez un fichier sur votre ordinateur.");
    const form = document.createElement("form");
    const label = document.createElement("label");
    label.textContent = save ? text("File name", "Nom du fichier") : text("Local file", "Fichier local");
    const input = document.createElement("input");
    input.type = save ? "text" : "file";
    input.required = true;
    input.style.cssText = "box-sizing:border-box;display:block;width:100%;margin:10px 0 20px;padding:10px;border:1px solid #65708a;border-radius:6px;background:#10141d;color:#f1f4fb;font:inherit;";
    if (save) {
        input.value = leaf(UTF8ToString(initialPtr)) || ("document" + (extensions[0] || ""));
    } else {
        // A wildcard option means unrestricted input. The application validates contents.
        const unrestricted = (filter.match(new RegExp("[(][^)]*[)]", "g")) || []).some(group =>
            ["*", "*.*"].includes(group.slice(1, -1).trim()));
        if (!unrestricted) input.accept = extensions.join(",");
    }
    label.append(input);
    const message = document.createElement("p");
    message.setAttribute("role", "alert");
    const actions = document.createElement("div");
    actions.style.cssText = "display:flex;gap:12px;justify-content:flex-end;";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = text("Cancel", "Annuler");
    const confirm = document.createElement("button");
    confirm.type = "submit";
    confirm.textContent = save ? text("Download", "Télécharger") : text("Open", "Ouvrir");
    for (const button of [cancel, confirm])
        button.style.cssText = "padding:10px 16px;border:1px solid #65708a;border-radius:6px;background:#253149;color:#fff;font:inherit;cursor:pointer;";
    confirm.style.background = "#2f6bff";
    const finish = path => {
        if (request.ready) return;
        request.path = path;
        request.ready = true;
        panel.close();
        panel.remove();
        if (previousFocus?.isConnected) previousFocus.focus();
    };
    cancel.onclick = () => finish("");
    panel.addEventListener("cancel", event => { event.preventDefault(); finish(""); });
    // Do not let Escape/Enter propagate to the application under the modal.
    panel.addEventListener("keydown", event => event.stopPropagation());
    let reading = false;
    form.onsubmit = async event => {
        event.preventDefault();
        if (reading || request.ready) return;
        message.textContent = "";
        try {
            if (save) {
                let name = safeName(input.value);
                if (!name || name === "." || name === "..") {
                    message.textContent = text("Enter a file name.", "Saisissez un nom de fichier.");
                    return;
                }
                if (!name.includes(".") && extensions.length) name += extensions[0];
                FS.mkdirTree(directory);
                finish(directory + "/" + name);
            } else {
                const file = input.files[0];
                if (!file) return;
                reading = true;
                confirm.disabled = true;
                const bytes = new Uint8Array(await file.arrayBuffer());
                // Cancellation during an asynchronous read must not resurrect the dialog.
                if (request.ready) return;
                FS.mkdirTree(directory);
                const name = safeName(file.name);
                if (!name || name === "." || name === "..") throw new Error(text("Invalid file name.", "Nom de fichier invalide."));
                const path = directory + "/" + name;
                FS.writeFile(path, bytes);
                finish(path);
            }
        } catch (error) {
            if (!request.ready) message.textContent = String(error.message || error);
        } finally {
            reading = false;
            confirm.disabled = false;
        }
    };
    actions.append(cancel, confirm);
    form.append(label, message, actions);
    panel.append(heading, description, form);
    document.body.append(panel);
    panel.showModal();
    input.focus();
    if (save) input.select();
    return token;
});

EM_JS(int, sw_file_dialog_web_ready, (int token), {
    return Module["swFileDialogs"].pending.get(token).ready ? 1 : 0;
});

EM_JS(char*, sw_file_dialog_web_take, (int token), {
    const state = Module["swFileDialogs"];
    const path = state.pending.get(token).path;
    state.pending.delete(token);
    return path ? stringToNewUTF8(path) : 0;
});

EM_JS(char*, sw_file_dialog_web_download, (const char* pathPtr), {
    let url;
    let link;
    try {
        const path = UTF8ToString(pathPtr);
        // Snapshot after the writer closes, so later saves cannot alter this download.
        const bytes = FS.readFile(path);
        url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
        link = document.createElement("a");
        link.href = url;
        link.download = path.split("/").pop();
        link.hidden = true;
        document.body.append(link);
        link.click();
        link.remove();
        // Keep the object URL alive until the browser has consumed it.
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        return 0;
    } catch (error) {
        if (link) link.remove();
        if (url) URL.revokeObjectURL(url);
        return stringToNewUTF8(String(error.message || error));
    }
});
