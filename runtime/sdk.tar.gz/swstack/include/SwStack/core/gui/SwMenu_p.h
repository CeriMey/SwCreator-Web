#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwMenu.h"

struct SwMenu::Data {
    SwVector<SwAction*> m_actions;
    SwPointer<SwWidget> m_root;
    SwPointer<PopupOverlay> m_overlay;
    SwPointer<PopupList> m_popup;
    bool m_ownsOverlay{true};
    bool m_rootResizeHooked{false};
    SwPointer<SwMenu> m_openSubMenu;
    int m_openSubMenuIndex{-1};
    bool m_hoverCloseEnabled{false};
    SwRect m_hoverKeepAliveRect;
    SwTimer* m_hoverCloseTimer{nullptr};
    int m_lastMouseX{0};
    int m_lastMouseY{0};
};
