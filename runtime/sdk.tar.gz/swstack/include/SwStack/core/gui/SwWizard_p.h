#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwWizard.h"

struct SwWizard::Data {
    SwVector<SwWizardPage*> m_pages;
    int m_currentIndex{0};
    StepperWidget* m_stepper{nullptr};
    SwWidget* m_separator{nullptr};
    SwLabel* m_titleLabel{nullptr};
    SwLabel* m_subTitleLabel{nullptr};
    SwStackedWidget* m_stack{nullptr};
    SwPushButton* m_backBtn{nullptr};
    SwPushButton* m_nextBtn{nullptr};
    SwPushButton* m_finishBtn{nullptr};
    SwPushButton* m_cancelBtn{nullptr};
};
struct SwWizardPage::Data {
    SwString m_title;
    SwString m_subTitle;
};
