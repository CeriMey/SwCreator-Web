#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwXmlSyntaxTheme {
    SwTextCharFormat tagFormat;
    SwTextCharFormat attributeFormat;
    SwTextCharFormat valueFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat cdataFormat;
    SwTextCharFormat entityFormat;
    SwTextCharFormat doctypeFormat;
    SwTextCharFormat piFormat;
};

inline SwTextCharFormat swXmlMakeFormat_(const SwColor& color,
                                          FontWeight weight = Normal,
                                          bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwXmlSyntaxTheme swXmlSyntaxThemeVsCodeDark() {
    SwXmlSyntaxTheme theme;
    theme.tagFormat       = swXmlMakeFormat_(SwColor{86, 156, 214});
    theme.attributeFormat = swXmlMakeFormat_(SwColor{156, 220, 254});
    theme.valueFormat     = swXmlMakeFormat_(SwColor{206, 145, 120});
    theme.commentFormat   = swXmlMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.cdataFormat     = swXmlMakeFormat_(SwColor{181, 206, 168});
    theme.entityFormat    = swXmlMakeFormat_(SwColor{78, 201, 176});
    theme.doctypeFormat   = swXmlMakeFormat_(SwColor{197, 134, 192});
    theme.piFormat        = swXmlMakeFormat_(SwColor{197, 134, 192});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwXmlSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwXmlSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwXmlSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwXmlSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        CommentState = 1,
        TagState = 2,
        CDataState = 3
    };

    static bool isTagNameChar_(char ch);

    int highlightInsideTag_(const SwString& text, int start);

    static int findCommentEnd_(const SwString& text, int start);

    static int findCDataEnd_(const SwString& text, int start);

public:
    ~SwXmlSyntaxHighlighter();
private:
    // What the class keeps (SwXmlSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
