﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwJoystick.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwJoystick in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the joystick interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwJoystick.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * Virtual joystick widget built on SwWidget.
 *
 * Provides normalized tilt vectors in the [-1, 1] range. Positive Y points down, in widget
 * coordinates. The stick returns to center on mouse release. Arrow keys move it in 0.1 steps;
 * Home and Escape center it. The Type property changes its physical design and travel geometry.
 * Repeat modes can continuously emit control commands while the stick is displaced.
 **************************************************************************************************/

#include "SwWidget.h"
#include "SwPainter.h"
#include "SwTimer.h"

#include <algorithm>
#include <cmath>

class SW_WIDGETS_EXPORT SwJoystick : public SwWidget {
    SW_OBJECT(SwJoystick, SwWidget)

public:
    /** Visual family of the control. More families can be added without changing its output. */
    enum class Type {
        Gamepad,
        FlightStick,
        Arcade
    };

    /** Selects the complete housing, gate and handle design. Default: Gamepad. */
    SW_PROPERTY_D(Type, Type);

    /**
     * Pivot-to-grip height in millimetres (to the ball centre for Arcade).
     * Each type has a fixed lateral gate
     * travel; inclination is asin(tip travel / StickHeight). A taller stick
     * therefore makes a smaller angle at the same lateral position.
     * Defaults: 12 mm (gamepad), 180 mm (flight stick), 70 mm (arcade).
     */
    SW_PROPERTY_D(float, StickHeight);

public:
    enum class RepeatMode {
        ValueChangedOnly,
        RepeatIfNotZero,
        Repeat
    };

    /**
     * @brief Constructs a `SwJoystick` instance.
     * @param parent Optional parent object that owns this instance.
     * @param false Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwJoystick(SwWidget* parent = nullptr);

    /**
     * @brief Sets the repeat Mode.
     * @param mode Mode value that controls the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRepeatMode(RepeatMode mode);

    /**
     * @brief Returns the current repeat Mode.
     * @return The current repeat Mode.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    RepeatMode repeatMode() const;

    /**
     * @brief Sets the repeat Interval.
     * @param intervalMs Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRepeatInterval(int intervalMs);

    /**
     * @brief Returns the current repeat Interval.
     * @return The current repeat Interval.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int repeatInterval() const;

    /**
     * @brief Returns the current horizontal Value.
     * @return The current horizontal Value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float horizontalValue() const;
    /**
     * @brief Returns the current vertical Value.
     * @return The current vertical Value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float verticalValue() const;

    /**
     * @brief Returns the current magnitude.
     * @return The current magnitude.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float magnitude() const;

    /**
     * @brief Returns the current angle Degrees.
     * @return The current angle Degrees.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    float angleDegrees() const;

    /** Physical inclination away from the centre axis, in degrees. */
    float inclinationDegrees() const;

    /** Lateral distance of the grip from its neutral position, in millimetres. */
    float tipDistance() const;

    SW_SIGNAL(moved, float, float);
    SW_SIGNAL(directionChanged, float, float);

protected:
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    void keyPressEvent(KeyEvent* event) override;

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    int travelRadius() const;

    void resetStick(bool notify);

    void setTilt(float x, float y);

    void emitIfNeeded(bool forced);

    void updateRepeatTimerState();

public:
    ~SwJoystick();
private:
    // What the class keeps (SwJoystick_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

