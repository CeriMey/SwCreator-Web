/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwStandardItemModel.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwStandardItemModel in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the standard item model interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwStandardItem and SwStandardItemModel.
 *
 * Model-oriented declarations here define the data contract consumed by views, delegates, or
 * algorithms, with an emphasis on stable roles, ownership, and update flow rather than on
 * presentation details.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwStandardItemModel - standard item model.
 *
 * Minimal implementation to back SwTreeView / SwTableView.
 **************************************************************************************************/

#include "SwAbstractItemModel.h"
#include "graphics/SwImage.h"

#include "SwList.h"
#include "SwString.h"

class SwStandardItemModel;

class SW_GUI_EXPORT SwStandardItem {
public:
    /**
     * @brief Constructs a `SwStandardItem` instance.
     * @param text Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwStandardItem(const SwString& text = SwString());

    /**
     * @brief Destroys the `SwStandardItem` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwStandardItem();

    /**
     * @brief Constructs a `SwStandardItem` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwStandardItem(const SwStandardItem&) = delete;
    /**
     * @brief Performs the `operator=` operation.
     * @return The requested operator =.
     */
    SwStandardItem& operator=(const SwStandardItem&) = delete;

    /**
     * @brief Sets the text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setText(const SwString& text);
    /**
     * @brief Returns the current text.
     * @return The current text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString text() const;

    void setEditText(const SwString& text);

    SwString editText() const;

    bool hasEditText() const;

    /**
     * @brief Sets the tool Tip.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setToolTip(const SwString& text);
    /**
     * @brief Returns the current tool Tip.
     * @return The current tool Tip.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString toolTip() const;

    /**
     * @brief Sets the editable.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEditable(bool on);
    /**
     * @brief Returns whether the object reports editable.
     * @return `true` when the object reports editable; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isEditable() const;

    /**
     * @brief Sets the icon.
     * @param icon Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIcon(const SwImage& icon);
    /**
     * @brief Returns the current icon.
     * @return The current icon.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwImage icon() const;

    /**
     * @brief Returns the current parent.
     * @return The current parent.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStandardItem* parent() const;

    /**
     * @brief Returns the current row.
     * @return The current row.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int row() const;
    /**
     * @brief Returns the current column.
     * @return The current column.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int column() const;

    /**
     * @brief Performs the `rowCount` operation.
     * @return The requested row Count.
     */
    int rowCount() const;

    /**
     * @brief Returns the current column Count.
     * @return The current column Count.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int columnCount() const;

    /**
     * @brief Performs the `child` operation.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @return The requested child.
     */
    SwStandardItem* child(int row, int column = 0) const;

    /**
     * @brief Performs the `appendRow` operation.
     * @param item Item affected by the operation.
     */
    void appendRow(SwStandardItem* item);

    /**
     * @brief Performs the `appendRow` operation.
     * @param items Collection of items affected by the operation.
     */
    void appendRow(const SwList<SwStandardItem*>& items);

    /**
     * @brief Sets the child.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @param item Item affected by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setChild(int row, int column, SwStandardItem* item);

    void removeAllChildren();

private:
    friend class SwStandardItemModel;

    void attachToParent(SwStandardItem* parent, int row, int column);

    void clearChildren();

private:
    // What the class keeps (SwStandardItemModel_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

class SW_GUI_EXPORT SwStandardItemModel : public SwAbstractItemModel {
    SW_OBJECT(SwStandardItemModel, SwAbstractItemModel)

public:
    /**
     * @brief Constructs a `SwStandardItemModel` instance.
     * @param rows Value passed to the method.
     * @param columns Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwStandardItemModel(int rows = 0,
                                 int columns = 1,
                                 SwObject* parent = nullptr);

    /**
     * @brief Destroys the `SwStandardItemModel` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwStandardItemModel() override;

    /**
     * @brief Returns the current invisible Root Item.
     * @return The current invisible Root Item.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStandardItem* invisibleRootItem() const;

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Sets the column Count.
     * @param columns Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnCount(int columns);

    /**
     * @brief Performs the `columnCount` operation.
     * @param parent Optional parent object that owns this instance.
     * @return The requested column Count.
     */
    int columnCount(const SwModelIndex& parent = SwModelIndex()) const override;

    /**
     * @brief Performs the `rowCount` operation.
     * @param parent Optional parent object that owns this instance.
     * @return The requested row Count.
     */
    int rowCount(const SwModelIndex& parent = SwModelIndex()) const override;

    /**
     * @brief Performs the `index` operation.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @return The requested index.
     */
    SwModelIndex index(int row,
                       int column,
                       const SwModelIndex& parent = SwModelIndex()) const override;

    /**
     * @brief Performs the `parent` operation.
     * @param child Value passed to the method.
     * @return The requested parent.
     */
    SwModelIndex parent(const SwModelIndex& child) const override;

    /**
     * @brief Performs the `data` operation.
     * @param index Value passed to the method.
     * @param role Value passed to the method.
     * @return The requested data.
     */
    SwAny data(const SwModelIndex& index, SwItemDataRole role = SwItemDataRole::DisplayRole) const override;

    /**
     * @brief Sets the data.
     * @param index Value passed to the method.
     * @param value Value passed to the method.
     * @param role Value passed to the method.
     * @return `true` on success; otherwise `false`.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    bool setData(const SwModelIndex& index, const SwAny& value, SwItemDataRole role = SwItemDataRole::EditRole) override;

    /**
     * @brief Performs the `headerData` operation.
     * @param section Value passed to the method.
     * @param orientation Value passed to the method.
     * @param role Value passed to the method.
     * @return The requested header Data.
     */
    SwAny headerData(int section,
                     SwOrientation orientation,
                     SwItemDataRole role = SwItemDataRole::DisplayRole) const override;

    /**
     * @brief Performs the `sort` operation.
     * @param column Value passed to the method.
     * @param order Value passed to the method.
     */
    void sort(int column, SwSortOrder order = SwSortOrder::AscendingOrder) override;

    /**
     * @brief Sets the horizontal Header Labels.
     * @param labels Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHorizontalHeaderLabels(const SwList<SwString>& labels);

    /**
     * @brief Performs the `item` operation.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @return The requested item.
     */
    SwStandardItem* item(int row, int column = 0) const;

    /**
     * @brief Sets the item.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @param item Item affected by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItem(int row, int column, SwStandardItem* item);

    /**
     * @brief Performs the `appendRow` operation.
     * @param item Item affected by the operation.
     */
    void appendRow(SwStandardItem* item);

    /**
     * @brief Performs the `appendRow` operation.
     * @param items Collection of items affected by the operation.
     */
    void appendRow(const SwList<SwStandardItem*>& items);

    /**
     * @brief Performs the `flags` operation.
     * @param index Value passed to the method.
     * @return The requested flags.
     */
    SwItemFlags flags(const SwModelIndex& index) const override;

    /// Returns the item represented by a model index, or nullptr for an invalid index.
    SwStandardItem* itemFromIndex(const SwModelIndex& index) const;

private:
    void sortChildrenRecursive(SwStandardItem* parent, int column, SwSortOrder order);
    // What the class keeps (SwStandardItemModel_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
