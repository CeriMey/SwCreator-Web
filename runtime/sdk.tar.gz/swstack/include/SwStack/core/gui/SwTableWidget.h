#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file
 * @ingroup core_gui
 * @brief Declares `SwTableWidget`, a convenience table view backed by a standard model.
 *
 * The widget packages `SwTableView` together with an internal `SwStandardItemModel` so
 * callers can populate cells without manually wiring a model first. It is the higher-level
 * table API for editable grids, simple forms, and utility dialogs.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwStandardItemModel.h"
#include "SwTableView.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwTableWidget : public SwTableView {
    SW_OBJECT(SwTableWidget, SwTableView)

public:
    /**
     * @brief Constructs a `SwTableWidget` instance.
     * @param rows Value passed to the method.
     * @param columns Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwTableWidget(int rows = 0, int columns = 0, SwWidget* parent = nullptr);

    /**
     * @brief Returns the current model.
     * @return The current model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStandardItemModel* model() const;

    /**
     * @brief Performs the `rowCount` operation.
     * @return The requested row Count.
     */
    int rowCount() const;
    /**
     * @brief Performs the `columnCount` operation.
     * @return The requested column Count.
     */
    int columnCount() const;

    /**
     * @brief Sets the cell Widget.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @param widget Widget associated with the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCellWidget(int row, int column, SwWidget* widget);

    /**
     * @brief Sets the row Count.
     * @param rows Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRowCount(int rows);

    /**
     * @brief Sets the column Count.
     * @param columns Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColumnCount(int columns);

    /**
     * @brief Sets the horizontal Header Labels.
     * @param labels Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHorizontalHeaderLabels(const SwList<SwString>& labels);

    /**
     * @brief Performs the `item` operation.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @return The requested item.
     */
    SwStandardItem* item(int row, int column) const;
    /**
     * @brief Sets the item.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @param item Item affected by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setItem(int row, int column, SwStandardItem* item);

private:
public:
    ~SwTableWidget();
private:
    // What the class keeps (SwTableWidget_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
