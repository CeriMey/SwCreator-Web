﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwScrollArea.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwScrollArea in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the scroll area interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwScrollArea.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwScrollArea - scroll area.
 *
 * Requires painter clipping support to avoid drawing outside the viewport.
 **************************************************************************************************/

#include "SwFrame.h"
#include "SwScrollBar.h"

class SW_WIDGETS_EXPORT SwScrollArea : public SwFrame {
    SW_OBJECT(SwScrollArea, SwFrame)

public:
    /**
     * @brief Constructs a `SwScrollArea` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwScrollArea(SwWidget* parent = nullptr);

    /**
     * @brief Performs the `refreshLayout` operation.
     */
    void refreshLayout();

    /**
     * @brief Sets the widget.
     * @param widget Widget associated with the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWidget(SwWidget* widget);

    /**
     * @brief Returns the current widget.
     * @return The current widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* widget() const;

    /**
     * @brief Sets the widget Resizable.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWidgetResizable(bool on);

    /**
     * @brief Returns the current widget Resizable.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool widgetResizable() const;

    /**
     * @brief Returns the current horizontal Scroll Bar.
     * @return The current horizontal Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBar* horizontalScrollBar() const;
    /**
     * @brief Returns the current vertical Scroll Bar.
     * @return The current vertical Scroll Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwScrollBar* verticalScrollBar() const;

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

private:
    class SW_WIDGETS_EXPORT Viewport : public SwWidget {
        SW_OBJECT(Viewport, SwWidget)

    public:
        /**
         * @brief Constructs a `Viewport` instance.
         * @param parent Optional parent object that owns this instance.
         *
         * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
         */
        explicit Viewport(SwWidget* parent = nullptr);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;
    };

    void initDefaults();

    void updateLayout();

    void updateLayoutOnce_();

    void onContentResized_(int, int);

    void updateContentPosition();


    SwSize scrollAreaSizeHint_(bool minimum) const;
public:
    ~SwScrollArea();
private:
    // What the class keeps (SwScrollArea_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

