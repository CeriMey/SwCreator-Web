﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwRoundColorPicker.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwRoundColorPicker in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the round color picker interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwRoundColorPicker.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwRoundColorPicker - Hue wheel + saturation/value disk.
 *
 * No external GUI dependency: rendering is done via SwPainter::drawImage on SwImage buffers.
 *
 * Interaction:
 * - Drag on the ring to change Hue (0..360Â°)
 * - Drag inside the disk to change Saturation/Value (mapped to a circular area like the reference implementation)
 **************************************************************************************************/

#include "SwWidget.h"
#include "graphics/SwImage.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

class SW_WIDGETS_EXPORT SwRoundColorPicker : public SwWidget {
    SW_OBJECT(SwRoundColorPicker, SwWidget)

public:
    /**
     * @brief Constructs a `SwRoundColorPicker` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwRoundColorPicker(SwWidget* parent = nullptr);

    /**
     * @brief Sets the color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setColor(const SwColor& color);

    /**
     * @brief Returns the current color.
     * @return The current color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor color() const;

    SW_SIGNAL(colorChanged, const SwColor&);

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

private:
    struct Hsv {
        double h{0.0}; // degrees [0..360)
        double s{1.0}; // [0..1]
        double v{1.0}; // [0..1]
    };

    static bool sameColor(const SwColor& a, const SwColor& b);

    static std::uint32_t packArgb(int a, int r, int g, int b);

    static Hsv rgbToHsv(const SwColor& rgb);

    static SwColor hsvToRgb(double h, double s, double v);

    void syncHsvFromColor();

    void updateMetrics();

    void regenerateHueImage();

    void regenerateSvImage();

    void drawCursor(SwPainter* painter, int cx, int cy) const;

    void drawHueCursor(SwPainter* painter, int cx, int cy) const;

    void drawSvCursor(SwPainter* painter, int cx, int cy) const;

    void updateHueFromPoint(int x, int y);

    void updateSvFromPoint(int x, int y);

    void applyHsvToColor();

    int hitTest(int px, int py) const;

public:
    ~SwRoundColorPicker();
private:
    // What the class keeps (SwRoundColorPicker_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

