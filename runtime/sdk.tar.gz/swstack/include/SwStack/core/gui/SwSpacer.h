#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwSpacer.h
 * @ingroup core_gui
 * @brief Declares the design/runtime helper widget exposed by SwSpacer in the CoreSw GUI layer.
 */

#include "SwWidget.h"

class SW_WIDGETS_EXPORT SwSpacer : public SwWidget {
    SW_OBJECT(SwSpacer, SwWidget)

    SW_PROPERTY_D(SwString, Orientation);
private:
protected:
    SW_PROPERTY_D(SwString, HorizontalPolicy);
private:
protected:
    SW_PROPERTY_D(SwString, VerticalPolicy);
private:
protected:
    SW_PROPERTY_D(int, SizeHintWidth);
private:
protected:
    SW_PROPERTY_D(int, SizeHintHeight);
private:
protected:

public:
    enum class Direction {
        Horizontal,
        Vertical
    };

    explicit SwSpacer(SwWidget* parent = nullptr);

    explicit SwSpacer(Direction direction, SwWidget* parent = nullptr);

    void setDirection(Direction direction);

    Direction direction() const;

    void setSizePolicy(const SwSizePolicy& policy);

    SwSizePolicy sizePolicy() const;

    void changeSize(int width,
                    int height,
                    SwSizePolicy::Policy horizontalPolicy = SwSizePolicy::Minimum,
                    SwSizePolicy::Policy verticalPolicy = SwSizePolicy::Minimum);

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    static SwString policyToString(SwSizePolicy::Policy policy);

    static SwSizePolicy::Policy policyFromString(SwString value);

private:
    void init_();
public:
    ~SwSpacer();
private:
    // What the class keeps (SwSpacer_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
