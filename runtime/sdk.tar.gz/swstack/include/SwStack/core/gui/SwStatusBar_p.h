#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwStatusBar.h"

struct SwStatusBar::Data {
    SwLabel* m_messageLabel{nullptr};
    SwVector<SwWidget*> m_permanent;
    SwTimer* m_clearTimer{nullptr};
    int m_margin{4};
    int m_spacing{6};
};
