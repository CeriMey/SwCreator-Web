#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwLayout.h"

struct SwAbstractLayout::Data {
    SwWidget* m_parentWidget;
    int m_spacing;
    int m_leftMargin;
    int m_topMargin;
    int m_rightMargin;
    int m_bottomMargin;
    SwRect m_lastContentRect{0, 0, -1, -1};
    bool m_layoutDirty{true};
    int m_updateDepth{0};
};
struct SwFormLayout::Data {
    SwVector<Row> m_rows;
    SwLayoutItem* m_pending{nullptr};
};
struct SwGridLayout::Data {
    SwVector<Cell> m_cells;
    SwVector<int> m_columnStretch;
    SwVector<int> m_rowStretch;
    int m_horizontalSpacing;
    int m_verticalSpacing;
};

struct SwBoxLayout::Data {
    SwVector<Item> m_items;
};
