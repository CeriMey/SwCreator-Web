#pragma once

/**
 * @file src/core/gui/SwScaledPainter.h
 * @ingroup core_gui
 * @brief Declares SwScaledPainter, a painter that scales and moves everything drawn through it.
 *
 * A parent widget that paints its children through an SwScaledPainter shows them zoomed without
 * changing their geometry: a designer canvas keeps its form at 1x for layout and hit-testing and
 * only its picture changes. Rectangles keep shared edges by rounding their corners, borders and
 * radii scale with a one pixel minimum, text is drawn with a font scaled to the same factor, and
 * paths, rotated text and translucent images reach the base painter scaled as well.
 */

#include "SwPainter.h"

class SW_GUI_EXPORT SwScaledPainter final : public SwPainter {
public:
    /**
     * @brief Draws on @p base at @p scale, the origin of this painter landing on (@p dx, @p dy).
     *
     * A device point is `dx + x * scale, dy + y * scale`; the base painter applies its own offset
     * and clip after that.
     */
    SwScaledPainter(SwPainter* base, double scale, double dx = 0.0, double dy = 0.0);

    double scale() const;

    void clear(const SwColor& color) override;
    void fillRect(const SwRect& rect, const SwColor& fillColor, const SwColor& borderColor, int borderWidth) override;
    void fillRoundedRect(const SwRect& rect, int radius, const SwColor& fillColor, const SwColor& borderColor,
                         int borderWidth) override;
    void fillRoundedRect(const SwRect& rect, int radiusTL, int radiusTR, int radiusBR, int radiusBL,
                         const SwColor& fillColor, const SwColor& borderColor, int borderWidth) override;
    void drawRect(const SwRect& rect, const SwColor& borderColor, int borderWidth) override;
    void drawDashedRect(const SwRect& rect, const SwColor& color, int borderWidth, int dashLen, int gapLen) override;
    void drawLine(int x1, int y1, int x2, int y2, const SwColor& color, int width) override;
    void drawPolyline(const SwPoint* points, int count, const SwColor& color, int width) override;
    void fillPolygon(const SwPoint* points, int count, const SwColor& fillColor, const SwColor& borderColor,
                     int borderWidth) override;
    void pushClipRect(const SwRect& rect) override;
    void popClipRect() override;
    void fillEllipse(const SwRect& rect, const SwColor& fillColor, const SwColor& borderColor, int borderWidth) override;
    void drawEllipse(const SwRect& rect, const SwColor& borderColor, int borderWidth) override;
    void drawImage(const SwRect& targetRect, const SwImage& image, const SwRect* sourceRect = nullptr) override;
    bool drawBgra32(const SwRect& targetRect, const uint8_t* pixels, int width, int height, int stride) override;
    bool drawNativeImage(const SwRect& targetRect, const SwImage& frame) override;
    void drawText(const SwRect& rect, const SwString& text, DrawTextFormats alignment, const SwColor& color,
                  const SwFont& font) override;
    void finalize() override;
    SwRect mapToDevice(const SwRect& rect) const override;
    SwPoint mapToDevice(const SwPoint& point) const override;
    void* nativeHandle() override;

    /** @brief Maps a rectangle of this painter's coordinates to the base painter's coordinates. */
    SwRect mapRect(const SwRect& rect) const;
    /** @brief Maps a point of this painter's coordinates to the base painter's coordinates. */
    SwPoint mapPoint(const SwPoint& point) const;
    /** @brief Returns @p font with its size multiplied by the scale. */
    SwFont scaledFont(const SwFont& font) const;

    SwScaledPainter(const SwScaledPainter& other);
    SwScaledPainter& operator=(const SwScaledPainter& other);
    ~SwScaledPainter();

protected:
    void virtual_hook(int id, void* data) override;

private:
    struct Data;
    SwSharedDataPointer<Data> d_;
};
