#pragma once

#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 ***************************************************************************************************/

/**
 * @file SwWidgetPerfTrace.h
 * @brief GUI widget performance tracing, activated by SW_WIDGET_PERF_TRACE=1.
 *
 * Usage
 * -----
 *   Set  SW_WIDGET_PERF_TRACE=1  before launching the process to enable collection.
 *   Call sw::gui::perf::dump()   at any point to print the collected metrics to stdout.
 *   Call sw::gui::perf::reset()  to clear metrics between test phases.
 *
 * When the env var is absent or "0" every macro and function returns at once. The metrics are one
 * table for the process, kept by SwGui.
 *
 * Macros
 * ------
 *   SW_WIDGET_PERF_SCOPE("paintEvent")   — RAII scope timer: records elapsed ms on destruction.
 *   SW_WIDGET_PERF_COUNT("update")       — increments a named counter without timing overhead.
 */

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#ifdef _MSC_VER
#include <cstdio>  // _dupenv_s
#endif

namespace sw {
namespace gui {
namespace perf {

struct SW_GUI_EXPORT Metric {
    unsigned long long count{0};
    double totalMs{0.0};
    double maxMs{0.0};
};

SW_GUI_EXPORT bool enabled();

/** Record an elapsed duration for a named metric. */
SW_GUI_EXPORT void addSample(const char* name, double elapsedMs);

/** Increment a named counter without recording time (for high-frequency events). */
SW_GUI_EXPORT void addCount(const char* name);

SW_GUI_EXPORT void reset();

SW_GUI_EXPORT Metric metric(const char* name);

SW_GUI_EXPORT void dump(std::ostream& stream = std::cout);

/** RAII scope timer — records name+duration when it goes out of scope. */
class SW_GUI_EXPORT ScopeTimer {
public:
    explicit ScopeTimer(const char* name);

    ~ScopeTimer();

private:
    const char*                          m_name;
    std::chrono::steady_clock::time_point m_start;
};

} // namespace perf
} // namespace gui
} // namespace sw

// ── Macros ────────────────────────────────────────────────────────────────────

/** Time the current scope.  @p name must be a string literal. */
#define SW_WIDGET_PERF_SCOPE(name) \
    sw::gui::perf::ScopeTimer swPerfTimer_##__LINE__(name)

/** Increment a named event counter (no time recorded). */
#define SW_WIDGET_PERF_COUNT(name) \
    sw::gui::perf::addCount(name)
