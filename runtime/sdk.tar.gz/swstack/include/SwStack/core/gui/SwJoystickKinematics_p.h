#pragma once

#include "core/gui/SwJoystick.h"

#include <algorithm>
#include <cmath>

namespace sw_joystick_kinematics {

constexpr float degreesToRadians = 0.01745329252f;

inline float referenceHeight(SwJoystick::Type type) {
    switch (type) {
    case SwJoystick::Type::Gamepad: return 12.0f;
    case SwJoystick::Type::FlightStick: return 180.0f;
    case SwJoystick::Type::Arcade: return 70.0f;
    }
    return 12.0f;
}

inline float referenceHeightOnCanvas(SwJoystick::Type type) {
    switch (type) {
    case SwJoystick::Type::Gamepad: return 72.0f;
    case SwJoystick::Type::FlightStick: return 263.0f;
    case SwJoystick::Type::Arcade: return 211.0f;
    }
    return 72.0f;
}

inline float referenceMaximumAngle(SwJoystick::Type type) {
    return (type == SwJoystick::Type::FlightStick ? 18.0f : 25.0f) * degreesToRadians;
}

inline float gateTravel(SwJoystick::Type type) {
    return referenceHeight(type) * std::sin(referenceMaximumAngle(type));
}

inline float maximumAngle(SwJoystick::Type type, float height) {
    return std::asin(std::min(0.95f, gateTravel(type) / std::max(1.0f, height)));
}

} // namespace sw_joystick_kinematics
