#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file
 * @ingroup core_gui
 * @brief Declares `SwStatusLight`, a compact painted status indicator widget.
 */

#include "SwWidget.h"

#include <algorithm>

#ifdef Success
#undef Success
#endif

class SW_WIDGETS_EXPORT SwStatusLight : public SwWidget {
    SW_OBJECT(SwStatusLight, SwWidget)

public:
    enum class Tone {
        Neutral,
        Good,
        Warning,
        Danger
    };

    explicit SwStatusLight(SwWidget* parent = nullptr);

    void setTone(Tone tone);

    Tone tone() const;

    void setDiameter(int diameter);

    int diameter() const;

    SwSize sizeHint() const override;

protected:
    void paintEvent(PaintEvent* event) override;

private:
    static SwColor coreColor_(Tone tone);

    static SwColor glowColor_(Tone tone);

    static SwColor highlightColor_(Tone tone);

    void initDefaults_();

public:
    ~SwStatusLight();
private:
    // What the class keeps (SwStatusLight_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
