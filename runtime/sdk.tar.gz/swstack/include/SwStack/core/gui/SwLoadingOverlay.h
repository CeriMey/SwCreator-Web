#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwWidget.h"
#include "SwTimer.h"
#include "core/object/SwPointer.h"

#include <algorithm>
#include <cmath>

#if defined(_WIN32)
// The native painting's types (SwLoadingOverlay.cpp includes GDI+).
namespace Gdiplus { class Color; class Graphics; class GraphicsPath; }
#endif

class SW_WIDGETS_EXPORT SwLoadingOverlay : public SwWidget {
    SW_OBJECT(SwLoadingOverlay, SwWidget)

public:
    explicit SwLoadingOverlay(SwWidget* parent = nullptr);
    ~SwLoadingOverlay() override;

    void start();
    void stop();
    bool isActive() const;

    SW_PROPERTY_D(bool, Active);
private:
protected:
    SW_PROPERTY_D(bool, AutoFillParent);
private:
protected:
    SW_PROPERTY_D(bool, BlockInput);
private:
protected:
    SW_PROPERTY_D(bool, ShowBackdrop);
private:
protected:
    SW_PROPERTY_D(bool, ShowPanel);
private:
protected:
    SW_PROPERTY_D(SwString, Text);
private:
protected:
    SW_PROPERTY_D(SwString, OverlayColor);
private:
protected:
    SW_PROPERTY_D(SwString, PanelColor);
private:
protected:
    SW_PROPERTY_D(SwString, PanelBorderColor);
private:
protected:
    SW_PROPERTY_D(SwString, PanelShadowColor);
private:
protected:
    SW_PROPERTY_D(SwString, SpinnerColor);
private:
protected:
    SW_PROPERTY_D(SwString, SpinnerTrailColor);
private:
protected:
    SW_PROPERTY_D(SwString, SpinnerGlowColor);
private:
protected:
    SW_PROPERTY_D(SwString, SpinnerStyle);
private:
protected:
    SW_PROPERTY_D(SwString, TextColor);
private:
protected:
    SW_PROPERTY_D(int, SpinnerSize);
private:
protected:
    SW_PROPERTY_D(int, SpinnerThickness);
private:
protected:
    SW_PROPERTY_D(int, SegmentCount);
private:
protected:
    SW_PROPERTY_D(int, SegmentLength);
private:
protected:
    SW_PROPERTY_D(int, SpinnerSweepDegrees);
private:
protected:
    SW_PROPERTY_D(int, AnimationInterval);
private:
protected:
    SW_PROPERTY_D(int, AnimationStep);
private:
protected:
    SW_PROPERTY_D(int, BoxWidth);
private:
protected:
    SW_PROPERTY_D(int, BoxMinHeight);
private:
protected:
    SW_PROPERTY_D(int, BoxPadding);
private:
protected:
    SW_PROPERTY_D(int, BoxSpacing);
private:
protected:
    SW_PROPERTY_D(int, BoxRadius);
private:
protected:

protected:
    void newParentEvent(SwObject* parent) override;
    void showEvent(Event* event) override;
    void hideEvent(Event* event) override;
    void resizeEvent(ResizeEvent* event) override;
    void paintEvent(PaintEvent* event) override;
    void mousePressEvent(MouseEvent* event) override;
    void mouseReleaseEvent(MouseEvent* event) override;
    void mouseDoubleClickEvent(MouseEvent* event) override;
    void mouseMoveEvent(MouseEvent* event) override;
    void wheelEvent(WheelEvent* event) override;
    void keyPressEvent(KeyEvent* event) override;
    void keyReleaseEvent(KeyEvent* event) override;

private:
    struct SW_WIDGETS_EXPORT ColorSpec_ {
        ColorSpec_() = default;
        ColorSpec_(const SwColor& colorValue, float alphaValue);

        SwColor color{0, 0, 0};
        float alpha{1.0f};
    };

    struct LayoutSpec_ {
        SwRect panelRect{0, 0, 0, 0};
        SwRect spinnerRect{0, 0, 0, 0};
        SwRect textRect{0, 0, 0, 0};
        bool hasText{false};
    };

    void initDefaults_();
    bool shouldBlockInput_() const;
    void syncActiveState_();
    void startAnimation_();
    void stopAnimation_();
    void restartAnimation_();
    void advanceAnimation_();
    void observeParent_(SwWidget* parentWidget);
    void disconnectObservedParent_();
    void syncToParent_();
    void captureFocus_();
    void releaseFocusCapture_();
    SwWidget* findRootWidget_() const;
    LayoutSpec_ layoutSpec_() const;
    SwString styleValue_(const char* propertyName) const;
    SwString firstStyleValue_(const char* nameA, const char* nameB = nullptr, const char* nameC = nullptr) const;
    ColorSpec_ parseColorSpec_(const SwString& text, const ColorSpec_& fallback) const;
    ColorSpec_ resolveColor_(const char* styleName,
                             const SwString& propertyValue,
                             const ColorSpec_& fallback,
                             const char* styleAlias = nullptr) const;
    int resolveMetric_(const char* styleName,
                       int propertyValue,
                       int fallback,
                       const char* styleAlias = nullptr,
                       const char* styleAlias2 = nullptr) const;
    int resolveSpinnerSize_() const;
    int resolveSpinnerThickness_() const;
    int resolveSegmentCount_() const;
    int resolveSegmentLength_() const;
    SwString resolveSpinnerStyle_() const;
    int resolveSpinnerSweepDegrees_() const;
    int resolveBoxWidth_(int spinnerSize, int boxPadding) const;
    int resolveBoxMinHeight_() const;
    int resolveBoxPadding_() const;
    int resolveBoxSpacing_() const;
    int resolveBoxRadius_() const;
    ColorSpec_ overlayColor_() const;
    ColorSpec_ panelColor_() const;
    ColorSpec_ panelBorderColor_() const;
    ColorSpec_ panelShadowColor_() const;
    ColorSpec_ spinnerHeadColor_() const;
    ColorSpec_ spinnerTrailColor_() const;
    ColorSpec_ spinnerGlowColor_() const;
    ColorSpec_ textColor_() const;
    static SwColor mixColor_(const SwColor& a, const SwColor& b, double t);
    static ColorSpec_ mixColorSpec_(const ColorSpec_& a, const ColorSpec_& b, double t);
    static double segmentStrength_(int frame, int index, int count);
    static SwColor approximateAlphaColor_(const ColorSpec_& spec);
    void paintFallback_(SwPainter* painter);
    void paintSpinnerFallback_(SwPainter* painter, const SwRect& spinnerRect);
    void paintRingSpinnerFallback_(SwPainter* painter, const SwRect& spinnerRect);
    void paintText_(SwPainter* painter);

#if defined(_WIN32)
    static unsigned char alphaByte_(float alpha);
    static Gdiplus::Color toGdiColor_(const ColorSpec_& spec, float alphaScale = 1.0f);
    static void addRoundedRectPath_(Gdiplus::GraphicsPath& path, const SwRect& rect, int radius);
    bool paintNativeAlpha_(SwPainter* painter);
    void paintPanelNative_(Gdiplus::Graphics& graphics, const SwRect& panelRect, int radius);
    void paintSpinnerNative_(Gdiplus::Graphics& graphics, const SwRect& spinnerRect);
    void paintRingSpinnerNative_(Gdiplus::Graphics& graphics, const SwRect& spinnerRect);
#endif

private:
    // What the class keeps (SwLoadingOverlay_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
