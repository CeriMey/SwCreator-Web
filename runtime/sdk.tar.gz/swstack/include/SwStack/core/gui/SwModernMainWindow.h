#pragma once

#include "SwMainWindow.h"

/**
 * A main window with a compact application header in the native caption area.
 * The inherited centralWidget(), menuBar(), toolBar() and statusBar() keep
 * their usual roles. Applications can put project navigation, a command field
 * and actions in the three optional header slots.
 *
 * Windows keeps its system resizing, snapping and close handling. Platforms
 * without custom-caption support keep their native window decorations.
 */
class SW_WIDGETS_EXPORT SwModernMainWindow : public SwMainWindow {
    SW_OBJECT(SwModernMainWindow, SwMainWindow)
public:
    enum class ColorScheme { Light, Dark };

    explicit SwModernMainWindow(const SwString& title = "Application", int width = 1100, int height = 760);
    ~SwModernMainWindow() override;

    SwWidget* titleBar() const;
    static constexpr int titleBarHeight() { return 44; }
    bool hasCustomTitleBar() const;

    // A slot takes ownership of its widget; replacing it deletes the old one.
    // Pass nullptr to clear it. Unused slots take no space.
    void setLeadingWidget(SwWidget* widget);
    void setCommandWidget(SwWidget* widget);
    void setActionsWidget(SwWidget* widget);
    SwWidget* leadingWidget() const;
    SwWidget* commandWidget() const;
    SwWidget* actionsWidget() const;

    void setColorScheme(ColorScheme scheme);
    ColorScheme colorScheme() const;
    void setAccentColor(const SwColor& color);
    SwColor accentColor() const;

    // Refresh after changing a slot's preferred size or adding menus.
    void refreshTitleBar();
    bool isMaximized() const;
    void toggleMaximized();
    void requestClose();
    // Uses the actual native frame thickness, including the custom caption.
    void resizeNativeWindow(const SwSize& size);

private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};
