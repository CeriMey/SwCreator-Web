#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTreeView.h"

struct SwTreeView::Data {
    bool m_resizingRowHeight{false};
    int m_rowResizeStartY{0};
    int m_rowResizeStartHeight{0};
    SwAbstractItemModel* m_model{nullptr};
    SwItemSelectionModel* m_selectionModel{nullptr};
    SwHeaderView* m_header{nullptr};
    SwScrollBar* m_hBar{nullptr};
    SwScrollBar* m_vBar{nullptr};
    int m_rowHeight{28};
    int m_indent{22};
    int m_iconSize{16};
    int m_itemContentLeftPad{0};
    bool m_rootIsDecorated{true};
    bool m_alternating{true};
    bool m_showGrid{true};
    SwScrollBarPolicy m_hPolicy{SwScrollBarPolicy::ScrollBarAsNeeded};
    SwScrollBarPolicy m_vPolicy{SwScrollBarPolicy::ScrollBarAsNeeded};
    int m_headerHeight{32};
    bool m_headerHidden{false};
    int m_scrollBarThickness{14};
    bool m_dragEnabled{false};
    bool m_acceptDrops{false};
    bool m_dropIndicatorShown{false};
    bool m_pressed{false};
    bool m_dragging{false};
    int m_pressX{0};
    int m_pressY{0};
    SwModelIndex m_pressIndex;
    SwModelIndex m_dragIndex;
    SwModelIndex m_dropIndex;
    int m_dropVisibleRow{-1};
    SwModelIndex m_hoverIndex;
    SwList<VisibleRow> m_visible;
    SwList<int> m_expanded;
    SwList<IndexWidgetEntry> m_indexWidgets;
    TreeColors m_colors;
    std::function<bool(SwPainter*, const SwTreeView::RowPaint&)> m_rowPainter;
    SwFont     m_treeFont{L"Segoe UI", 9, Normal};
    bool       m_treeFontSet{false};
};
