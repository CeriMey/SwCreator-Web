﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwMessageBox.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwMessageBox in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the message box interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwMessageBox.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwMessageBox - message box.
 *
 * Focus:
 * - Built on SwDialog (native window by default on Windows).
 * - Standard buttons, icon support (Information, Warning, Critical, Question).
 **************************************************************************************************/

#include "SwDialog.h"
#include "SwLabel.h"
#include "SwPushButton.h"

#include <algorithm>
#include <cmath>

class SW_WIDGETS_EXPORT SwMessageBox : public SwDialog {
    SW_OBJECT(SwMessageBox, SwDialog)

public:
    enum StandardButton {
        NoButton = 0x0,
        Ok = 0x1,
        Cancel = 0x2,
        Yes = 0x4,
        No = 0x8
    };

    enum Icon {
        NoIcon = 0,
        Information,
        Warning,
        Critical,
        Question
    };

    /**
     * @brief Constructs a `SwMessageBox` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwMessageBox(SwWidget* parent = nullptr);

    /**
     * @brief Sets the icon.
     * @param icon Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIcon(Icon icon);

    /**
     * @brief Returns the current icon.
     * @return The current icon.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Icon icon() const;

    /**
     * @brief Sets the text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setText(const SwString& text);

    /**
     * @brief Returns the current text.
     * @return The current text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString text() const;

    /**
     * @brief Sets the informative Text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setInformativeText(const SwString& text);

    SwString informativeText() const;

    /**
     * @brief Sets the standard Buttons.
     * @param buttons Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStandardButtons(int buttons);

    /**
     * @brief Returns the current standard Buttons.
     * @return The current standard Buttons.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int standardButtons() const;

    /**
     * @brief Returns the current clicked Button.
     * @return The current clicked Button.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int clickedButton() const;

    /**
     * @brief Performs the `information` operation.
     * @param parent Optional parent object that owns this instance.
     * @param title Title text applied by the operation.
     * @param text Value passed to the method.
     * @param buttons Value passed to the method.
     * @return The requested information.
     */
    static int information(SwWidget* parent,
                           const SwString& title,
                           const SwString& text,
                           int buttons = Ok);

    /**
     * @brief Performs the `question` operation.
     * @param parent Optional parent object that owns this instance.
     * @param title Title text applied by the operation.
     * @param text Value passed to the method.
     * @param buttons Value passed to the method.
     * @return The requested question.
     */
    static int question(SwWidget* parent,
                        const SwString& title,
                        const SwString& text,
                        int buttons = Yes | No);

    /**
     * @brief Performs the `warning` operation.
     * @param parent Optional parent object that owns this instance.
     * @param title Title text applied by the operation.
     * @param text Value passed to the method.
     * @param buttons Value passed to the method.
     * @return The requested warning.
     */
    static int warning(SwWidget* parent,
                       const SwString& title,
                       const SwString& text,
                       int buttons = Ok);

    /**
     * @brief Performs the `critical` operation.
     * @param parent Optional parent object that owns this instance.
     * @param title Title text applied by the operation.
     * @param text Value passed to the method.
     * @param buttons Value passed to the method.
     * @return The requested critical.
     */
    static int critical(SwWidget* parent,
                        const SwString& title,
                        const SwString& text,
                        int buttons = Ok);

    /// The push button of standard button @p which, nullptr when the box does not show it, as
    /// QMessageBox::button(): its text can be changed. setStandardButtons() makes new buttons.
    SwPushButton* button(StandardButton which) const;

    /// Gives standard button @p button the text @p text, as QMessageBox::setButtonText(), whether
    /// the box shows it yet or not. By default the buttons speak the language of SwStack's standard
    /// dialogs (SwFileDialog::defaultUiLanguage(): the system's, or the one the application sets),
    /// as Qt's take theirs from the translations the application loads.
    void setButtonText(int button, const SwString& text);

protected:
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    class SW_WIDGETS_EXPORT IconWidget final : public SwWidget {
        SW_OBJECT(IconWidget, SwWidget)

    public:
        /**
         * @brief Performs the `IconWidget` operation.
         * @param parent Optional parent object that owns this instance.
         * @return The requested icon Widget.
         */
        explicit IconWidget(SwWidget* parent = nullptr);

        /**
         * @brief Sets the icon.
         * @param m_icon Value passed to the method.
         *
         * @details Call this method to replace the currently stored value with the caller-provided one.
         */
        void setIcon(Icon icon);

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

    private:
        void paintInformation(SwPainter* painter, const SwRect& r, int sz);

        void paintWarning(SwPainter* painter, const SwRect& r, int sz);

        void paintCritical(SwPainter* painter, const SwRect& r, int sz);

        void paintQuestion(SwPainter* painter, const SwRect& r, int sz);

        Icon m_icon{NoIcon};
    };

    static constexpr int kIconSize = 40;
    static constexpr int kIconGap = 14;

    void autoFitHeight();

    void buildUi();

    void updateContentLayout();

    void createButtons();

    void layoutButtons();

#if defined(_WIN32)
    static HICON createEnvelopeIcon_();

    static HICON createCircleLetterIcon_(const wchar_t* letter, int r, int g_, int b);
#endif

    static SwString buttonText(int id);


public:
    ~SwMessageBox();
private:
    // What the class keeps (SwMessageBox_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

