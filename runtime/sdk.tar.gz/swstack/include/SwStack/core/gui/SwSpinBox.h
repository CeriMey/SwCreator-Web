﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwSpinBox.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwSpinBox in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the spin box interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwSpinBox.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwFrame.h"
#include "SwLineEdit.h"
#include "SwWidgetPlatformAdapter.h"

#include <algorithm>

class SW_WIDGETS_EXPORT SwSpinBox : public SwFrame {
    SW_OBJECT(SwSpinBox, SwFrame)

public:
    /**
     * @brief Constructs a `SwSpinBox` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwSpinBox(SwWidget* parent = nullptr);

    /**
     * @brief Sets the range.
     * @param minimum Value passed to the method.
     * @param maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRange(int minimum, int maximum);

    /**
     * @brief Sets the minimum.
     * @param m_maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMinimum(int minimum);
    /**
     * @brief Sets the maximum.
     * @param maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMaximum(int maximum);

    /**
     * @brief Returns the current minimum.
     * @return The current minimum.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int minimum() const;
    /**
     * @brief Returns the current maximum.
     * @return The current maximum.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int maximum() const;

    /**
     * @brief Sets the single Step.
     * @param m_singleStep Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSingleStep(int step);
    /**
     * @brief Returns the current single Step.
     * @return The current single Step.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int singleStep() const;

    /**
     * @brief Sets the value.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setValue(int value);

    /**
     * @brief Returns the current value.
     * @return The current value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int value() const;

    /**
     * @brief Returns the current line Edit.
     * @return The current line Edit.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwLineEdit* lineEdit() const;

    SW_SIGNAL(valueChanged, int);

protected:
    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

private:
    struct ArrowFillRadii {
        int tl{0};
        int tr{0};
        int br{0};
        int bl{0};
    };

    class SW_WIDGETS_EXPORT ArrowButton final : public SwWidget {
        SW_OBJECT(ArrowButton, SwWidget)

    public:
        enum class Direction { Up, Down };

        /**
         * @brief Performs the `ArrowButton` operation.
         * @param dir Value passed to the method.
         * @param parent Optional parent object that owns this instance.
         * @return The requested arrow Button.
         */
        explicit ArrowButton(Direction dir, SwWidget* parent = nullptr);

        SW_SIGNAL_VOID(clicked);

    protected:
        SW_PROPERTY_D(bool, Pressed);
    private:
        bool m_Pressed = false;
        bool m_Pressed_registered_ = sw_register_Pressed_();
    protected:

        /**
         * @brief Handles the paint Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void paintEvent(PaintEvent* event) override;

        /**
         * @brief Handles the mouse Press Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mousePressEvent(MouseEvent* event) override;

        /**
         * @brief Handles the mouse Release Event forwarded by the framework.
         * @param event Event object forwarded by the framework.
         *
         * @details Override this hook when the default framework behavior needs to be extended or replaced.
         */
        void mouseReleaseEvent(MouseEvent* event) override;

    private:
        Direction m_dir{Direction::Up};
        SwSpinBox* m_owner{nullptr};
    };

    int arrowColumnWidth() const;

    void resolveFrameMetrics_(int& borderWidth,
                              int& radiusTopRight,
                              int& radiusBottomRight);

    SwRect arrowHighlightRect_(const SwRect& buttonRect,
                               ArrowButton::Direction dir);

    ArrowFillRadii arrowHighlightRadii_(ArrowButton::Direction dir);

    void buildChildren();

    void updateLayout();

    void stepUp();

    void stepDown();

    void updateTextFromValue();

    void commitEdit();

    void sanitizeEditText(const SwString& txt);

    void focusEditorForStepping_();

    void refreshStepSelection_();

    void initDefaults();

public:
    ~SwSpinBox();
private:
    // What the class keeps (SwSpinBox_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
