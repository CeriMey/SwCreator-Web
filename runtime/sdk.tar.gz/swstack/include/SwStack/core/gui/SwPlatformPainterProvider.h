/* Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once

#include "core/gui/SwPainter.h"
#include "SwObject.h"

struct SwPlatformPaintEvent;
class SwPlatformPainter;
class SwPlatformWindow;

/**
 * Optional native painter provider, owned by the application or one of its objects.
 *
 * Providers are consulted on the GUI thread before the platform's default painter. Returning
 * false from accepts() leaves the window to the next provider. After accepting a window,
 * createPainter() may return null to defer a frame; the software painter is then not invoked.
 * This keeps an asynchronous presentation backend from mixing incompatible window surfaces.
 * A returned painter is owned by SwScopedPlatformPainter and has not yet begun painting.
 */
class SW_GUI_EXPORT SwPlatformPainterProvider : public SwObject {
    SW_OBJECT(SwPlatformPainterProvider, SwObject)
  public:
    explicit SwPlatformPainterProvider(SwObject* parent = nullptr);
    ~SwPlatformPainterProvider() override;

    virtual bool accepts(const SwPlatformPaintEvent& event) = 0;
    virtual SwPlatformPainter* createPainter(const SwPlatformPaintEvent& event) = 0;

    /// Posts a coalesced native repaint, if the window still exists. GUI thread only.
    static void requestWindowUpdate(void* nativeWindow, void* nativeDisplay = nullptr);
    /// Native event dispatchers call this before posting a deferred window deletion callback.
    static void nativeWindowDestroyed(void* nativeWindow, void* nativeDisplay = nullptr);

  protected:
    /// Called before native window destruction. Release window-specific presentation resources.
    virtual void releaseWindow(void* nativeWindow, void* nativeDisplay);

  private:
    friend class SwPlatformWindow;
    friend class SwScopedPlatformPainter;
    static SwPlatformPainterProvider* providerFor(const SwPlatformPaintEvent& event);
    static void windowCreated(SwPlatformWindow* window);
    static void windowDestroyed(SwPlatformWindow* window);
};
