#pragma once

/**
 * @file src/core/gui/SwGuiEvent.h
 * @ingroup core_gui
 * @brief The window-system events: resize, move, close, paint, mouse, wheel and key.
 *
 * They belong to Gui, as QResizeEvent or QMouseEvent belong to QtGui: a window (SwWindow) and a
 * widget (SwWidget) receive the same events. Their layouts are frozen (docs/BINARY_COMPATIBILITY.md).
 */

#include "../SwStackExport.h"
#include "SwEvent.h"
#include "Sw.h"
#include "platform/SwPlatformIntegration.h"

#include <vector>

class SwPainter;

class SW_GUI_EXPORT Event : public SwEvent {
public:
    explicit Event(EventType type);

    Event* clone() const override;
};


// Classe pour l'Ã©vÃ©nement de redimensionnement
class SW_GUI_EXPORT ResizeEvent : public Event {
public:
    ~ResizeEvent() override;
    ResizeEvent(int w, int h);

    int width() const;
    int height() const;

private:
    int newWidth, newHeight;
};

class SW_GUI_EXPORT MoveEvent : public Event {
public:
    ~MoveEvent() override;
    MoveEvent(int xPos, int yPos);

    int x() const;
    int y() const;
    SwPoint pos() const;

private:
    int newX;
    int newY;
};

// Classe pour l'Ã©vÃ©nement de dessin
class SW_GUI_EXPORT CloseEvent : public Event {
public:
    CloseEvent();
    CloseEvent* clone() const override;
};

class SW_GUI_EXPORT PaintEvent : public Event {
public:
    ~PaintEvent() override;
    PaintEvent(SwPainter* painter, const SwRect& paintRect);

    SwPainter* painter() const;
    const SwRect& paintRect() const;

    // The parts of paintRect that need painting, in the same coordinates; empty means all of it.
    // The painter is already clipped to them: this is for skipping what lies outside.
    const std::vector<SwRect>& paintRegion() const;
    void setPaintRegion(std::vector<SwRect> region);

private:
    SwPainter* m_painter;
    SwRect m_rect;
    std::vector<SwRect> m_region;
};

// Classe pour un clic de souris
class SW_GUI_EXPORT MouseEvent : public Event {
public:
    ~MouseEvent() override;
    MouseEvent(EventType type,
               int xPos,
               int yPos,
               SwMouseButton button = SwMouseButton::NoButton,
               bool ctrl = false,
               bool shift = false,
               bool alt = false);

    int x() const;
    int y() const;
    SwPoint pos() const;
    void setX(int xPos);
    void setY(int yPos);
    void setPos(const SwPoint& p);
    int globalX() const;
    int globalY() const;
    SwPoint globalPos() const;
    void setGlobalX(int xPos);
    void setGlobalY(int yPos);
    void setGlobalPos(const SwPoint& p);
    SwMouseButton button() const;
    void setButton(SwMouseButton button);
    int getDeltaX() const;
    void setDeltaX(int dx);
    int getDeltaY() const;
    void setDeltaY(int dy);
    double getSpeedX() const;
    void setSpeedX(double sx);
    double getSpeedY() const;
    void setSpeedY(double sy);

    bool isCtrlPressed() const;
    bool isShiftPressed() const;
    bool isAltPressed() const;

    void setCtrlPressed(bool on);
    void setShiftPressed(bool on);
    void setAltPressed(bool on);

private:
    int xPosition, yPosition;
    SwMouseButton m_button{SwMouseButton::NoButton};
    bool ctrlPressed{false};
    bool shiftPressed{false};
    bool altPressed{false};
    int globalXPosition{0};
    int globalYPosition{0};
    int deltaX, deltaY;
    double speedX, speedY;
};

// Classe pour un Ã©vÃ©nement de clavier
class SW_GUI_EXPORT WheelEvent : public Event {
public:
    ~WheelEvent() override;
    WheelEvent(int xPos,
               int yPos,
               int delta,
               bool ctrl = false,
               bool shift = false,
               bool alt = false);

    int x() const;
    int y() const;
    SwPoint pos() const;
    void setX(int xPos);
    void setY(int yPos);
    void setPos(const SwPoint& p);
    int globalX() const;
    int globalY() const;
    SwPoint globalPos() const;
    void setGlobalX(int xPos);
    void setGlobalY(int yPos);
    void setGlobalPos(const SwPoint& p);
    int delta() const;

    bool isCtrlPressed() const;
    bool isShiftPressed() const;
    bool isAltPressed() const;

private:
    int xPosition{0};
    int yPosition{0};
    int globalXPosition{0};
    int globalYPosition{0};
    int wheelDelta{0};
    bool ctrlPressed{false};
    bool shiftPressed{false};
    bool altPressed{false};
};

class SW_GUI_EXPORT KeyEvent : public Event {
public:
    ~KeyEvent() override;
    KeyEvent(int keyCode, bool ctrl = false, bool shift = false, bool alt = false,
             wchar_t textChar = L'\0', bool textProvided = false,
             EventType type = EventType::KeyPressEvent);

    int key() const;
    bool isCtrlPressed() const;
    bool isShiftPressed() const;
    bool isAltPressed() const;

    // Unicode character translated by the platform for the active keyboard layout (AZERTY, etc.).
    // L'\0' for dead keys (first press), control keys, or keys without a character output.
    wchar_t text() const;

    // True when the platform performed the key-to-char translation (e.g. Win32 WM_CHAR path).
    // Widgets must NOT call translateCharacter() when this is true, even when text() == L'\0'.
    bool isTextProvided() const;

private:
    int keyPressed;
    bool ctrlPressed;
    bool shiftPressed;
    bool altPressed;
    wchar_t textChar{L'\0'};
    bool textProvidedFlag{false};
};
