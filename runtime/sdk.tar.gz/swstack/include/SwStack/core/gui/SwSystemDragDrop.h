#pragma once

/**
 * @file src/core/gui/SwSystemDragDrop.h
 * @ingroup core_gui
 * @brief Drag and drop between a window and the rest of the system.
 *
 * SwDragDrop draws a drag inside the application. SwSystemDragDrop hands it to the operating
 * system instead, so that it can leave the window and come back, and so that a window accepts
 * what other applications drop on it: files from the file manager, or a private format that
 * another window of the application started.
 *
 * - startDrag() runs the system's drag loop with one private format (a name and its text) and an
 *   optional preview painted once by the application's painter.
 * - registerDropTarget() makes a window a drop target: its handler sees the private formats it
 *   named and the files, in the window's logical client coordinates.
 *
 * Windows implements both through OLE. Elsewhere they report that the system does not take the
 * drag (startDrag() returns false, the registration is invalid): callers keep their in-window
 * fallback.
 */

#include "SwDragDrop.h"
#include "SwString.h"
#include "SwWidgetPlatformAdapter.h"
#include "../SwStackExport.h"

#include <vector>

class SW_GUI_EXPORT SwSystemDragDrop {
public:
    /**
     * @brief What a drag carries: one private format (a name and its text) and files.
     */
    struct Data {
        SwString format;                 ///< A private format's name, e.g. "MyApp.WidgetClass"; empty for none.
        SwString text;                   ///< That format's value.
        std::vector<SwString> files;     ///< Absolute paths, Qt style ("C:/dir/file").
    };

    /**
     * @brief Receives the drags that enter a registered window.
     *
     * Coordinates are the window's logical client coordinates.
     */
    class DropHandler {
    public:
        virtual ~DropHandler() = default;
        virtual bool canAcceptDrop(const Data& data, int clientX, int clientY) = 0;
        virtual void dragOver(const Data& data, int clientX, int clientY) = 0;
        virtual void dragLeave() = 0;
        virtual void drop(const Data& data, int clientX, int clientY) = 0;
    };

    /**
     * @brief Keeps a window registered as a drop target until it is destroyed or moved from.
     */
    class SW_GUI_EXPORT Registration {
    public:
        Registration() = default;
        ~Registration();
        Registration(const Registration&) = delete;
        Registration& operator=(const Registration&) = delete;
        Registration(Registration&& other) noexcept;
        Registration& operator=(Registration&& other) noexcept;

        bool isValid() const;

    private:
        friend class SwSystemDragDrop;
        void reset_();
        void* m_dropTarget{nullptr};
        SwWidgetPlatformHandle m_windowHandle{};
    };

    /**
     * @brief Runs the system's drag loop with @p data until the drop or the cancel.
     * @param label Text drawn beside the preview in the drag image.
     * @return true when the system ran the drag; false when it does not take drags (the caller
     *         then uses SwDragDrop inside its window).
     */
    static bool startDrag(const Data& data,
                          const SwString& label = SwString(),
                          const SwFont& font = SwFont(),
                          const SwDragDrop::Preview& preview = SwDragDrop::Preview{});

    /**
     * @brief Makes @p windowHandle a drop target for files and the private @p formats.
     */
    static Registration registerDropTarget(const SwWidgetPlatformHandle& windowHandle,
                                           DropHandler* handler,
                                           const std::vector<SwString>& formats);
};
