#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwMainWindow.h"

// The platform, which the public header no longer shows (SwMainWindow.h).
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#endif

struct SwMainWindow::Data {
    std::unique_ptr<SwPlatformWindow> m_platformWindow;
    std::wstring m_windowTitle;
    SwIcon m_windowIcon;
    struct {
        int x{0};
        int y{0};
    } lastMousePosition;
    std::chrono::steady_clock::time_point lastMoveTime; ///< Last recorded time of mouse movement.
    bool m_deleteHandled{false};
    bool m_chromeInitialized{false};
    SwVerticalLayout* m_chromeLayout{nullptr};
    SwWidget* m_centralWidget{nullptr};
    SwMenuBar* m_menuBar{nullptr};
    SwToolBar* m_toolBar{nullptr};
    SwStatusBar* m_statusBar{nullptr};
    bool m_forceFullClientPaint{true};
    SwMenu* m_helpMenu{nullptr};
    SwDialog* m_aboutDialog{nullptr};
};
