#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwAbstractSeries.h"

struct SwAbstractSeries::Data {
    SwVector<SwPointF> m_points{};
    int m_maxPoints{0};
    bool m_visible{true};
    SwColor m_color{0, 120, 215};
    SwString m_name{};
};
