#pragma once

#include <memory>
#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwSystemTrayIcon.h
 * @brief System tray icon with context menu, tooltip, and click signals.
 *
 * Usage:
 * @code
 *   SwSystemTrayIcon tray(&window);
 *   tray.setToolTip("My App");
 *   tray.addAction("Show",  [&]() { window.show(); });
 *   tray.addSeparator();
 *   tray.addAction("Quit",  [&]() { app.quit(); });
 *   tray.show();
 * @endcode
 */

#include "SwObject.h"
#include "SwString.h"
#include "SwList.h"
#include "SwIcon.h"
#include "Sw.h"
#include <functional>
#include <string>


class SW_WIDGETS_EXPORT SwSystemTrayIcon : public SwObject {
    SW_OBJECT(SwSystemTrayIcon, SwObject)

public:
    enum class MessageIcon {
        NoIcon,
        Information,
        Warning,
        Critical
    };

    explicit SwSystemTrayIcon(SwObject* parent = nullptr);

    ~SwSystemTrayIcon() override;

    // -- Configuration --

    void setToolTip(const SwString& tip);
    SwString toolTip() const;

    /** @brief Set icon from a SwIcon object. */
    void setIcon(const SwIcon& icon);

    /** @brief Set icon from a file path (.ico, .bmp). */
    void setIconPath(const SwString& iconPath);

    const SwIcon& icon() const;

    // -- Menu actions --

    struct Action {
        SwString text;
        std::function<void()> callback;
        bool separator = false;
    };

    void addAction(const SwString& text, const std::function<void()>& callback);

    void addSeparator();

    void clearActions();

    // -- Show / Hide --

    void show();

    void hide();

    bool isVisible() const;

    SwPoint lastActivationScreenPoint() const;

    void showMessage(const SwString& title,
                     const SwString& message,
                     MessageIcon icon = MessageIcon::Information,
                     int timeoutMs = 10000);

signals:
    SW_SIGNAL_VOID(activated)
    SW_SIGNAL_VOID(doubleClicked)

private:

#ifndef _WIN32
    void updateIcon_();
    void updateTip_();
#endif

#ifdef _WIN32

    HICON loadIcon_();

    void updateIcon_();

    void updateTip_();

    static DWORD messageIconFlags_(MessageIcon icon);

    static std::wstring toWide_(const SwString& value);

    void showContextMenu_();

    void rememberActivationPoint_();

    void emitActivatedFromTrayEvent_();

    static const wchar_t* trayWindowClassName_();

    static void ensureTrayWindowClassRegistered_();

    HWND createMessageWindow_();

    void destroyMessageWindow_();

    static UINT trayEvent_(LPARAM lParam);

    static LRESULT __stdcall trayProc_(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
#endif
private:
    // What the class keeps (SwSystemTrayIcon_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
