#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwKeySequence.h"

struct SwKeySequence::Data : SwSharedData {
    SwKey m_key{SwKey::Unknown};
    char m_char{'\0'};
    bool m_ctrl{false};
    bool m_shift{false};
    bool m_alt{false};
};
