#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwDragDrop.h"

struct SwDragDrop::Data : SwSharedData {
    SwWidgetPlatformHandle m_handle{};
    SwString m_text;
    SwFont m_font;
    int m_x{0};
    int m_y{0};
    bool m_showPlus{true};
    bool m_dropAllowed{true};
    bool m_active{false};
};
