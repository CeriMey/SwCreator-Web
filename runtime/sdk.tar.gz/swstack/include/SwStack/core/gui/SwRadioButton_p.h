#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwRadioButton.h"

struct SwRadioButton::Data {
    SwString m_Text = "RadioButton";
    bool m_Text_registered_ = sw_register_Text_();
    bool m_Pressed = false;
    bool m_Pressed_registered_ = sw_register_Pressed_();
    bool m_checked{false};
    bool m_autoExclusive{true};
    SwColor m_accent{0, 120, 215};
    SwRadioButton::RadioColors m_colors;
    int m_indicatorSize{18};
    int m_textSpacing{10};
};
