#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwChartView.h"

struct SwChartView::Data {
    SwChart* m_chart{nullptr};
    bool m_enableMouseZoom{false};
    bool m_enableMousePan{false};
    bool m_enablePlayMode{false};
    bool m_showLegend{true};
    bool m_panning{false};
    int m_lastPanX{0};
    int m_lastPanY{0};
    bool m_handlingChartChange{false};
};
