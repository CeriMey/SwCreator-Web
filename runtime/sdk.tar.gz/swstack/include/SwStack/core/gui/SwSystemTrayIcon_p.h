#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwSystemTrayIcon.h"

// The platform, which the public header no longer shows (SwSystemTrayIcon.h).
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#define SW_TRAY_MSG (WM_USER + 200)
#ifndef NIN_SELECT
#define NIN_SELECT (WM_USER + 0)
#endif
#ifndef NIN_KEYSELECT
#define NIN_KEYSELECT (WM_USER + 1)
#endif
#ifndef NIIF_NONE
#define NIIF_NONE 0x00000000
#endif
#ifndef NIIF_INFO
#define NIIF_INFO 0x00000001
#endif
#ifndef NIIF_WARNING
#define NIIF_WARNING 0x00000002
#endif
#ifndef NIIF_ERROR
#define NIIF_ERROR 0x00000003
#endif
#endif

struct SwSystemTrayIcon::Data {
    SwString m_tooltip;
    SwString m_iconPath;
    SwIcon m_icon;
    SwList<Action> m_actions;
    bool m_visible = false;
    SwPoint m_lastActivationPoint{0, 0};
#ifdef _WIN32
    HWND m_hwnd = nullptr;
#endif
#ifdef _WIN32
    ULONGLONG m_lastActivationEmitMs = 0;
#endif
};
