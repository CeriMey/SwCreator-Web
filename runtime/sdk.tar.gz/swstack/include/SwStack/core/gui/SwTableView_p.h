#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTableView.h"

struct SwTableView::Data {
    SwAbstractItemModel* m_model{nullptr};
    SwItemSelectionModel* m_selectionModel{nullptr};
    SwStyledItemDelegate* m_delegate{nullptr};
    SwHeaderView* m_header{nullptr};
    SwScrollBar* m_hBar{nullptr};
    SwScrollBar* m_vBar{nullptr};
    bool m_alternating{true};
    bool m_showGrid{true};
    SwTableView::TableColors m_colors;
    bool m_sortingEnabled{true};
    int m_sortColumn{-1};
    SwSortOrder m_sortOrder{SwSortOrder::AscendingOrder};
    SwScrollBarPolicy m_hPolicy{SwScrollBarPolicy::ScrollBarAsNeeded};
    SwScrollBarPolicy m_vPolicy{SwScrollBarPolicy::ScrollBarAsNeeded};
    int m_defaultColumnWidth{160};
    int m_rowHeight{26};
    int m_headerHeight{32};
    int m_scrollBarThickness{14};
    bool m_dragEnabled{false};
    bool m_acceptDrops{false};
    bool m_dropIndicatorShown{false};
    bool m_pressed{false};
    bool m_dragging{false};
    bool m_resizingRowHeight{false};
    int m_pressX{0};
    int m_pressY{0};
    int m_rowResizeStartY{0};
    int m_rowResizeStartHeight{0};
    SwModelIndex m_pressIndex;
    SwModelIndex m_dragIndex;
    SwModelIndex m_dropIndex;
    SwModelIndex m_hoverIndex;
    SwModelIndex m_editIndex;
    SwWidget* m_editorWidget{nullptr};
    bool m_committingEditor{false};
    SwList<IndexWidgetEntry> m_indexWidgets;
};
