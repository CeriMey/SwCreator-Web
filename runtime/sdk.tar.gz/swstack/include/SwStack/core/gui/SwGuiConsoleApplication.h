
/**
 * @file
 * @ingroup core_gui
 * @brief Declares a console-driven menu shell built on the stack type system.
 *
 * `SwGuiConsoleApplication` organizes actions in a tree of paths and renders a simple
 * interactive textual navigator on standard input and output. It is useful for tooling or
 * demos that want structured navigation without bringing up a native windowing backend.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

#include "SwString.h"
#include "SwVector.h"

#include <cctype>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <limits>
#include <string>
#include <utility>


/**
 * @brief Runs a navigable console menu composed of nodes and callback actions.
 */
class SW_GUI_EXPORT SwGuiConsoleApplication {
    class ConsoleEchoGuard;

public:
    /**
     * @brief Constructs a `SwGuiConsoleApplication` instance.
     * @param true Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwGuiConsoleApplication();

    /**
     * @brief Destroys the `SwGuiConsoleApplication` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwGuiConsoleApplication();

    /**
     * @brief Sets the title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTitle(const SwString& title);
    /**
     * @brief Sets the footer.
     * @param footer Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFooter(const SwString& footer);
    /**
     * @brief Sets the status Message.
     * @param message Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStatusMessage(const SwString& message);

    /**
     * @brief Sets a callback invoked before each menu render.
     *
     * The hook is useful for callers that need to refresh dynamic status text before
     * the menu is drawn.
     */
    void setBeforeRenderCallback(std::function<void()> callback);

    /**
     * @brief Adds the specified entry.
     * @param path Path used by the operation.
     * @param label Value passed to the method.
     * @param action Value passed to the method.
     */
    void addEntry(const SwString& path,
                  const SwString& label,
                  std::function<void()> action = std::function<void()>());

    /**
     * @brief Performs the `showModal` operation.
     * @param title Title text applied by the operation.
     * @param body Value passed to the method.
     * @param waitForEnter Value passed to the method.
     */
    void showModal(const SwString& title,
                   const std::function<void()>& body,
                   bool waitForEnter = true);

    /**
     * @brief Prompts for one console line.
     * @param prompt Text displayed before reading.
     * @param echo Whether typed characters should be echoed by the terminal.
     * @return Trimmed user input.
     */
    SwString promptLine(const SwString& prompt, bool echo = true);

    /**
     * @brief Returns the current exec.
     * @return The current exec.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int exec();

private:

    static bool readLine(std::string& input, bool echo);

#if defined(_WIN32)
    static bool readLineFromWindowsConsole_(std::string& input, bool echo);
#endif

    struct Node {
        SwString name;
        SwString label;
        Node* parent{nullptr};
        SwVector<Node*> children;
        /**
         * @brief Returns the current function<void.
         * @return The current function<void.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        std::function<void()> action;
    };

    Node* ensureNode(const SwString& path, const SwString& label);

    static SwVector<SwString> splitPath(const SwString& path);

    static SwString normalizedInput_(const std::string& input);

    static bool parseMenuIndex_(const SwString& value, int& index);

    bool resolveCdCommand_(const SwString& value, Node* current, Node*& target) const;

    static void trimAscii_(std::string& value);

    SwString currentPath(Node* node) const;

    void render(Node* current);

    void clearScreen() const;

public:
    SwGuiConsoleApplication(const SwGuiConsoleApplication& other);
    SwGuiConsoleApplication& operator=(const SwGuiConsoleApplication& other);
private:
    // What the class keeps (SwGuiConsoleApplication_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
