#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwFrame.h"

struct SwFrame::Data {
    Shape m_shape{Shape::NoFrame};
    Shadow m_shadow{Shadow::Plain};
    int m_lineWidth{1};
    int m_midLineWidth{0};
};
