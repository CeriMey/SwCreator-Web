#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwStandardItemModel.h"

struct SwStandardItemModel::Data {
    SwStandardItem* m_root{nullptr};
    int m_columnCount{1};
    SwList<SwString> m_horizontalHeaders;
};

struct SwStandardItem::Data {
    SwString m_text;
    SwString m_editText;
    SwString m_toolTip;
    SwImage  m_icon;
    bool m_editable{false};
    bool m_hasEditText{false};
    SwStandardItem* m_parent{nullptr};
    int m_rowInParent{-1};
    int m_columnInParent{-1};
    SwList<SwList<SwStandardItem*>> m_children;
};
