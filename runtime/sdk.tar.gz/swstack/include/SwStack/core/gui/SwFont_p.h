#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwFont.h"

// The platform, which the public header no longer shows (SwFont.h).
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#endif

struct SwFont::Data : SwSharedData {
    std::wstring familyName;
    int pointSize;
    int pixelSize{0};
    FontWeight weight;
    bool italic;
    bool underline;
    HFONT hFont = nullptr;
    bool m_ownsFontHandle{false};
    int m_cachedDpiY{0};
    bool m_dirty{true};
};
