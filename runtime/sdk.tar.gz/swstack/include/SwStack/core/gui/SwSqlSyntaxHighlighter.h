#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwSqlSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat typeFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat operatorFormat;
    SwTextCharFormat variableFormat;
};

inline SwTextCharFormat swSqlMakeFormat_(const SwColor& color,
                                          FontWeight weight = Normal,
                                          bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) { format.setFontWeight(weight); }
    if (italic) { format.setFontItalic(true); }
    return format;
}

inline SwSqlSyntaxTheme swSqlSyntaxThemeVsCodeDark() {
    SwSqlSyntaxTheme theme;
    theme.keywordFormat  = swSqlMakeFormat_(SwColor{86, 156, 214}, Medium);
    theme.functionFormat = swSqlMakeFormat_(SwColor{220, 220, 170});
    theme.typeFormat     = swSqlMakeFormat_(SwColor{78, 201, 176});
    theme.commentFormat  = swSqlMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat   = swSqlMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat   = swSqlMakeFormat_(SwColor{181, 206, 168});
    theme.operatorFormat = swSqlMakeFormat_(SwColor{212, 212, 212});
    theme.variableFormat = swSqlMakeFormat_(SwColor{156, 220, 254});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwSqlSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwSqlSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwSqlSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwSqlSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        BlockCommentState = 1
    };

    static bool isIdentStart_(char ch);

    static bool isIdentPart_(char ch);

    static int findBlockCommentEnd_(const SwString& text, int start);

    static bool isKeyword_(const SwString& word);

    static bool isType_(const SwString& word);

    static bool isFunction_(const SwString& word);

public:
    ~SwSqlSyntaxHighlighter();
private:
    // What the class keeps (SwSqlSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
