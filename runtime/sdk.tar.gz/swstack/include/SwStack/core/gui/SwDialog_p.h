#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwDialog.h"
#include "core/gui/SwScrollArea.h"

// The platform, which the public header no longer shows (SwDialog.h).
#if SW_PLATFORM_WIN32
#include "platform/win/SwWindows.h"
#elif SW_PLATFORM_X11
#include "platform/x11/SwX11PlatformIntegration.h"
#endif

struct SwDialog::Data {
    SwString m_title;
    bool m_modal{true};
    bool m_dismissOnOutsideClick{false};
    bool m_frameless{false};
    bool m_toolWindow{false};
    bool m_contentOnly{false};
    int m_contentMargin{18};
    int m_headerHeight{44};
    int m_footerHeight{56};
    bool m_fullWidthFooter{false};
    bool m_inputTransparent{false};
    unsigned char m_opacity{255};
    bool m_nativeWindowResizable{false};
#if SW_PLATFORM_WIN32 || SW_PLATFORM_X11 || SW_PLATFORM_WEB
    bool m_useNativeWindow{true};
#else
    bool m_useNativeWindow{false};
#endif
    int m_result{Rejected};
    SwWidget* m_root{nullptr};
    ModalOverlay* m_overlay{nullptr};
    SwWidget* m_overlayRootConnected{nullptr};
    SwPointer<SwWidget> m_previousFocus;
    SwPointer<SwWidget> m_focusRestoreRoot;
    SwPointer<SwWidget> m_blockedNativeOwner;
    SwPointer<SwObject> m_originalParent;
    SwRect m_originalRect{};
    Presentation m_activePresentation{Presentation::Embedded};
    std::unique_ptr<SwPlatformWindow> m_nativePlatformWindow;
#if SW_PLATFORM_WIN32
    HWND m_nativeHwnd{nullptr};
#endif
#if SW_PLATFORM_WIN32
    HWND m_nativeOwnerHwnd{nullptr};
#endif
#if SW_PLATFORM_WIN32
    bool m_nativeOwnerWasEnabled{false};
#endif
#if SW_PLATFORM_WIN32
    HICON m_nativeIcon{nullptr};
#endif
#if SW_PLATFORM_WIN32
#elif SW_PLATFORM_X11
    std::unique_ptr<SwPlatformWindow> m_x11PlatformWindow;
#endif
#if SW_PLATFORM_WIN32
#elif SW_PLATFORM_X11
    SwX11PlatformIntegration* m_x11Integration{nullptr};
#endif
    SwLabel* m_titleLabel{nullptr};
    SwWidget* m_content{nullptr};
    SwScrollArea* m_contentScroll{nullptr};
    SwWidget* m_buttonBar{nullptr};
};
