#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwLabel.h"

struct SwLabel::Data {
    SwString m_Text = "Label";
    bool m_Text_registered_ = sw_register_Text_();
    DrawTextFormats m_Alignment = DrawTextFormats(DrawTextFormat::Left | DrawTextFormat::VCenter | DrawTextFormat::SingleLine);
    bool m_Alignment_registered_ = sw_register_Alignment_();
};
