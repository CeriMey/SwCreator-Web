#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwEmojiPiker.h"

struct SwEmojiPiker::Data {
    SwTabWidget* m_tabWidget{nullptr};
    EmojisByTheme m_emojisByTheme;
    SwVector<SwString> m_tabKeys;           // Theme keys in tab order.
    SwVector<bool> m_populatedTabs;         // True once a tab's list has been filled.
    int m_buttonSize{40};
    int m_gridSpacing{5};
    int m_gridMargin{5};
    int m_emojiFontSize{18};
};
