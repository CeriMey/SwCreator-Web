#pragma once

#include "../SwStackExport.h"

#include "SwCheckBox.h"
#include "SwComboBox.h"
#include "SwDialog.h"
#include "SwDoubleSpinBox.h"
#include "SwGroupBox.h"
#include "SwLabel.h"
#include "SwLineEdit.h"
#include "SwPlainTextEdit.h"
#include "SwProgressBar.h"
#include "SwPushButton.h"
#include "SwRadioButton.h"
#include "SwSlider.h"
#include "SwSideBar.h"
#include "SwTabbedMainWindow.h"
#include "SwToggleSwitch.h"
#include "SwSpinBox.h"
#include "SwStackedWidget.h"
#include "SwTabWidget.h"
#include "SwTextEdit.h"
#include "SwToolButton.h"
#include "SwToolBox.h"
#include "SwUiLoaderDictionary.h"
#include "SwXmlDocument.h"

namespace swui::detail {

struct SW_UITOOLS_EXPORT UiConnection {
    SwString senderName;
    SwString signalName;
    SwString receiverName;
    SwString slotName;
};

inline SwString childText(const SwXmlNode& node, const char* childName) {
    const SwXmlNode* child = node.firstChild(childName);
    return child ? child->text.trimmed() : SwString();
}

inline UiConnection parseConnection(const SwXmlNode& connectionNode) {
    UiConnection connection;
    connection.senderName = childText(connectionNode, "sender");
    if (connection.senderName.isEmpty()) {
        connection.senderName = connectionNode.attr("sender");
    }

    connection.signalName = compat::normalizeMemberName(childText(connectionNode, "signal"));
    if (connection.signalName.isEmpty()) {
        connection.signalName = compat::normalizeMemberName(connectionNode.attr("signal"));
    }

    connection.receiverName = childText(connectionNode, "receiver");
    if (connection.receiverName.isEmpty()) {
        connection.receiverName = connectionNode.attr("receiver");
    }

    connection.slotName = compat::normalizeMemberName(childText(connectionNode, "slot"));
    if (connection.slotName.isEmpty()) {
        connection.slotName = compat::normalizeMemberName(connectionNode.attr("slot"));
    }
    return connection;
}

inline SwWidget* findNamedWidget(SwWidget* root, const SwString& name) {
    if (!root || name.isEmpty()) {
        return nullptr;
    }
    if (root->getObjectName() == name) {
        return root;
    }
    return root->findChild<SwWidget>(name);
}

inline bool invokeSlot(SwWidget* receiver, const SwString& slotName) {
    if (!receiver) {
        return false;
    }

    const SwString slot = slotName.toLower();
    if(auto* tabs=dynamic_cast<SwTabbedMainWindow*>(receiver)) {
        if(slot=="nexttab"){tabs->nextTab();return true;}
        if(slot=="previoustab"){tabs->previousTab();return true;}
        if(slot=="requestnewtab"){tabs->requestNewTab();return true;}
        if(slot=="requestclosecurrenttab"){tabs->requestCloseCurrentTab();return true;}
        if(slot=="togglerailcollapsed"){tabs->toggleRailCollapsed();return true;}
        if(slot=="showtoptabs"){tabs->showTopTabs();return true;}
        if(slot=="showlefttabs"){tabs->showLeftTabs();return true;}
        if(slot=="togglemaximized"){tabs->toggleMaximized();return true;}
        if(slot=="requestclose"){tabs->requestClose();return true;}
        if(slot=="cleartabs"){tabs->clearTabs();return true;}
    }

    if (auto* toggle = dynamic_cast<SwToggleSwitch*>(receiver)) {
        if (slot == "toggle") { toggle->toggle(); return true; }
        if (slot == "check") { toggle->check(); return true; }
        if (slot == "uncheck") { toggle->uncheck(); return true; }
    }
    if (auto* sidebar = dynamic_cast<SwSideBar*>(receiver)) {
        if (slot == "expand") sidebar->expand();
        else if (slot == "collapse") sidebar->collapse();
        else if (slot == "minimize") sidebar->minimize();
        else if (slot == "useautomaticmode") sidebar->useAutomaticMode();
        else if (slot == "toggle") sidebar->toggle();
        else if (slot == "reveal") sidebar->reveal();
        else if (slot == "dismiss") sidebar->dismiss();
        else if (slot == "pin") sidebar->pin();
        else if (slot == "unpin") sidebar->unpin();
        else if (slot == "togglepinned") sidebar->togglePinned();
        else return slot == "show" ? (sidebar->show(), true)
            : (slot == "hide" || slot == "close") ? (sidebar->hide(), true) : false;
        return true;
    }
    if (slot == "show") {
        receiver->show();
        return true;
    }
    if (slot == "hide" || slot == "close") {
        receiver->hide();
        return true;
    }
    if (slot == "accept" || slot == "accepted") {
        if (auto* dialog = dynamic_cast<SwDialog*>(receiver)) {
            dialog->accept();
            return true;
        }
    }
    if (slot == "reject" || slot == "rejected") {
        if (auto* dialog = dynamic_cast<SwDialog*>(receiver)) {
            dialog->reject();
            return true;
        }
    }
    if (slot == "clear") {
        if (auto* edit = dynamic_cast<SwLineEdit*>(receiver)) {
            edit->setText(SwString());
            return true;
        }
        if (auto* edit = dynamic_cast<SwPlainTextEdit*>(receiver)) {
            edit->clear();
            return true;
        }
        if (auto* edit = dynamic_cast<SwTextEdit*>(receiver)) {
            edit->clear();
            return true;
        }
        if (auto* combo = dynamic_cast<SwComboBox*>(receiver)) {
            combo->clear();
            return true;
        }
    }
    return false;
}

inline bool invokeSlot(SwWidget* receiver, const SwString& slotName, bool value) {
    if (dynamic_cast<SwToggleSwitch*>(receiver) &&
        (slotName.toLower()=="toggle" || slotName.toLower()=="check" || slotName.toLower()=="uncheck"))
        return invokeSlot(receiver,slotName);

    if(dynamic_cast<SwTabbedMainWindow*>(receiver)) {
        for(const char* name:{"nexttab","previoustab","requestnewtab","requestclosecurrenttab","togglerailcollapsed","showtoptabs","showlefttabs","togglemaximized","requestclose","cleartabs"})
            if(slotName.toLower()==name)return invokeSlot(receiver,slotName);
    }
    if (dynamic_cast<SwSideBar*>(receiver)) {
        for (const char* name : {"expand","collapse","minimize","useautomaticmode","toggle","reveal","dismiss","pin","unpin","togglepinned"})
            if (slotName.toLower() == name) return invokeSlot(receiver, slotName);
    }
    if (!receiver) {
        return false;
    }

    const SwString slot = slotName.toLower();
    if (slot == "setvisible" || slot == "visible" || slot == "show") {
        receiver->setVisible(value);
        return true;
    }
    if (slot == "sethidden" || slot == "hide") {
        receiver->setVisible(!value);
        return true;
    }
    if (slot == "setenabled" || slot == "setenable" || slot == "enabled") {
        receiver->setProperty("Enable", SwAny(value));
        return true;
    }
    if (slot == "setdisabled" || slot == "disabled") {
        receiver->setProperty("Enable", SwAny(!value));
        return true;
    }
    if (slot == "setchecked" || slot == "checked" || slot == "toggle") {
        if (auto* cb = dynamic_cast<SwCheckBox*>(receiver)) {
            cb->setChecked(value);
            return true;
        }
        if (auto* rb = dynamic_cast<SwRadioButton*>(receiver)) {
            rb->setChecked(value);
            return true;
        }
        if (auto* pb = dynamic_cast<SwPushButton*>(receiver)) {
            pb->setCheckable(true);
            pb->setChecked(value);
            return true;
        }
        if (auto* tb = dynamic_cast<SwToolButton*>(receiver)) {
            tb->setCheckable(true);
            tb->setChecked(value);
            return true;
        }
    }

    const SwString propertyName = compat::setterSlotToPropertyName(slotName);
    if (!propertyName.isEmpty()) {
        receiver->setProperty(propertyName, SwAny(value));
        return true;
    }
    return invokeSlot(receiver, slotName);
}

inline bool invokeSlot(SwWidget* receiver, const SwString& slotName, int value) {
    if (dynamic_cast<SwToggleSwitch*>(receiver) &&
        (slotName.toLower()=="toggle" || slotName.toLower()=="check" || slotName.toLower()=="uncheck"))
        return invokeSlot(receiver,slotName);

    if(dynamic_cast<SwTabbedMainWindow*>(receiver)) {
        for(const char* name:{"nexttab","previoustab","requestnewtab","requestclosecurrenttab","togglerailcollapsed","showtoptabs","showlefttabs","togglemaximized","requestclose","cleartabs"})
            if(slotName.toLower()==name)return invokeSlot(receiver,slotName);
    }
    if (dynamic_cast<SwSideBar*>(receiver)) {
        for (const char* name : {"expand","collapse","minimize","useautomaticmode","toggle","reveal","dismiss","pin","unpin","togglepinned"})
            if (slotName.toLower() == name) return invokeSlot(receiver, slotName);
    }
    if (!receiver) {
        return false;
    }

    const SwString slot = slotName.toLower();
    if (slot == "setcurrentindex") {
        if (auto* combo = dynamic_cast<SwComboBox*>(receiver)) {
            combo->setCurrentIndex(value);
            return true;
        }
        if (auto* tabs = dynamic_cast<SwTabWidget*>(receiver)) {
            tabs->setCurrentIndex(value);
            return true;
        }
        if (auto* stack = dynamic_cast<SwStackedWidget*>(receiver)) {
            stack->setCurrentIndex(value);
            return true;
        }
        if (auto* toolbox = dynamic_cast<SwToolBox*>(receiver)) {
            toolbox->setCurrentIndex(value);
            return true;
        }
    }
    if (slot == "setvalue") {
        if (auto* spin = dynamic_cast<SwSpinBox*>(receiver)) {
            spin->setValue(value);
            return true;
        }
        if (auto* dspin = dynamic_cast<SwDoubleSpinBox*>(receiver)) {
            dspin->setValue(static_cast<double>(value));
            return true;
        }
        if (auto* slider = dynamic_cast<SwSlider*>(receiver)) {
            slider->setValue(value);
            return true;
        }
        if (auto* progress = dynamic_cast<SwProgressBar*>(receiver)) {
            progress->setValue(value);
            return true;
        }
    }

    const SwString propertyName = compat::setterSlotToPropertyName(slotName);
    if (!propertyName.isEmpty()) {
        receiver->setProperty(propertyName, SwAny(value));
        return true;
    }
    return invokeSlot(receiver, slotName);
}

inline bool invokeSlot(SwWidget* receiver, const SwString& slotName, double value) {
    if (dynamic_cast<SwToggleSwitch*>(receiver) &&
        (slotName.toLower()=="toggle" || slotName.toLower()=="check" || slotName.toLower()=="uncheck"))
        return invokeSlot(receiver,slotName);

    if(dynamic_cast<SwTabbedMainWindow*>(receiver)) {
        for(const char* name:{"nexttab","previoustab","requestnewtab","requestclosecurrenttab","togglerailcollapsed","showtoptabs","showlefttabs","togglemaximized","requestclose","cleartabs"})
            if(slotName.toLower()==name)return invokeSlot(receiver,slotName);
    }
    if (dynamic_cast<SwSideBar*>(receiver)) {
        for (const char* name : {"expand","collapse","minimize","useautomaticmode","toggle","reveal","dismiss","pin","unpin","togglepinned"})
            if (slotName.toLower() == name) return invokeSlot(receiver, slotName);
    }
    if (!receiver) {
        return false;
    }

    const SwString slot = slotName.toLower();
    if (slot == "setvalue") {
        if (auto* dspin = dynamic_cast<SwDoubleSpinBox*>(receiver)) {
            dspin->setValue(value);
            return true;
        }
        if (auto* spin = dynamic_cast<SwSpinBox*>(receiver)) {
            spin->setValue(static_cast<int>(value));
            return true;
        }
        if (auto* slider = dynamic_cast<SwSlider*>(receiver)) {
            slider->setValue(static_cast<int>(value));
            return true;
        }
        if (auto* progress = dynamic_cast<SwProgressBar*>(receiver)) {
            progress->setValue(static_cast<int>(value));
            return true;
        }
    }

    const SwString propertyName = compat::setterSlotToPropertyName(slotName);
    if (!propertyName.isEmpty()) {
        receiver->setProperty(propertyName, SwAny(value));
        return true;
    }
    return invokeSlot(receiver, slotName);
}

inline bool invokeSlot(SwWidget* receiver, const SwString& slotName, const SwString& value) {
    if(auto* tabs=dynamic_cast<SwTabbedMainWindow*>(receiver)) {
        if(slotName.toLower()=="createtab"){tabs->createTab(value);return true;}
    }

    if (dynamic_cast<SwToggleSwitch*>(receiver) &&
        (slotName.toLower()=="toggle" || slotName.toLower()=="check" || slotName.toLower()=="uncheck"))
        return invokeSlot(receiver,slotName);

    if(dynamic_cast<SwTabbedMainWindow*>(receiver)) {
        for(const char* name:{"nexttab","previoustab","requestnewtab","requestclosecurrenttab","togglerailcollapsed","showtoptabs","showlefttabs","togglemaximized","requestclose","cleartabs"})
            if(slotName.toLower()==name)return invokeSlot(receiver,slotName);
    }
    if (dynamic_cast<SwSideBar*>(receiver)) {
        for (const char* name : {"expand","collapse","minimize","useautomaticmode","toggle","reveal","dismiss","pin","unpin","togglepinned"})
            if (slotName.toLower() == name) return invokeSlot(receiver, slotName);
    }
    if (!receiver) {
        return false;
    }

    const SwString slot = slotName.toLower();
    if (slot == "settext" || slot == "text") {
        if (auto* edit = dynamic_cast<SwLineEdit*>(receiver)) {
            edit->setText(value);
            return true;
        }
        if (auto* label = dynamic_cast<SwLabel*>(receiver)) {
            label->setText(value);
            return true;
        }
        if (auto* button = dynamic_cast<SwPushButton*>(receiver)) {
            button->setText(value);
            return true;
        }
        if (auto* button = dynamic_cast<SwToolButton*>(receiver)) {
            button->setText(value);
            return true;
        }
        if (auto* checkbox = dynamic_cast<SwCheckBox*>(receiver)) {
            checkbox->setText(value);
            return true;
        }
        if (auto* radio = dynamic_cast<SwRadioButton*>(receiver)) {
            radio->setText(value);
            return true;
        }
        if (auto* edit = dynamic_cast<SwTextEdit*>(receiver)) {
            edit->setText(value);
            return true;
        }
        if (auto* edit = dynamic_cast<SwPlainTextEdit*>(receiver)) {
            edit->setPlainText(value);
            return true;
        }
    }
    if (slot == "setplaintext") {
        if (auto* edit = dynamic_cast<SwPlainTextEdit*>(receiver)) {
            edit->setPlainText(value);
            return true;
        }
        if (auto* edit = dynamic_cast<SwTextEdit*>(receiver)) {
            edit->setPlainText(value);
            return true;
        }
    }
    if (slot == "sethtml") {
        if (auto* edit = dynamic_cast<SwTextEdit*>(receiver)) {
            edit->setHtml(value);
            return true;
        }
    }
    if (slot == "setcurrenttext") {
        if (auto* combo = dynamic_cast<SwComboBox*>(receiver)) {
            for (int i = 0; i < combo->count(); ++i) {
                if (combo->itemText(i) == value) {
                    combo->setCurrentIndex(i);
                    return true;
                }
            }
            return false;
        }
    }

    const SwString propertyName = compat::setterSlotToPropertyName(slotName);
    if (!propertyName.isEmpty()) {
        receiver->setProperty(propertyName, SwAny(value));
        return true;
    }
    return invokeSlot(receiver, slotName);
}

// Boolean, not Bool: Xlib defines Bool as a macro on Linux.
enum class UiSignalPayload {
    Unsupported,
    Void,
    Boolean,
    Int,
    Double,
    String
};

struct SW_UITOOLS_EXPORT UiSignalBinding {
    SwString name;
    UiSignalPayload payload{UiSignalPayload::Unsupported};
};

inline UiSignalBinding signalBindingFor(SwWidget* sender, const SwString& signalName) {
    if (!sender) {
        return {};
    }

    const SwString signal = signalName.toLower();
    if (dynamic_cast<SwToggleSwitch*>(sender)) {
        if (signal=="toggled" || signal=="clicked") return {signal,UiSignalPayload::Boolean};
        for (const char* name : {"pressed","released","animationFinished"})
            if (signal==SwString(name).toLower()) return {name,UiSignalPayload::Void};
        if (signal=="checkedchanged") return {"CheckedChanged",UiSignalPayload::Boolean};
        if (signal=="appearancechanged") return {"AppearanceChanged",UiSignalPayload::String};
        if (signal=="colorschemechanged") return {"ColorSchemeChanged",UiSignalPayload::String};
        if (signal=="trackwidthchanged") return {"TrackWidthChanged",UiSignalPayload::Int};
        if (signal=="trackheightchanged") return {"TrackHeightChanged",UiSignalPayload::Int};
        if (signal=="trackradiuschanged") return {"TrackRadiusChanged",UiSignalPayload::Int};
        if (signal=="thumbradiuschanged") return {"ThumbRadiusChanged",UiSignalPayload::Int};
        if (signal=="thumbpaddingchanged") return {"ThumbPaddingChanged",UiSignalPayload::Int};
        if (signal=="borderwidthchanged") return {"BorderWidthChanged",UiSignalPayload::Int};
        if (signal=="reliefdepthchanged") return {"ReliefDepthChanged",UiSignalPayload::Int};
        if (signal=="iconextentchanged") return {"IconExtentChanged",UiSignalPayload::Int};
        if (signal=="animationdurationchanged") return {"AnimationDurationChanged",UiSignalPayload::Int};
        if (signal=="lefticonsourcechanged") return {"LeftIconSourceChanged",UiSignalPayload::String};
        if (signal=="righticonsourcechanged") return {"RightIconSourceChanged",UiSignalPayload::String};
        if (signal=="thumbiconsourcechanged") return {"ThumbIconSourceChanged",UiSignalPayload::String};
        if (signal=="checkedthumbiconsourcechanged") return {"CheckedThumbIconSourceChanged",UiSignalPayload::String};
        if (signal=="tinticonschanged") return {"TintIconsChanged",UiSignalPayload::Boolean};
        if (signal=="usecustomcolorschanged") return {"UseCustomColorsChanged",UiSignalPayload::Boolean};
        if (signal=="ontooltipchanged") return {"OnToolTipChanged",UiSignalPayload::String};
        if (signal=="offtooltipchanged") return {"OffToolTipChanged",UiSignalPayload::String};
    }

    if(dynamic_cast<SwTabbedMainWindow*>(sender)) {
        if(signal=="currenttabchanged")return {"currentTabChanged",UiSignalPayload::Int};
        if(signal=="tabcloserequested")return {"tabCloseRequested",UiSignalPayload::Int};
        if(signal=="tabcountchanged")return {"tabCountChanged",UiSignalPayload::Int};
        if(signal=="newtabrequested")return {"newTabRequested",UiSignalPayload::Void};
        if(signal=="tabcreated")return {"tabCreated",UiSignalPayload::Int};
        if(signal=="tabcreationfailed")return {"tabCreationFailed",UiSignalPayload::String};
        if(signal=="tabregistrychanged")return {"tabRegistryChanged",UiSignalPayload::Void};
        if(signal=="tabpositionchanged")return {"TabPositionChanged",UiSignalPayload::String};
        if(signal=="currentindexchanged")return {"CurrentIndexChanged",UiSignalPayload::Int};
        if(signal=="tabsclosablechanged")return {"TabsClosableChanged",UiSignalPayload::Boolean};
        if(signal=="tabsmovablechanged")return {"TabsMovableChanged",UiSignalPayload::Boolean};
        if(signal=="newtabbuttonvisiblechanged")return {"NewTabButtonVisibleChanged",UiSignalPayload::Boolean};
        if(signal=="leftrailcollapsedchanged")return {"LeftRailCollapsedChanged",UiSignalPayload::Boolean};
        if(signal=="railtogglevisiblechanged")return {"RailToggleVisibleChanged",UiSignalPayload::Boolean};
        if(signal=="leftrailwidthchanged")return {"LeftRailWidthChanged",UiSignalPayload::Int};
        if(signal=="collapsedrailwidthchanged")return {"CollapsedRailWidthChanged",UiSignalPayload::Int};
        if(signal=="headerheightchanged")return {"HeaderHeightChanged",UiSignalPayload::Int};
        if(signal=="tabheightchanged")return {"TabHeightChanged",UiSignalPayload::Int};
        if(signal=="tabwidthchanged")return {"TabWidthChanged",UiSignalPayload::Int};
        if(signal=="minimumtabwidthchanged")return {"MinimumTabWidthChanged",UiSignalPayload::Int};
        if(signal=="tabradiuschanged")return {"TabRadiusChanged",UiSignalPayload::Int};
        if(signal=="iconextentchanged")return {"IconExtentChanged",UiSignalPayload::Int};
        if(signal=="colorschemechanged")return {"ColorSchemeChanged",UiSignalPayload::String};
        if(signal=="windowtitlevisiblechanged")return {"WindowTitleVisibleChanged",UiSignalPayload::Boolean};
        if(signal=="minimizebuttonvisiblechanged")return {"MinimizeButtonVisibleChanged",UiSignalPayload::Boolean};
        if(signal=="maximizebuttonvisiblechanged")return {"MaximizeButtonVisibleChanged",UiSignalPayload::Boolean};
        if(signal=="closebuttonvisiblechanged")return {"CloseButtonVisibleChanged",UiSignalPayload::Boolean};
    }
    if (dynamic_cast<SwSideBar*>(sender)) {
        if (signal == "effectivemodechanged") return {"effectiveModeChanged", UiSignalPayload::String};
        if (signal == "revealedchanged") return {"revealedChanged", UiSignalPayload::Boolean};
        if (signal == "dockwidthchanged") return {"dockWidthChanged", UiSignalPayload::Int};
        if (signal == "modechanged") return {"ModeChanged", UiSignalPayload::String};
        if (signal == "edgechanged") return {"EdgeChanged", UiSignalPayload::String};
        if (signal == "pinnedchanged") return {"PinnedChanged", UiSignalPayload::Boolean};
        if (signal == "expandedwidthchanged") return {"ExpandedWidthChanged", UiSignalPayload::Int};
        if (signal == "compactwidthchanged") return {"CompactWidthChanged", UiSignalPayload::Int};
        if (signal == "hiddenwidthchanged") return {"HiddenWidthChanged", UiSignalPayload::Int};
        if (signal == "compactbreakpointchanged") return {"CompactBreakpointChanged", UiSignalPayload::Int};
        if (signal == "hiddenbreakpointchanged") return {"HiddenBreakpointChanged", UiSignalPayload::Int};
        if (signal == "breakpointhysteresischanged") return {"BreakpointHysteresisChanged", UiSignalPayload::Int};
        if (signal == "revealdelaychanged") return {"RevealDelayChanged", UiSignalPayload::Int};
        if (signal == "hidedelaychanged") return {"HideDelayChanged", UiSignalPayload::Int};
        if (signal == "animationdurationchanged") return {"AnimationDurationChanged", UiSignalPayload::Int};
        if (signal == "hoverrevealchanged") return {"HoverRevealChanged", UiSignalPayload::Boolean};
        if (signal == "autohidechanged") return {"AutoHideChanged", UiSignalPayload::Boolean};
        if (signal == "closeonoutsideclickchanged") return {"CloseOnOutsideClickChanged", UiSignalPayload::Boolean};
        if (signal == "pinbuttonvisiblechanged") return {"PinButtonVisibleChanged", UiSignalPayload::Boolean};
        if (signal == "togglebuttonvisiblechanged") return {"ToggleButtonVisibleChanged", UiSignalPayload::Boolean};
        if (signal == "contentpaddingchanged") return {"ContentPaddingChanged", UiSignalPayload::Int};
        if (signal == "itemspacingchanged") return {"ItemSpacingChanged", UiSignalPayload::Int};
        if (signal == "titlechanged") return {"TitleChanged", UiSignalPayload::String};
        if (signal == "colorschemechanged") return {"ColorSchemeChanged", UiSignalPayload::String};
        for (const char* name : {"opened","closed","expanded","collapsed","minimized","animationFinished"})
            if (signal == SwString(name).toLower()) return {name, UiSignalPayload::Void};
    }
    if (signal == "clicked") {
        if (dynamic_cast<SwPushButton*>(sender)) return {"clicked", UiSignalPayload::Void};
        if (dynamic_cast<SwToolButton*>(sender) ||
            dynamic_cast<SwCheckBox*>(sender) ||
            dynamic_cast<SwRadioButton*>(sender)) {
            return {"clicked", UiSignalPayload::Boolean};
        }
    }

    if (signal == "toggled") {
        if (dynamic_cast<SwPushButton*>(sender) ||
            dynamic_cast<SwToolButton*>(sender) ||
            dynamic_cast<SwCheckBox*>(sender) ||
            dynamic_cast<SwRadioButton*>(sender) ||
            dynamic_cast<SwGroupBox*>(sender)) {
            return {"toggled", UiSignalPayload::Boolean};
        }
    }

    if (signal == "statechanged" && dynamic_cast<SwCheckBox*>(sender)) {
        return {"stateChanged", UiSignalPayload::Int};
    }

    if ((signal == "currentindexchanged" || signal == "activated" || signal == "highlighted") &&
        dynamic_cast<SwComboBox*>(sender)) {
        if (signal == "currentindexchanged") return {"currentIndexChanged", UiSignalPayload::Int};
        if (signal == "activated") return {"activated", UiSignalPayload::Int};
        return {"highlighted", UiSignalPayload::Int};
    }

    if (signal == "currenttextchanged" && dynamic_cast<SwComboBox*>(sender)) {
        return {"currentTextChanged", UiSignalPayload::String};
    }

    if (signal == "currentchanged") {
        if (dynamic_cast<SwTabWidget*>(sender) ||
            dynamic_cast<SwStackedWidget*>(sender) ||
            dynamic_cast<SwToolBox*>(sender)) {
            return {"currentChanged", UiSignalPayload::Int};
        }
    }

    if (signal == "valuechanged") {
        if (dynamic_cast<SwDoubleSpinBox*>(sender)) return {"valueChanged", UiSignalPayload::Double};
        if (dynamic_cast<SwSpinBox*>(sender) ||
            dynamic_cast<SwSlider*>(sender) ||
            dynamic_cast<SwProgressBar*>(sender)) {
            return {"valueChanged", UiSignalPayload::Int};
        }
    }

    if (signal == "textchanged" || signal == "textedited") {
        if (dynamic_cast<SwLineEdit*>(sender)) return {"TextChanged", UiSignalPayload::String};
        if (dynamic_cast<SwPlainTextEdit*>(sender) || dynamic_cast<SwTextEdit*>(sender)) {
            return {"textChanged", UiSignalPayload::Void};
        }
    }

    if (signal == "visibilitychanged") {
        return {"visibilityChanged", UiSignalPayload::Void};
    }

    if (signal == "focuschanged") {
        return {"FocusChanged", UiSignalPayload::Boolean};
    }

    return {};
}

inline bool connectSignalToSlot(SwWidget* sender, SwWidget* receiver, const UiConnection& connection) {
    if (!sender || !receiver || connection.signalName.isEmpty() || connection.slotName.isEmpty()) {
        return false;
    }

    if(auto* tabs=dynamic_cast<SwTabbedMainWindow*>(sender)) {
        if(connection.signalName.toLower()=="tabmoved") {
            SwObject::connect(tabs,&SwTabbedMainWindow::tabMoved,receiver,[receiver,slot=connection.slotName](int,int){invokeSlot(receiver,slot);});return true;
        }
    }
    const UiSignalBinding binding = signalBindingFor(sender, connection.signalName);
    if (binding.payload == UiSignalPayload::Unsupported || binding.name.isEmpty()) {
        return false;
    }

    const SwString slot = connection.slotName;
    switch (binding.payload) {
    case UiSignalPayload::Void:
        SwObject::connect(sender, binding.name, receiver, [receiver, slot]() { invokeSlot(receiver, slot); });
        return true;
    case UiSignalPayload::Boolean:
        SwObject::connect(sender, binding.name, receiver, [receiver, slot](bool value) { invokeSlot(receiver, slot, value); });
        return true;
    case UiSignalPayload::Int:
        SwObject::connect(sender, binding.name, receiver, [receiver, slot](int value) { invokeSlot(receiver, slot, value); });
        return true;
    case UiSignalPayload::Double:
        SwObject::connect(sender, binding.name, receiver, [receiver, slot](double value) { invokeSlot(receiver, slot, value); });
        return true;
    case UiSignalPayload::String:
        SwObject::connect(sender, binding.name, receiver, [receiver, slot](const SwString& value) { invokeSlot(receiver, slot, value); });
        return true;
    case UiSignalPayload::Unsupported:
    default:
        return false;
    }
}

inline void connectOne(SwWidget* root, const SwXmlNode& connectionNode) {
    const UiConnection connection = parseConnection(connectionNode);
    if (connection.senderName.isEmpty() || connection.receiverName.isEmpty() ||
        connection.signalName.isEmpty() || connection.slotName.isEmpty()) {
        return;
    }

    SwWidget* sender = findNamedWidget(root, connection.senderName);
    SwWidget* receiver = findNamedWidget(root, connection.receiverName);
    if (!sender || !receiver) {
        return;
    }

    (void)connectSignalToSlot(sender, receiver, connection);
}

inline void connectDeclaredUiConnections(SwWidget* root, const SwXmlNode& uiRoot) {
    if (!root) {
        return;
    }

    const SwXmlNode* connectionsNode = uiRoot.firstChild("connections");
    if (connectionsNode) {
        for (const auto* connectionNode : connectionsNode->childrenNamed("connection")) {
            if (connectionNode) {
                connectOne(root, *connectionNode);
            }
        }
        for (const auto* connectionNode : connectionsNode->childrenNamed("connect")) {
            if (connectionNode) {
                connectOne(root, *connectionNode);
            }
        }
    }

    for (const auto* connectionNode : uiRoot.childrenNamed("connect")) {
        if (connectionNode) {
            connectOne(root, *connectionNode);
        }
    }
}

} // namespace swui::detail
