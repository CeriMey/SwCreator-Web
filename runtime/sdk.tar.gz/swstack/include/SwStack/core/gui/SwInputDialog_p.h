#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwInputDialog.h"

struct SwInputDialog::Data {
    InputMode m_mode{TextInput};
    SwLabel* m_label{nullptr};
    SwLineEdit* m_lineEdit{nullptr};
    SwSpinBox* m_spinBox{nullptr};
    SwDoubleSpinBox* m_doubleSpinBox{nullptr};
    SwComboBox* m_comboBox{nullptr};
    SwPushButton* m_ok{nullptr};
    SwPushButton* m_cancel{nullptr};
};
