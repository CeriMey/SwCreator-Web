#pragma once
#include "SwMainWindow.h"
#include <functional>
#include <vector>

class SwMenu;

/** Browser-style window chrome, with an optional registry of owned widget pages.
 * Without a registry, the application handles newTabRequested and its own content.
 * Registry pages are created lazily, selected automatically and deleted on removeTab.
 * Closing is always a request, so unsaved changes can be handled before removeTab().
 */
class SW_WIDGETS_EXPORT SwTabbedMainWindow : public SwMainWindow {
    SW_OBJECT(SwTabbedMainWindow, SwMainWindow)
public:
    using TabFactory = std::function<SwWidget*(SwWidget* parent)>;
    struct TabType {
        SwString id;        // Stable application identifier.
        SwString name;      // Menu label and default title of new tabs.
        SwIcon icon;        // Used in both the menu and newly created tabs.
        TabFactory factory; // May be empty when createTabWidget() is overridden.
    };
    using TabRegistry = std::vector<TabType>;
    explicit SwTabbedMainWindow(const SwString& title = "Application", int width = 1100, int height = 760);
    ~SwTabbedMainWindow() override;
    SW_PROPERTY_D(SwString, TabPosition);
    SW_PROPERTY_D(SwStringList, Tabs);
    SW_PROPERTY_D(int, CurrentIndex);
    SW_PROPERTY_D(bool, TabsClosable);
    SW_PROPERTY_D(bool, TabsMovable);
    SW_PROPERTY_D(bool, NewTabButtonVisible);
    SW_PROPERTY_D(bool, LeftRailCollapsed);
    SW_PROPERTY_D(bool, RailToggleVisible);
    SW_PROPERTY_D(int, LeftRailWidth);
    SW_PROPERTY_D(int, CollapsedRailWidth);
    SW_PROPERTY_D(int, HeaderHeight);
    SW_PROPERTY_D(int, TabHeight);
    SW_PROPERTY_D(int, TabWidth);
    SW_PROPERTY_D(int, MinimumTabWidth);
    SW_PROPERTY_D(int, TabRadius);
    SW_PROPERTY_D(int, IconExtent);
    SW_PROPERTY_D(SwString, ColorScheme);
    SW_PROPERTY_D(SwColor, AccentColor);
    SW_PROPERTY_D(bool, WindowTitleVisible);
    SW_PROPERTY_D(bool, MinimizeButtonVisible);
    SW_PROPERTY_D(bool, MaximizeButtonVisible);
    SW_PROPERTY_D(bool, CloseButtonVisible);
public:
    int count() const;
    int currentIndex() const;
    SwString tabText(int index) const;
    int addTab(const SwString& text);
    int insertTab(int index, const SwString& text);
    void removeTab(int index);
    void moveTab(int from, int to);
    void clearTabs();
    void setTabText(int index, const SwString& text);
    void setTabIcon(int index, const SwIcon& icon);
    void setTabIconSource(int index, const SwString& source);
    SwString tabIconSource(int index) const;
    SwIcon tabIcon(int index) const;
    // Re-registering an id replaces its definition without affecting existing pages.
    bool registerTabType(const TabType& type);
    bool registerTabType(const SwString& id, const SwString& name, const SwIcon& icon, TabFactory factory);
    template<class Widget>
    bool registerTabType(const SwString& id, const SwString& name, const SwIcon& icon = SwIcon()) {
        return registerTabType(id, name, icon, [](SwWidget* parent) { return new Widget(parent); });
    }
    bool unregisterTabType(const SwString& id);
    bool setTabRegistry(const TabRegistry& registry);
    TabRegistry tabRegistry() const;
    void clearTabRegistry();
    // Returns -1 if the type is unknown or its factory fails. No empty tab is added.
    int createTab(const SwString& typeId);
    SwWidget* tabWidget(int index) const;
    SwWidget* currentTabWidget() const;
    SwString tabTypeId(int index) const;
    SwMenu* newTabMenu() const;
    SwWidget* titleBar() const;
    SwWidget* tabBar() const;
    int titleBarHeight() const;
    bool hasCustomTitleBar() const;
    bool isMaximized() const;
    void resizeNativeWindow(const SwSize& size);
    void refreshTitleBar();
    // Stable test/integration geometry, local to tabBar(). Empty if clipped/offscreen.
    SwRect tabRect(int index) const;
    SwRect tabCloseRect(int index) const;
    SwRect newTabButtonRect() const;
    void nextTab();
    void previousTab();
    void requestNewTab();
    void requestCloseCurrentTab();
    void toggleRailCollapsed();
    void showTopTabs();
    void showLeftTabs();
    void toggleMaximized();
    void requestClose();
    SW_SIGNAL(currentTabChanged, int);
    SW_SIGNAL(tabCloseRequested, int);
    SW_SIGNAL(tabMoved, int, int);
    SW_SIGNAL(tabCountChanged, int);
    SW_SIGNAL_VOID(newTabRequested);
    SW_SIGNAL(tabCreated, int);
    SW_SIGNAL(tabCreationFailed, const SwString&);
    SW_SIGNAL_VOID(tabRegistryChanged);
protected:
    virtual SwWidget* createTabWidget(const TabType& type, SwWidget* parent);
    virtual SwString newTabTitle(const TabType& type, SwWidget* widget) const;
    virtual SwIcon newTabIcon(const TabType& type, SwWidget* widget) const;
    virtual void populateNewTabMenu(SwMenu* menu);
private:
    void invalidateNewTabMenu_();
    void replaceTabs_(const SwStringList& tabs, int current, bool currentDocumentChanged = false);
    struct Data;
    SwObjectDataPointer<Data> d_;
};
