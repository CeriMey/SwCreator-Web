﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

// MainWindow.h
#pragma once

#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwMainWindow.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwMainWindow in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the main window interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwMainWindow.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

#include "SwGuiApplication.h"
#include "SwDialog.h"
#include "SwLabel.h"
#include "SwMenuBar.h"
#include "SwPushButton.h"
#include "SwStatusBar.h"
#include "SwIcon.h"
#include "SwTextEdit.h"
#include "SwToolBar.h"
#include "SwWidget.h"
#include "SwDragDrop.h"
#include "SwToolTip.h"
#include "SwShortcut.h"
#include "SwString.h"
#include <chrono>
#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>


class SW_WIDGETS_EXPORT SwMainWindow : public SwWidget {
public:
    SW_OBJECT(SwMainWindow, SwWidget)

    /**
     * @brief Constructs the SwMainWindow and registers it with SwGuiApplication.
     * @param title Title of the window.
     * @param width Width of the window.
     * @param height Height of the window.
     */
    SwMainWindow(const std::wstring& title = L"Main Window", int width = 800, int height = 600);

    /**
     * @brief Constructs a `SwMainWindow` instance.
     * @param title Title text applied by the operation.
     * @param width Width value.
     * @param height Height value.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwMainWindow(const SwString& title, int width = 800, int height = 600);

    /**
     * @brief Constructs a `SwMainWindow` instance.
     * @param title Title text applied by the operation.
     * @param width Width value.
     * @param height Height value.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwMainWindow(const wchar_t* title, int width = 800, int height = 600);

    /**
     * @brief Constructs a `SwMainWindow` instance.
     * @param title Title text applied by the operation.
     * @param width Width value.
     * @param height Height value.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwMainWindow(const char* title, int width = 800, int height = 600);

    /**
     * @brief Destructor. Deregisters the window from SwGuiApplication.
     */
    ~SwMainWindow() override;

    /**
     * @brief Shows the window.
     *
     * Displays the window.
     */
    void show() override;

    /**
     * @brief Hides the window.
     *
     * Hides the window from the screen.
     */
    void hide() override;

    /**
     * @brief Minimizes the window.
     *
     * Reduces the window to the taskbar.
     */
    void showMinimized();

    /**
     * @brief Maximizes the window.
     *
     * Expands the window to fill the screen.
     */
    void showMaximized();

    /// Moves the native window to @p position on the screen, as SwDialog::moveNativeWindow().
    void moveNativeWindow(const SwPoint& position);
    /// Gives the native window @p size, as SwDialog::resizeNativeWindow().
    void resizeNativeWindow(const SwSize& size);

    /**
     * @brief Restores the window.
     *
     * Restores the window to its original size and position.
     */
    void showNormal();

    // Main window chrome helpers.
    /**
     * @brief Performs the `menuBar` operation.
     * @return The requested menu Bar.
     */
    SwMenuBar* menuBar();
    /**
     * @brief Returns the current menu Bar.
     * @return The current menu Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwMenuBar* menuBar() const;

    /**
     * @brief Performs the `toolBar` operation.
     * @return The requested tool Bar.
     */
    SwToolBar* toolBar();
    /**
     * @brief Returns the current tool Bar.
     * @return The current tool Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwToolBar* toolBar() const;

    /**
     * @brief Performs the `statusBar` operation.
     * @return The requested status Bar.
     */
    SwStatusBar* statusBar();
    /**
     * @brief Returns the current status Bar.
     * @return The current status Bar.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwStatusBar* statusBar() const;

    /**
     * @brief Performs the `helpMenu` operation.
     * @return The requested help Menu.
     */
    SwMenu* helpMenu();
    /**
     * @brief Returns the current help Menu.
     * @return The current help Menu.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwMenu* helpMenu() const;

    /**
     * @brief Performs the `centralWidget` operation.
     * @return The requested central Widget.
     */
    SwWidget* centralWidget();
    /**
     * @brief Returns the current central Widget.
     * @return The current central Widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* centralWidget() const;

    // Backward compatible: layouts are applied to the central widget.
    /**
     * @brief Sets the layout.
     * @param layout Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLayout(SwAbstractLayout* layout);
    /**
     * @brief Performs the `layout` operation.
     * @return The requested layout.
     */
    SwAbstractLayout* layout() const;

    /**
     * @brief Defines the states for the window.
     */
    enum class WindowState {
        Minimized,
        Maximized,
        Normal
    };

    /**
     * @brief Sets the window to the specified state.
     *
     * Adjusts the window's display state based on the provided value.
     *
     * @param state The desired window state.
     */
    void setWindowState(WindowState state);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const std::wstring& title);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const SwString& title);

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const wchar_t* title);

    /**
     * @brief Sets the window icon (taskbar + title bar).
     * @param icon SwIcon to use as the window icon.
     */
    void setWindowIcon(const SwIcon& icon);

    const SwIcon& windowIcon() const;

    /**
     * @brief Sets the window Title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowTitle(const char* title);

    /**
     * @brief Returns the current window Title.
     * @return The current window Title.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const std::wstring& windowTitle() const;

    /**
     * @brief Sets the window Flags.
     * @param flags Flags that refine the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWindowFlags(WindowFlags flags);

    /**
     * @brief Returns the current window Flags.
     * @return The current window Flags.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    WindowFlags getWindowFlags() const;

    // Public event dispatch helpers (useful for popups / overlays).
    /**
     * @brief Performs the `dispatchMousePress` operation.
     * @param x Horizontal coordinate.
     * @param Left Value passed to the method.
     */
    void dispatchMousePress(int x, int y);
    /**
     * @brief Performs the `dispatchMouseRelease` operation.
     * @param x Horizontal coordinate.
     * @param Left Value passed to the method.
     */
    void dispatchMouseRelease(int x, int y);

private:


    static SwString defaultAboutHtml();

#if defined(_WIN32)
    HWND nativeHwnd_() const;
#endif

    void ensureAboutDialog();

    void showAboutDialog();

    void ensureChrome();

    void ensureToolBar();

    // Event Handlers

    void handlePaintRequest(const SwPlatformPaintEvent& paintEvent);

    SwPlatformSize implicitMinimumClientSize_() const;

    void applyWindowTitle();

    void handleDeleteRequest(bool requestAppExit);

    /**
     * @brief Handles window deletion.
     */
    void onDelete();

    /**
     * @brief Handles resize events.
     *
     * Adjusts the size of the widget based on the given width and height dimensions.
     *
     * @param width The new width of the widget.
     * @param height The new height of the widget.
     */
    void onResize(int width, int height);


    /**
     * @brief Handles mouse press events.
     * @param x X-coordinate of the mouse.
     * @param y Y-coordinate of the mouse.
     */
    void onMousePress(int x,
                      int y,
                      SwMouseButton button = SwMouseButton::Left,
                      bool ctrlPressed = false,
                      bool shiftPressed = false,
                      bool altPressed = false);

    /**
     * @brief Handles mouse release events.
     * @param x X-coordinate of the mouse.
     * @param y Y-coordinate of the mouse.
     */
    void onMouseRelease(int x,
                        int y,
                        SwMouseButton button = SwMouseButton::Left,
                        bool ctrlPressed = false,
                        bool shiftPressed = false,
                        bool altPressed = false);

    /**
     * @brief Handles mouse double-click events.
     * @param x X-coordinate of the mouse.
     * @param y Y-coordinate of the mouse.
     */
    void onMouseDoubleClick(int x,
                            int y,
                            SwMouseButton button = SwMouseButton::Left,
                            bool ctrlPressed = false,
                            bool shiftPressed = false,
                            bool altPressed = false);

    /**
     * @brief Handles mouse move events.
     * @param x X-coordinate of the mouse.
     * @param y Y-coordinate of the mouse.
     */
    void onMouseMove(int x, int y, bool ctrlPressed = false, bool shiftPressed = false, bool altPressed = false);

    void onMouseLeave();

    void onMouseWheel(int x, int y, int delta, bool ctrlPressed, bool shiftPressed, bool altPressed);

    /**
     * @brief Handles key press events.
     * @param keyCode Virtual key code.
     * @param ctrlPressed Whether Ctrl is pressed.
     * @param shiftPressed Whether Shift is pressed.
     * @param altPressed Whether Alt is pressed.
     */
    void onKeyPress(int keyCode, bool ctrlPressed, bool shiftPressed, bool altPressed, wchar_t textChar = L'\0', bool textProvided = false);

    void onKeyRelease(int keyCode, bool ctrlPressed, bool shiftPressed, bool altPressed);

#if defined(_WIN32)
    static std::wstring decodeWindowTitleFromChar_(const char* title);
#endif

#if !defined(_WIN32)
    static std::wstring decodeWindowTitleFromChar_(const char* title);
#endif

    static std::string toUtf8(const std::wstring& value);

    void handleMouseEvent(EventType type, const SwMouseEvent& event);

    void handleMouseMove(const SwMouseEvent& event);

    void handleMouseLeave();

    void handleWheelEvent(const SwMouseEvent& event);

    void handleKeyEvent(const SwKeyEvent& event);

    void handleKeyReleaseEvent(const SwKeyEvent& event);
private:
    // What the class keeps (SwMainWindow_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
