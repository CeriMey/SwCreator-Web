/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwKeySequence.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwKeySequence in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the key sequence interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwKey and SwKeySequence.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwKeySequence - key sequence helper.
 *
 * Scope (v1):
 * - Stores a single key + modifiers (Ctrl/Shift/Alt).
 * - Cross-platform matching using SwWidgetPlatformAdapter helpers for common keys.
 * - Optional string parsing (e.g. "Ctrl+Shift+A", "Alt+Up", "Esc").
 **************************************************************************************************/

#include "SwWidgetPlatformAdapter.h"

#include "core/types/SwString.h"

#include <cctype>

enum class SwKey {
    Unknown = 0,
    Character,
    Up,
    Down,
    Left,
    Right,
    Home,
    End,
    Return,
    Escape,
    Backspace,
    Delete,
    Space,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
    PageUp,
    PageDown,
    Tab
};

class SW_GUI_EXPORT SwKeySequence {
public:
    /**
     * @brief Constructs a `SwKeySequence` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwKeySequence();

    /**
     * @brief Constructs a `SwKeySequence` instance.
     * @param ch Value passed to the method.
     * @param ctrl Value passed to the method.
     * @param shift Value passed to the method.
     * @param alt Value passed to the method.
     * @param alt Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwKeySequence(char ch, bool ctrl = false, bool shift = false, bool alt = false);

    /**
     * @brief Constructs a `SwKeySequence` instance.
     * @param key Value passed to the method.
     * @param ctrl Value passed to the method.
     * @param shift Value passed to the method.
     * @param alt Value passed to the method.
     * @param alt Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwKeySequence(SwKey key, bool ctrl = false, bool shift = false, bool alt = false);

    /**
     * @brief Returns whether the object reports valid.
     * @return `true` when the object reports valid; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isValid() const;

    /**
     * @brief Returns the current key.
     * @return The current key.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwKey key() const;
    /**
     * @brief Returns the current character.
     * @return The current character.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    char character() const;
    /**
     * @brief Returns the current ctrl.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool ctrl() const;
    /**
     * @brief Returns the current shift.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool shift() const;
    /**
     * @brief Returns the current alt.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool alt() const;

    /**
     * @brief Sets the enabled Modifiers.
     * @param ctrl Value passed to the method.
     * @param shift Value passed to the method.
     * @param alt Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEnabledModifiers(bool ctrl, bool shift, bool alt);

    /**
     * @brief Performs the `matches` operation.
     * @param keyCode Value passed to the method.
     * @param ctrlPressed Value passed to the method.
     * @param shiftPressed Value passed to the method.
     * @param altPressed Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool matches(int keyCode, bool ctrlPressed, bool shiftPressed, bool altPressed) const;

    /**
     * @brief Returns the current to String.
     * @return The current to String.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString toString() const;

    /**
     * @brief Performs the `fromString` operation.
     * @param text Value passed to the method.
     * @return The requested from String.
     */
    static SwKeySequence fromString(const SwString& text);

    /**
     * @brief Performs the `operator==` operation.
     * @param other Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator==(const SwKeySequence& other) const;

    /**
     * @brief Performs the `operator!=` operation.
     * @param this Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator!=(const SwKeySequence& other) const;

private:
    SwString keyName_() const;

public:
    ~SwKeySequence();
public:
    SwKeySequence(const SwKeySequence& other);
    SwKeySequence& operator=(const SwKeySequence& other);
private:
    // What the class keeps (SwKeySequence_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
