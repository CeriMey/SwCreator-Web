/**
 * @file src/core/gui/graphics/SwImageBmpCodec.h
 * @ingroup core_graphics
 * @brief Declares the built-in BMP codec in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the BMP codec interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwImageBmpCodec.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief BMP reader / writer moved out of the old SwImage.h, behaviour-identical.
 *
 * Reader: BITMAPFILEHEADER + BITMAPINFOHEADER (>= 40 bytes), BI_RGB, 1 plane, 24 or 32 bpp,
 * bottom-up (positive height) or top-down (negative height); the pixel data offset and
 * biSizeImage are honoured exactly as the old loader did. Writer: 32-bit BGRA, top-down, BI_RGB,
 * 72 DPI, same header bytes as the old SwImage::save().
 *
 * Include-order note: no `#pragma once`; "SwImageCodec.h" is included first, outside the body
 * guard (see SwImageCodec.h).
 */

#include "SwImageCodec.h"

#ifndef SW_IMAGE_BMP_CODEC_H_BODY
#define SW_IMAGE_BMP_CODEC_H_BODY

#include "../../SwStackExport.h"

#include "SwString.h"
#include "SwByteArray.h"
#include "SwDebug.h"

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <vector>

static constexpr const char* kSwLogCategory_SwImageBmpCodec = "sw.gui.swimagebmpcodec";

/**
 * @brief Built-in uncompressed BMP codec (priority 0).
 */
class SW_GUI_EXPORT SwImageBmpCodec : public SwImageCodec {
public:
    /**
     * @brief Returns "bmp".
     * @return The id.
     */
    const SwString& id() const override;

    /**
     * @brief Built-in priority.
     * @return 0.
     */
    int priority() const override;

    /**
     * @brief Sniffs the "BM" signature.
     * @param magic Stream start.
     * @param n Bytes available.
     * @return `true` for "BM".
     */
    bool canDecode(const std::uint8_t* magic, std::size_t n) const override;

    /**
     * @brief Encodes "bmp" only.
     * @param format Normalized format name.
     * @return `true` for "bmp".
     */
    bool canEncode(const SwString& format) const override;

    /**
     * @brief Decodes a 24 / 32-bit BI_RGB bitmap into a BGRA32 image.
     * @param bytes Encoded bytes.
     * @param size Byte count.
     * @param out Receives the image.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool decode(const std::uint8_t* bytes, std::size_t size, SwImage& out, SwString* error) override;

    /**
     * @brief Encodes the legacy BGRA32 view as a 32-bit top-down BI_RGB bitmap.
     * @param image Image to encode.
     * @param format Normalized format name ("bmp").
     * @param options Unused.
     * @param out Receives the file bytes.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool encode(const SwImage& image, const SwString& format, const SwImageCodecOptions& options,
                SwByteArray& out, SwString* error) override;

private:
    static std::uint16_t readU16_(const std::uint8_t* p);

    static std::uint32_t readU32_(const std::uint8_t* p);

    static std::int32_t readS32_(const std::uint8_t* p);

    static void appendU16_(SwByteArray& out, std::uint16_t v);

    static void appendU32_(SwByteArray& out, std::uint32_t v);

    static void appendS32_(SwByteArray& out, std::int32_t v);
};

#endif // SW_IMAGE_BMP_CODEC_H_BODY
