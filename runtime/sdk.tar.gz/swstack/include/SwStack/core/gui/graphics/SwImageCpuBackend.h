#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImageCpuBackend.h
 * @ingroup core_graphics
 * @brief Declares the CPU reference image backend in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the CPU backend interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwImageCpuBackend and the SwImageCpuKernels
 * namespace holding the exact integer pixel math shared by the scalar and SIMD paths.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Reference and fallback backend: every op, every format pair, scalar first.
 *
 * Contract (see SwImagePipeline.md §8): priority 0, CPU in / CPU out, fusesChains = true (ops
 * are executed sequentially into scratch buffers, an adjacent Crop + Scale runs as one pass),
 * every loop bounds-checked against SwImageLayout, unsupported input fails with a clear error
 * string and never crashes.
 *
 * Format coverage:
 * - Convert: every pair among Gray8 / RGB24 / BGR24 / RGBA32 / BGRA32 (packed 8-bit), between
 *   those and NV12 / YUV420P / YUY2 / P010 / P016, and between the YUV formats themselves
 *   (NV12 <-> YUV420P is a direct plane shuffle, the other YUV pairs go through 8-bit Y / U / V
 *   rows with chroma resampled by the same 2x2 / pair averaging as RGB -> YUV).
 * - Crop: every format (unaligned origins copy with nearest chroma; YUY2 odd origins re-pair).
 * - Scale / Flip / Rotate / WarpAffine / WarpPerspective / Remap / Composite: directly on the
 *   packed 8-bit formats; a planar / 16-bit / YUY2 input is converted to BGRA32 internally and
 *   converted back only when the chain does not end in a packed 8-bit format.
 *
 * Pixel math is exact integer arithmetic (SwImageCpuKernels) so that the scalar path, the SSE2
 * / NEON kernels and an independent reference agree bit for bit:
 * - YUV -> RGB limited range: C = Y - 16, D = U - 128, E = V - 128, BT.601 (default when the
 *   colour space is Undefined) R = clamp8((298 C + 409 E + 128) >> 8), G = clamp8((298 C -
 *   100 D - 208 E + 128) >> 8), B = clamp8((298 C + 516 D + 128) >> 8); BT.709 / BT.2020 use
 *   their own coefficients (see yuvToRgbCoeffs).
 * - RGB -> YUV limited range: BT.601 Y = ((66 R + 129 G + 25 B + 128) >> 8) + 16,
 *   U = ((-38 R - 74 G + 112 B + 128) >> 8) + 128, V = ((112 R - 94 G - 18 B + 128) >> 8) + 128.
 * - 4:2:0 chroma from RGB averages each 2x2 block as (sum + 2) >> 2 (edge blocks average the
 *   available samples, rounding half up); 4:2:0 -> RGB uses nearest chroma. YUY2 shares chroma
 *   per pixel pair. P010 / P016 are reduced to 8 bits (word >> 8) before conversion and
 *   produced as (byte << 8).
 * - Gray8 from RGB: (77 R + 150 G + 29 B + 128) >> 8. Alpha is dropped or set to 255.
 * - Scale Nearest: sx = ((2 dx + 1) srcW) / (2 dstW). Linear: fx = (dx + 0.5) srcW / dstW - 0.5
 *   clamped, x0 = floor(fx), x1 = min(x0 + 1, srcW - 1), wx = round((fx - x0) 256),
 *   out = (p00 (256 - wx)(256 - wy) + p10 wx (256 - wy) + p01 (256 - wx) wy + p11 wx wy +
 *   32768) >> 16. Area: box filter with 1/256 coverage weights (Linear on an upscaled axis).
 *   Cubic: Catmull-Rom, 4 taps, 1/256 fixed point, clamped.
 * - Composite SourceOver (straight alpha): a = (srcA round(alpha 255) + 127) / 255,
 *   out = (src a + dst (255 - a) + 127) / 255, outA = a + (dstA (255 - a) + 127) / 255.
 * - Warp: destination -> source mapping with pixel centres at +0.5, sampled at (sx - 0.5,
 *   sy - 0.5); Remap meshes give (sx, sy) in the same pixel-centre convention (an identity
 *   mesh holds x + 0.5, y + 0.5). Rotate90 is clockwise.
 *
 * SIMD kernels exist only for NV12 / YUV420P -> BGRA32, BGRA32 -> NV12 / YUV420P, the
 * BGRA32 <-> RGBA32 swizzle and the bilinear scale of BGRA32; they are gated at runtime by
 * setSimdEnabled() (configuration, not instrumentation) so a self-test can prove SIMD == scalar.
 */

#include "SwImageBackend.h"
#include "SwImageOps.h"
#include "SwImageStorage.h"
#include "SwPixelFormat.h"
#include "SwString.h"
#include "SwDebug.h"
#include "Sw.h"

#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <memory>
#include <vector>

#if defined(__SSE2__) || defined(_M_X64)
#include <emmintrin.h>
#define SW_IMAGE_CPU_HAVE_SSE2 1
#elif defined(__ARM_NEON)
#include <arm_neon.h>
#define SW_IMAGE_CPU_HAVE_NEON 1
#endif

static constexpr const char* kSwLogCategory_SwImageCpuBackend = "sw.gui.swimagecpubackend";

/**
 * @brief Exact integer pixel math shared by the CPU backend, its SIMD kernels and self-tests.
 */
namespace SwImageCpuKernels {

/**
 * @brief YUV -> RGB coefficients of the `298 * C` limited-range formulas.
 */
struct SW_GUI_EXPORT YuvToRgbCoeffs {
    int rv;   ///< R += rv * E
    int gu;   ///< G -= gu * D
    int gv;   ///< G -= gv * E
    int bu;   ///< B += bu * D
};

/**
 * @brief RGB -> YUV coefficients of the `(... + 128) >> 8` limited-range formulas.
 */
struct SW_GUI_EXPORT RgbToYuvCoeffs {
    int yr; int yg; int yb;
    int ur; int ug; int ub;
    int vr; int vg; int vb;
};

/**
 * @brief Resolves the colour space used by a YUV <-> RGB conversion.
 * @param opCs Colour space requested by the Convert op (Undefined = keep the input tag).
 * @param srcCs Colour space tag of the input storage.
 * @return `opCs` when defined, else `srcCs` when defined, else BT.601.
 */
inline SwColorSpace effectiveColorSpace(SwColorSpace opCs, SwColorSpace srcCs) {
    if (opCs != SwColorSpace::Undefined) {
        return opCs;
    }
    if (srcCs != SwColorSpace::Undefined) {
        return srcCs;
    }
    return SwColorSpace::BT601;
}

/**
 * @brief Returns the YUV -> RGB coefficients of a colour space (BT.601 for Undefined).
 * @param cs Colour space.
 * @return Coefficients.
 */
inline YuvToRgbCoeffs yuvToRgbCoeffs(SwColorSpace cs) {
    YuvToRgbCoeffs k;
    switch (cs) {
    case SwColorSpace::BT709:  k.rv = 459; k.gu = 55;  k.gv = 136; k.bu = 541; break;
    case SwColorSpace::BT2020: k.rv = 430; k.gu = 48;  k.gv = 167; k.bu = 548; break;
    default:                   k.rv = 409; k.gu = 100; k.gv = 208; k.bu = 516; break;
    }
    return k;
}

/**
 * @brief Returns the RGB -> YUV coefficients of a colour space (BT.601 for Undefined).
 * @param cs Colour space.
 * @return Coefficients.
 */
inline RgbToYuvCoeffs rgbToYuvCoeffs(SwColorSpace cs) {
    RgbToYuvCoeffs k;
    switch (cs) {
    case SwColorSpace::BT709:
        k.yr = 47;  k.yg = 157;  k.yb = 16;
        k.ur = -26; k.ug = -87;  k.ub = 112;
        k.vr = 112; k.vg = -102; k.vb = -10;
        break;
    case SwColorSpace::BT2020:
        k.yr = 56;  k.yg = 145;  k.yb = 13;
        k.ur = -30; k.ug = -79;  k.ub = 109;
        k.vr = 109; k.vg = -100; k.vb = -9;
        break;
    default:
        k.yr = 66;  k.yg = 129;  k.yb = 25;
        k.ur = -38; k.ug = -74;  k.ub = 112;
        k.vr = 112; k.vg = -94;  k.vb = -18;
        break;
    }
    return k;
}

/**
 * @brief Clamps an integer to [0, 255].
 * @param v Value.
 * @return Clamped byte.
 */
inline std::uint8_t clamp8(int v) {
    return static_cast<std::uint8_t>(v < 0 ? 0 : (v > 255 ? 255 : v));
}

/**
 * @brief Converts one limited-range YUV sample to RGB.
 * @param k Coefficients.
 * @param Y Luma (0..255).
 * @param U Chroma U (0..255).
 * @param V Chroma V (0..255).
 * @param r Receives red.
 * @param g Receives green.
 * @param b Receives blue.
 */
inline void yuvToRgb(const YuvToRgbCoeffs& k, int Y, int U, int V,
                     std::uint8_t& r, std::uint8_t& g, std::uint8_t& b) {
    const int C = Y - 16;
    const int D = U - 128;
    const int E = V - 128;
    const int luma = 298 * C + 128;
    r = clamp8((luma + k.rv * E) >> 8);
    g = clamp8((luma - k.gu * D - k.gv * E) >> 8);
    b = clamp8((luma + k.bu * D) >> 8);
}

/**
 * @brief Converts one RGB pixel to limited-range YUV.
 * @param k Coefficients.
 * @param r Red.
 * @param g Green.
 * @param b Blue.
 * @param Y Receives luma.
 * @param U Receives chroma U.
 * @param V Receives chroma V.
 */
inline void rgbToYuv(const RgbToYuvCoeffs& k, int r, int g, int b,
                     std::uint8_t& Y, std::uint8_t& U, std::uint8_t& V) {
    Y = clamp8(((k.yr * r + k.yg * g + k.yb * b + 128) >> 8) + 16);
    U = clamp8(((k.ur * r + k.ug * g + k.ub * b + 128) >> 8) + 128);
    V = clamp8(((k.vr * r + k.vg * g + k.vb * b + 128) >> 8) + 128);
}

/**
 * @brief Luma of an RGB pixel for Gray8 (any colour space).
 * @param r Red.
 * @param g Green.
 * @param b Blue.
 * @return `(77 r + 150 g + 29 b + 128) >> 8`.
 */
inline std::uint8_t grayFromRgb(int r, int g, int b) {
    return static_cast<std::uint8_t>((77 * r + 150 * g + 29 * b + 128) >> 8);
}

/**
 * @brief Reads a little-endian 16-bit sample.
 * @param p Byte pointer.
 * @return The value.
 */
inline unsigned load16le(const std::uint8_t* p) {
    return static_cast<unsigned>(p[0]) | (static_cast<unsigned>(p[1]) << 8);
}

/**
 * @brief Writes a little-endian 16-bit sample.
 * @param p Byte pointer.
 * @param v Value (low 16 bits used).
 */
inline void store16le(std::uint8_t* p, unsigned v) {
    p[0] = static_cast<std::uint8_t>(v & 0xFFu);
    p[1] = static_cast<std::uint8_t>((v >> 8) & 0xFFu);
}

/**
 * @brief Reads a native 32-bit word without alignment requirement.
 * @param p Byte pointer.
 * @return The word.
 */
inline std::uint32_t load32(const std::uint8_t* p) {
    std::uint32_t v;
    std::memcpy(&v, p, 4);
    return v;
}

/**
 * @brief Writes a native 32-bit word without alignment requirement.
 * @param p Byte pointer.
 * @param v The word.
 */
inline void store32(std::uint8_t* p, std::uint32_t v) {
    std::memcpy(p, &v, 4);
}

/**
 * @brief floor() to int with the argument clamped to a safe range.
 * @param v Value.
 * @return floor(v) as int.
 */
inline int floorToInt(double v) {
    if (!(v == v)) {
        return 0;
    }
    if (v > 1.0e9) {
        v = 1.0e9;
    } else if (v < -1.0e9) {
        v = -1.0e9;
    }
    return static_cast<int>(std::floor(v));
}

/**
 * @brief Rounds a fraction in [0, 1] to 1/256 units.
 * @param frac Fraction.
 * @return round(frac * 256) clamped to [0, 256].
 */
inline int weight256(double frac) {
    int w = static_cast<int>(std::floor(frac * 256.0 + 0.5));
    if (w < 0) {
        w = 0;
    } else if (w > 256) {
        w = 256;
    }
    return w;
}

/**
 * @brief Clamps an index to [0, n - 1].
 * @param i Index.
 * @param n Length.
 * @return Clamped index.
 */
inline int clampIndex(int i, int n) {
    return i < 0 ? 0 : (i >= n ? n - 1 : i);
}

/**
 * @brief Mirrors an index without repeating the edge (-1 -> 0, n -> n - 1).
 * @param i Index.
 * @param n Length.
 * @return Reflected index.
 */
inline int reflectIndex(int i, int n) {
    if (n <= 1) {
        return 0;
    }
    const int period = 2 * n;
    i %= period;
    if (i < 0) {
        i += period;
    }
    if (i >= n) {
        i = period - 1 - i;
    }
    return i;
}

/**
 * @brief Wraps an index modulo n.
 * @param i Index.
 * @param n Length.
 * @return Wrapped index.
 */
inline int wrapIndex(int i, int n) {
    if (n <= 1) {
        return 0;
    }
    i %= n;
    if (i < 0) {
        i += n;
    }
    return i;
}

/**
 * @brief Applies a border rule to a tap index (Constant taps are clamped; the caller has
 *        already decided whether the sample position is inside the image).
 * @param i Index.
 * @param n Length.
 * @param border Border rule.
 * @return Mapped index.
 */
inline int borderIndex(int i, int n, SwImageBorder border) {
    switch (border) {
    case SwImageBorder::Reflect: return reflectIndex(i, n);
    case SwImageBorder::Wrap: return wrapIndex(i, n);
    default: return clampIndex(i, n);
    }
}

} // namespace SwImageCpuKernels

/**
 * @brief CPU backend: scalar reference kernels (+ SIMD when enabled and available).
 */
class SW_GUI_EXPORT SwImageCpuBackend : public SwImageBackend {
public:
    /**
     * @brief Creates the backend (always available).
     * @return The backend.
     */
    static std::shared_ptr<SwImageBackend> create();

    /**
     * @brief Constructs the backend and fills its capability descriptor.
     */
    SwImageCpuBackend();

    /**
     * @brief Returns the capability descriptor.
     * @return The descriptor.
     */
    const SwImageBackendInfo& info() const override;

    /**
     * @brief The CPU backend is always available.
     * @return `true`.
     */
    bool isAvailable() override;

    /**
     * @brief Process-wide switch: when false every kernel takes its scalar path.
     *
     * Configuration, not instrumentation: lets a self-test prove SIMD == scalar bit-exactly.
     *
     * @param enabled `true` to allow SSE2 / NEON kernels.
     */
    static void setSimdEnabled(bool enabled);

    /**
     * @brief Returns the SIMD switch.
     * @return `true` when SIMD kernels may be used.
     */
    static bool simdEnabled();

    /**
     * @brief Returns whether this build carries SIMD kernels at all (SSE2 or NEON).
     * @return `true` when a SIMD instruction set was compiled in.
     */
    static bool simdCompiled();

    /**
     * @brief Refines the masks: every op on every known format, with parameter sanity checks.
     * @param op Operation.
     * @param input Layout of the op input.
     * @return `true` when execute() can perform the op.
     */
    bool supports(const SwImageOp& op, const SwImageLayout& input) const override;

    /**
     * @brief Executes the ops sequentially into scratch CPU buffers.
     *
     * An adjacent Crop + Scale pair runs as one pass. Geometric ops on planar / 16-bit / YUY2
     * inputs convert to BGRA32 first and convert back at the end of the chain unless a later
     * Convert made the conversion back unnecessary.
     *
     * @param src CPU resident input.
     * @param srcView Region of interest ({0,0,0,0} = whole image).
     * @param ops Ops applied in order.
     * @param wantedOutput Ignored (results are always CPU resident).
     * @param out Receives the result (aliases `src` when nothing had to be done).
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool execute(const std::shared_ptr<SwImageStorage>& src, const SwRect& srcView,
                 const std::vector<SwImageOp>& ops, SwImageResidency wantedOutput,
                 std::shared_ptr<SwImageStorage>& out, SwString* error) override;

    /**
     * @brief CPU -> CPU "upload" is the identity.
     * @param cpu CPU storage.
     * @param out Receives `cpu`.
     * @param error Receives a reason on failure (may be null).
     * @return `true` when `cpu` is CPU resident.
     */
    bool upload(const std::shared_ptr<SwImageStorage>& cpu,
                std::shared_ptr<SwImageStorage>& out, SwString* error) override;

    /**
     * @brief CPU -> CPU "download" is the identity.
     * @param native Storage; must already be CPU resident.
     * @param outCpu Receives `native`.
     * @param error Receives a reason on failure (may be null).
     * @return `true` when `native` is CPU resident.
     */
    bool download(const std::shared_ptr<SwImageStorage>& native,
                  std::shared_ptr<SwImageStorage>& outCpu, SwString* error) override;

private:
    typedef std::shared_ptr<SwImageStorage> StoragePtr_;

    static std::atomic<bool>& simdFlag_();

    // ------------------------------------------------------------------------------------
    // Format classification
    // ------------------------------------------------------------------------------------

    static bool isKnown_(SwPixelFormat f);

    static bool isPacked8_(SwPixelFormat f);

    static bool is420_(SwPixelFormat f);

    // ------------------------------------------------------------------------------------
    // Validation, allocation, row access
    // ------------------------------------------------------------------------------------

    /**
     * @brief Checks that every plane of a CPU storage is addressable within its buffer.
     */
    bool validate_(const StoragePtr_& s, const char* what, SwString* error) const;

    /**
     * @brief Allocates a canonical CPU storage after checking the size limits.
     */
    bool allocate_(SwPixelFormat f, int w, int h, StoragePtr_& out, const char* what, SwString* error) const;

    static const std::uint8_t* row_(const StoragePtr_& s, int plane, int y);

    static std::uint8_t* wrow_(const StoragePtr_& s, int plane, int y);

    static SwString rectText_(const SwRect& r);

    /**
     * @brief Converts a non packed-8-bit input to BGRA32 and remembers the format to restore.
     */
    bool ensurePacked8_(StoragePtr_& cur, SwPixelFormat& deferred, SwString* error) const;

    // ------------------------------------------------------------------------------------
    // Packed pixel access
    // ------------------------------------------------------------------------------------

    static void loadPixel_(SwPixelFormat f, const std::uint8_t* p,
                           std::uint8_t& r, std::uint8_t& g, std::uint8_t& b, std::uint8_t& a);

    static void storePixel_(SwPixelFormat f, std::uint8_t* p,
                            std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a);

    /**
     * @brief Splits one packed-8-bit row into R / G / B / A arrays.
     */
    static void loadPackedRow_(SwPixelFormat f, const std::uint8_t* s, int w,
                               std::uint8_t* r, std::uint8_t* g, std::uint8_t* b, std::uint8_t* a);

    /**
     * @brief Packs R / G / B / A arrays into one packed-8-bit row.
     */
    static void storePackedRow_(SwPixelFormat f, std::uint8_t* d, int w,
                                const std::uint8_t* r, const std::uint8_t* g, const std::uint8_t* b,
                                const std::uint8_t* a);

    // ------------------------------------------------------------------------------------
    // YUV row access (full resolution 8-bit Y / U / V, chroma replicated)
    // ------------------------------------------------------------------------------------

    /**
     * @brief Extracts row `y` of a YUV storage as 8-bit full-resolution Y / U / V arrays.
     */
    static void extractYuvRow_(const StoragePtr_& src, int y, std::uint8_t* Y, std::uint8_t* U, std::uint8_t* V);

    /**
     * @brief Stores one or two consecutive rows (starting at an even `y`) of full-resolution
     *        Y / U / V into a YUV storage, subsampling the chroma with rounding half up.
     */
    static void storeYuvRows_(const StoragePtr_& dst, int y, int rows,
                              const std::uint8_t* Y0, const std::uint8_t* U0, const std::uint8_t* V0,
                              const std::uint8_t* Y1, const std::uint8_t* U1, const std::uint8_t* V1);

    // ------------------------------------------------------------------------------------
    // Crop
    // ------------------------------------------------------------------------------------

    /**
     * @brief Copies the rectangle `r` of `src` into a new canonical storage (any format).
     */
    bool crop_(const StoragePtr_& src, const SwRect& r, StoragePtr_& out, SwString* error) const;

    // ------------------------------------------------------------------------------------
    // Convert
    // ------------------------------------------------------------------------------------

    /**
     * @brief Converts `src` to `target` (any known pair); `opCs` selects / tags the colour space.
     */
    bool convert_(const StoragePtr_& src, SwPixelFormat target, SwColorSpace opCs,
                  StoragePtr_& out, SwString* error) const;

    bool convertPackedToPacked_(const StoragePtr_& src, const StoragePtr_& dst) const;

    bool convertYuvToPacked_(const StoragePtr_& src, const StoragePtr_& dst, SwColorSpace cs) const;

    bool convertPackedToYuv_(const StoragePtr_& src, const StoragePtr_& dst, SwColorSpace cs) const;

    bool convertYuvToYuv_(const StoragePtr_& src, const StoragePtr_& dst) const;

    /**
     * @brief NV12 / YUV420P -> BGRA32 (scalar reference + SIMD body when enabled).
     */
    bool fast420ToBgra_(const StoragePtr_& src, const StoragePtr_& dst, SwColorSpace cs) const;

    /**
     * @brief BGRA32 -> NV12 / YUV420P (scalar reference + SIMD body when enabled).
     */
    bool fastBgraTo420_(const StoragePtr_& src, const StoragePtr_& dst, SwColorSpace cs) const;

    // ------------------------------------------------------------------------------------
    // Scale (packed 8-bit formats; fused crop through `srcRect`)
    // ------------------------------------------------------------------------------------

    /**
     * @brief Per-axis resampling taps: for output coordinate d, taps are
     *        index[start[d] .. start[d] + count[d]) weighted by weight[...], summing to total[d].
     */
    struct AxisTaps_ {
        std::vector<int> start;
        std::vector<int> count;
        std::vector<int> total;
        std::vector<int> index;
        std::vector<int> weight;
    };

    static void pushTap_(AxisTaps_& t, int index, int weight);

    static void buildTaps_(int srcLen, int dstLen, SwImageFilter filter, AxisTaps_& t);

    static int divRound_(long long acc, long long total);

    /**
     * @brief Resamples the `srcRect` region of a packed 8-bit storage to `dstW` x `dstH`.
     */
    bool scalePacked_(const StoragePtr_& src, const SwRect& srcRect, int dstW, int dstH,
                      SwImageFilter filter, StoragePtr_& out, SwString* error) const;

    // ------------------------------------------------------------------------------------
    // Flip / Rotate (packed 8-bit formats)
    // ------------------------------------------------------------------------------------

    bool flipPacked_(const StoragePtr_& src, bool horizontal, bool vertical, StoragePtr_& out, SwString* error) const;

    bool rotatePacked_(const StoragePtr_& src, SwImageRotation rot, StoragePtr_& out, SwString* error) const;

    // ------------------------------------------------------------------------------------
    // Warp / Remap (packed 8-bit formats)
    // ------------------------------------------------------------------------------------

    /**
     * @brief Samples a packed 8-bit image at pixel-centre coordinates (fx, fy) with a border rule.
     */
    static void samplePacked_(const std::uint8_t* base, std::size_t stride, int w, int h, int bpp,
                              double fx, double fy, SwImageFilter filter, SwImageBorder border,
                              const std::uint8_t* borderPx, std::uint8_t* dst);

    static void borderPixel_(SwPixelFormat f, std::uint32_t bgra, std::uint8_t* px);

    bool warpPacked_(const StoragePtr_& src, const SwImageOp& op, StoragePtr_& out, SwString* error) const;

    bool remapPacked_(const StoragePtr_& src, const SwImageOp& op, StoragePtr_& out, SwString* error) const;

    // ------------------------------------------------------------------------------------
    // Composite (packed 8-bit canvas, any source format)
    // ------------------------------------------------------------------------------------

    static SwRect intersect_(const SwRect& a, int w, int h);

    bool compositePacked_(const StoragePtr_& canvasIn, const SwImageOp& op, StoragePtr_& out, SwString* error) const;

    // ------------------------------------------------------------------------------------
    // SIMD dispatch (each kernel returns the number of leading pixels it processed)
    // ------------------------------------------------------------------------------------

    static int simdYuv420ToBgra_(const std::uint8_t* yRow, const std::uint8_t* uRow, const std::uint8_t* vRow,
                                 std::uint8_t* dst, int width, const SwImageCpuKernels::YuvToRgbCoeffs& k);

    static int simdBgraToYuv420_(const std::uint8_t* row0, const std::uint8_t* row1, std::uint8_t* y0, std::uint8_t* y1,
                                 std::uint8_t* uOut, std::uint8_t* vOut, int width, const SwImageCpuKernels::RgbToYuvCoeffs& k);

    static int simdSwizzleRB_(const std::uint8_t* src, std::uint8_t* dst, int width);

    static int simdBilinearBgra_(const std::uint8_t* row0, const std::uint8_t* row1, int wy,
                                 const int* x0, const int* x1, const int* wx, std::uint8_t* dst, int dstW);

#if defined(SW_IMAGE_CPU_HAVE_SSE2)
    // ------------------------------------------------------------------------------------
    // SSE2 kernels (bit-identical to the scalar formulas: 32-bit madd accumulation)
    // ------------------------------------------------------------------------------------

    static __m128i pair16_(int lo, int hi);

    /**
     * @brief Takes the low 16 bits of each 32-bit lane of `a` (low half) and `b` (high half).
     */
    static __m128i pack32to16_(__m128i a, __m128i b);

    static int sse2Yuv420ToBgra_(const std::uint8_t* yRow, const std::uint8_t* uRow, const std::uint8_t* vRow,
                                 std::uint8_t* dst, int width, const SwImageCpuKernels::YuvToRgbCoeffs& k);

    static void sse2LoadBgra8_(const std::uint8_t* p, __m128i& R, __m128i& G, __m128i& B);

    static __m128i sse2Madd3_(__m128i rgLo, __m128i rgHi, __m128i b1Lo, __m128i b1Hi,
                              __m128i kRg, __m128i kB1, __m128i offset);

    static int sse2BgraToYuv420_(const std::uint8_t* row0, const std::uint8_t* row1, std::uint8_t* y0, std::uint8_t* y1,
                                 std::uint8_t* uOut, std::uint8_t* vOut, int width, const SwImageCpuKernels::RgbToYuvCoeffs& k);

    static int sse2SwizzleRB_(const std::uint8_t* src, std::uint8_t* dst, int width);

    static int sse2BilinearBgra_(const std::uint8_t* row0, const std::uint8_t* row1, int wy,
                                 const int* x0, const int* x1, const int* wx, std::uint8_t* dst, int dstW);
#endif // SW_IMAGE_CPU_HAVE_SSE2

#if defined(SW_IMAGE_CPU_HAVE_NEON)
    // ------------------------------------------------------------------------------------
    // NEON kernels (widening multiply-accumulate: exact 32-bit arithmetic)
    // ------------------------------------------------------------------------------------

    static int neonYuv420ToBgra_(const std::uint8_t* yRow, const std::uint8_t* uRow, const std::uint8_t* vRow,
                                 std::uint8_t* dst, int width, const SwImageCpuKernels::YuvToRgbCoeffs& k) {
        const int n = width & ~7;
        const int16x8_t c16 = vdupq_n_s16(16);
        const int16x8_t c128 = vdupq_n_s16(128);
        const int32x4_t r128 = vdupq_n_s32(128);
        const std::int16_t rv = static_cast<std::int16_t>(k.rv);
        const std::int16_t gu = static_cast<std::int16_t>(k.gu);
        const std::int16_t gv = static_cast<std::int16_t>(k.gv);
        const std::int16_t bu = static_cast<std::int16_t>(k.bu);
        for (int x = 0; x < n; x += 8) {
            const int16x8_t C = vsubq_s16(vreinterpretq_s16_u16(vmovl_u8(vld1_u8(yRow + x))), c16);
            uint8x8_t u8, v8;
            if (vRow) {
                const uint8x8_t u4 = vreinterpret_u8_u32(vdup_n_u32(SwImageCpuKernels::load32(uRow + (x >> 1))));
                const uint8x8_t v4 = vreinterpret_u8_u32(vdup_n_u32(SwImageCpuKernels::load32(vRow + (x >> 1))));
                u8 = vzip_u8(u4, u4).val[0];
                v8 = vzip_u8(v4, v4).val[0];
            } else {
                const uint8x8_t uv8 = vld1_u8(uRow + x);
                const uint8x8x2_t d = vuzp_u8(uv8, uv8);
                u8 = vzip_u8(d.val[0], d.val[0]).val[0];
                v8 = vzip_u8(d.val[1], d.val[1]).val[0];
            }
            const int16x8_t D = vsubq_s16(vreinterpretq_s16_u16(vmovl_u8(u8)), c128);
            const int16x8_t E = vsubq_s16(vreinterpretq_s16_u16(vmovl_u8(v8)), c128);
            const int32x4_t lLo = vaddq_s32(vmull_n_s16(vget_low_s16(C), 298), r128);
            const int32x4_t lHi = vaddq_s32(vmull_n_s16(vget_high_s16(C), 298), r128);
            const int32x4_t rLo = vshrq_n_s32(vmlal_n_s16(lLo, vget_low_s16(E), rv), 8);
            const int32x4_t rHi = vshrq_n_s32(vmlal_n_s16(lHi, vget_high_s16(E), rv), 8);
            const int32x4_t gLo = vshrq_n_s32(vmlsl_n_s16(vmlsl_n_s16(lLo, vget_low_s16(D), gu), vget_low_s16(E), gv), 8);
            const int32x4_t gHi = vshrq_n_s32(vmlsl_n_s16(vmlsl_n_s16(lHi, vget_high_s16(D), gu), vget_high_s16(E), gv), 8);
            const int32x4_t bLo = vshrq_n_s32(vmlal_n_s16(lLo, vget_low_s16(D), bu), 8);
            const int32x4_t bHi = vshrq_n_s32(vmlal_n_s16(lHi, vget_high_s16(D), bu), 8);
            uint8x8x4_t px;
            px.val[0] = vqmovun_s16(vcombine_s16(vqmovn_s32(bLo), vqmovn_s32(bHi)));
            px.val[1] = vqmovun_s16(vcombine_s16(vqmovn_s32(gLo), vqmovn_s32(gHi)));
            px.val[2] = vqmovun_s16(vcombine_s16(vqmovn_s32(rLo), vqmovn_s32(rHi)));
            px.val[3] = vdup_n_u8(255);
            vst4_u8(dst + x * 4, px);
        }
        return n;
    }

    static int32x4_t neonMadd3_(int16x4_t R, int16x4_t G, int16x4_t B, std::int16_t kr, std::int16_t kg, std::int16_t kb, int offset) {
        const int32x4_t acc = vmlal_n_s16(vmlal_n_s16(vmlal_n_s16(vdupq_n_s32(128), R, kr), G, kg), B, kb);
        return vaddq_s32(vshrq_n_s32(acc, 8), vdupq_n_s32(offset));
    }

    static int neonBgraToYuv420_(const std::uint8_t* row0, const std::uint8_t* row1, std::uint8_t* y0, std::uint8_t* y1,
                                 std::uint8_t* uOut, std::uint8_t* vOut, int width, const SwImageCpuKernels::RgbToYuvCoeffs& k) {
        const int n = width & ~7;
        const std::int16_t yr = static_cast<std::int16_t>(k.yr), yg = static_cast<std::int16_t>(k.yg), yb = static_cast<std::int16_t>(k.yb);
        const std::int16_t ur = static_cast<std::int16_t>(k.ur), ug = static_cast<std::int16_t>(k.ug), ub = static_cast<std::int16_t>(k.ub);
        const std::int16_t vr = static_cast<std::int16_t>(k.vr), vg = static_cast<std::int16_t>(k.vg), vb = static_cast<std::int16_t>(k.vb);
        for (int x = 0; x < n; x += 8) {
            uint32x4_t usum = vdupq_n_u32(0);
            uint32x4_t vsum = vdupq_n_u32(0);
            for (int r = 0; r < 2; ++r) {
                const std::uint8_t* srow = r == 0 ? row0 : row1;
                std::uint8_t* yOut = r == 0 ? y0 : y1;
                const uint8x8x4_t px = vld4_u8(srow + x * 4);
                const int16x8_t B = vreinterpretq_s16_u16(vmovl_u8(px.val[0]));
                const int16x8_t G = vreinterpretq_s16_u16(vmovl_u8(px.val[1]));
                const int16x8_t R = vreinterpretq_s16_u16(vmovl_u8(px.val[2]));
                const int32x4_t yLo = neonMadd3_(vget_low_s16(R), vget_low_s16(G), vget_low_s16(B), yr, yg, yb, 16);
                const int32x4_t yHi = neonMadd3_(vget_high_s16(R), vget_high_s16(G), vget_high_s16(B), yr, yg, yb, 16);
                const int32x4_t uLo = neonMadd3_(vget_low_s16(R), vget_low_s16(G), vget_low_s16(B), ur, ug, ub, 128);
                const int32x4_t uHi = neonMadd3_(vget_high_s16(R), vget_high_s16(G), vget_high_s16(B), ur, ug, ub, 128);
                const int32x4_t vLo = neonMadd3_(vget_low_s16(R), vget_low_s16(G), vget_low_s16(B), vr, vg, vb, 128);
                const int32x4_t vHi = neonMadd3_(vget_high_s16(R), vget_high_s16(G), vget_high_s16(B), vr, vg, vb, 128);
                vst1_u8(yOut + x, vqmovun_s16(vcombine_s16(vqmovn_s32(yLo), vqmovn_s32(yHi))));
                const uint16x8_t U16 = vreinterpretq_u16_s16(vcombine_s16(vqmovn_s32(uLo), vqmovn_s32(uHi)));
                const uint16x8_t V16 = vreinterpretq_u16_s16(vcombine_s16(vqmovn_s32(vLo), vqmovn_s32(vHi)));
                usum = vaddq_u32(usum, vpaddlq_u16(U16));
                vsum = vaddq_u32(vsum, vpaddlq_u16(V16));
            }
            const uint32x4_t u = vshrq_n_u32(vaddq_u32(usum, vdupq_n_u32(2)), 2);
            const uint32x4_t v = vshrq_n_u32(vaddq_u32(vsum, vdupq_n_u32(2)), 2);
            const uint16x4_t u16 = vmovn_u32(u);
            const uint16x4_t v16 = vmovn_u32(v);
            const uint8x8_t u8 = vmovn_u16(vcombine_u16(u16, u16));
            const uint8x8_t v8 = vmovn_u16(vcombine_u16(v16, v16));
            if (vOut) {
                SwImageCpuKernels::store32(uOut + (x >> 1), vget_lane_u32(vreinterpret_u32_u8(u8), 0));
                SwImageCpuKernels::store32(vOut + (x >> 1), vget_lane_u32(vreinterpret_u32_u8(v8), 0));
            } else {
                vst1_u8(uOut + x, vzip_u8(u8, v8).val[0]);
            }
        }
        return n;
    }

    static int neonSwizzleRB_(const std::uint8_t* src, std::uint8_t* dst, int width) {
        const int n = width & ~7;
        for (int x = 0; x < n; x += 8) {
            uint8x8x4_t px = vld4_u8(src + x * 4);
            const uint8x8_t t = px.val[0];
            px.val[0] = px.val[2];
            px.val[2] = t;
            vst4_u8(dst + x * 4, px);
        }
        return n;
    }

    static int neonBilinearBgra_(const std::uint8_t* row0, const std::uint8_t* row1, int wy,
                                 const int* x0, const int* x1, const int* wx, std::uint8_t* dst, int dstW) {
        using SwImageCpuKernels::load32;
        const int n = dstW & ~1;
        const std::uint16_t wy0 = static_cast<std::uint16_t>(256 - wy);
        const std::uint16_t wy1 = static_cast<std::uint16_t>(wy);
        const uint32x4_t round = vdupq_n_u32(32768);
        for (int dx = 0; dx < n; dx += 2) {
            const int xa0 = x0[dx], xa1 = x1[dx], xb0 = x0[dx + 1], xb1 = x1[dx + 1];
            const uint16x8_t P00 = vmovl_u8(vreinterpret_u8_u64(vcreate_u64(static_cast<std::uint64_t>(load32(row0 + xa0 * 4)) |
                                                                            (static_cast<std::uint64_t>(load32(row0 + xb0 * 4)) << 32))));
            const uint16x8_t P10 = vmovl_u8(vreinterpret_u8_u64(vcreate_u64(static_cast<std::uint64_t>(load32(row0 + xa1 * 4)) |
                                                                            (static_cast<std::uint64_t>(load32(row0 + xb1 * 4)) << 32))));
            const uint16x8_t P01 = vmovl_u8(vreinterpret_u8_u64(vcreate_u64(static_cast<std::uint64_t>(load32(row1 + xa0 * 4)) |
                                                                            (static_cast<std::uint64_t>(load32(row1 + xb0 * 4)) << 32))));
            const uint16x8_t P11 = vmovl_u8(vreinterpret_u8_u64(vcreate_u64(static_cast<std::uint64_t>(load32(row1 + xa1 * 4)) |
                                                                            (static_cast<std::uint64_t>(load32(row1 + xb1 * 4)) << 32))));
            const uint16x8_t w0 = vcombine_u16(vdup_n_u16(static_cast<std::uint16_t>(256 - wx[dx])), vdup_n_u16(static_cast<std::uint16_t>(256 - wx[dx + 1])));
            const uint16x8_t w1 = vcombine_u16(vdup_n_u16(static_cast<std::uint16_t>(wx[dx])), vdup_n_u16(static_cast<std::uint16_t>(wx[dx + 1])));
            const uint32x4_t h0Lo = vmlal_u16(vmull_u16(vget_low_u16(P00), vget_low_u16(w0)), vget_low_u16(P10), vget_low_u16(w1));
            const uint32x4_t h0Hi = vmlal_u16(vmull_u16(vget_high_u16(P00), vget_high_u16(w0)), vget_high_u16(P10), vget_high_u16(w1));
            const uint32x4_t h1Lo = vmlal_u16(vmull_u16(vget_low_u16(P01), vget_low_u16(w0)), vget_low_u16(P11), vget_low_u16(w1));
            const uint32x4_t h1Hi = vmlal_u16(vmull_u16(vget_high_u16(P01), vget_high_u16(w0)), vget_high_u16(P11), vget_high_u16(w1));
            const uint16x4_t H0Lo = vmovn_u32(h0Lo), H0Hi = vmovn_u32(h0Hi), H1Lo = vmovn_u32(h1Lo), H1Hi = vmovn_u32(h1Hi);
            const uint32x4_t sLo = vshrq_n_u32(vaddq_u32(vmlal_n_u16(vmull_n_u16(H0Lo, wy0), H1Lo, wy1), round), 16);
            const uint32x4_t sHi = vshrq_n_u32(vaddq_u32(vmlal_n_u16(vmull_n_u16(H0Hi, wy0), H1Hi, wy1), round), 16);
            vst1_u8(dst + dx * 4, vmovn_u16(vcombine_u16(vmovn_u32(sLo), vmovn_u32(sHi))));
        }
        return n;
    }
#endif // SW_IMAGE_CPU_HAVE_NEON

public:
    ~SwImageCpuBackend();
public:
    SwImageCpuBackend(const SwImageCpuBackend& other);
    SwImageCpuBackend& operator=(const SwImageCpuBackend& other);
private:
    // What the class keeps (SwImageCpuBackend_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
