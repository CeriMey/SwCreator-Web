#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImageStorage.h
 * @ingroup core_graphics
 * @brief Declares the backing-store types used by SwImage in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the image storage interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwImageResidency, SwDmaBufDescriptor,
 * SwNativeImageHandle, SwImageFence and SwImageStorage.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Backing store of an image: residency, CPU bytes, opaque native handle, DMA-BUF, fence.
 *
 * An SwImageStorage is shared between SwImage handles through std::shared_ptr and is
 * effectively immutable after creation; copy-on-write happens in SwImage. Native handles are
 * opaque here: no vendor header is included, the backends cast `handle0` / `handle1` back to
 * their real types.
 */

#include "SwPixelFormat.h"
#include "SwString.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <memory>
#include <utility>
#include <vector>


/**
 * @brief Where the pixels of a storage live.
 *
 * `Auto` is not a residency: it is only valid as the `preferred` argument of
 * SwImage::materialize() and means "stay where the last backend put the result".
 */
enum class SwImageResidency {
    Cpu,
    DmaBuf,
    D3D11,
    AndroidHardwareBuffer,
    AndroidSurface,
    Vendor,
    Auto
};

/**
 * @brief Number of real residencies (Auto excluded), for bit masks.
 */
static const int kSwImageResidencyCount = static_cast<int>(SwImageResidency::Vendor) + 1;

/**
 * @brief Returns a stable name for a residency.
 * @param residency Residency value.
 * @return Static string such as "cpu" or "d3d11".
 */
inline const char* SwImageResidencyName(SwImageResidency residency) {
    switch (residency) {
    case SwImageResidency::Cpu: return "cpu";
    case SwImageResidency::DmaBuf: return "dmabuf";
    case SwImageResidency::D3D11: return "d3d11";
    case SwImageResidency::AndroidHardwareBuffer: return "ahardwarebuffer";
    case SwImageResidency::AndroidSurface: return "androidsurface";
    case SwImageResidency::Vendor: return "vendor";
    case SwImageResidency::Auto: return "auto";
    }
    return "unknown";
}

/**
 * @brief Generic Linux DMA-BUF description (field names == old SwVideoFrame::NativeVaapiPrimeStorage).
 *
 * Move-only. On Linux the descriptor owns its file descriptors and closes them in its destructor
 * (move assignment closes the previously owned fds first, exactly like the old
 * NativeVaapiPrimeStorage). On other platforms the fds are plain ints and are never closed.
 */
struct SW_GUI_EXPORT SwDmaBufDescriptor {
    struct Object {
        int fd{-1};
        std::uint32_t size{0};
        std::uint64_t drmFormatModifier{0};
    };

    struct Layer {
        std::uint32_t drmFormat{0};
        std::uint32_t numPlanes{0};
        std::uint32_t objectIndex[4] = {0, 0, 0, 0};
        std::uint32_t offset[4] = {0, 0, 0, 0};
        std::uint32_t pitch[4] = {0, 0, 0, 0};
    };

    std::uint32_t fourcc{0};
    std::uint32_t width{0};
    std::uint32_t height{0};
    std::uint32_t rtFormat{0};
    std::uint32_t numObjects{0};
    std::array<Object, 4> objects{};
    std::uint32_t numLayers{0};
    std::array<Layer, 4> layers{};

    /**
     * @brief Constructs an empty descriptor (every fd is -1).
     */
    SwDmaBufDescriptor() = default;
    SwDmaBufDescriptor(const SwDmaBufDescriptor&) = delete;
    SwDmaBufDescriptor& operator=(const SwDmaBufDescriptor&) = delete;

    /**
     * @brief Takes over the fds of `other`, which is left empty.
     * @param other Descriptor to move from.
     */
    SwDmaBufDescriptor(SwDmaBufDescriptor&& other) noexcept;

    /**
     * @brief Closes the currently owned fds, then takes over those of `other`.
     * @param other Descriptor to move from.
     * @return `*this`.
     */
    SwDmaBufDescriptor& operator=(SwDmaBufDescriptor&& other) noexcept;

    /**
     * @brief Closes the owned fds (Linux only).
     */
    ~SwDmaBufDescriptor();

    /**
     * @brief Returns whether the descriptor references at least one object.
     * @return `true` when numObjects > 0 and the first fd is valid.
     */
    bool isValid() const;

private:
    void closeOwnedFds_();
};

/**
 * @brief Opaque description of a native (non-CPU) image object.
 *
 * `owner` keeps the native object alive (a ComPtr holder struct, an AHardwareBuffer wrapper, a
 * vendor object); `handle0` / `handle1` are raw pointers the owning backend knows how to cast.
 */
struct SW_GUI_EXPORT SwNativeImageHandle {
    SwImageResidency residency{SwImageResidency::Cpu};
    std::shared_ptr<void> owner;      ///< keeps the native object alive
    void* handle0{nullptr};           ///< D3D11: ID3D11Texture2D*   Android: AHardwareBuffer*   Vendor: backend object
    void* handle1{nullptr};           ///< D3D11: ID3D11Device*
    std::uint32_t nativeFormat{0};    ///< D3D11: DXGI_FORMAT
    std::uint32_t subresource{0};     ///< D3D11: array slice
    SwString vendorBackendId;         ///< Vendor residency: id of the owning backend (must be able to exportDmaBuf)
};

/**
 * @brief Completion fence attached to a storage produced by an asynchronous backend.
 */
class SW_GUI_EXPORT SwImageFence {
public:
    virtual ~SwImageFence();

    /**
     * @brief Blocks until the work producing the storage has completed.
     * @param timeoutMs Timeout in milliseconds, -1 = infinite.
     * @return `true` when signaled before the timeout.
     */
    virtual bool wait(int timeoutMs = -1) = 0;

    /**
     * @brief Polls the fence.
     * @return `true` when the work has completed.
     */
    virtual bool isSignaled() const = 0;
};

/**
 * @brief Shared, effectively immutable backing store of an image.
 *
 * Create instances only through the static factories. CPU storages expose their bytes through
 * `data()` / `planeData()`; native storages expose an opaque handle or a DMA-BUF descriptor and
 * return nullptr from the CPU accessors.
 */
class SW_GUI_EXPORT SwImageStorage {
public:
    /**
     * @brief Allocates zero-initialised CPU memory for `layout`.
     * @param layout Layout to allocate (its dataSize and strides are honoured).
     * @return The storage, or nullptr when the layout is invalid or empty.
     */
    static std::shared_ptr<SwImageStorage> allocateCpu(const SwImageLayout& layout);

    /**
     * @brief Wraps externally owned CPU memory without copying it.
     * @param layout Layout of the wrapped bytes (strides / offsets describe `data`).
     * @param owner Keeps the memory alive for as long as the storage exists.
     * @param data First byte of plane 0; when nullptr, `owner.get()` is used.
     * @param size Number of addressable bytes starting at `data`.
     * @return The storage, or nullptr when the layout is invalid or the buffer is too small.
     */
    static std::shared_ptr<SwImageStorage> wrapCpu(const SwImageLayout& layout,
                                                   std::shared_ptr<void> owner,
                                                   std::uint8_t* data,
                                                   std::size_t size);

    /**
     * @brief Wraps a native (GPU / hardware-buffer / vendor) object.
     * @param layout Logical layout of the native image (format and size; strides are informative).
     * @param handle Opaque native handle; its residency must not be Cpu.
     * @return The storage, or nullptr when the layout is invalid or the handle residency is Cpu / Auto.
     */
    static std::shared_ptr<SwImageStorage> wrapNative(const SwImageLayout& layout,
                                                      const SwNativeImageHandle& handle);

    /**
     * @brief Takes ownership of a DMA-BUF descriptor (and of its fds on Linux).
     * @param layout Logical layout of the buffer.
     * @param dmaBuf Descriptor moved into the storage.
     * @return The storage, or nullptr when the layout is invalid.
     */
    static std::shared_ptr<SwImageStorage> wrapDmaBuf(const SwImageLayout& layout,
                                                      SwDmaBufDescriptor&& dmaBuf);

    /**
     * @brief Returns the layout of the stored pixels.
     * @return The layout.
     */
    const SwImageLayout& layout() const;

    /**
     * @brief Returns where the pixels live.
     * @return The residency.
     */
    SwImageResidency residency() const;

    /**
     * @brief Returns whether the pixels are addressable by the CPU.
     * @return `true` for CPU residency.
     */
    bool isCpu() const;

    /**
     * @brief Returns the first byte of plane `i` (CPU only).
     * @param i Plane index.
     * @return Pointer, or nullptr for native storages / invalid planes.
     */
    std::uint8_t* planeData(std::size_t i);

    /**
     * @brief Returns the first byte of plane `i` (CPU only).
     * @param i Plane index.
     * @return Pointer, or nullptr for native storages / invalid planes.
     */
    const std::uint8_t* planeData(std::size_t i) const;

    /**
     * @brief Returns the stride in bytes of plane `i`.
     * @param i Plane index.
     * @return Stride, 0 for invalid planes.
     */
    int planeStride(std::size_t i) const;

    /**
     * @brief Returns the number of rows of plane `i`.
     * @param i Plane index.
     * @return Rows, 0 for invalid planes.
     */
    int planeHeight(std::size_t i) const;

    /**
     * @brief Returns the first byte of the CPU buffer (plane 0).
     * @return Pointer, or nullptr for native storages.
     */
    std::uint8_t* data();

    /**
     * @brief Returns the first byte of the CPU buffer (plane 0).
     * @return Pointer, or nullptr for native storages.
     */
    const std::uint8_t* data() const;

    /**
     * @brief Returns the number of addressable bytes of the CPU buffer.
     * @return Byte count, 0 for native storages.
     */
    std::size_t dataSize() const;

    /**
     * @brief Returns the object keeping the memory / native object alive.
     * @return The owner handle (may be null for wrapDmaBuf storages).
     */
    std::shared_ptr<void> owner() const;

    /**
     * @brief Returns the opaque native handle (residency Cpu for CPU storages).
     * @return The handle.
     */
    const SwNativeImageHandle& native() const;

    /**
     * @brief Returns the DMA-BUF descriptor of a wrapDmaBuf storage.
     * @return Pointer, or nullptr when the storage does not own a DMA-BUF.
     */
    const SwDmaBufDescriptor* dmaBuf() const;

    /**
     * @brief Returns the colour space tag.
     * @return The colour space.
     */
    SwColorSpace colorSpace() const;

    /**
     * @brief Sets the colour space tag (metadata only, pixels are untouched).
     * @param cs Colour space.
     */
    void setColorSpace(SwColorSpace cs);

    /**
     * @brief Returns the completion fence, if any.
     * @return The fence or null.
     */
    std::shared_ptr<SwImageFence> fence() const;

    /**
     * @brief Attaches a completion fence (asynchronous backends).
     * @param fence Fence or null.
     */
    void setFence(std::shared_ptr<SwImageFence> fence);

    /**
     * @brief Waits for the fence when there is one.
     * @param timeoutMs Timeout in milliseconds, -1 = infinite.
     * @return `true` when there is no fence or it signaled in time.
     */
    bool wait(int timeoutMs = -1) const;

private:
    SwImageStorage();
    SwImageStorage(const SwImageStorage&) = delete;
    SwImageStorage& operator=(const SwImageStorage&) = delete;

public:
    ~SwImageStorage();
private:
    // What the class keeps (SwImageStorage_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

/**
 * @brief Copies the pixels of a CPU storage into a freshly allocated canonical CPU storage.
 *
 * Used for copy-on-write detaches and for CPU staging. Padded strides are honoured on the
 * source side; the destination uses SwDescribeImageLayout strides.
 *
 * @param src Source storage (must be CPU resident).
 * @return The copy, or nullptr when `src` is not CPU resident.
 */
inline std::shared_ptr<SwImageStorage> SwImageStorageCloneCpu(const std::shared_ptr<SwImageStorage>& src) {
    if (!src || !src->isCpu()) {
        return std::shared_ptr<SwImageStorage>();
    }
    const SwImageLayout& in = src->layout();
    std::shared_ptr<SwImageStorage> dst =
        SwImageStorage::allocateCpu(SwDescribeImageLayout(in.format, in.width, in.height));
    if (!dst) {
        return dst;
    }
    for (int p = 0; p < in.planeCount; ++p) {
        const std::size_t idx = static_cast<std::size_t>(p);
        const std::uint8_t* s = src->planeData(idx);
        std::uint8_t* d = dst->planeData(idx);
        if (!s || !d) {
            return std::shared_ptr<SwImageStorage>();
        }
        const int rows = in.planeHeights[idx];
        const int srcStride = in.stride[idx];
        const int dstStride = dst->layout().stride[idx];
        const std::size_t rowBytes = static_cast<std::size_t>(dstStride < srcStride ? dstStride : srcStride);
        for (int y = 0; y < rows; ++y) {
            std::memcpy(d + static_cast<std::size_t>(y) * static_cast<std::size_t>(dstStride),
                        s + static_cast<std::size_t>(y) * static_cast<std::size_t>(srcStride),
                        rowBytes);
        }
    }
    dst->setColorSpace(src->colorSpace());
    return dst;
}
