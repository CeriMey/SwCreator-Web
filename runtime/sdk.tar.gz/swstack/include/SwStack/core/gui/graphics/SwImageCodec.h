/**
 * @file src/core/gui/graphics/SwImageCodec.h
 * @ingroup core_graphics
 * @brief Declares the image codec interface and SwImageCodecRegistry in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the image codec interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwImageCodecOptions, SwImageCodec and
 * SwImageCodecRegistry.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Codec interface + registry that sniffs magic bytes and picks the encoder by format name.
 *
 * Include-order note (no `#pragma once` on purpose): this header and SwImage.h depend on each
 * other. SwImage.h is always included first (outside the body guard below) so that the class
 * SwImage is complete when the codecs are defined, and SwImage.h includes this header back after
 * its class definition. The body guard makes the second pass a no-op. The same scheme is used by
 * SwImageBmpCodec.h. Including any of the three headers first works.
 */

#include "SwImage.h"

#ifndef SW_IMAGE_CODEC_H_BODY
#define SW_IMAGE_CODEC_H_BODY

#include "../../SwStackExport.h"

#include "SwString.h"
#include "SwByteArray.h"
#include "SwDebug.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

static constexpr const char* kSwLogCategory_SwImageCodec = "sw.gui.swimagecodec";

/**
 * @brief Encoder options shared by every codec.
 */
struct SW_GUI_EXPORT SwImageCodecOptions {
    int jpegQuality{90};   ///< 1..100
    bool pngFast{true};    ///< stored deflate blocks (fast) instead of real compression
};

/**
 * @brief Interface implemented by every image codec (BMP, PNG, JPEG, WIC, VA-API JPEG, ...).
 */
class SW_GUI_EXPORT SwImageCodec {
public:
    virtual ~SwImageCodec();

    /**
     * @brief Stable codec id such as "bmp", "png", "jpeg", "wic".
     * @return The id.
     */
    virtual const SwString& id() const = 0;

    /**
     * @brief Higher wins when several codecs sniff the same bytes / encode the same format.
     * @return Priority (built-in CPU codecs: 0).
     */
    virtual int priority() const;

    /**
     * @brief Returns whether the magic bytes look like a container this codec decodes.
     * @param magic First bytes of the stream.
     * @param n Number of bytes available (may be small).
     * @return `true` when decode() should be tried.
     */
    virtual bool canDecode(const std::uint8_t* magic, std::size_t n) const = 0;

    /**
     * @brief Returns whether the codec encodes the named format ("png", "jpeg", "bmp", ...).
     * @param format Normalized lowercase format name.
     * @return `true` when encode() supports it.
     */
    virtual bool canEncode(const SwString& format) const = 0;

    /**
     * @brief Decodes a whole stream.
     * @param bytes Encoded bytes.
     * @param size Byte count.
     * @param out Receives the decoded image.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    virtual bool decode(const std::uint8_t* bytes, std::size_t size, SwImage& out, SwString* error) = 0;

    /**
     * @brief Encodes an image.
     * @param image Image (codecs materialize it as they need).
     * @param format Normalized lowercase format name.
     * @param options Encoder options.
     * @param out Receives the encoded bytes (cleared first).
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    virtual bool encode(const SwImage& image, const SwString& format, const SwImageCodecOptions& options,
                        SwByteArray& out, SwString* error) = 0;

protected:
    /**
     * @brief Stores `message` (prefixed with the codec id) into `error` when non-null.
     * @param error Destination or null.
     * @param message Reason.
     */
    void setError_(SwString* error, const SwString& message) const;
};

/**
 * @brief Process-wide, thread-safe registry of codecs.
 */
class SW_GUI_EXPORT SwImageCodecRegistry {
public:
    /**
     * @brief Returns the registry (created on first call with the built-in codecs, never destroyed).
     * @return The registry.
     */
    static SwImageCodecRegistry& instance();

    /**
     * @brief Registers a codec; a codec whose id is already registered is ignored (warning logged).
     * @param codec Codec to register.
     */
    void registerCodec(const std::shared_ptr<SwImageCodec>& codec);

    /**
     * @brief Returns the codecs, highest priority first.
     * @return Registered codecs.
     */
    std::vector<std::shared_ptr<SwImageCodec> > codecs() const;

    /**
     * @brief Looks a codec up by id.
     * @param id Codec id.
     * @return The codec or null.
     */
    std::shared_ptr<SwImageCodec> codec(const SwString& id) const;

    /**
     * @brief Returns the highest-priority codec whose canDecode() accepts the magic bytes.
     * @param bytes Stream start.
     * @param size Byte count.
     * @return The codec or null.
     */
    std::shared_ptr<SwImageCodec> sniff(const std::uint8_t* bytes, std::size_t size) const;

    /**
     * @brief Decodes with the first sniffing codec that succeeds (priority order).
     * @param bytes Encoded bytes.
     * @param size Byte count.
     * @param out Receives the image.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool decode(const std::uint8_t* bytes, std::size_t size, SwImage& out, SwString* error = nullptr) const;

    /**
     * @brief Encodes with the highest-priority codec that encodes `format`.
     * @param image Image to encode.
     * @param format Format name (normalized with normalizeFormat()).
     * @param options Encoder options.
     * @param out Receives the encoded bytes.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool encode(const SwImage& image, const SwString& format, const SwImageCodecOptions& options,
                SwByteArray& out, SwString* error = nullptr) const;

    /**
     * @brief Normalizes a format hint: strips a leading dot, lowercases, maps "jpg" to "jpeg".
     * @param hint Format name or extension.
     * @return Normalized name.
     */
    static SwString normalizeFormat(const SwString& hint);

private:
    SwImageCodecRegistry();   // defined below, after the built-in codecs

    static bool priorityGreater_(const std::shared_ptr<SwImageCodec>& a, const std::shared_ptr<SwImageCodec>& b);

public:
    ~SwImageCodecRegistry();
private:
    // What the class keeps (SwImageCodec_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ---------------------------------------------------------------------------------------------
// Built-in codecs. Each one is a header that includes "SwImageCodec.h" first (see the include-order
// note above) and defines its class inside its own body guard. WIC, on Windows, is the library's
// own (SwImageCodec.cpp).
// ---------------------------------------------------------------------------------------------
#include "SwImageBmpCodec.h"
#include "SwImagePngCodec.h"
#include "SwImageJpegCodec.h"

/**
 * @brief Registers the built-in codecs (BMP, PNG, JPEG, and WIC on Windows when available).
 */

#endif // SW_IMAGE_CODEC_H_BODY
