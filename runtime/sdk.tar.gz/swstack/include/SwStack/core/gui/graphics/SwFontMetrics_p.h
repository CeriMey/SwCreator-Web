#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwFontMetrics.h"

// The platform, which the public header no longer shows (SwFontMetrics.h).
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#endif

struct SwFontMetrics::Data : SwSharedData {
    SwFont m_font;
};
