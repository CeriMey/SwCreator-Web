#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwBrush.h"

struct SwBrush::Data : SwSharedData {
    Style m_style{NoBrush};
    SwColor m_color{0, 0, 0};
    SwGradient m_gradient{};
};
struct SwGradient::Data : SwSharedData {
    SwPointF m_start{};
    SwPointF m_end{};
    SwColor m_color0{0, 0, 0};
    SwColor m_color1{255, 255, 255};
};
