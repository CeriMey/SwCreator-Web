#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwImageBackendRegistry.h"

struct SwImageBackendRegistry::Data {
    SwString m_ForcedBackend = SwString();
    bool m_ForcedBackend_registered_ = sw_register_ForcedBackend_();
    mutable std::mutex m_mutex;
    std::vector<std::shared_ptr<SwImageBackend> > m_backends;
    bool m_shutdown = false;
    SwString m_forcedBackendShadow;
};
