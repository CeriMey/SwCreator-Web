#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwImageCodec.h"

struct SwImageCodecRegistry::Data {
    mutable std::mutex m_mutex;
    std::vector<std::shared_ptr<SwImageCodec> > m_codecs;
};
