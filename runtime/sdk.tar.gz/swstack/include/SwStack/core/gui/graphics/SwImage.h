#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImage.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwImage in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the image interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwImage.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Defines SwImage, the lightweight hardware-aware image handle of the graphics stack.
 *
 * SwImage is a value type: a shared pointer to an SwImageStorage (CPU bytes, a D3D11 texture, a
 * DMA-BUF, ...), a small chain of pending ops, a zero-copy view rectangle, an orientation hint
 * and a colour space tag. Copying is O(1) and shares the storage; value semantics are preserved
 * through copy-on-write: every mutating accessor (`bits()`, `scanLine()`, `fill()`, `create()`,
 * non-const `planeData()`) first materializes the pending ops, then detaches when the storage is
 * shared, so two copies never observe each other's writes.
 *
 * Ops (`converted()`, `cropped()`, `scaled()`, ...) are lazy: they return a new handle sharing
 * the source storage with the op appended. `materialize()` runs SwImagePlanner::simplify + plan +
 * execute on the registered backends (SwImageBackendRegistry, CPU first) and returns a handle with
 * no pending op.
 *
 * The legacy API (Format_ARGB32, width/height/bytesPerLine, bits/scanLine, BMP load/save) is
 * preserved bit-for-bit: Format_ARGB32 is SwPixelFormat::BGRA32 in memory, and the uint32_t
 * accessors give the "legacy view", i.e. the image materialized to CPU BGRA32 (converted if
 * necessary, logged once at debug level).
 */

#include "SwPixelFormat.h"
#include "SwImageOps.h"
#include "SwImageStorage.h"
#include "SwImageBackend.h"
#include "SwImageBackendRegistry.h"
#include "SwImagePlanner.h"
#include "SwString.h"
#include "SwByteArray.h"
#include "SwDebug.h"
#include "Sw.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <memory>
#include <string>
#include <vector>

static constexpr const char* kSwLogCategory_SwImage = "sw.gui.swimage";

struct SwImageCodecOptions;   // SwImageCodec.h (included after the class)

/**
 * @brief Lightweight image handle: shared storage, lazy op chain, zero-copy view, COW.
 *
 * The class behaves like a regular value type. Copying a SwImage shares the underlying storage;
 * the first write through a copy detaches it, which makes it safe to pass images between widgets
 * and rendering helpers without sharing lifetime-sensitive backend objects.
 */
class SW_GUI_EXPORT SwImage {
public:
    enum Format {
        Format_Invalid,
        Format_ARGB32
    };

    /**
     * @brief Constructs a null image.
     */
    SwImage();

    /**
     * @brief Constructs a zero-filled ARGB32 image (null when the size or format is invalid).
     * @param w Width value.
     * @param h Height value.
     * @param fmt Legacy format (only Format_ARGB32 allocates).
     */
    SwImage(int w, int h, Format fmt = Format_ARGB32);

    // ----------------------------------------------------------------------------------------
    // Legacy API (exact signatures and behaviour preserved)
    // ----------------------------------------------------------------------------------------

    /**
     * @brief Returns whether the image has no pixels.
     * @return `true` when null.
     */
    bool isNull() const;

    /**
     * @brief Returns the width of the result (after pending ops and view).
     * @return Width in pixels, 0 when null.
     */
    int width() const;

    /**
     * @brief Returns the height of the result (after pending ops and view).
     * @return Height in pixels, 0 when null.
     */
    int height() const;

    /**
     * @brief Returns the BGRA32 stride of the legacy view.
     * @return Bytes per scanline of `constBits()`, 0 when null.
     */
    int bytesPerLine() const;

    /**
     * @brief Returns the legacy format.
     * @return Format_ARGB32 iff pixelFormat() == BGRA32, otherwise Format_Invalid.
     */
    Format format() const;

    /**
     * @brief Allocates a zero-filled ARGB32 image, replacing the current content.
     * @param w Width value.
     * @param h Height value.
     * @param fmt Legacy format (anything but Format_ARGB32 makes the image null).
     */
    void create(int w, int h, Format fmt = Format_ARGB32);

    /**
     * @brief Fills every pixel of the legacy (BGRA32) view with `argb`.
     * @param argb 0xAARRGGBB value.
     */
    void fill(std::uint32_t argb);

    /**
     * @brief Returns writable BGRA32 pixels (materializes, converts and detaches as needed).
     * @return Pointer to the first pixel, nullptr when null.
     */
    std::uint32_t* bits();

    /**
     * @brief Returns read-only BGRA32 pixels (materializes and converts as needed).
     * @return Pointer to the first pixel, nullptr when null.
     */
    const std::uint32_t* constBits() const;

    /**
     * @brief Returns a writable BGRA32 scanline.
     * @param y Vertical coordinate.
     * @return Pointer to the row, nullptr when out of range or null.
     */
    std::uint32_t* scanLine(int y);

    /**
     * @brief Returns a read-only BGRA32 scanline.
     * @param y Vertical coordinate.
     * @return Pointer to the row, nullptr when out of range or null.
     */
    const std::uint32_t* constScanLine(int y) const;

    /**
     * @brief Saves the image; the codec is chosen by extension (.png / .jpg / .jpeg / .bmp, else BMP).
     * @param filePath Path of the target file.
     * @return `true` on success; otherwise `false`.
     */
    bool save(const SwString& filePath) const;

    /**
     * @brief Loads a file; the codec is chosen by sniffing the magic bytes.
     * @param filePath Path of the source file.
     * @return `true` on success (the image is left unchanged on failure).
     */
    bool load(const SwString& filePath);

    /**
     * @brief Returns this image materialized to CPU BGRA32 (what painters draw).
     * @return The legacy view, null on failure.
     */
    SwImage toLegacyArgb32() const;

    // ----------------------------------------------------------------------------------------
    // Construction
    // ----------------------------------------------------------------------------------------

    /**
     * @brief Allocates a zero-filled CPU image.
     * @param w Width.
     * @param h Height.
     * @param fmt Pixel format.
     * @return The image, null when the arguments are invalid.
     */
    static SwImage allocate(int w, int h, SwPixelFormat fmt);

    /**
     * @brief Allocates a CPU image and copies `size` bytes of canonical-layout pixels into it.
     * @param w Width.
     * @param h Height.
     * @param fmt Pixel format.
     * @param data Source bytes (canonical layout, see SwDescribeImageLayout).
     * @param size Number of bytes available at `data`.
     * @return The image (pixels beyond `size` stay zero), null when the arguments are invalid.
     */
    static SwImage fromCopy(int w, int h, SwPixelFormat fmt, const void* data, std::size_t size);

    /**
     * @brief Wraps externally owned CPU memory without copying.
     * @param layout Layout describing the bytes (strides honoured).
     * @param owner Keeps the memory alive while any handle references it.
     * @param size Number of addressable bytes.
     * @param data First byte of plane 0; nullptr means `owner.get()`.
     * @return The image, null when the buffer is too small or the layout invalid.
     */
    static SwImage wrapExternal(const SwImageLayout& layout, std::shared_ptr<void> owner,
                                std::size_t size, std::uint8_t* data = nullptr);

    /**
     * @brief Wraps a native (GPU / hardware buffer / vendor) object.
     * @param layout Logical layout.
     * @param handle Opaque native handle.
     * @param cs Colour space tag.
     * @return The image, null when the handle is invalid.
     */
    static SwImage wrapNative(const SwImageLayout& layout, const SwNativeImageHandle& handle,
                              SwColorSpace cs = SwColorSpace::Undefined);

    /**
     * @brief Takes ownership of a DMA-BUF (and of its fds on Linux).
     * @param layout Logical layout.
     * @param dmaBuf Descriptor moved into the storage.
     * @param cs Colour space tag.
     * @return The image, null when the layout is invalid.
     */
    static SwImage wrapDmaBuf(const SwImageLayout& layout, SwDmaBufDescriptor&& dmaBuf,
                              SwColorSpace cs = SwColorSpace::Undefined);

    /**
     * @brief Wraps an existing storage (shared, not copied).
     * @param storage Storage or null.
     * @return The image.
     */
    static SwImage fromStorage(std::shared_ptr<SwImageStorage> storage);

    /**
     * @brief Decodes an encoded image (PNG / JPEG / BMP, sniffed) through the codec registry.
     * @param bytes Encoded bytes.
     * @param size Byte count.
     * @return The decoded image, null on failure.
     */
    static SwImage fromData(const void* bytes, std::size_t size);

    /**
     * @brief Encodes the image with the codec named by `formatHint` ("png", "jpeg", "bmp").
     * @param out Receives the encoded bytes.
     * @param formatHint Format name or extension.
     * @return `true` on success.
     */
    bool saveToData(SwByteArray& out, const SwString& formatHint) const;

    /**
     * @brief Encodes the image with explicit codec options (JPEG quality, ...).
     * @param out Receives the encoded bytes.
     * @param formatHint Format name or extension.
     * @param options Codec options.
     * @return `true` on success.
     */
    bool saveToData(SwByteArray& out, const SwString& formatHint, const SwImageCodecOptions& options) const;

    // ----------------------------------------------------------------------------------------
    // Description
    // ----------------------------------------------------------------------------------------

    /**
     * @brief Returns the pixel format of the result (after pending ops).
     * @return The format, Unknown when null.
     */
    SwPixelFormat pixelFormat() const;

    /**
     * @brief Returns the layout of the result (after pending ops and view).
     *
     * For a zero-copy view the strides are those of the parent storage; otherwise the layout is
     * canonical.
     *
     * @return The layout.
     */
    const SwImageLayout& layout() const;

    /**
     * @brief Returns where the source storage lives.
     * @return The residency (Cpu when null).
     */
    SwImageResidency residency() const;

    /**
     * @brief Returns whether no op is pending.
     * @return `true` when the pixels are ready in the source storage.
     */
    bool isMaterialized() const;

    /**
     * @brief Returns the number of pending ops (the view is not an op).
     * @return Count.
     */
    std::size_t pendingOpCount() const;

    /**
     * @brief Returns the pending ops.
     * @return The op chain.
     */
    const std::vector<SwImageOp>& pendingOps() const;

    /**
     * @brief Returns the colour space tag.
     * @return The colour space.
     */
    SwColorSpace colorSpace() const;

    /**
     * @brief Sets the colour space tag (metadata; the pixels are untouched).
     * @param cs Colour space.
     */
    void setColorSpace(SwColorSpace cs);

    /**
     * @brief Returns the orientation hint (EXIF-like, never applied to the pixels).
     * @return The rotation.
     */
    SwImageRotation orientation() const;

    /**
     * @brief Sets the orientation hint.
     * @param rotation Rotation.
     */
    void setOrientation(SwImageRotation rotation);

    /**
     * @brief Returns the plane count of the result format.
     * @return Count (0 when null).
     */
    int planeCount() const;

    /**
     * @brief Returns a writable plane (materializes to CPU without converting, detaches if shared).
     * @param i Plane index.
     * @return Pointer or nullptr.
     */
    std::uint8_t* planeData(std::size_t i);

    /**
     * @brief Returns a read-only plane (materializes to CPU without converting).
     * @param i Plane index.
     * @return Pointer or nullptr.
     */
    const std::uint8_t* planeData(std::size_t i) const;

    /**
     * @brief Returns the stride of a plane of the result.
     * @param i Plane index.
     * @return Bytes per row, 0 when invalid.
     */
    int planeStride(std::size_t i) const;

    /**
     * @brief Returns the row count of a plane of the result.
     * @param i Plane index.
     * @return Rows, 0 when invalid.
     */
    int planeHeight(std::size_t i) const;

    /**
     * @brief Returns the source storage (may still have pending ops / a view).
     * @return The storage or null.
     */
    std::shared_ptr<SwImageStorage> storage() const;

    /**
     * @brief Returns the zero-copy view rectangle on the source storage ({0,0,0,0} = none).
     * @return The view.
     */
    const SwRect& viewRect() const;

    // ----------------------------------------------------------------------------------------
    // Lazy ops: each returns a new handle sharing the source storage with the op appended
    // ----------------------------------------------------------------------------------------

    /**
     * @brief Appends a Convert op.
     * @param fmt Target format.
     * @param cs Colour space tag of the result.
     * @return The new handle.
     */
    SwImage converted(SwPixelFormat fmt, SwColorSpace cs = SwColorSpace::Undefined) const;

    /**
     * @brief Appends a Crop op.
     * @param rect Rectangle in result pixels.
     * @return The new handle.
     */
    SwImage cropped(const SwRect& rect) const;

    /**
     * @brief Appends a Scale op.
     * @param w Output width.
     * @param h Output height.
     * @param filter Interpolation filter.
     * @return The new handle.
     */
    SwImage scaled(int w, int h, SwImageFilter filter = SwImageFilter::Linear) const;

    /**
     * @brief Appends a Flip op.
     * @param h Mirror horizontally.
     * @param v Mirror vertically.
     * @return The new handle.
     */
    SwImage flipped(bool h, bool v) const;

    /**
     * @brief Appends a Rotate op (physical rotation).
     * @param rotation Rotation.
     * @return The new handle.
     */
    SwImage rotated(SwImageRotation rotation) const;

    /**
     * @brief Appends a WarpAffine op.
     * @param m Row-major 2x3 destination -> source matrix.
     * @param w Output width.
     * @param h Output height.
     * @param filter Interpolation filter.
     * @param border Border rule.
     * @param bv Border colour (packed BGRA).
     * @return The new handle.
     */
    SwImage warpedAffine(const double m[6], int w, int h, SwImageFilter filter = SwImageFilter::Linear,
                         SwImageBorder border = SwImageBorder::Clamp, std::uint32_t bv = 0) const;

    /**
     * @brief Appends a WarpPerspective op.
     * @param m Row-major 3x3 destination -> source homography.
     * @param w Output width.
     * @param h Output height.
     * @param filter Interpolation filter.
     * @param border Border rule.
     * @param bv Border colour (packed BGRA).
     * @return The new handle.
     */
    SwImage warpedPerspective(const double m[9], int w, int h, SwImageFilter filter = SwImageFilter::Linear,
                              SwImageBorder border = SwImageBorder::Clamp, std::uint32_t bv = 0) const;

    /**
     * @brief Appends a Remap op.
     * @param mesh Lookup mesh.
     * @param filter Interpolation filter.
     * @param border Border rule.
     * @return The new handle.
     */
    SwImage remapped(std::shared_ptr<const SwImageRemapMesh> mesh, SwImageFilter filter = SwImageFilter::Linear,
                     SwImageBorder border = SwImageBorder::Clamp) const;

    /**
     * @brief Appends a Composite op drawing `src` at `dstRect` (src is captured materialized).
     * @param src Image drawn over this one.
     * @param dstRect Destination rectangle in result pixels.
     * @param alpha Straight alpha multiplier.
     * @param blend Blend mode.
     * @return The new handle (unchanged when `src` is null or cannot be materialized).
     */
    SwImage composited(const SwImage& src, const SwRect& dstRect, float alpha = 1.0f,
                       SwImageBlend blend = SwImageBlend::SourceOver) const;

    /**
     * @brief Appends every op of a recipe.
     * @param recipe Recipe.
     * @return The new handle.
     */
    SwImage applied(const SwImageRecipe& recipe) const;

    /**
     * @brief Returns a zero-copy region of interest (folded into a leading Crop when planned).
     *
     * With no pending op the view composes with the current one; with pending ops a Crop op is
     * appended instead (same result). The rectangle is clamped to the image; an empty
     * intersection yields a null image.
     *
     * @param rect Rectangle in result pixels.
     * @return The view handle.
     */
    SwImage view(const SwRect& rect) const;

    /**
     * @brief Splits the image into cols x rows views (row-major), each enlarged by `overlap`.
     * @param cols Column count.
     * @param rows Row count.
     * @param overlap Pixels added on every side (clamped to the image).
     * @return The tile views.
     */
    std::vector<SwImage> tiles(int cols, int rows, int overlap = 0) const;

    // ----------------------------------------------------------------------------------------
    // Execution
    // ----------------------------------------------------------------------------------------

    /**
     * @brief Runs the pending ops (and view) through the planner and the backends.
     *
     * `preferred` is where the result should live; SwImageResidency::Auto means "stay where the
     * last backend put it". The result has no pending op and no view. On failure the image is
     * returned unchanged and `*error` is filled.
     *
     * @param preferred Residency of the result.
     * @param error Receives a reason on failure (may be null).
     * @return The materialized image.
     */
    SwImage materialize(SwImageResidency preferred = SwImageResidency::Cpu, SwString* error = nullptr) const;

    /**
     * @brief Materializes to CPU memory.
     * @param error Receives a reason on failure (may be null).
     * @return The CPU image (unchanged on failure).
     */
    SwImage toCpu(SwString* error = nullptr) const;

    /**
     * @brief Materializes to the given residency.
     * @param residency Target residency.
     * @param error Receives a reason on failure (may be null).
     * @return The image (unchanged on failure).
     */
    SwImage toResidency(SwImageResidency residency, SwString* error = nullptr) const;

    /**
     * @brief Waits for the storage fence, if any.
     * @param timeoutMs Timeout in milliseconds, -1 = infinite.
     * @return `true` when ready.
     */
    bool wait(int timeoutMs = -1) const;

private:
    friend class SwImageRecipe;

    void reset_();

    bool hasView_() const;

    static SwRect clampRect_(const SwRect& r, int w, int h);

    /**
     * @brief A view can alias the parent bytes when the storage is CPU resident and the origin
     * is aligned to the chroma subsampling of every plane.
     */
    bool viewIsZeroCopy_() const;

    SwImageLayout viewLayout_() const;

    void refresh_() const;

    /**
     * @brief Pointer to plane `i` of the current (CPU, no pending op) result, honouring the view.
     */
    std::uint8_t* viewPlanePointer_(std::size_t i) const;

    /**
     * @brief Replaces this handle's state with `other` (used by the const accessors, which are
     * allowed to materialize into the handle since the value is unchanged).
     */
    void adopt_(const SwImage& other) const;

    /**
     * @brief Ensures the state is (CPU storage, no pending op, zero-copy view or none).
     */
    bool cpuView_() const;

    /**
     * @brief Ensures the state is the legacy view: CPU, BGRA32, no pending op.
     */
    bool legacyView_() const;

    /**
     * @brief Copy-on-write detach: after cpuView_(), makes the storage exclusively owned and
     * view-free so that writes never reach another handle.
     */
    bool detachForWrite_();

    bool cpuWritable_();

    bool legacyWritable_();

    SwImage appended_(const SwImageOp& op) const;

    /**
     * @brief Builds a Composite op whose source is this image, materialized in place (Auto).
     */
    bool makeCompositeOp_(const SwRect& dstRect, float alpha, SwImageBlend blend, SwImageOp& op) const;

    static SwString formatFromPath_(const SwString& filePath);

public:
    ~SwImage();
public:
    SwImage(const SwImage& other);
    SwImage& operator=(const SwImage& other);
private:
    // What the class keeps (SwImage_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// The codec registry needs the complete SwImage; SwImage::load/save need the registry.
#include "SwImageCodec.h"

