#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwImageStorage.h"

// The platform, which the public header no longer shows (SwImageStorage.h).
#if defined(__linux__)
#include <unistd.h>
#endif

struct SwImageStorage::Data {
    SwImageLayout m_layout;
    SwImageResidency m_residency{SwImageResidency::Cpu};
    std::shared_ptr<void> m_owner;
    std::uint8_t* m_data{nullptr};
    std::size_t m_size{0};
    SwNativeImageHandle m_native;
    SwDmaBufDescriptor m_dmaBuf;
    bool m_hasDmaBuf{false};
    SwColorSpace m_colorSpace{SwColorSpace::Undefined};
    std::shared_ptr<SwImageFence> m_fence;
};
