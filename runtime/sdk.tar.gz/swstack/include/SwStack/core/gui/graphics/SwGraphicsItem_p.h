#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwGraphicsItem.h"

struct SwGraphicsItem::Data {
    // Position / transform
    SwPointF m_pos{};
    double m_z{0.0};
    double m_rotation{0.0};
    double m_scaleFactor{1.0};
    SwPointF m_transformOrigin{};
    SwTransform m_transform{};
    // State
    bool m_visible{true};
    bool m_enabled{true};
    bool m_selected{false};
    double m_opacity{1.0};
    int m_flags{0};
    // Cursor / tooltip
    CursorType m_cursor{CursorType::Arrow};
    bool m_hasCursor{false};
    SwString m_toolTip{};
    // Hover / drop / touch
    bool m_acceptHover{false};
    bool m_acceptDrops{false};
    bool m_acceptTouch{false};
    bool m_filtersChildEvents{false};
    // Focus / grab
    bool m_hasFocus{false};
    bool m_isUnderMouse{false};
    bool m_active{true};
    // Hierarchy
    SwGraphicsItem* m_parent{nullptr};
    std::vector<SwGraphicsItem*> m_children;
    SwGraphicsItemGroup* m_group{nullptr};
    SwGraphicsItem* m_focusProxy{nullptr};
    // Scene
    SwGraphicsScene* m_scene{nullptr};
    std::function<void()> m_changeCallback;
    // Cache
    SwGraphicsCacheMode m_cacheMode{SwGraphicsCacheMode::NoCache};
    SwGraphicsPanelModality m_panelModality{SwGraphicsPanelModality::NonModal};
    // Scene event filters
    std::vector<SwGraphicsItem*> m_sceneEventFilters;
    // Custom data
    std::map<int, SwString> m_data;
};
