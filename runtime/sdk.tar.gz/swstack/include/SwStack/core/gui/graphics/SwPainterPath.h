/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwPainterPath.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwPainterPath in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the painter path interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwPainterPath.
 *
 * Directory and path declarations here usually define normalization, lookup, traversal, and
 * platform-neutral path manipulation rules that other modules can depend on.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */


/***************************************************************************************************
 * SwPainterPath: Qt-like QPainterPath — moveTo/lineTo/cubicTo/quadTo/arcTo + boolean ops.
 **************************************************************************************************/

/**
 * @file
 * @brief Declares the vector path builder used by painting and scene geometry.
 *
 * SwPainterPath records reusable vector outlines made of line segments, Bezier
 * curves, arcs, and convenience shapes. The same path object can later be
 * consumed for rasterization, clipping, hit testing, bounding-box queries, or
 * scene selection checks.
 *
 * Within the stack this type is the canonical representation for complex 2D
 * geometry. It therefore sits at the intersection of the painter API, the
 * retained-mode scene graph, and shape-based interaction code.
 */

#include "SwGraphicsTypes.h"
#include "SwVector.h"

#include <vector>

namespace { inline double swClamp_(double v, double lo, double hi) { return std::max(lo, std::min(hi, v)); } }

/**
 * @brief Stores a sequence of vector drawing commands and derived shape helpers.
 */
class SW_GUI_EXPORT SwPainterPath {
public:
    enum ElementType {
        MoveToElement,
        LineToElement,
        CurveToElement,          // cubic control point 1
        CurveToDataElement,      // cubic control point 2 / end point
        CloseSubpathElement
    };

    enum FillRule {
        OddEvenFill,
        WindingFill
    };

    struct SW_GUI_EXPORT Element {
        ElementType type{MoveToElement};
        SwPointF p{};

        /**
         * @brief Constructs a `Element` instance.
         *
         * @details The instance is initialized and prepared for immediate use.
         */
        Element();
        /**
         * @brief Constructs a `Element` instance.
         * @param typeValue Value passed to the method.
         * @param pointValue Value passed to the method.
         *
         * @details The instance is initialized and prepared for immediate use.
         */
        Element(ElementType typeValue, const SwPointF& pointValue);

        /**
         * @brief Returns whether the object reports move To.
         * @return `true` when the object reports move To; otherwise `false`.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        bool isMoveTo() const;
        /**
         * @brief Returns whether the object reports line To.
         * @return `true` when the object reports line To; otherwise `false`.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        bool isLineTo() const;
        /**
         * @brief Returns whether the object reports curve To.
         * @return `true` when the object reports curve To; otherwise `false`.
         *
         * @details The returned value reflects the state currently stored by the instance.
         */
        bool isCurveTo() const;
    };

    /**
     * @brief Constructs a `SwPainterPath` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwPainterPath();
    /**
     * @brief Constructs a `SwPainterPath` instance.
     * @param startPoint Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwPainterPath(const SwPointF& startPoint);

    // -------------------------------------------------------------------
    // Path construction
    // -------------------------------------------------------------------
    /**
     * @brief Performs the `moveTo` operation.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     */
    void moveTo(double x, double y);
    /**
     * @brief Performs the `moveTo` operation.
     * @param y Vertical coordinate.
     */
    void moveTo(const SwPointF& p);

    /**
     * @brief Performs the `lineTo` operation.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     */
    void lineTo(double x, double y);
    /**
     * @brief Performs the `lineTo` operation.
     * @param y Vertical coordinate.
     */
    void lineTo(const SwPointF& p);

    /**
     * @brief Performs the `cubicTo` operation.
     * @param c1x Value passed to the method.
     * @param c1y Value passed to the method.
     * @param c2x Value passed to the method.
     * @param c2y Value passed to the method.
     * @param ex Value passed to the method.
     * @param ey Value passed to the method.
     */
    void cubicTo(double c1x, double c1y, double c2x, double c2y, double ex, double ey);
    /**
     * @brief Performs the `cubicTo` operation.
     * @param c1 Value passed to the method.
     * @param c2 Value passed to the method.
     * @param end Value passed to the method.
     */
    void cubicTo(const SwPointF& c1, const SwPointF& c2, const SwPointF& end);

    /**
     * @brief Performs the `quadTo` operation.
     * @param cx Value passed to the method.
     * @param cy Value passed to the method.
     * @param ex Value passed to the method.
     * @param ey Value passed to the method.
     */
    void quadTo(double cx, double cy, double ex, double ey);
    /**
     * @brief Performs the `quadTo` operation.
     * @param ctrl Value passed to the method.
     * @param y Vertical coordinate.
     */
    void quadTo(const SwPointF& ctrl, const SwPointF& end);

    /**
     * @brief Performs the `arcTo` operation.
     * @param rect Rectangle used by the operation.
     * @param startAngle Value passed to the method.
     * @param sweepLength Value passed to the method.
     */
    void arcTo(const SwRectF& rect, double startAngle, double sweepLength);

    /**
     * @brief Performs the `arcMoveTo` operation.
     * @param rect Rectangle used by the operation.
     * @param angle Value passed to the method.
     */
    void arcMoveTo(const SwRectF& rect, double angle);

    /**
     * @brief Closes the subpath handled by the object.
     *
     * @details The call affects the runtime state associated with the underlying resource or service.
     */
    void closeSubpath();

    // -------------------------------------------------------------------
    // Convenience shapes
    // -------------------------------------------------------------------
    /**
     * @brief Adds the specified rect.
     * @param rect Rectangle used by the operation.
     */
    void addRect(const SwRectF& rect);
    /**
     * @brief Adds the specified rect.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param w Width value.
     */
    void addRect(double x, double y, double w, double h);

    /**
     * @brief Adds the specified ellipse.
     * @param rect Rectangle used by the operation.
     */
    void addEllipse(const SwRectF& rect);
    /**
     * @brief Adds the specified ellipse.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param w Width value.
     */
    void addEllipse(double x, double y, double w, double h);
    /**
     * @brief Adds the specified ellipse.
     * @param center Value passed to the method.
     * @param rx Value passed to the method.
     * @param ry Value passed to the method.
     */
    void addEllipse(const SwPointF& center, double rx, double ry);

    /**
     * @brief Adds the specified rounded Rect.
     * @param rect Rectangle used by the operation.
     * @param xRadius Value passed to the method.
     * @param yRadius Value passed to the method.
     */
    void addRoundedRect(const SwRectF& rect, double xRadius, double yRadius);

    /**
     * @brief Adds the specified polygon.
     * @param polygon Value passed to the method.
     */
    void addPolygon(const SwPolygonF& polygon);

    /**
     * @brief Adds the specified path.
     * @param other Value passed to the method.
     */
    void addPath(const SwPainterPath& other);

    /**
     * @brief Performs the `connectPath` operation.
     * @param other Value passed to the method.
     */
    void connectPath(const SwPainterPath& other);

    // -------------------------------------------------------------------
    // Queries
    // -------------------------------------------------------------------
    /**
     * @brief Returns whether the object reports empty.
     * @return `true` when the object reports empty; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isEmpty() const;
    /**
     * @brief Performs the `elementCount` operation.
     * @return The requested element Count.
     */
    int elementCount() const;
    /**
     * @brief Performs the `elementAt` operation.
     * @param i Value passed to the method.
     * @return The requested element At.
     */
    const Element& elementAt(int i) const;

    /**
     * @brief Returns the current elements.
     * @return The current elements.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const std::vector<Element>& elements() const;

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Sets the fill Rule.
     * @param rule Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFillRule(FillRule rule);
    /**
     * @brief Returns the current fill Rule.
     * @return The current fill Rule.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    FillRule fillRule() const;

    /**
     * @brief Returns the current current Position.
     * @return The current current Position.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF currentPosition() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const;

    /**
     * @brief Returns the current control Point Rect.
     * @return The current control Point Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF controlPointRect() const;

    /**
     * @brief Performs the `contains` operation.
     * @param point Point used by the operation.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwPointF& point) const;

    /**
     * @brief Performs the `contains` operation.
     * @param rect Rectangle used by the operation.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwRectF& rect) const;

    /**
     * @brief Performs the `intersects` operation.
     * @param rect Rectangle used by the operation.
     * @return `true` on success; otherwise `false`.
     */
    bool intersects(const SwRectF& rect) const;

    // -------------------------------------------------------------------
    // Flatten path to polygon (for hit-testing and rendering)
    // -------------------------------------------------------------------
    /**
     * @brief Performs the `toFillPolygon` operation.
     * @param transform Value passed to the method.
     * @return The requested to Fill Polygon.
     */
    SwPolygonF toFillPolygon(const SwTransform& transform = SwTransform()) const;

    /**
     * @brief Performs the `toFillPolygon` operation.
     * @param int Value passed to the method.
     * @return The requested to Fill Polygon.
     */
    SwPolygonF toFillPolygon(int /* ignored flatness */) const;

    /**
     * @brief Performs the `toSubpathPolygons` operation.
     * @param transform Value passed to the method.
     * @return The requested to Subpath Polygons.
     */
    std::vector<SwPolygonF> toSubpathPolygons(const SwTransform& transform = SwTransform()) const;

    // -------------------------------------------------------------------
    // Translate / transform
    // -------------------------------------------------------------------
    /**
     * @brief Performs the `translate` operation.
     * @param dx Value passed to the method.
     * @param dy Value passed to the method.
     */
    void translate(double dx, double dy);
    /**
     * @brief Performs the `translate` operation.
     * @param y Vertical coordinate.
     */
    void translate(const SwPointF& offset);

    /**
     * @brief Performs the `translated` operation.
     * @param dx Value passed to the method.
     * @param dy Value passed to the method.
     * @return The requested translated.
     */
    SwPainterPath translated(double dx, double dy) const;
    /**
     * @brief Performs the `translated` operation.
     * @param y Vertical coordinate.
     * @return The requested translated.
     */
    SwPainterPath translated(const SwPointF& offset) const;

    // -------------------------------------------------------------------
    // Boolean operations (approximate, via polygon)
    // -------------------------------------------------------------------
    /**
     * @brief Performs the `united` operation.
     * @param other Value passed to the method.
     * @return The requested united.
     */
    SwPainterPath united(const SwPainterPath& other) const;

    /**
     * @brief Performs the `intersected` operation.
     * @return The requested intersected.
     */
    SwPainterPath intersected(const SwPainterPath& /*other*/) const;

    /**
     * @brief Performs the `subtracted` operation.
     * @return The requested subtracted.
     */
    SwPainterPath subtracted(const SwPainterPath& /*other*/) const;

    /**
     * @brief Returns the current simplified.
     * @return The current simplified.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath simplified() const;

    // -------------------------------------------------------------------
    // Reverse
    // -------------------------------------------------------------------
    /**
     * @brief Returns the current to Reversed.
     * @return The current to Reversed.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath toReversed() const;

    /**
     * @brief The path cut into dashes, for a dashed stroke.
     * @param pattern Lengths drawn and skipped in turn, in the path's units: {6, 4} draws 6, skips 4.
     * @param offset Where in the pattern the path starts.
     *
     * Curves are flattened first. A dash runs on across vertices and across a closed subpath's
     * closing point; each subpath starts the pattern again at @p offset. A pattern that is empty,
     * holds a negative length or adds up to nothing returns the path unchanged.
     */
    SwPainterPath dashed(const SwVector<double>& pattern, double offset = 0.0) const;

    // -------------------------------------------------------------------
    // Length / percent
    // -------------------------------------------------------------------
    /**
     * @brief Returns the current length.
     * @return The current length.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double length() const;

    /**
     * @brief Performs the `percentAtLength` operation.
     * @param len Value passed to the method.
     * @return The requested percent At Length.
     */
    double percentAtLength(double len) const;

    /**
     * @brief Performs the `pointAtPercent` operation.
     * @param t Value passed to the method.
     * @return The requested point At Percent.
     */
    SwPointF pointAtPercent(double t) const;

    /**
     * @brief Performs the `angleAtPercent` operation.
     * @param t Value passed to the method.
     * @return The requested angle At Percent.
     */
    double angleAtPercent(double t) const;

    /**
     * @brief Performs the `slopeAtPercent` operation.
     * @param t Value passed to the method.
     * @return The requested slope At Percent.
     */
    double slopeAtPercent(double t) const;

    // -------------------------------------------------------------------
    // Swap / comparison
    // -------------------------------------------------------------------
    /**
     * @brief Performs the `swap` operation.
     * @param m_fillRule Value passed to the method.
     */
    void swap(SwPainterPath& other);

    /**
     * @brief Performs the `operator==` operation.
     * @param o Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator==(const SwPainterPath& o) const;
    /**
     * @brief Performs the `operator!=` operation.
     * @param this Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator!=(const SwPainterPath& o) const;

    // flattenCubic_ is public for external rendering (e.g. SwGraphicsPathItem)
    /**
     * @brief Performs the `flattenCubic_` operation.
     * @param p0 Value passed to the method.
     * @param p1 Value passed to the method.
     * @param p2 Value passed to the method.
     * @param p3 Value passed to the method.
     * @param out Value passed to the method.
     * @param t Value passed to the method.
     * @param mapP0 Value passed to the method.
     * @param depth Value passed to the method.
     * @return The requested flatten Cubic.
     */
    static void flattenCubic_(const SwPointF& p0, const SwPointF& p1, const SwPointF& p2, const SwPointF& p3,
                              SwPolygonF& out, const SwTransform& t, bool mapP0 = false, int depth = 0);

private:

    void flattenTo_(SwPolygonF& out, const SwTransform& t) const;

    SwPainterPath intersected_(const SwRectF& rect) const;
public:
    ~SwPainterPath();
public:
    SwPainterPath(const SwPainterPath& other);
    SwPainterPath& operator=(const SwPainterPath& other);
private:
    // What the class keeps (SwPainterPath_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

// Inline definition of flattenCubic_ (public static, used by SwGraphicsPathItem paint)
