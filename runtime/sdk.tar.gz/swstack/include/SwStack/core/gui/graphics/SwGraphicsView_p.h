#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwGraphicsView.h"

struct SwGraphicsView::Data {
    // --- Members ---
    SwGraphicsScene* m_scene{nullptr};
    double m_scale{1.0};
    SwPointF m_scroll{0.0, 0.0};
    SwTransform m_viewTransform{};
    SwRectF m_sceneRectOverride{};
    // Drag mode
    DragMode m_dragMode{NoDrag};
    bool m_interactive{true};
    bool m_dragging{false};
    SwPointF m_lastDragPos{};
    // Rubber band
    bool m_rubberBanding{false};
    SwPointF m_rubberBandOrigin{};
    SwRectF m_rubberBandRect{};
    // Render hints / optimization
    int m_renderHints{0};
    ViewportUpdateMode m_viewportUpdateMode{MinimalViewportUpdate};
    int m_optimizationFlags{0};
    // Anchors / alignment
    ViewportAnchor m_transformationAnchor{AnchorViewCenter};
    ViewportAnchor m_resizeAnchor{NoAnchor};
    int m_alignment{AlignCenter};
    int m_cacheMode{CacheNone};
    // Proxy widgets
    std::vector<SwWidget*> m_proxyWidgets;
};
