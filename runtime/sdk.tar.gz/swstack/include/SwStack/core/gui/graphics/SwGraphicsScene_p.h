#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwGraphicsScene.h"

struct SwGraphicsScene::Data {
    SwRectF m_sceneRect{};
    std::vector<SwGraphicsItem*> m_items;
    std::vector<SwGraphicsView*> m_views;
    // Selection
    SwPainterPath m_selectionArea{};
    // Focus
    SwGraphicsItem* m_focusItem{nullptr};
    bool m_stickyFocus{false};
    // Mouse
    SwGraphicsItem* m_mouseGrabberItem{nullptr};
    SwGraphicsItem* m_keyboardGrabberItem{nullptr};
    SwGraphicsItem* m_movingItem{nullptr};
    SwGraphicsItem* m_lastHoverItem{nullptr};
    SwPointF m_lastMouseScenePos{};
    SwPoint m_lastMouseScreenPos{0, 0};
    // Background / foreground
    SwBrush m_backgroundBrush{};
    SwBrush m_foregroundBrush{};
    SwFont m_font{};
    // Index
    ItemIndexMethod m_indexMethod{NoIndex};
    int m_bspTreeDepth{0};
    double m_minimumRenderSize{0.0};
};
