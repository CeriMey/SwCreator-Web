#pragma once

// Private, backend-independent text geometry. SwFontMetrics resolves the same
// font face and logical units as the active painter (Windows, X11 or Canvas).
#include "core/gui/graphics/SwFontMetrics.h"
#include <algorithm>
#include <vector>

namespace swTextGeometry {
class FontMetricsCache {
public:
    int height(const SwFont& font) const {
        for (const auto& entry : m_entries)
            if (entry.font == font) return entry.height;
        const int height = (std::max)(1, SwFontMetrics(font).height());
        if (m_entries.size() >= 32) m_entries.clear();
        m_entries.push_back({font, height});
        return height;
    }
private:
    struct Entry { SwFont font; int height; };
    mutable std::vector<Entry> m_entries;
};

inline int lineHeight(int fontHeight, int minimumHeight = 0) {
    return (std::max)((std::max)(1, fontHeight) + 4, minimumHeight);
}

inline SwRect caretRect(const SwRect& line, int x, int fontHeight) {
    if (line.height <= 0) return {x, line.y, 1, 0};
    const int height = (std::max)(1, (std::min)(line.height, fontHeight));
    return {x, line.y + (std::max)(0, (line.height - height) / 2), 1, height};
}
}
