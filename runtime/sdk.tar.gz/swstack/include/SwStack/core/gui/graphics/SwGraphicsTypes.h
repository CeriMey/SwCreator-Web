#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwGraphicsTypes.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwGraphicsTypes in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the graphics types interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwPointF, SwSizeF, SwRectF, SwLineF, SwPolygonF, and
 * SwTransform.
 *
 * Type-oriented declarations here establish shared vocabulary for the surrounding subsystem so
 * multiple components can exchange data and configuration without ad-hoc conventions.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Defines the geometry primitives shared by the graphics subsystem.
 *
 * This header plays the same foundational role as a small 2D math module. It
 * provides points, sizes, rectangles, lines, polygons, and supporting helpers
 * that are reused by painting code, scene graphs, event payloads, and view
 * coordinate conversion logic.
 *
 * The types are deliberately plain and header-only so they can be embedded in
 * higher-level classes without additional allocation, virtual dispatch, or
 * platform dependencies.
 */

#include <algorithm>
#include <cmath>
#include <vector>

#ifndef SW_PI
#define SW_PI 3.14159265358979323846
#endif

// ---------------------------------------------------------------------------
// SwPointF
// ---------------------------------------------------------------------------
/**
 * @brief Represents a point in double-precision 2D space.
 */
struct SW_GUI_EXPORT SwPointF {
    double x{0.0};
    double y{0.0};

    /**
     * @brief Constructs a `SwPointF` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwPointF() = default;
    /**
     * @brief Constructs a `SwPointF` instance.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwPointF(double px, double py);

    /**
     * @brief Performs the `manhattanLength` operation.
     * @param y Vertical coordinate.
     * @return The requested manhattan Length.
     */
    double manhattanLength() const;
    /**
     * @brief Returns whether the object reports null.
     * @return `true` when the object reports null; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isNull() const;

    /**
     * @brief Performs the `operator+=` operation.
     * @param o Value passed to the method.
     * @return The requested operator +=.
     */
    SwPointF& operator+=(const SwPointF& o);
    /**
     * @brief Performs the `operator-=` operation.
     * @param o Value passed to the method.
     * @return The requested operator -=.
     */
    SwPointF& operator-=(const SwPointF& o);
    /**
     * @brief Performs the `operator*=` operation.
     * @param f Value passed to the method.
     * @return The requested operator *=.
     */
    SwPointF& operator*=(double f);
    /**
     * @brief Performs the `operator/=` operation.
     * @param f Value passed to the method.
     * @return The requested operator /=.
     */
    SwPointF& operator/=(double f);

    friend SwPointF operator+(const SwPointF& a, const SwPointF& b) { return {a.x + b.x, a.y + b.y}; }
    friend SwPointF operator-(const SwPointF& a, const SwPointF& b) { return {a.x - b.x, a.y - b.y}; }
    friend SwPointF operator*(const SwPointF& p, double f) { return {p.x * f, p.y * f}; }
    friend SwPointF operator*(double f, const SwPointF& p) { return {p.x * f, p.y * f}; }
    friend bool operator==(const SwPointF& a, const SwPointF& b) { return a.x == b.x && a.y == b.y; }
    friend bool operator!=(const SwPointF& a, const SwPointF& b) { return !(a == b); }

    /**
     * @brief Performs the `dotProduct` operation.
     * @param a Value passed to the method.
     * @param b Value passed to the method.
     * @return The requested dot Product.
     */
    static double dotProduct(const SwPointF& a, const SwPointF& b);
};

struct SwRectF;

inline SwRectF swBoundingRectOfPoints(const SwPointF* points, int count);
inline double swDistance(const SwPointF& a, const SwPointF& b);

// ---------------------------------------------------------------------------
// SwSizeF
// ---------------------------------------------------------------------------
/**
 * @brief Represents a width/height pair in double-precision space.
 */
struct SW_GUI_EXPORT SwSizeF {
    double w{-1.0};
    double h{-1.0};

    /**
     * @brief Constructs a `SwSizeF` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSizeF() = default;
    /**
     * @brief Constructs a `SwSizeF` instance.
     * @param pw Value passed to the method.
     * @param ph Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSizeF(double pw, double ph);

    /**
     * @brief Returns the current width.
     * @return The current width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double width() const;
    /**
     * @brief Returns the current height.
     * @return The current height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double height() const;
    /**
     * @brief Sets the width.
     * @param pw Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWidth(double pw);
    /**
     * @brief Sets the height.
     * @param ph Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeight(double ph);

    /**
     * @brief Returns whether the object reports empty.
     * @return `true` when the object reports empty; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isEmpty() const;
    /**
     * @brief Returns whether the object reports null.
     * @return `true` when the object reports null; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isNull() const;
    /**
     * @brief Returns whether the object reports valid.
     * @return `true` when the object reports valid; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isValid() const;

    /**
     * @brief Performs the `transpose` operation.
     */
    void transpose();
    /**
     * @brief Returns the current transposed.
     * @return The current transposed.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSizeF transposed() const;

    /**
     * @brief Performs the `expandedTo` operation.
     * @param h Height value.
     * @return The requested expanded To.
     */
    SwSizeF expandedTo(const SwSizeF& o) const;
    /**
     * @brief Performs the `boundedTo` operation.
     * @param h Height value.
     * @return The requested bounded To.
     */
    SwSizeF boundedTo(const SwSizeF& o) const;

    /**
     * @brief Performs the `operator+=` operation.
     * @param o Value passed to the method.
     * @return The requested operator +=.
     */
    SwSizeF& operator+=(const SwSizeF& o);
    /**
     * @brief Performs the `operator-=` operation.
     * @param o Value passed to the method.
     * @return The requested operator -=.
     */
    SwSizeF& operator-=(const SwSizeF& o);
    /**
     * @brief Performs the `operator*=` operation.
     * @param f Value passed to the method.
     * @return The requested operator *=.
     */
    SwSizeF& operator*=(double f);
    /**
     * @brief Performs the `operator/=` operation.
     * @param f Value passed to the method.
     * @return The requested operator /=.
     */
    SwSizeF& operator/=(double f);

    friend bool operator==(const SwSizeF& a, const SwSizeF& b) { return a.w == b.w && a.h == b.h; }
    friend bool operator!=(const SwSizeF& a, const SwSizeF& b) { return !(a == b); }
};

// ---------------------------------------------------------------------------
// SwRectF
// ---------------------------------------------------------------------------
/**
 * @brief Represents an axis-aligned rectangle using double-precision geometry.
 */
struct SW_GUI_EXPORT SwRectF {
    double x{0.0};
    double y{0.0};
    double width{0.0};
    double height{0.0};

    /**
     * @brief Constructs a `SwRectF` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwRectF() = default;
    /**
     * @brief Constructs a `SwRectF` instance.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     * @param w Width value.
     * @param h Height value.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwRectF(double px, double py, double w, double h);
    /**
     * @brief Constructs a `SwRectF` instance.
     * @param topLeft Value passed to the method.
     * @param h Height value.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwRectF(const SwPointF& topLeft, const SwSizeF& size);
    /**
     * @brief Constructs a `SwRectF` instance.
     * @param topLeft Value passed to the method.
     * @param y Vertical coordinate.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwRectF(const SwPointF& topLeft, const SwPointF& bottomRight);

    /**
     * @brief Returns the current left.
     * @return The current left.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double left() const;
    /**
     * @brief Returns the current top.
     * @return The current top.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double top() const;
    /**
     * @brief Returns the current right.
     * @return The current right.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double right() const;
    /**
     * @brief Returns the current bottom.
     * @return The current bottom.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double bottom() const;

    /**
     * @brief Returns the current top Left.
     * @return The current top Left.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF topLeft() const;
    /**
     * @brief Returns the current top Right.
     * @return The current top Right.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF topRight() const;
    /**
     * @brief Returns the current bottom Left.
     * @return The current bottom Left.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF bottomLeft() const;
    /**
     * @brief Returns the current bottom Right.
     * @return The current bottom Right.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF bottomRight() const;
    /**
     * @brief Returns the current center.
     * @return The current center.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF center() const;

    /**
     * @brief Returns the current size.
     * @return The current size.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSizeF size() const;
    /**
     * @brief Sets the size.
     * @param s Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSize(const SwSizeF& s);

    /**
     * @brief Sets the left.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLeft(double v);
    /**
     * @brief Sets the top.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTop(double v);
    /**
     * @brief Sets the right.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRight(double v);
    /**
     * @brief Sets the bottom.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBottom(double v);
    /**
     * @brief Sets the top Left.
     * @param y Vertical coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTopLeft(const SwPointF& p);
    /**
     * @brief Sets the bottom Right.
     * @param y Vertical coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBottomRight(const SwPointF& p);

    /**
     * @brief Sets the x.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setX(double v);
    /**
     * @brief Sets the y.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setY(double v);
    /**
     * @brief Sets the width.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWidth(double v);
    /**
     * @brief Sets the height.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeight(double v);

    /**
     * @brief Returns whether the object reports empty.
     * @return `true` when the object reports empty; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isEmpty() const;
    /**
     * @brief Returns whether the object reports null.
     * @return `true` when the object reports null; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isNull() const;
    /**
     * @brief Returns whether the object reports valid.
     * @return `true` when the object reports valid; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isValid() const;

    /**
     * @brief Returns the current normalized.
     * @return The current normalized.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF normalized() const;

    /**
     * @brief Performs the `contains` operation.
     * @param p Value passed to the method.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwPointF& p) const;

    /**
     * @brief Performs the `contains` operation.
     * @param other Value passed to the method.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwRectF& other) const;

    /**
     * @brief Performs the `intersects` operation.
     * @param other Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool intersects(const SwRectF& other) const;

    /**
     * @brief Performs the `intersected` operation.
     * @param other Value passed to the method.
     * @return The requested intersected.
     */
    SwRectF intersected(const SwRectF& other) const;

    /**
     * @brief Performs the `united` operation.
     * @param other Value passed to the method.
     * @return The requested united.
     */
    SwRectF united(const SwRectF& other) const;

    /**
     * @brief Performs the `translate` operation.
     * @param dx Value passed to the method.
     * @param dy Value passed to the method.
     */
    void translate(double dx, double dy);
    /**
     * @brief Performs the `translate` operation.
     * @param offset Value passed to the method.
     */
    void translate(const SwPointF& offset);
    /**
     * @brief Performs the `translated` operation.
     * @param dx Value passed to the method.
     * @param dy Value passed to the method.
     * @return The requested translated.
     */
    SwRectF translated(double dx, double dy) const;
    /**
     * @brief Performs the `translated` operation.
     * @param offset Value passed to the method.
     * @return The requested translated.
     */
    SwRectF translated(const SwPointF& offset) const;

    /**
     * @brief Performs the `moveCenter` operation.
     * @param p Value passed to the method.
     */
    void moveCenter(const SwPointF& p);
    /**
     * @brief Performs the `moveTopLeft` operation.
     * @param p Value passed to the method.
     */
    void moveTopLeft(const SwPointF& p);
    /**
     * @brief Performs the `moveTo` operation.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     */
    void moveTo(double px, double py);
    /**
     * @brief Performs the `moveTo` operation.
     * @param p Value passed to the method.
     */
    void moveTo(const SwPointF& p);

    /**
     * @brief Performs the `adjust` operation.
     * @param dx1 Value passed to the method.
     * @param dy1 Value passed to the method.
     * @param dx2 Value passed to the method.
     * @param dy2 Value passed to the method.
     */
    void adjust(double dx1, double dy1, double dx2, double dy2);
    /**
     * @brief Performs the `adjusted` operation.
     * @param dx1 Value passed to the method.
     * @param dy1 Value passed to the method.
     * @param dx2 Value passed to the method.
     * @param dy2 Value passed to the method.
     * @return The requested adjusted.
     */
    SwRectF adjusted(double dx1, double dy1, double dx2, double dy2) const;

    friend bool operator==(const SwRectF& a, const SwRectF& b) {
        return a.x == b.x && a.y == b.y && a.width == b.width && a.height == b.height;
    }
    friend bool operator!=(const SwRectF& a, const SwRectF& b) { return !(a == b); }
};

// ---------------------------------------------------------------------------
// SwLineF
// ---------------------------------------------------------------------------
/**
 * @brief Represents a line segment between two points.
 */
struct SW_GUI_EXPORT SwLineF {
    SwPointF p1{};
    SwPointF p2{};

    /**
     * @brief Constructs a `SwLineF` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwLineF() = default;
    /**
     * @brief Constructs a `SwLineF` instance.
     * @param a Value passed to the method.
     * @param b Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwLineF(const SwPointF& a, const SwPointF& b);
    /**
     * @brief Constructs a `SwLineF` instance.
     * @param x1 Value passed to the method.
     * @param y1 Value passed to the method.
     * @param x2 Value passed to the method.
     * @param y2 Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwLineF(double x1, double y1, double x2, double y2);

    /**
     * @brief Performs the `length` operation.
     * @param p2 Value passed to the method.
     * @return The current length value.
     */
    double length() const;
    /**
     * @brief Returns the current dx.
     * @return The current dx.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double dx() const;
    /**
     * @brief Returns the current dy.
     * @return The current dy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double dy() const;
    /**
     * @brief Performs the `angle` operation.
     * @return The requested angle.
     */
    double angle() const;
    /**
     * @brief Returns whether the object reports null.
     * @return `true` when the object reports null; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isNull() const;

    /**
     * @brief Performs the `center` operation.
     * @param y Vertical coordinate.
     * @return The requested center.
     */
    SwPointF center() const;
    /**
     * @brief Performs the `pointAt` operation.
     * @param y Vertical coordinate.
     * @return The requested point At.
     */
    SwPointF pointAt(double t) const;

    /**
     * @brief Sets the length.
     * @param len Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLength(double len);

    /**
     * @brief Performs the `normalVector` operation.
     * @return The requested normal Vector.
     */
    SwLineF normalVector() const;
    /**
     * @brief Returns the current unit Vector.
     * @return The current unit Vector.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwLineF unitVector() const;

    /**
     * @brief Performs the `translate` operation.
     * @param offset Value passed to the method.
     */
    void translate(const SwPointF& offset);
    /**
     * @brief Performs the `translate` operation.
     * @param dx Value passed to the method.
     */
    void translate(double dx, double dy);
    /**
     * @brief Performs the `translated` operation.
     * @param offset Value passed to the method.
     * @return The requested translated.
     */
    SwLineF translated(const SwPointF& offset) const;
};

// ---------------------------------------------------------------------------
// SwPolygonF
// ---------------------------------------------------------------------------
struct SW_GUI_EXPORT SwPolygonF {
    std::vector<SwPointF> points;

    /**
     * @brief Constructs a `SwPolygonF` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwPolygonF() = default;
    /**
     * @brief Constructs a `SwPolygonF` instance.
     * @param pts Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwPolygonF(std::initializer_list<SwPointF> pts);
    /**
     * @brief Constructs a `SwPolygonF` instance.
     * @param pts Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwPolygonF(const std::vector<SwPointF>& pts);

    /**
     * @brief Performs the `append` operation.
     * @param p Value passed to the method.
     */
    void append(const SwPointF& p);
    /**
     * @brief Performs the `size` operation.
     * @return The current size value.
     */
    int size() const;
    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const;
    /**
     * @brief Returns whether the object reports empty.
     * @return `true` when the object reports empty; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isEmpty() const;
    /**
     * @brief Clears the current object state.
     */
    void clear();
    /**
     * @brief Performs the `at` operation.
     * @param i Value passed to the method.
     * @return The requested at.
     */
    const SwPointF& at(int i) const;
    /**
     * @brief Performs the `first` operation.
     * @return The requested first.
     */
    const SwPointF& first() const;
    /**
     * @brief Performs the `last` operation.
     * @return The requested last.
     */
    const SwPointF& last() const;
    /**
     * @brief Performs the `operator[]` operation.
     * @param i Value passed to the method.
     * @return The requested operator [].
     */
    SwPointF& operator[](int i);
    /**
     * @brief Performs the `operator[]` operation.
     * @param i Value passed to the method.
     * @return The requested operator [].
     */
    const SwPointF& operator[](int i) const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const;

    /**
     * @brief Performs the `containsPoint` operation.
     * @param p Value passed to the method.
     * @return `true` when the object reports contains Point; otherwise `false`.
     */
    bool containsPoint(const SwPointF& p) const;

    /**
     * @brief Performs the `translated` operation.
     * @param dx Value passed to the method.
     * @param dy Value passed to the method.
     * @return The requested translated.
     */
    SwPolygonF translated(double dx, double dy) const;
    /**
     * @brief Performs the `translated` operation.
     * @param y Vertical coordinate.
     * @return The requested translated.
     */
    SwPolygonF translated(const SwPointF& offset) const;
    /**
     * @brief Performs the `translate` operation.
     * @param dx Value passed to the method.
     * @param points Value passed to the method.
     */
    void translate(double dx, double dy);
    /**
     * @brief Performs the `translate` operation.
     * @param y Vertical coordinate.
     */
    void translate(const SwPointF& offset);
};

// ---------------------------------------------------------------------------
// Free helpers
// ---------------------------------------------------------------------------
inline SwRectF swBoundingRectOfPoints(const SwPointF* points, int count) {
    if (!points || count <= 0) return {};
    double minX = points[0].x, maxX = points[0].x;
    double minY = points[0].y, maxY = points[0].y;
    for (int i = 1; i < count; ++i) {
        minX = std::min(minX, points[i].x);
        maxX = std::max(maxX, points[i].x);
        minY = std::min(minY, points[i].y);
        maxY = std::max(maxY, points[i].y);
    }
    return SwRectF(minX, minY, maxX - minX, maxY - minY);
}

inline double swDistance(const SwPointF& a, const SwPointF& b) {
    const double dx = a.x - b.x;
    const double dy = a.y - b.y;
    return std::sqrt(dx * dx + dy * dy);
}

// ---------------------------------------------------------------------------
// SwTransform  (QTransform equivalent — 3x3 affine / projective matrix)
//
//   | m11  m12  m13 |     Mapping: x' = m11*x + m21*y + m31
//   | m21  m22  m23 |              y' = m12*x + m22*y + m32
//   | m31  m32  m33 |              w' = m13*x + m23*y + m33
//                                  result = (x'/w', y'/w')
// ---------------------------------------------------------------------------
class SW_GUI_EXPORT SwTransform {
public:
    enum TransformationType { TxNone, TxTranslate, TxScale, TxRotate, TxShear, TxProject };

    /**
     * @brief Constructs a `SwTransform` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwTransform();

    /**
     * @brief Constructs a `SwTransform` instance.
     * @param m11 Value passed to the method.
     * @param m12 Value passed to the method.
     * @param m13 Value passed to the method.
     * @param m21 Value passed to the method.
     * @param m22 Value passed to the method.
     * @param m23 Value passed to the method.
     * @param m31 Value passed to the method.
     * @param m32 Value passed to the method.
     * @param m33 Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwTransform(double m11, double m12, double m13,
                double m21, double m22, double m23,
                double m31, double m32, double m33);

    /**
     * @brief Constructs a `SwTransform` instance.
     * @param m11 Value passed to the method.
     * @param m12 Value passed to the method.
     * @param m21 Value passed to the method.
     * @param m22 Value passed to the method.
     * @param dx Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwTransform(double m11, double m12,
                double m21, double m22,
                double dx, double dy);

    // Element access
    /**
     * @brief Returns the current m11.
     * @return The current m11.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m11() const;
    /**
     * @brief Returns the current m12.
     * @return The current m12.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m12() const;
    /**
     * @brief Returns the current m13.
     * @return The current m13.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m13() const;
    /**
     * @brief Returns the current m21.
     * @return The current m21.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m21() const;
    /**
     * @brief Returns the current m22.
     * @return The current m22.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m22() const;
    /**
     * @brief Returns the current m23.
     * @return The current m23.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m23() const;
    /**
     * @brief Returns the current m31.
     * @return The current m31.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m31() const;
    /**
     * @brief Returns the current m32.
     * @return The current m32.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m32() const;
    /**
     * @brief Returns the current m33.
     * @return The current m33.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double m33() const;
    /**
     * @brief Returns the current dx.
     * @return The current dx.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double dx() const;
    /**
     * @brief Returns the current dy.
     * @return The current dy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double dy() const;

    /**
     * @brief Sets the matrix.
     * @param m11 Value passed to the method.
     * @param m12 Value passed to the method.
     * @param m13 Value passed to the method.
     * @param m21 Value passed to the method.
     * @param m22 Value passed to the method.
     * @param m23 Value passed to the method.
     * @param m31 Value passed to the method.
     * @param m32 Value passed to the method.
     * @param m33 Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMatrix(double m11, double m12, double m13,
                   double m21, double m22, double m23,
                   double m31, double m32, double m33);

    // Identity / type queries
    /**
     * @brief Returns whether the object reports identity.
     * @return `true` when the object reports identity; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isIdentity() const;
    /**
     * @brief Returns whether the object reports affine.
     * @return `true` when the object reports affine; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isAffine() const;
    /**
     * @brief Returns whether the object reports translating.
     * @return `true` when the object reports translating; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isTranslating() const;
    /**
     * @brief Returns whether the object reports rotating.
     * @return `true` when the object reports rotating; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isRotating() const;
    /**
     * @brief Returns whether the object reports scaling.
     * @return `true` when the object reports scaling; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isScaling() const;

    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    TransformationType type() const;

    /**
     * @brief Returns the current determinant.
     * @return The current determinant.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double determinant() const;

    /**
     * @brief Returns whether the object reports invertible.
     * @return `true` when the object reports invertible; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isInvertible() const;

    /**
     * @brief Resets the object to a baseline state.
     * @param this Value passed to the method.
     */
    void reset();

    // Chainable mutators (post-multiply style, same as Qt)
    /**
     * @brief Performs the `translate` operation.
     * @param tdx Value passed to the method.
     * @param tdy Value passed to the method.
     * @return The requested translate.
     */
    SwTransform& translate(double tdx, double tdy);

    /**
     * @brief Performs the `scale` operation.
     * @param sx Value passed to the method.
     * @param sy Value passed to the method.
     * @return The requested scale.
     */
    SwTransform& scale(double sx, double sy);

    /**
     * @brief Performs the `rotate` operation.
     * @param angleDegrees Value passed to the method.
     * @return The requested rotate.
     */
    SwTransform& rotate(double angleDegrees);

    /**
     * @brief Performs the `shear` operation.
     * @param sh Value passed to the method.
     * @param sv Value passed to the method.
     * @return The requested shear.
     */
    SwTransform& shear(double sh, double sv);

    // Mapping
    /**
     * @brief Performs the `map` operation.
     * @param p Value passed to the method.
     * @return The requested map.
     */
    SwPointF map(const SwPointF& p) const;

    /**
     * @brief Performs the `map` operation.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param mx Value passed to the method.
     * @param my Value passed to the method.
     */
    void map(double x, double y, double* mx, double* my) const;

    /**
     * @brief Performs the `map` operation.
     * @param p2 Value passed to the method.
     * @return The requested map.
     */
    SwLineF map(const SwLineF& l) const;

    /**
     * @brief Performs the `map` operation.
     * @param poly Value passed to the method.
     * @return The requested map.
     */
    SwPolygonF map(const SwPolygonF& poly) const;

    /**
     * @brief Performs the `mapRect` operation.
     * @param r Value passed to the method.
     * @return The requested map Rect.
     */
    SwRectF mapRect(const SwRectF& r) const;

    /**
     * @brief Performs the `mapToPolygon` operation.
     * @param r Value passed to the method.
     * @return The requested map To Polygon.
     */
    SwPolygonF mapToPolygon(const SwRectF& r) const;

    // Inverse
    /**
     * @brief Performs the `inverted` operation.
     * @param invertible Value passed to the method.
     * @return The requested inverted.
     */
    SwTransform inverted(bool* invertible = nullptr) const;

    /**
     * @brief Returns the current transposed.
     * @return The current transposed.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwTransform transposed() const;

    /**
     * @brief Returns the current adjoint.
     * @return The current adjoint.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwTransform adjoint() const;

    // Operators
    /**
     * @brief Performs the `operator*` operation.
     * @param o Value passed to the method.
     * @return The requested operator *.
     */
    SwTransform operator*(const SwTransform& o) const;
    /**
     * @brief Performs the `operator*=` operation.
     * @param o Value passed to the method.
     * @return The requested operator *=.
     */
    SwTransform& operator*=(const SwTransform& o);
    /**
     * @brief Performs the `operator==` operation.
     * @param o Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator==(const SwTransform& o) const;
    /**
     * @brief Performs the `operator!=` operation.
     * @param this Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool operator!=(const SwTransform& o) const;

    // Static factories
    /**
     * @brief Performs the `fromTranslate` operation.
     * @param tdx Value passed to the method.
     * @param tdy Value passed to the method.
     * @return The requested from Translate.
     */
    static SwTransform fromTranslate(double tdx, double tdy);
    /**
     * @brief Performs the `fromScale` operation.
     * @param sx Value passed to the method.
     * @param sy Value passed to the method.
     * @return The requested from Scale.
     */
    static SwTransform fromScale(double sx, double sy);
    /**
     * @brief Performs the `fromRotate` operation.
     * @param angleDegrees Value passed to the method.
     * @return The requested from Rotate.
     */
    static SwTransform fromRotate(double angleDegrees);
    /**
     * @brief Performs the `fromShear` operation.
     * @param sh Value passed to the method.
     * @param sv Value passed to the method.
     * @return The requested from Shear.
     */
    static SwTransform fromShear(double sh, double sv);

private:
    double m_11, m_12, m_13;
    double m_21, m_22, m_23;
    double m_31, m_32, m_33;
};
