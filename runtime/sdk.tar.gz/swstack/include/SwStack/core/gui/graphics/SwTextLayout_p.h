#pragma once

// Private text geometry shared by widgets and platform backends.
// Coordinates are logical; character positions are UTF-8 byte offsets.
#include "core/gui/SwFont.h"
#include "core/gui/SwTextDocument.h"
#include "core/gui/SwWidgetPlatformAdapter.h"
#include <list>
#include <memory>
#include <vector>

class SwPainter;

namespace swTextLayout {
class SW_GUI_EXPORT RunLayout {
public:
    RunLayout(const SwWidgetPlatformHandle& handle, const SwString& text, const SwFont& font);
    float advance() const;
    float position(size_t byteOffset) const;
    size_t hitTest(float x) const;
private:
    struct Data;
    std::shared_ptr<const Data> d_;
};

struct Segment {
    size_t start{0}, end{0};
    SwFont font;
    SwTextCharFormat format;
    bool formatted{false};
    int x{0};
};

// Color, background and decorations never split shaping. Only a different
// typeface/size/weight/style starts a new run.
struct ShapedRun {
    size_t start{0}, end{0};
    SwString text;
    SwFont font;
    int x{0};
    float advance{0.0f};
    std::shared_ptr<const RunLayout> layout;
};

class SW_GUI_EXPORT FormattedLine {
public:
    FormattedLine(const SwWidgetPlatformHandle& handle, const SwString& text,
                  const SwFont& font, const SwList<SwTextLayoutFormatRange>& formats);
    int offset(size_t byteOffset) const;
    size_t index(int x) const;
    void draw(SwPainter* painter, const SwRect& line, const SwColor& foreground) const;

    SwString text;
    SwFont font;
    SwList<SwTextLayoutFormatRange> formats;
    std::vector<Segment> segments;
    std::vector<ShapedRun> runs;
    int width{0};
    size_t retainedBytes{0};
};

class SW_GUI_EXPORT LineCache {
public:
    void clear() const;
    void checkFont(const SwFont& font) const;
    std::shared_ptr<const FormattedLine> get(int lineIndex,
        const SwWidgetPlatformHandle& handle, const SwString& text, const SwFont& font,
        const SwList<SwTextLayoutFormatRange>& formats) const;
    int maxWidth() const;
private:
    struct Entry { int index; std::shared_ptr<const FormattedLine> line; };
    mutable std::list<Entry> m_entries;
    mutable size_t m_bytes{0};
    mutable SwFont m_font;
    mutable SwWidgetPlatformHandle m_handle;
    mutable bool m_hasFont{false};
    mutable int m_maxWidth{0};
};
}
