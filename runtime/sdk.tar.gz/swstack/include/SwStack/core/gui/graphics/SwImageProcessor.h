#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImageProcessor.h
 * @ingroup core_graphics
 * @brief Declares the SwImageProcessor SwObject in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the asynchronous recipe executor. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwImageProcessor.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief SwImageProcessor: recipe execution as an SwObject with signals, slots and properties.
 *
 * The processor applies its `Recipe` property to every image handed to the `process()` slot and
 * reports the result through `imageReady(const SwImage&)` or `failed(const SwString&)`.
 *
 * - `Asynchronous == false`: `process()` materializes on the caller thread and emits
 *   `imageReady` / `failed` before returning.
 * - `Asynchronous == true` (default): `process()` snapshots the image and the current property
 *   values into a job, queues it and returns immediately. A `std::thread` worker (started
 *   lazily, stopped and joined in the destructor) materializes the jobs one by one. The queue
 *   holds at most `MaxQueueDepth` jobs: a new frame evicts the oldest waiting one (latest wins,
 *   as video wants) and the cumulative drop counter is emitted as `dropped(int)`.
 *
 * Signal delivery for asynchronous jobs follows SwMediaPlayer::dispatchToAffinity_ and
 * SwVideoWidget::postGuardedUiAction_: the result is marshalled to the thread that owns the
 * processor (its SwObject affinity thread) through SwObject::postToAffinity(); when the processor
 * has no live affinity thread, the current thread's SwCoreApplication::postEvent() is used; when
 * neither exists (no SwCoreApplication at all) the signals are emitted synchronously from the
 * worker thread. Every posted closure carries a weak lifetime guard and re-checks
 * SwObject::isLive(), so a destroyed processor never receives a late result. As for every
 * SwObject, the processor is expected to be destroyed on its owner thread.
 *
 * The `Backend` property ("" = automatic) forces a backend for this processor only. The global
 * SwImageBackendRegistry::ForcedBackend is never touched: the registry offers no scoped override,
 * so the processor plans the chain itself with SwImagePlanner::simplify() restricted to the
 * forced backend (transfers may use whichever backend owns a residency, exactly like the
 * planner's forced mode) and runs it through SwImagePlanner::execute().
 */

#include "SwImage.h"
#include "SwImageBackend.h"
#include "SwImageBackendRegistry.h"
#include "SwImageOps.h"
#include "SwImagePlanner.h"
#include "SwImageStorage.h"
#include "SwPixelFormat.h"
#include "SwObject.h"
#include "SwCoreApplication.h"
#include "SwString.h"
#include "SwDebug.h"
#include "Sw.h"

#include <condition_variable>
#include <cstddef>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <thread>
#include <utility>
#include <vector>

static constexpr const char* kSwLogCategory_SwImageProcessor = "sw.gui.swimageprocessor";

/**
 * @brief SwObject that applies an SwImageRecipe to incoming images, synchronously or on a worker.
 *
 * Properties (each with its generated setter, getter and `<Name>Changed` signal):
 * - `Recipe` (SwImageRecipe): the op chain applied by process(); takes effect on the next call.
 * - `Backend` (SwString): "" = automatic, else the id of the only backend allowed to run ops.
 * - `Asynchronous` (bool, default true): worker thread vs caller thread.
 * - `MaxQueueDepth` (int, default 2): frames allowed to wait; older ones are dropped.
 * - `OutputResidency` (SwImageResidency, default Cpu): where results must live (Auto = stay).
 */
class SW_GUI_EXPORT SwImageProcessor : public SwObject {
    SW_OBJECT(SwImageProcessor, SwObject)

public:
    /**
     * @brief Constructs an idle processor (no worker thread until the first asynchronous job).
     * @param parent Optional parent object that owns this instance.
     */
    explicit SwImageProcessor(SwObject* parent = nullptr);

    /**
     * @brief Invalidates the lifetime guard, stops and joins the worker, discards waiting jobs.
     *
     * Results posted to the owner thread but not yet delivered are dropped by their guard.
     */
    ~SwImageProcessor() override;

    /**
     * @brief Property Recipe: the op chain applied to every processed image.
     *
     * Takes effect on the next process() call; jobs already queued keep the recipe they were
     * queued with.
     */
    SW_PROPERTY_D(SwImageRecipe, Recipe);
private:
protected:

    /**
     * @brief Property Backend: "" = automatic (the planner decides), else a backend id such as
     * "cpu" or "d3d11" that is the only backend allowed to execute ops for this processor.
     *
     * The global registry's ForcedBackend property is never modified.
     */
    SW_PROPERTY_D(SwString, Backend);
private:
protected:

    /**
     * @brief Property Asynchronous: `true` runs jobs on the worker thread, `false` on the caller.
     *
     * Switching to `false` does not stop a running worker: jobs already queued still complete
     * asynchronously, new process() calls run inline.
     */
    SW_PROPERTY_D(bool, Asynchronous);
private:
protected:

    /**
     * @brief Property MaxQueueDepth: number of frames allowed to wait for the worker (min 1).
     *
     * When the queue is full a new frame evicts the oldest waiting one. Lowering the depth trims
     * the queue immediately; every eviction increments the counter emitted by dropped(int).
     */
    SW_PROPERTY_D(int, MaxQueueDepth);
private:
protected:

    /**
     * @brief Property OutputResidency: residency of the emitted image (Auto = wherever the last
     * backend left it).
     */
    SW_PROPERTY_D(SwImageResidency, OutputResidency);
private:
protected:

signals:
    /**
     * @brief Emitted with the materialized result (no pending op) of a processed image.
     */
    SW_SIGNAL(imageReady, const SwImage&)

    /**
     * @brief Emitted with a human-readable reason when a job cannot be executed.
     */
    SW_SIGNAL(failed, const SwString&)

    /**
     * @brief Emitted with the cumulative number of frames dropped because of MaxQueueDepth.
     */
    SW_SIGNAL(dropped, int)

public slots:
    /**
     * @brief Applies the Recipe to `image` and reports through imageReady() / failed().
     *
     * Synchronous mode: the work happens on the caller thread and the signal is emitted before
     * this method returns. Asynchronous mode: the image and the current Recipe / Backend /
     * OutputResidency are captured into a job, the worker thread is started if needed and the
     * job is queued; when the queue already holds MaxQueueDepth jobs the oldest is evicted and
     * dropped(int) is emitted on the owner thread.
     *
     * @param image Input image (a null image is reported through failed()).
     */
    void process(const SwImage& image);

public:
    /**
     * @brief Blocks until every queued job has been executed by the worker.
     *
     * Results are still delivered through the owner thread's event loop, so after flush() the
     * signals may be pending in that loop rather than already emitted. Returns immediately in
     * synchronous mode, when no worker was ever started, or when called from the worker thread.
     */
    void flush();

    /**
     * @brief Returns the number of jobs waiting for the worker (thread-safe).
     * @return Queue length (the job being executed is not counted).
     */
    std::size_t queuedCount() const;

    /**
     * @brief Returns the cumulative number of frames dropped because of MaxQueueDepth.
     * @return The value last emitted by dropped(int), 0 when nothing was dropped.
     */
    int droppedCount() const;

    /**
     * @brief Returns whether the worker thread has been started (thread-safe).
     * @return `true` after the first asynchronous process() call.
     */
    bool isWorkerRunning() const;

private:
    /**
     * @brief Snapshot of one process() call: the image plus the property values at that time.
     */
    struct Job_ {
        SwImage image;
        SwImageRecipe recipe;
        SwString backend;
        SwImageResidency residency{SwImageResidency::Cpu};
    };

    // ----------------------------------------------------------------------------------------
    // Worker thread
    // ----------------------------------------------------------------------------------------

    std::size_t queueDepthLocked_() const;

    void startWorkerLocked_();

    void stopWorker_();

    void trimQueue_();

    void workerLoop_();

    // ----------------------------------------------------------------------------------------
    // Delivery on the owner thread (weak-guarded, see SwVideoWidget::postGuardedUiAction_)
    // ----------------------------------------------------------------------------------------

    void postImageReady_(const SwImage& image);

    void postFailed_(const SwString& error);

    void emitDropped_(int total);

    /**
     * @brief Runs `fn` on the owner thread, guarded against destruction of the processor.
     *
     * Order of preference: inline when already on the affinity thread; SwObject::postToAffinity()
     * (the affinity thread's SwCoreApplication loop); the current thread's SwCoreApplication;
     * finally inline on the calling thread when no event loop is reachable (no SwCoreApplication
     * in the process).
     */
    void deliverToOwner_(std::function<void()> fn);

    // ----------------------------------------------------------------------------------------
    // Execution (static: no member is touched from the worker thread)
    // ----------------------------------------------------------------------------------------

    static void setError_(SwString* error, const SwString& message);

    static bool execute_(const Job_& job, SwImage& out, SwString* error);

    /**
     * @brief Plans and executes `work` with every op restricted to `backendId`, without touching
     * the global registry's ForcedBackend (per-call forced-backend semantics).
     */
    static bool materializeWithBackend_(const SwImage& work, const SwString& backendId,
                                        SwImageResidency preferred, SwImage& out, SwString* error);

    static bool addDownload_(const std::vector<std::shared_ptr<SwImageBackend> >& available,
                             SwImageResidency from, SwImagePlan& plan, SwString* error);

    static void addUpload_(const std::shared_ptr<SwImageBackend>& target, SwImagePlan& plan);

    // ----------------------------------------------------------------------------------------
    // State
    // ----------------------------------------------------------------------------------------

private:
    // What the class keeps (SwImageProcessor_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
