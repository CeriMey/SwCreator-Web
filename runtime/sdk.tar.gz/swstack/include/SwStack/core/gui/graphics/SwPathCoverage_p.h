#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwPainterPath.h"
#include "core/types/Sw.h"

#include <vector>

/**
 * @brief The anti-aliased coverage of a filled or stroked path, one device row at a time.
 *
 * It is how SwPainter draws SwPainter::fillPath() and the anti-aliased SwPainter::drawPath() on a
 * painter that has no native way to: the coverage, times the opacity, becomes the alpha of an image
 * handed to drawImage(), which every backend blends.
 *
 * A fill is sampled exactly along each row and on eight sub-rows per pixel, with the path's fill
 * rule. A stroke is the set of points within half the width of a segment, round at joins and ends;
 * where segments overlap a pixel keeps its largest coverage, so a stroke is painted once.
 * Coordinates are device pixels, a pixel's centre at +0.5; the coverage is limited to the first
 * 16384 pixels of each axis, the largest window a painter targets.
 */
class SwPathCoverage {
public:
    static SwPathCoverage forFill(const SwPainterPath& path);
    static SwPathCoverage forStroke(const SwPainterPath& path, double width);

    /// The device pixels the coverage can touch; empty when there is nothing to draw.
    SwRect bounds() const { return m_bounds; }

    /// The coverage of row @p y, in [0, 1], for the bounds' columns, written into @p out.
    void row(int y, float* out) const;

private:
    struct Edge {
        double x0, y0, x1, y1;   // y0 < y1
        int winding;             // +1 downwards, -1 upwards
    };
    struct Segment {
        double ax, ay, bx, by;
    };
    void fillRow_(int y, float* out) const;
    void strokeRow_(int y, float* out) const;

    SwRect m_bounds{0, 0, 0, 0};
    bool m_stroke{false};
    bool m_evenOdd{true};
    double m_width{0};
    std::vector<Edge> m_edges;
    std::vector<Segment> m_segments;
    mutable std::vector<float> m_delta;
    mutable std::vector<std::pair<double, int>> m_crossings;
};
