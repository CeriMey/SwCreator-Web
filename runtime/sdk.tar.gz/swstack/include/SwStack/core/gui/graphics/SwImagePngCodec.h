/**
 * @file src/core/gui/graphics/SwImagePngCodec.h
 * @ingroup core_graphics
 * @brief Declares the built-in PNG codec in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the PNG codec interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwImagePngCodec.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief PNG reader / writer with an in-header zlib inflater (RFC 1950 / RFC 1951).
 *
 * Decoder: 8-bit gray, gray+alpha, RGB, RGBA and palette images (including tRNS transparency),
 * 1/2/4-bit gray and palette expansions, 16-bit samples reduced to 8 bits, all five filter types.
 * Interlaced (Adam7) images are rejected with an error. Output is BGRA32, or Gray8 for grayscale
 * images without transparency. Every length and dimension is validated, no allocation exceeds
 * 1 GiB, truncated or malformed streams return `false` (never undefined behaviour).
 *
 * Encoder: 8-bit RGBA (RGB when the source has no alpha channel, Gray8 for Gray8 sources), filter
 * type 0 on every row. The deflate stream uses stored blocks (max 65535 bytes each) with Adler-32
 * and CRC-32 by default; when `SW_IMAGE_WITH_MINIZ` is defined the vendored miniz (tdefl through
 * its zlib-style `mz_compress2` entry point) produces real compression.
 *
 * Include-order note: no `#pragma once`; "SwImageCodec.h" is included first, outside the body
 * guard (see SwImageCodec.h).
 */

#include "SwImageCodec.h"

#ifndef SW_IMAGE_PNG_CODEC_H_BODY
#define SW_IMAGE_PNG_CODEC_H_BODY

#include "../../SwStackExport.h"

#include "SwString.h"
#include "SwByteArray.h"
#include "SwDebug.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>


static constexpr const char* kSwLogCategory_SwImagePngCodec = "sw.gui.swimagepngcodec";

/**
 * @brief Built-in PNG codec (priority 0).
 */
class SW_GUI_EXPORT SwImagePngCodec : public SwImageCodec {
public:
    /**
     * @brief Returns "png".
     * @return The id.
     */
    const SwString& id() const override;

    /**
     * @brief Built-in priority.
     * @return 0.
     */
    int priority() const override;

    /**
     * @brief Sniffs the 8-byte PNG signature.
     * @param magic Stream start.
     * @param n Bytes available.
     * @return `true` for a PNG signature.
     */
    bool canDecode(const std::uint8_t* magic, std::size_t n) const override;

    /**
     * @brief Encodes "png" only.
     * @param format Normalized format name.
     * @return `true` for "png".
     */
    bool canEncode(const SwString& format) const override;

    /**
     * @brief Decodes a non-interlaced PNG into BGRA32 (or Gray8 for opaque grayscale).
     * @param bytes Encoded bytes.
     * @param size Byte count.
     * @param out Receives the image.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool decode(const std::uint8_t* bytes, std::size_t size, SwImage& out, SwString* error) override;

    /**
     * @brief Encodes the image as 8-bit RGBA / RGB / Gray PNG with filter type 0.
     * @param image Image to encode.
     * @param format Normalized format name ("png").
     * @param options `pngFast` selects the compression level when miniz is compiled in.
     * @param out Receives the file bytes.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool encode(const SwImage& image, const SwString& format, const SwImageCodecOptions& options,
                SwByteArray& out, SwString* error) override;

private:
    static const std::uint64_t kMaxBytes_ = static_cast<std::uint64_t>(1) << 30;   // 1 GiB
    static const std::uint64_t kMaxPixels_ = static_cast<std::uint64_t>(1) << 28;  // 268 Mpixels

    struct Header_ {
        int width{0};
        int height{0};
        int bitDepth{0};
        int colorType{0};
        int channels{0};
    };

    static const std::uint8_t* signature_();

    bool parseHeader_(const std::uint8_t* d, Header_& hdr, SwString* error) const;

    static bool unfilterRow_(std::uint8_t filter, std::uint8_t* cur, const std::uint8_t* prev, std::size_t n, std::size_t bpp);

    /**
     * @brief Reads the x-th sample of a row at the native bit depth (1/2/4/8/16 bits).
     */
    static unsigned sample_(const std::uint8_t* row, std::size_t index, int depth);

    static std::uint8_t to8_(unsigned v, int depth);

    void convertRow_(const Header_& hdr, const std::uint8_t* src, std::uint8_t* dst, bool grayOut,
                     const std::vector<std::uint8_t>& palette, int paletteCount,
                     const std::vector<std::uint8_t>& trnsAlpha, bool hasTrns, const std::uint16_t* trnsKey,
                     bool& paletteWarned) const;

    // ---------------------------------------------------------------------------------------
    // Encoder helpers
    // ---------------------------------------------------------------------------------------

    static bool compress_(const std::vector<std::uint8_t>& raw, std::vector<std::uint8_t>& zlib, bool fast);

    static void appendChunk_(SwByteArray& out, const char* type, const std::uint8_t* data, std::size_t length);

    // ---------------------------------------------------------------------------------------
    // Byte helpers, CRC-32, Adler-32
    // ---------------------------------------------------------------------------------------

    static std::uint16_t readU16_(const std::uint8_t* p);

    static std::uint32_t readU32_(const std::uint8_t* p);

    static void writeU32_(std::uint8_t* p, std::uint32_t v);

    struct SW_GUI_EXPORT CrcTable_ {
        std::uint32_t t[256];
        CrcTable_();
    };

    static std::uint32_t crc32Update_(std::uint32_t crc, const std::uint8_t* p, std::size_t n);

    static std::uint32_t crc32_(const std::uint8_t* p, std::size_t n);

    static std::uint32_t adler32_(const std::uint8_t* p, std::size_t n);

    // ---------------------------------------------------------------------------------------
    // zlib / deflate inflater (RFC 1950 / 1951): stored, fixed and dynamic Huffman blocks.
    // The whole output buffer is the sliding window (PNG outputs are bounded and preallocated).
    // ---------------------------------------------------------------------------------------

    class SW_GUI_EXPORT Inflater_ {
    public:
        static bool inflateZlib(const std::uint8_t* in, std::size_t n, std::uint8_t* out, std::size_t outSize, std::string& err);

    private:
        struct SW_GUI_EXPORT Huff_ {
            std::vector<std::uint32_t> table;   // 1 << 15 entries: (len << 16) | symbol, 0 = invalid

            Huff_();

            bool build(const std::uint8_t* lengths, int n);
        };

        Inflater_(const std::uint8_t* in, std::size_t n, std::uint8_t* out, std::size_t outSize);

        void need(int k);

        bool consume(int k);

        bool bits(int k, std::uint32_t& v);

        void alignToByte();

        bool decodeSymbol(const Huff_& h, int& sym);

        bool run(std::string& err);

        bool stored(std::string& err);

        bool fixed(std::string& err);

        bool dynamic(std::string& err);

        bool codes(std::string& err);

        const std::uint8_t* m_in;
        std::size_t m_n;
        std::size_t m_pos;
        std::uint32_t m_bitBuf;
        int m_bitCnt;
        int m_padBits;
        std::uint8_t* m_out;
        std::size_t m_outSize;
        std::size_t m_outPos;
        Huff_ m_lit;
        Huff_ m_dist;
    };
};

#endif // SW_IMAGE_PNG_CODEC_H_BODY
