#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImageBackend.h
 * @ingroup core_graphics
 * @brief Declares the image backend interface and capability descriptor in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the image backend interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwImageBackendInfo and SwImageBackend, plus the
 * SwImageResidencyBit / SwImageOpBit / SwPixelFormatBit mask helpers.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Backend interface: a backend executes op segments on storages of a given residency.
 *
 * Backends never include the registry. A backend declares what it accepts through
 * SwImageBackendInfo (masks) and refines it through supports(); the planner routes around
 * anything a backend refuses. No vendor function is ever exposed above its backend.
 */

#include "SwImageOps.h"
#include "SwImageStorage.h"
#include "SwPixelFormat.h"
#include "SwString.h"
#include "Sw.h"

#include <cstdint>
#include <memory>
#include <vector>

/**
 * @brief Returns the residencyMask bit of a residency.
 * @param r Residency (Auto has no bit and yields 0).
 * @return `1 << r`.
 */
inline std::uint32_t SwImageResidencyBit(SwImageResidency r) {
    if (r == SwImageResidency::Auto) {
        return 0u;
    }
    return 1u << static_cast<unsigned>(r);
}

/**
 * @brief Returns the opMask bit of an op kind.
 * @param k Op kind.
 * @return `1 << k`.
 */
inline std::uint32_t SwImageOpBit(SwImageOpKind k) {
    return 1u << static_cast<unsigned>(k);
}

/**
 * @brief Returns the format mask bit of a pixel format.
 * @param f Pixel format.
 * @return `1 << f`.
 */
inline std::uint64_t SwPixelFormatBit(SwPixelFormat f) {
    return static_cast<std::uint64_t>(1) << static_cast<unsigned>(f);
}

/**
 * @brief Mask covering every op kind.
 * @return The mask.
 */
inline std::uint32_t SwImageOpMaskAll() {
    std::uint32_t m = 0;
    for (int i = 0; i < kSwImageOpKindCount; ++i) {
        m |= 1u << static_cast<unsigned>(i);
    }
    return m;
}

/**
 * @brief Mask covering every known pixel format (Unknown excluded).
 * @return The mask.
 */
inline std::uint64_t SwPixelFormatMaskAll() {
    std::uint64_t m = 0;
    for (int i = 1; i < kSwPixelFormatCount; ++i) {
        m |= static_cast<std::uint64_t>(1) << static_cast<unsigned>(i);
    }
    return m;
}

/**
 * @brief Static capability descriptor of a backend.
 */
struct SW_GUI_EXPORT SwImageBackendInfo {
    SwString id;                                              ///< "cpu", "d3d11", "vaapi", "v4l2m2m", "g2d", "nvbuf", "gles", "android"
    SwString displayName;
    int priority{0};                                          ///< higher wins when several can do a step
    std::uint32_t residencyMask{0};                           ///< 1 << SwImageResidency accepted as INPUT by execute()
    SwImageResidency outputResidency{SwImageResidency::Cpu};  ///< where results live
    std::uint32_t opMask{0};                                  ///< 1 << SwImageOpKind
    std::uint64_t inputFormatMask{0};                         ///< 1 << SwPixelFormat
    std::uint64_t outputFormatMask{0};                        ///< 1 << SwPixelFormat
    int maxWidth{0};                                          ///< 0 = unbounded
    int maxHeight{0};                                         ///< 0 = unbounded
    int strideAlignment{1};                                   ///< bytes; planner allocates CPU staging accordingly
    bool fusesChains{false};                                  ///< can execute a whole segment in one submission
    bool asynchronous{false};                                 ///< results carry a fence

    /**
     * @brief Returns whether `r` is accepted as execute() input.
     * @param r Residency.
     * @return `true` when the bit is set.
     */
    bool acceptsResidency(SwImageResidency r) const;

    /**
     * @brief Returns whether the op kind is in opMask.
     * @param k Op kind.
     * @return `true` when the bit is set.
     */
    bool acceptsOp(SwImageOpKind k) const;

    /**
     * @brief Returns whether the format is in inputFormatMask.
     * @param f Pixel format.
     * @return `true` when the bit is set.
     */
    bool acceptsInputFormat(SwPixelFormat f) const;

    /**
     * @brief Returns whether the format is in outputFormatMask.
     * @param f Pixel format.
     * @return `true` when the bit is set.
     */
    bool acceptsOutputFormat(SwPixelFormat f) const;
};

/**
 * @brief Interface implemented by every image backend (CPU, D3D11, VA-API, ...).
 *
 * Implementations must be thread-safe in execute() / upload() / download(), must never throw,
 * and report every unsupported combination through supports() so the planner can route around it.
 */
class SW_GUI_EXPORT SwImageBackend {
public:
    virtual ~SwImageBackend();

    /**
     * @brief Returns the static capability descriptor.
     * @return The descriptor.
     */
    virtual const SwImageBackendInfo& info() const = 0;

    /**
     * @brief Runtime probe (device / library present). Cached, cheap after the first call.
     * @return `true` when the backend can execute work.
     */
    virtual bool isAvailable() = 0;

    /**
     * @brief Finer check than the masks: can this op be applied to an input with this layout?
     *
     * The default checks opMask, inputFormatMask (input format), outputFormatMask (Convert
     * target) and maxWidth / maxHeight against the op output size.
     *
     * @param op Operation.
     * @param input Layout of the op input.
     * @return `true` when execute() would accept the op.
     */
    virtual bool supports(const SwImageOp& op, const SwImageLayout& input) const;

    /**
     * @brief Executes a segment of ops on `src` (restricted to `srcView` when non-empty).
     * @param src Input storage; its residency is in residencyMask.
     * @param srcView Region of interest of `src` ({0,0,0,0} = whole image).
     * @param ops Ops applied in order.
     * @param wantedOutput Residency the caller would like for `out` (backends may ignore it).
     * @param out Receives the result storage (never aliases `src` when ops is non-empty and a
     *            pixel changed; may alias it when the segment is a no-op).
     * @param error Receives a human-readable reason on failure (may be null).
     * @return `true` on success.
     */
    virtual bool execute(const std::shared_ptr<SwImageStorage>& src, const SwRect& srcView,
                         const std::vector<SwImageOp>& ops, SwImageResidency wantedOutput,
                         std::shared_ptr<SwImageStorage>& out, SwString* error) = 0;

    /**
     * @brief Copies a CPU storage into this backend's output residency.
     * @param cpu CPU resident source.
     * @param out Receives the native storage.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success. Default: unsupported.
     */
    virtual bool upload(const std::shared_ptr<SwImageStorage>& cpu,
                        std::shared_ptr<SwImageStorage>& out, SwString* error);

    /**
     * @brief Copies a native storage of this backend into CPU memory.
     * @param native Native source (residency == outputResidency, or one this backend can read).
     * @param outCpu Receives the CPU storage.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success. Default: unsupported.
     */
    virtual bool download(const std::shared_ptr<SwImageStorage>& native,
                          std::shared_ptr<SwImageStorage>& outCpu, SwString* error);

    /**
     * @brief Imports a DMA-BUF storage into this backend's residency (Linux).
     * @param dmaBuf Storage with residency DmaBuf.
     * @param out Receives the imported storage.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success. Default: unsupported.
     */
    virtual bool importDmaBuf(const std::shared_ptr<SwImageStorage>& dmaBuf,
                              std::shared_ptr<SwImageStorage>& out, SwString* error);

    /**
     * @brief Exports a native storage of this backend as a DMA-BUF storage (Linux).
     * @param native Storage with this backend's output residency.
     * @param outDmaBuf Receives the DmaBuf storage.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success. Default: unsupported.
     */
    virtual bool exportDmaBuf(const std::shared_ptr<SwImageStorage>& native,
                              std::shared_ptr<SwImageStorage>& outDmaBuf, SwString* error);

protected:
    /**
     * @brief Stores `message` (prefixed with the backend id) into `error` when non-null.
     * @param error Destination or null.
     * @param message Reason.
     */
    void setError_(SwString* error, const SwString& message) const;
};
