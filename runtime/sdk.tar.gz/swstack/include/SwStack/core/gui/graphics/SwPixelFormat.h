#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwPixelFormat.h
 * @ingroup core_graphics
 * @brief Declares the pixel format vocabulary shared by the CoreSw graphics and media layers.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the pixel format interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwPixelFormat, SwColorSpace, SwImageRotation and
 * SwImageLayout, plus the SwDescribeImageLayout / SwPixelFormat* helper functions.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Pixel formats, colour spaces, rotations and the memory layout descriptor.
 *
 * The types declared here used to live in media/SwVideoTypes.h (SwVideoPixelFormat,
 * SwVideoColorSpace, SwVideoRotation, SwVideoFormatInfo). They now belong to the graphics
 * layer so that SwImage, the image backends and the codecs can share one vocabulary; the
 * media header keeps every old name as an alias.
 *
 * SwImage::Format_ARGB32 (0xAARRGGBB stored in a native little-endian uint32_t) is exactly
 * SwPixelFormat::BGRA32 in memory. There is deliberately no ARGB32 enumerator.
 */

#include <array>
#include <cstddef>
#include <cstdint>

/**
 * @brief Pixel formats understood by the image pipeline.
 */
enum class SwPixelFormat {
    Unknown,
    Gray8,
    RGB24,
    BGR24,
    RGBA32,
    BGRA32,
    NV12,
    P010,
    P016,
    YUY2,
    YUV420P
};

/**
 * @brief Colour space tag of YUV data (limited range unless stated otherwise).
 */
enum class SwColorSpace {
    Undefined,
    BT601,
    BT709,
    BT2020
};

/**
 * @brief Quarter-turn rotations, used both as an orientation hint and as a physical op.
 */
enum class SwImageRotation {
    Identity,
    Rotate90,
    Rotate180,
    Rotate270
};

/**
 * @brief Number of enumerators in SwPixelFormat (for bit masks).
 */
static const int kSwPixelFormatCount = static_cast<int>(SwPixelFormat::YUV420P) + 1;

/**
 * @brief Describes how a pixel format is laid out in memory.
 *
 * Field names are identical to the old SwVideoFormatInfo so that media code keeps compiling.
 */
struct SW_GUI_EXPORT SwImageLayout {
    SwPixelFormat format{SwPixelFormat::Unknown};
    int width{0};
    int height{0};
    int planeCount{0};
    std::array<int, 4> stride{};
    std::array<int, 4> planeHeights{};
    std::array<std::size_t, 4> planeOffsets{};
    std::size_t dataSize{0};

    /**
     * @brief Returns whether the layout describes a usable image.
     * @return `true` when the format is known and both dimensions are positive.
     */
    bool isValid() const;

    /**
     * @brief Returns whether the layout has more than one plane.
     * @return `true` for NV12 / P010 / P016 / YUV420P.
     */
    bool isPlanar() const;

    /**
     * @brief Returns whether the layout is a single packed plane.
     * @return `true` for packed RGB / Gray / YUY2 formats.
     */
    bool isPacked() const;

    /**
     * @brief Compares two layouts field by field.
     * @param other Layout to compare with.
     * @return `true` when every field is equal.
     */
    bool operator==(const SwImageLayout& other) const;

    /**
     * @brief Negation of operator==.
     * @param other Layout to compare with.
     * @return `true` when at least one field differs.
     */
    bool operator!=(const SwImageLayout& other) const;
};

/**
 * @brief Returns the number of planes of a pixel format (0 for Unknown).
 * @param format Pixel format.
 * @return Plane count.
 */
inline int SwPixelFormatPlaneCount(SwPixelFormat format) {
    switch (format) {
    case SwPixelFormat::NV12: return 2;
    case SwPixelFormat::P010: return 2;
    case SwPixelFormat::P016: return 2;
    case SwPixelFormat::YUV420P: return 3;
    case SwPixelFormat::Unknown: return 0;
    default: return 1;
    }
}

/**
 * @brief Returns whether the format is one of the packed RGB formats.
 * @param format Pixel format.
 * @return `true` for RGB24 / BGR24 / RGBA32 / BGRA32.
 */
inline bool SwPixelFormatIsRGB(SwPixelFormat format) {
    return format == SwPixelFormat::RGB24 || format == SwPixelFormat::BGR24 ||
           format == SwPixelFormat::RGBA32 || format == SwPixelFormat::BGRA32;
}

/**
 * @brief Returns whether the format carries an alpha channel.
 * @param format Pixel format.
 * @return `true` for RGBA32 / BGRA32.
 */
inline bool SwPixelFormatHasAlpha(SwPixelFormat format) {
    return format == SwPixelFormat::RGBA32 || format == SwPixelFormat::BGRA32;
}

/**
 * @brief Returns whether the format is a YUV format (packed or planar).
 * @param format Pixel format.
 * @return `true` for NV12 / P010 / P016 / YUY2 / YUV420P.
 */
inline bool SwPixelFormatIsYUV(SwPixelFormat format) {
    return format == SwPixelFormat::NV12 || format == SwPixelFormat::P010 ||
           format == SwPixelFormat::P016 || format == SwPixelFormat::YUY2 ||
           format == SwPixelFormat::YUV420P;
}

/**
 * @brief Returns the bytes per pixel of a packed format, 0 for planar or unknown formats.
 * @param format Pixel format.
 * @return Bytes per pixel of plane 0 for packed formats.
 */
inline int SwPixelFormatBytesPerPixel(SwPixelFormat format) {
    switch (format) {
    case SwPixelFormat::Gray8: return 1;
    case SwPixelFormat::RGB24: return 3;
    case SwPixelFormat::BGR24: return 3;
    case SwPixelFormat::RGBA32: return 4;
    case SwPixelFormat::BGRA32: return 4;
    case SwPixelFormat::YUY2: return 2;
    default: return 0;
    }
}

/**
 * @brief Returns a stable lowercase name for a pixel format.
 * @param format Pixel format.
 * @return Static string such as "bgra32" or "nv12".
 */
inline const char* SwPixelFormatName(SwPixelFormat format) {
    switch (format) {
    case SwPixelFormat::Gray8: return "gray8";
    case SwPixelFormat::RGB24: return "rgb24";
    case SwPixelFormat::BGR24: return "bgr24";
    case SwPixelFormat::RGBA32: return "rgba32";
    case SwPixelFormat::BGRA32: return "bgra32";
    case SwPixelFormat::NV12: return "nv12";
    case SwPixelFormat::P010: return "p010";
    case SwPixelFormat::P016: return "p016";
    case SwPixelFormat::YUY2: return "yuy2";
    case SwPixelFormat::YUV420P: return "yuv420p";
    default: return "unknown";
    }
}

/**
 * @brief Returns a stable name for a colour space.
 * @param cs Colour space.
 * @return Static string such as "bt709".
 */
inline const char* SwColorSpaceName(SwColorSpace cs) {
    switch (cs) {
    case SwColorSpace::BT601: return "bt601";
    case SwColorSpace::BT709: return "bt709";
    case SwColorSpace::BT2020: return "bt2020";
    default: return "undefined";
    }
}

/**
 * @brief Returns a stable name for a rotation.
 * @param rotation Rotation value.
 * @return Static string such as "rotate90".
 */
inline const char* SwImageRotationName(SwImageRotation rotation) {
    switch (rotation) {
    case SwImageRotation::Rotate90: return "rotate90";
    case SwImageRotation::Rotate180: return "rotate180";
    case SwImageRotation::Rotate270: return "rotate270";
    default: return "identity";
    }
}

/**
 * @brief Describes the sampling geometry of one plane of a pixel format.
 *
 * A "sample" is the smallest addressable unit of the plane: one pixel for packed RGB / Gray
 * planes and luma planes, one UV pair for NV12 / P010 / P016 chroma planes, one U (or V) for
 * YUV420P chroma planes, one pixel (2 bytes, half a macropixel) for YUY2.
 *
 * @param format Pixel format.
 * @param plane Plane index.
 * @param shiftX Receives the horizontal subsampling shift (0 = full, 1 = half).
 * @param shiftY Receives the vertical subsampling shift (0 = full, 1 = half).
 * @param bytesPerSample Receives the byte size of one sample.
 * @return `false` when the plane does not exist for this format.
 */
inline bool SwPixelFormatPlaneGeometry(SwPixelFormat format, int plane,
                                       int& shiftX, int& shiftY, int& bytesPerSample) {
    shiftX = 0;
    shiftY = 0;
    bytesPerSample = 0;
    if (plane < 0 || plane >= SwPixelFormatPlaneCount(format)) {
        return false;
    }
    switch (format) {
    case SwPixelFormat::Gray8:
    case SwPixelFormat::RGB24:
    case SwPixelFormat::BGR24:
    case SwPixelFormat::RGBA32:
    case SwPixelFormat::BGRA32:
    case SwPixelFormat::YUY2:
        bytesPerSample = SwPixelFormatBytesPerPixel(format);
        return true;
    case SwPixelFormat::NV12:
        if (plane == 0) { bytesPerSample = 1; return true; }
        shiftX = 1; shiftY = 1; bytesPerSample = 2;
        return true;
    case SwPixelFormat::P010:
    case SwPixelFormat::P016:
        if (plane == 0) { bytesPerSample = 2; return true; }
        shiftX = 1; shiftY = 1; bytesPerSample = 4;
        return true;
    case SwPixelFormat::YUV420P:
        if (plane == 0) { bytesPerSample = 1; return true; }
        shiftX = 1; shiftY = 1; bytesPerSample = 1;
        return true;
    default:
        return false;
    }
}

/**
 * @brief Computes the canonical (tightly packed) layout of a pixel format at a given size.
 *
 * Identical to the old SwDescribeVideoFormat: strides are width * bytesPerSample, chroma
 * planes are (width + 1) / 2 by (height + 1) / 2, planes follow each other without padding.
 *
 * @param format Pixel format.
 * @param width Width in pixels.
 * @param height Height in pixels.
 * @return The layout; planeCount / dataSize are 0 when the format or size is invalid.
 */
inline SwImageLayout SwDescribeImageLayout(SwPixelFormat format, int width, int height) {
    SwImageLayout info;
    info.format = format;
    info.width = width;
    info.height = height;

    if (width <= 0 || height <= 0) {
        return info;
    }

    const int planes = SwPixelFormatPlaneCount(format);
    if (planes <= 0) {
        info.planeCount = 0;
        info.dataSize = 0;
        return info;
    }

    info.planeCount = planes;
    std::size_t offset = 0;
    for (int p = 0; p < planes; ++p) {
        int shiftX = 0, shiftY = 0, bps = 0;
        SwPixelFormatPlaneGeometry(format, p, shiftX, shiftY, bps);
        const int samplesX = shiftX ? (width + 1) >> shiftX : width;
        const int rows = shiftY ? (height + 1) >> shiftY : height;
        info.stride[static_cast<std::size_t>(p)] = samplesX * bps;
        info.planeHeights[static_cast<std::size_t>(p)] = rows;
        info.planeOffsets[static_cast<std::size_t>(p)] = offset;
        offset += static_cast<std::size_t>(info.stride[static_cast<std::size_t>(p)]) *
                  static_cast<std::size_t>(rows);
    }
    info.dataSize = offset;
    return info;
}

/**
 * @brief Computes a layout whose plane strides are rounded up to a byte alignment.
 *
 * Backends with stride requirements (e.g. 16 / 64 bytes) use this to allocate staging
 * buffers; plane offsets stay contiguous.
 *
 * @param format Pixel format.
 * @param width Width in pixels.
 * @param height Height in pixels.
 * @param strideAlignment Alignment in bytes (values <= 1 give the canonical layout).
 * @return The aligned layout.
 */
inline SwImageLayout SwDescribeImageLayoutAligned(SwPixelFormat format, int width, int height,
                                                  int strideAlignment) {
    SwImageLayout info = SwDescribeImageLayout(format, width, height);
    if (strideAlignment <= 1 || info.planeCount <= 0) {
        return info;
    }
    std::size_t offset = 0;
    for (int p = 0; p < info.planeCount; ++p) {
        const std::size_t idx = static_cast<std::size_t>(p);
        const int stride = info.stride[idx];
        const int aligned = ((stride + strideAlignment - 1) / strideAlignment) * strideAlignment;
        info.stride[idx] = aligned;
        info.planeOffsets[idx] = offset;
        offset += static_cast<std::size_t>(aligned) * static_cast<std::size_t>(info.planeHeights[idx]);
    }
    info.dataSize = offset;
    return info;
}

/**
 * @brief Returns the rotation obtained by applying `second` after `first`.
 * @param first First rotation.
 * @param second Second rotation.
 * @return Combined rotation (mod 360).
 */
inline SwImageRotation SwImageRotationCombine(SwImageRotation first, SwImageRotation second) {
    const int quarter = (static_cast<int>(first) + static_cast<int>(second)) & 3;
    return static_cast<SwImageRotation>(quarter);
}

/**
 * @brief Returns whether a rotation swaps width and height.
 * @param rotation Rotation value.
 * @return `true` for Rotate90 / Rotate270.
 */
inline bool SwImageRotationSwapsAxes(SwImageRotation rotation) {
    return rotation == SwImageRotation::Rotate90 || rotation == SwImageRotation::Rotate270;
}
