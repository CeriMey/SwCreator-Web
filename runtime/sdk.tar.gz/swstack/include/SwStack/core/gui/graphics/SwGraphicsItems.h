#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwGraphicsItems.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwGraphicsItems in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the graphics items interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwGraphicsRectItem, SwGraphicsEllipseItem,
 * SwGraphicsLineItem, SwGraphicsTextItem, SwGraphicsSimpleTextItem, SwGraphicsPixmapItem,
 * SwGraphicsPathItem, and SwGraphicsPolygonItem, plus related helper declarations.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/***************************************************************************************************
 * Concrete SwGraphicsItem subclasses  (Qt-like)
 *
 *   SwGraphicsRectItem        (QGraphicsRectItem)
 *   SwGraphicsEllipseItem     (QGraphicsEllipseItem)
 *   SwGraphicsLineItem        (QGraphicsLineItem)
 *   SwGraphicsTextItem        (QGraphicsTextItem)
 *   SwGraphicsSimpleTextItem  (QGraphicsSimpleTextItem)
 *   SwGraphicsPixmapItem      (QGraphicsPixmapItem)
 *   SwGraphicsPathItem        (QGraphicsPathItem)
 *   SwGraphicsPolygonItem     (QGraphicsPolygonItem)
 *   SwGraphicsProxyWidget     (QGraphicsProxyWidget)
 *   SwGraphicsItemGroup       (QGraphicsItemGroup)
 **************************************************************************************************/

/**
 * @file
 * @brief Declares the stock graphics-item subclasses shipped with the scene module.
 *
 * This header provides ready-to-use scene primitives such as rectangles,
 * ellipses, lines, text blocks, pixmaps, arbitrary paths, polygons, proxy
 * widgets, and grouping items. Each class specializes SwGraphicsItem with the
 * geometry, shape, and paint behavior appropriate for one visual primitive.
 */

#include "graphics/SwBrush.h"
#include "graphics/SwFontMetrics.h"
#include "graphics/SwGraphicsItem.h"
#include "graphics/SwGraphicsRenderContext.h"
#include "graphics/SwPainterPath.h"
#include "graphics/SwPen.h"
#include "graphics/SwPixmap.h"

#include "SwPainter.h"
#include "SwString.h"
#include "SwWidget.h"

#include <algorithm>
#include <cmath>

// ===================================================================
// SwGraphicsRectItem
// ===================================================================
/**
 * @brief Scene item that renders an axis-aligned rectangle.
 */
class SW_WIDGETS_EXPORT SwGraphicsRectItem : public SwGraphicsItem {
public:
    enum { Type = 3 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsRectItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsRectItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsRectItem` instance.
     * @param r Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param r Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsRectItem(const SwRectF& r, SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsRectItem` instance.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param w Width value.
     * @param h Height value.
     * @param parent Optional parent object that owns this instance.
     * @param h Height value.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsRectItem(double x, double y, double w, double h, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the rect.
     * @param m_rect Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRect(const SwRectF& r);
    /**
     * @brief Sets the rect.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param w Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRect(double x, double y, double w, double h);
    /**
     * @brief Returns the current rect.
     * @return The current rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF rect() const;

    /**
     * @brief Sets the pen.
     * @param m_pen Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPen(const SwPen& p);
    /**
     * @brief Returns the current pen.
     * @return The current pen.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPen pen() const;

    /**
     * @brief Sets the brush.
     * @param m_brush Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBrush(const SwBrush& b);
    /**
     * @brief Returns the current brush.
     * @return The current brush.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwBrush brush() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `contains` operation.
     * @param point Point used by the operation.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwPointF& point) const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsRectItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsEllipseItem
// ===================================================================
/**
 * @brief Scene item that renders an ellipse or pie-like arc segment.
 */
class SW_WIDGETS_EXPORT SwGraphicsEllipseItem : public SwGraphicsItem {
public:
    enum { Type = 4 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsEllipseItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsEllipseItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsEllipseItem` instance.
     * @param r Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param r Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsEllipseItem(const SwRectF& r, SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsEllipseItem` instance.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param w Width value.
     * @param h Height value.
     * @param parent Optional parent object that owns this instance.
     * @param h Height value.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsEllipseItem(double x, double y, double w, double h, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the rect.
     * @param m_rect Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRect(const SwRectF& r);
    /**
     * @brief Sets the rect.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     * @param w Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRect(double x, double y, double w, double h);
    /**
     * @brief Returns the current rect.
     * @return The current rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF rect() const;

    /**
     * @brief Sets the start Angle.
     * @param m_startAngle Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStartAngle(int angle);
    /**
     * @brief Returns the current angle.
     * @return The current angle.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int startAngle() const;

    /**
     * @brief Sets the span Angle.
     * @param m_spanAngle Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSpanAngle(int angle);
    /**
     * @brief Returns the current span Angle.
     * @return The current span Angle.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int spanAngle() const;

    /**
     * @brief Sets the pen.
     * @param m_pen Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPen(const SwPen& p);
    /**
     * @brief Returns the current pen.
     * @return The current pen.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPen pen() const;

    /**
     * @brief Sets the brush.
     * @param m_brush Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBrush(const SwBrush& b);
    /**
     * @brief Returns the current brush.
     * @return The current brush.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwBrush brush() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `contains` operation.
     * @param point Point used by the operation.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwPointF& point) const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsEllipseItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsLineItem
// ===================================================================
/**
 * @brief Scene item that renders a single stroked line segment.
 */
class SW_WIDGETS_EXPORT SwGraphicsLineItem : public SwGraphicsItem {
public:
    enum { Type = 6 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsLineItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsLineItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsLineItem` instance.
     * @param l Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param l Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsLineItem(const SwLineF& l, SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsLineItem` instance.
     * @param x1 Value passed to the method.
     * @param y1 Value passed to the method.
     * @param x2 Value passed to the method.
     * @param y2 Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param y2 Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsLineItem(double x1, double y1, double x2, double y2, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the line.
     * @param m_line Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLine(const SwLineF& l);
    /**
     * @brief Sets the line.
     * @param x1 Value passed to the method.
     * @param y1 Value passed to the method.
     * @param x2 Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLine(double x1, double y1, double x2, double y2);
    /**
     * @brief Returns the current line.
     * @return The current line.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwLineF line() const;

    /**
     * @brief Sets the pen.
     * @param m_pen Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPen(const SwPen& p);
    /**
     * @brief Returns the current pen.
     * @return The current pen.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPen pen() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsLineItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsTextItem
// ===================================================================
/**
 * @brief Scene item that renders selectable or editable text content.
 */
class SW_WIDGETS_EXPORT SwGraphicsTextItem : public SwGraphicsItem {
public:
    enum { Type = 8 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    enum TextInteractionFlag {
        NoTextInteraction         = 0,
        TextSelectableByMouse     = 1,
        TextSelectableByKeyboard  = 2,
        TextEditable              = 4,
        TextEditorInteraction     = TextSelectableByMouse | TextSelectableByKeyboard | TextEditable,
        TextBrowserInteraction    = TextSelectableByMouse
    };

    /**
     * @brief Constructs a `SwGraphicsTextItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsTextItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsTextItem` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param text Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsTextItem(const SwString& text, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the plain Text.
     * @param m_text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPlainText(const SwString& text);
    /**
     * @brief Returns the current to Plain Text.
     * @return The current to Plain Text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString toPlainText() const;

    /**
     * @brief Sets the html.
     * @param m_html Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHtml(const SwString& html);
    /**
     * @brief Returns the current to Html.
     * @return The current to Html.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString toHtml() const;

    /**
     * @brief Sets the default Text Color.
     * @param m_color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setDefaultTextColor(const SwColor& c);
    /**
     * @brief Returns the current default Text Color.
     * @return The current default Text Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor defaultTextColor() const;

    /**
     * @brief Sets the font.
     * @param m_font Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFont(const SwFont& f);
    /**
     * @brief Returns the current font.
     * @return The current font.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwFont font() const;

    /**
     * @brief Sets the text Width.
     * @param m_textWidth Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTextWidth(double width);
    /**
     * @brief Returns the current text Width.
     * @return The current text Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double textWidth() const;

    /**
     * @brief Sets the text Interaction Flags.
     * @param flags Flags that refine the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTextInteractionFlags(int flags);
    /**
     * @brief Returns the current text Interaction Flags.
     * @return The current text Interaction Flags.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int textInteractionFlags() const;

    /**
     * @brief Sets the open External Links.
     * @param open Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOpenExternalLinks(bool open);
    /**
     * @brief Returns the current external Links.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool openExternalLinks() const;

    /**
     * @brief Sets the tab Changes Focus.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTabChangesFocus(bool on);
    /**
     * @brief Returns the current tab Changes Focus.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool tabChangesFocus() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsTextItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsSimpleTextItem
// ===================================================================
class SW_WIDGETS_EXPORT SwGraphicsSimpleTextItem : public SwGraphicsItem {
public:
    enum { Type = 9 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsSimpleTextItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsSimpleTextItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsSimpleTextItem` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param text Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsSimpleTextItem(const SwString& text, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the text.
     * @param m_text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setText(const SwString& text);
    /**
     * @brief Returns the current text.
     * @return The current text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString text() const;

    /**
     * @brief Sets the font.
     * @param m_font Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFont(const SwFont& f);
    /**
     * @brief Returns the current font.
     * @return The current font.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwFont font() const;

    /**
     * @brief Sets the pen.
     * @param m_pen Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPen(const SwPen& p);
    /**
     * @brief Returns the current pen.
     * @return The current pen.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPen pen() const;

    /**
     * @brief Sets the brush.
     * @param m_brush Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBrush(const SwBrush& b);
    /**
     * @brief Returns the current brush.
     * @return The current brush.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwBrush brush() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsSimpleTextItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsPixmapItem
// ===================================================================
class SW_WIDGETS_EXPORT SwGraphicsPixmapItem : public SwGraphicsItem {
public:
    enum { Type = 7 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    enum ShapeMode { MaskShape, BoundingRectShape, HeuristicMaskShape };

    /**
     * @brief Constructs a `SwGraphicsPixmapItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsPixmapItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsPixmapItem` instance.
     * @param pix Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param pix Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsPixmapItem(const SwPixmap& pix, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the pixmap.
     * @param m_pixmap Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPixmap(const SwPixmap& pix);
    /**
     * @brief Returns the current pixmap.
     * @return The current pixmap.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPixmap pixmap() const;

    /**
     * @brief Sets the offset.
     * @param m_offset Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOffset(const SwPointF& offset);
    /**
     * @brief Sets the offset.
     * @param x Horizontal coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOffset(double x, double y);
    /**
     * @brief Returns the current offset.
     * @return The current offset.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF offset() const;

    /**
     * @brief Sets the shape Mode.
     * @param mode Mode value that controls the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setShapeMode(ShapeMode mode);
    /**
     * @brief Returns the current shape Mode.
     * @return The current shape Mode.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    ShapeMode shapeMode() const;

    /**
     * @brief Sets the transformation Mode.
     * @param mode Mode value that controls the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTransformationMode(int mode);
    /**
     * @brief Returns the current transformation Mode.
     * @return The current transformation Mode.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int transformationMode() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsPixmapItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsPathItem
// ===================================================================
class SW_WIDGETS_EXPORT SwGraphicsPathItem : public SwGraphicsItem {
public:
    enum { Type = 2 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsPathItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsPathItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsPathItem` instance.
     * @param path Path used by the operation.
     * @param parent Optional parent object that owns this instance.
     * @param path Path used by the operation.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsPathItem(const SwPainterPath& path, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the path.
     * @param m_path Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPath(const SwPainterPath& p);
    /**
     * @brief Returns the current path.
     * @return The current path.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath path() const;

    /**
     * @brief Sets the pen.
     * @param m_pen Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPen(const SwPen& p);
    /**
     * @brief Returns the current pen.
     * @return The current pen.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPen pen() const;

    /**
     * @brief Sets the brush.
     * @param m_brush Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBrush(const SwBrush& b);
    /**
     * @brief Returns the current brush.
     * @return The current brush.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwBrush brush() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `contains` operation.
     * @param point Point used by the operation.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwPointF& point) const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsPathItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsPolygonItem
// ===================================================================
class SW_WIDGETS_EXPORT SwGraphicsPolygonItem : public SwGraphicsItem {
public:
    enum { Type = 5 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsPolygonItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsPolygonItem(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsPolygonItem` instance.
     * @param polygon Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param polygon Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsPolygonItem(const SwPolygonF& polygon, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the polygon.
     * @param m_polygon Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPolygon(const SwPolygonF& polygon);
    /**
     * @brief Returns the current polygon.
     * @return The current polygon.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPolygonF polygon() const;

    /**
     * @brief Sets the pen.
     * @param m_pen Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPen(const SwPen& p);
    /**
     * @brief Returns the current pen.
     * @return The current pen.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPen pen() const;

    /**
     * @brief Sets the brush.
     * @param m_brush Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBrush(const SwBrush& b);
    /**
     * @brief Returns the current brush.
     * @return The current brush.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwBrush brush() const;

    /**
     * @brief Sets the fill Rule.
     * @param rule Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFillRule(SwPainterPath::FillRule rule);
    /**
     * @brief Returns the current fill Rule.
     * @return The current fill Rule.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath::FillRule fillRule() const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `contains` operation.
     * @param point Point used by the operation.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwPointF& point) const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
public:
    ~SwGraphicsPolygonItem();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsProxyWidget
// ===================================================================
class SW_WIDGETS_EXPORT SwGraphicsProxyWidget : public SwGraphicsItem {
public:
    enum { Type = 12 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsProxyWidget` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsProxyWidget(SwGraphicsItem* parent = nullptr);
    /**
     * @brief Constructs a `SwGraphicsProxyWidget` instance.
     * @param w Width value.
     * @param parent Optional parent object that owns this instance.
     * @param w Width value.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwGraphicsProxyWidget(SwWidget* w, SwGraphicsItem* parent = nullptr);

    /**
     * @brief Sets the widget.
     * @param m_widget Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWidget(SwWidget* w);
    /**
     * @brief Returns the current widget.
     * @return The current widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* widget() const;

    /**
     * @brief Creates the requested proxy For Child Widget.
     * @return The resulting proxy For Child Widget.
     */
    SwGraphicsProxyWidget* createProxyForChildWidget(SwWidget* /*child*/);

    /**
     * @brief Sets the widget Base Size.
     * @param w Width value.
     * @param h Height value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setWidgetBaseSize(int w, int h);

    /**
     * @brief Returns the current widget Base Size.
     * @return The current widget Base Size.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwSize widgetBaseSize() const;

    /**
     * @brief Performs the `subWidgetRect` operation.
     * @return The requested sub Widget Rect.
     */
    SwRectF subWidgetRect(const SwWidget* /*widget*/) const;

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     */
    void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) override;

private:
    void syncBaseSizeFromWidget_();

public:
    ~SwGraphicsProxyWidget();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsItemGroup
// ===================================================================
class SW_WIDGETS_EXPORT SwGraphicsItemGroup : public SwGraphicsItem {
public:
    enum { Type = 10 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int type() const override;

    /**
     * @brief Constructs a `SwGraphicsItemGroup` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsItemGroup(SwGraphicsItem* parent = nullptr);

    /**
     * @brief Adds the specified to Group.
     * @param item Item affected by the operation.
     */
    void addToGroup(SwGraphicsItem* item);

    /**
     * @brief Removes the specified from Group.
     * @param item Item affected by the operation.
     */
    void removeFromGroup(SwGraphicsItem* item);

    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF boundingRect() const override;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPainterPath shape() const override;

    /**
     * @brief Performs the `paint` operation.
     */
    void paint(SwPainter* /*painter*/, const SwGraphicsRenderContext& /*ctx*/) override;

private:
public:
    ~SwGraphicsItemGroup();
private:
    // What the class keeps (SwGraphicsItems_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

// ===================================================================
// SwGraphicsItem deferred implementations  (need full class defs above)
// ===================================================================


// ===================================================================
// Paint helpers  (inline, keep header-only)
// ===================================================================
inline int swRoundToInt_(double v) {
    return static_cast<int>(std::lround(v));
}

