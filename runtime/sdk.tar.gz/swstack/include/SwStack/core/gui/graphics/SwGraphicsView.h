﻿#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwGraphicsView.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwGraphicsView in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the graphics view interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwGraphicsView.
 *
 * View-oriented declarations here mainly describe how underlying state is projected into a visual
 * or interactive surface, including how refresh, selection, or presentation concerns are exposed
 * at the API boundary.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/***************************************************************************************************
 * SwGraphicsView  â€”  Qt-like QGraphicsView with full API coverage.
 *
 * - Scene association & viewport
 * - Drag modes (NoDrag, ScrollHandDrag, RubberBandDrag)
 * - Render hints
 * - fitInView, centerOn, ensureVisible
 * - Full transform (rotate, scale, translate, shear, resetTransform)
 * - Transformation / resize anchors
 * - Interactive mode & event forwarding to scene
 * - Alignment
 * - Viewport update modes, optimization flags
 * - Rubber band selection
 **************************************************************************************************/

/**
 * @file
 * @brief Declares the widget that visualizes and interacts with a graphics scene.
 *
 * SwGraphicsView bridges retained-mode scene content with the regular widget
 * hierarchy. It manages viewport state, scene attachment, coordinate mapping,
 * scrolling, zooming, and event forwarding so scene items can be rendered and
 * manipulated inside a standard UI surface.
 */

#include "SwWidget.h"

#include "graphics/SwGraphicsScene.h"
#include "graphics/SwGraphicsRenderContext.h"
#include "graphics/SwGraphicsTypes.h"

#include <algorithm>
#include <cmath>
#include <vector>

/**
 * @brief Widget facade for rendering a SwGraphicsScene.
 */
class SW_WIDGETS_EXPORT SwGraphicsView : public SwWidget {
    SW_OBJECT(SwGraphicsView, SwWidget)

public:
    // --- DragMode (matches QGraphicsView::DragMode) ---
    enum DragMode {
        NoDrag,
        ScrollHandDrag,
        RubberBandDrag
    };

    // --- ViewportAnchor ---
    enum ViewportAnchor {
        NoAnchor,
        AnchorViewCenter,
        AnchorUnderMouse
    };

    // --- ViewportUpdateMode ---
    enum ViewportUpdateMode {
        FullViewportUpdate,
        MinimalViewportUpdate,
        SmartViewportUpdate,
        NoViewportUpdate,
        BoundingRectViewportUpdate
    };

    // --- OptimizationFlag ---
    enum OptimizationFlag {
        DontClipPainter            = 0x1,
        DontSavePainterState       = 0x2,
        DontAdjustForAntialiasing  = 0x4,
        IndirectPainting           = 0x8
    };

    // --- RenderHint ---
    enum RenderHint {
        Antialiasing               = 0x1,
        TextAntialiasing           = 0x2,
        SmoothPixmapTransform      = 0x4,
        HighQualityAntialiasing    = 0x8
    };

    // --- CacheModeFlag ---
    enum CacheModeFlag {
        CacheNone       = 0x0,
        CacheBackground = 0x1
    };

    // --- Alignment ---
    enum Alignment {
        AlignLeft    = 0x01,
        AlignRight   = 0x02,
        AlignHCenter = 0x04,
        AlignTop     = 0x20,
        AlignBottom  = 0x40,
        AlignVCenter = 0x80,
        AlignCenter  = AlignHCenter | AlignVCenter
    };

    // ===================================================================
    // Construction
    // ===================================================================
    /// Constructs a graphics view with no attached scene.
    explicit SwGraphicsView(SwWidget* parent = nullptr);

    /// Constructs a graphics view already attached to the supplied scene.
    explicit SwGraphicsView(SwGraphicsScene* scene, SwWidget* parent = nullptr);

    /// Detaches the view from its scene registration list before destruction.
    ~SwGraphicsView() override;

    // ===================================================================
    // Scene
    // ===================================================================
    /**
     * @brief Attaches the view to a scene.
     * @param scene New scene to display, or `nullptr` to detach the current one.
     *
     * The view updates signal connections, scene registration, proxy-widget
     * synchronization, and schedules a repaint.
     */
    void setScene(SwGraphicsScene* scene);

    /// Returns the scene currently displayed by the view, or `nullptr`.
    SwGraphicsScene* scene() const;

    // ===================================================================
    // Scene rect (override what part of the scene is visible)
    // ===================================================================
    /// Returns the explicit scene rectangle override when set, otherwise the attached scene rectangle.
    SwRectF sceneRect() const;

    /// Sets the scene rectangle override used by the view.
    void setSceneRect(const SwRectF& rect);
    /// Convenience overload that builds the scene rectangle override from coordinates and size.
    void setSceneRect(double x, double y, double w, double h);

    // ===================================================================
    // Transform
    // ===================================================================
    /// Sets the scalar zoom factor used by the view.
    void setScale(double s);
    /// Returns the scalar zoom factor currently applied by the view.
    double scale() const;

    /// Returns the matrix-based view transform.
    SwTransform transform() const;

    /**
     * @brief Sets or combines the matrix-based view transform.
     * @param transform Transform to install or combine.
     * @param combine When `true`, multiplies the new transform with the current one.
     */
    void setTransform(const SwTransform& transform, bool combine = false);

    /// Resets the matrix transform and scalar zoom back to the identity state.
    void resetTransform();

    /// Returns the effective viewport transform after combining matrix transform and scalar zoom.
    SwTransform viewportTransform() const;
    /// Returns whether any non-identity transform is currently applied.
    bool isTransformed() const;

    /// Applies an additional rotation to the view transform.
    void rotate(double angle);
    /// Applies an additional shear to the view transform.
    void shear(double sh, double sv);
    /// Applies an additional translation to the view transform.
    void translate(double dx, double dy);

    // ===================================================================
    // Coordinate mapping  (scene <-> view widget coordinates)
    // ===================================================================
    /// Maps a scene-space point into viewport-local widget coordinates.
    SwPointF mapFromScene(const SwPointF& scenePoint) const;

    /// Convenience overload that maps scalar scene coordinates into viewport-local coordinates.
    SwPointF mapFromScene(double x, double y) const;

    /// Maps a scene-space rectangle into viewport-local widget coordinates.
    SwPolygonF mapFromScene(const SwRectF& sceneRect) const;

    /// Maps a scene-space polygon into viewport-local widget coordinates.
    SwPolygonF mapFromScene(const SwPolygonF& polygon) const;

    /// Maps a viewport-local widget-space point into scene coordinates.
    SwPointF mapToScene(const SwPointF& viewPoint) const;

    /// Convenience overload that maps scalar widget coordinates into scene space.
    SwPointF mapToScene(int x, int y) const;

    /// Maps a widget-space rectangle into scene coordinates.
    SwPolygonF mapToScene(const SwRect& viewRect) const;

    /// Maps a widget-space polygon into scene coordinates.
    SwPolygonF mapToScene(const SwPolygonF& polygon) const;

    /// Returns the bounding viewport rectangle that covers a mapped scene rectangle.
    SwRect mapRectFromScene(const SwRectF& sceneRect) const;

    /// Returns the bounding scene rectangle that covers a mapped viewport rectangle.
    SwRectF mapRectToScene(const SwRect& viewRect) const;

    // ===================================================================
    // Scroll (pan)
    // ===================================================================
    /// Sets the scroll offset expressed in scene coordinates.
    void setScroll(double sx, double sy);
    /// Returns the current scroll offset expressed in scene coordinates.
    SwPointF scrollOffset() const;

    /// Scrolls the view contents by a device-space delta converted back into scene space.
    void scrollContentsBy(int dx, int dy);

    // ===================================================================
    // fitInView / centerOn / ensureVisible
    // ===================================================================
    /**
     * @brief Adjusts the view so the supplied scene rectangle fits inside the viewport.
     * @param rect Scene rectangle to fit.
     * @param aspectRatioMode Reserved aspect ratio policy parameter.
     */
    void fitInView(const SwRectF& rect, int /*aspectRatioMode*/ = 0 /*IgnoreAspectRatio*/);

    /// Convenience overload that fits a rectangle expressed as coordinates and size.
    void fitInView(double x, double y, double w, double h, int mode = 0);

    /// Fits the scene bounding rectangle of the supplied item inside the viewport.
    void fitInView(const SwGraphicsItem* item, int aspectRatioMode = 0);

    /// Centers the view on a scene-space point.
    void centerOn(const SwPointF& pos);

    /// Convenience overload that centers the view from scalar scene coordinates.
    void centerOn(double x, double y);

    /// Centers the view on the scene bounding rectangle of the supplied item.
    void centerOn(const SwGraphicsItem* item);

    /**
     * @brief Scrolls the view enough to make a scene rectangle visible.
     * @param rect Rectangle that should become visible.
     * @param xmargin Horizontal visibility margin in device pixels.
     * @param ymargin Vertical visibility margin in device pixels.
     */
    void ensureVisible(const SwRectF& rect, int xmargin = 50, int ymargin = 50);

    /// Convenience overload that ensures visibility for coordinates and size.
    void ensureVisible(double x, double y, double w, double h, int xm = 50, int ym = 50);

    /// Ensures that the scene bounding rectangle of the supplied item becomes visible.
    void ensureVisible(const SwGraphicsItem* item, int xmargin = 50, int ymargin = 50);

    // ===================================================================
    // Item lookup through the view
    // ===================================================================
    /// Returns the top-most scene item located under a widget-space point.
    SwGraphicsItem* itemAt(const SwPoint& pos) const;
    /// Convenience overload that takes the query position as scalar widget coordinates.
    SwGraphicsItem* itemAt(int x, int y) const;

    /// Returns all items currently registered in the attached scene.
    std::vector<SwGraphicsItem*> items() const;
    /// Returns items found under a widget-space point.
    std::vector<SwGraphicsItem*> items(const SwPoint& pos) const;
    /// Returns items intersecting a widget-space rectangle.
    std::vector<SwGraphicsItem*> items(const SwRect& rect) const;

    // ===================================================================
    // Drag mode
    // ===================================================================
    /// Selects how mouse dragging should be interpreted by the view.
    void setDragMode(DragMode mode);
    /// Returns the current drag interaction mode.
    DragMode dragMode() const;

    /// Returns the current rubber-band rectangle in scene coordinates.
    SwRectF rubberBandRect() const;

    // ===================================================================
    // Interactive
    // ===================================================================
    /// Enables or disables forwarding of interactive input to the attached scene.
    void setInteractive(bool on);
    /// Returns whether interactive input is forwarded to the attached scene.
    bool isInteractive() const;

    // ===================================================================
    // Render hints
    // ===================================================================
    /// Enables or disables a single render-hint flag.
    void setRenderHint(RenderHint hint, bool on = true);
    /// Replaces the full render-hint bitmask.
    void setRenderHints(int hints);
    /// Returns the active render-hint bitmask.
    int renderHints() const;

    // ===================================================================
    // Viewport update mode
    // ===================================================================
    /// Sets the viewport update strategy used by the view.
    void setViewportUpdateMode(ViewportUpdateMode mode);
    /// Returns the viewport update strategy used by the view.
    ViewportUpdateMode viewportUpdateMode() const;

    // ===================================================================
    // Optimization flags
    // ===================================================================
    /// Enables or disables one optimization flag.
    void setOptimizationFlag(OptimizationFlag flag, bool on = true);
    /// Replaces the full optimization-flag bitmask.
    void setOptimizationFlags(int flags);
    /// Returns the active optimization-flag bitmask.
    int optimizationFlags() const;

    // ===================================================================
    // Anchors
    // ===================================================================
    /// Sets the anchor used when applying view transformations.
    void setTransformationAnchor(ViewportAnchor anchor);
    /// Returns the anchor used when applying view transformations.
    ViewportAnchor transformationAnchor() const;

    /// Sets the anchor used when the view is resized.
    void setResizeAnchor(ViewportAnchor anchor);
    /// Returns the anchor used when the view is resized.
    ViewportAnchor resizeAnchor() const;

    // ===================================================================
    // Alignment
    // ===================================================================
    /// Sets the content alignment policy used by the view.
    void setAlignment(int alignment);
    /// Returns the content alignment policy used by the view.
    int alignment() const;

    // ===================================================================
    // Cache mode
    // ===================================================================
    /// Sets the cache mode bitmask used by the view.
    void setCacheMode(int mode);
    /// Returns the cache mode bitmask used by the view.
    int cacheMode() const;
    /// Drops cached content and schedules a repaint.
    void resetCachedContent();

    // ===================================================================
    // Scene event forwarding helpers (for advanced use)
    // ===================================================================
    /// Requests a refresh after a scene update affecting multiple rectangles.
    void updateScene(const std::vector<SwRectF>& /*rects*/);
    /// Requests a refresh after a scene-rectangle update.
    void updateSceneRect(const SwRectF& /*rect*/);
    /// Requests a refresh after explicit scene invalidation.
    void invalidateScene(const SwRectF& /*rect*/ = SwRectF(), int /*layers*/ = 0);

protected:
    // ===================================================================
    // Paint
    // ===================================================================
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    // ===================================================================
    // Resize
    // ===================================================================
    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    // ===================================================================
    // Mouse events â€” forward to scene
    // ===================================================================
    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Double Click Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseDoubleClickEvent(MouseEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void keyPressEvent(KeyEvent* event) override;

    void keyReleaseEvent(KeyEvent* event) override;

    // ===================================================================
    // Virtual drawing hooks (override for custom background/foreground)
    // ===================================================================
    /**
     * @brief Performs the `drawBackground` operation.
     * @param painter Value passed to the method.
     * @param rect Rectangle used by the operation.
     * @return The requested draw Background.
     */
    virtual void drawBackground(SwPainter* painter, const SwRectF& rect);

    /**
     * @brief Performs the `drawForeground` operation.
     * @param painter Value passed to the method.
     * @param rect Rectangle used by the operation.
     * @return The requested draw Foreground.
     */
    virtual void drawForeground(SwPainter* painter, const SwRectF& rect);

private:
    int buildModifiers_(MouseEvent* event) const;

    void onSceneChanged_();

    void syncProxyWidgets_();

    SwPointF mapFromSceneDevice_(const SwPointF& scenePoint) const;

    SwRect mapFromSceneDevice_(const SwRectF& sceneRect) const;

private:
    // What the class keeps (SwGraphicsView_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

