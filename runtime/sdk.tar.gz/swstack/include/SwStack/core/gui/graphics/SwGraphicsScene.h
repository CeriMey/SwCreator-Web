#pragma once

#include "../../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/***************************************************************************************************
 * SwGraphicsScene  —  Qt-like QGraphicsScene with full API coverage.
 *
 * - Item management: addItem, removeItem, clear, items (sorted)
 * - Hit-testing: itemAt, items(point), items(rect), items(path), items(polygon)
 * - Selection: selectedItems, setSelectionArea, clearSelection
 * - Focus: focusItem, setFocusItem, clearFocus
 * - Mouse grab: mouseGrabberItem
 * - Event dispatch to items (mouse, hover, key, wheel, drag-drop, context menu)
 * - Background / foreground brush
 * - Convenience helpers (addRect, addEllipse, addLine, addText, …)
 * - Signals: changed, selectionChanged, focusItemChanged, sceneRectChanged
 **************************************************************************************************/

/**
 * @file
 * @ingroup core_graphics
 * @brief Declares the retained-mode scene that owns graphics items and dispatches interaction.
 *
 * @details
 * `SwGraphicsScene` stores items, defines the logical scene rectangle, performs hit testing,
 * manages selection and focus state, and routes input events toward the appropriate scene item.
 * It is the model-side counterpart of `SwGraphicsView`, which is responsible for viewport
 * presentation.
 */

#include "SwObject.h"

#include "graphics/SwGraphicsItems.h"
#include "graphics/SwGraphicsSceneEvent.h"
#include "graphics/SwGraphicsTypes.h"
#include "graphics/SwPainterPath.h"

#include <algorithm>
#include <functional>
#include <memory>
#include <vector>

// Xlib defines FocusIn and FocusOut as macros; here they name SwGraphicsSceneEventType values.
// Set aside for this header and restored at its end, whatever was included before it.
#pragma push_macro("FocusIn")
#pragma push_macro("FocusOut")
#undef FocusIn
#undef FocusOut

class SwGraphicsView;

/**
 * @class SwGraphicsScene
 * @brief Owns a collection of graphics items together with scene-wide state.
 *
 * @details
 * `SwGraphicsScene` is the retained-mode scene container behind `SwGraphicsView`. It keeps track
 * of graphics items, selection, focus, hover state, grabbers, background / foreground brushes, and
 * attached views, while also offering a Qt-like convenience API for creating common scene items.
 *
 * Responsibilities are split intentionally:
 * - items own their own geometry, painting, and item-local interaction policy,
 * - the scene resolves hit testing and scene-wide state transitions,
 * - the view maps the scene into a concrete viewport and forwards input into scene coordinates.
 *
 * This separation keeps item code reusable and independent from any single widget or platform
 * backend.
 */
class SW_WIDGETS_EXPORT SwGraphicsScene : public SwObject {
    SW_OBJECT(SwGraphicsScene, SwObject)

public:
    // --- Item sort order ---
    enum ItemIndexMethod { NoIndex, BspTreeIndex };

    /// Constructs an empty scene and optionally attaches it to a parent object.
    explicit SwGraphicsScene(SwObject* parent = nullptr);

    /// Constructs a scene with an explicit logical rectangle.
    SwGraphicsScene(const SwRectF& sceneRect, SwObject* parent = nullptr);

    /// Convenience constructor that takes the scene rectangle as coordinates and size.
    SwGraphicsScene(double x, double y, double w, double h, SwObject* parent = nullptr);

    /// Destroys the scene and deletes any remaining top-level items that it still owns.
    ~SwGraphicsScene() override;

    // ===================================================================
    // Scene rect
    // ===================================================================
    /**
     * @brief Sets the explicit logical rectangle associated with the scene.
     * @param rect New scene bounds in scene coordinates.
     *
     * Once set, this rectangle becomes the value returned by sceneRect()
     * instead of deriving bounds from the currently registered items.
     */
    void setSceneRect(const SwRectF& rect);

    /// Convenience overload that builds the scene rectangle from coordinates and size.
    void setSceneRect(double x, double y, double w, double h);

    /**
     * @brief Returns the scene rectangle exposed by the scene.
     * @return The explicit rectangle if one was set, otherwise the union of item bounds.
     */
    SwRectF sceneRect() const;

    /// Returns the current scene width in scene units.
    double width() const;
    /// Returns the current scene height in scene units.
    double height() const;

    // ===================================================================
    // Item management
    // ===================================================================
    /**
     * @brief Adds an item to the scene if it is not already present.
     * @param item Item to register.
     *
     * The scene installs its internal scene pointer and change callback so item
     * updates can invalidate the scene and any attached views.
     */
    void addItem(SwGraphicsItem* item);

    /**
     * @brief Removes an item from the scene and deletes it.
     * @param item Item to remove.
     *
     * When the item owns child items, the whole subtree is detached first.
     * Focus, hover, and grabber references targeting the removed item are also cleared.
     */
    void removeItem(SwGraphicsItem* item);

    /**
     * @brief Destroys a group item while preserving the child items it contains.
     * @param group Group item to dismantle.
     */
    void destroyItemGroup(SwGraphicsItemGroup* group);

    /**
     * @brief Creates a new group item and adds the supplied items to it.
     * @param items Items that should become children of the created group.
     * @return The newly created group item.
     */
    SwGraphicsItemGroup* createItemGroup(const std::vector<SwGraphicsItem*>& items);

    /// Removes all items from the scene, resets scene-level interaction state, and emits change.
    void clear();

    // ===================================================================
    // Item queries
    // ===================================================================
    /// Returns the raw list of items currently registered in the scene.
    const std::vector<SwGraphicsItem*>& items() const;

    /**
     * @brief Returns all items sorted by z value.
     * @param sortOrder `0` for ascending z order, `1` for descending z order.
     * @return A copied and sorted item list.
     */
    std::vector<SwGraphicsItem*> items(int sortOrder) const;

    /**
     * @brief Returns the items located at a scene position.
     * @param pos Query position in scene coordinates.
     * @param mode Selection mode used for hit testing.
     * @param sortOrder `0` for ascending z order, `1` for descending z order.
     * @return Matching items sorted using the requested z-order policy.
     */
    std::vector<SwGraphicsItem*> items(const SwPointF& pos,
                                       SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape,
                                       int sortOrder = 1 /*descending*/) const;

    /**
     * @brief Returns the items that intersect or are contained in a rectangle.
     * @param rect Query rectangle in scene coordinates.
     * @param mode Selection mode controlling containment versus intersection semantics.
     * @return Matching items.
     */
    std::vector<SwGraphicsItem*> items(const SwRectF& rect,
                                       SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape) const;

    /// Returns items selected by the bounding rectangle of the supplied polygon.
    std::vector<SwGraphicsItem*> items(const SwPolygonF& polygon,
                                       SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape) const;

    /// Returns items selected by the bounding rectangle of the supplied painter path.
    std::vector<SwGraphicsItem*> items(const SwPainterPath& path,
                                       SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape) const;

    /**
     * @brief Returns the top-most item at a scene position.
     * @param pos Query position in scene coordinates.
     * @param deviceTransform Reserved compatibility parameter currently ignored.
     * @return The front-most matching item, or `nullptr` if none is found.
     */
    SwGraphicsItem* itemAt(const SwPointF& pos, const SwTransform& /*deviceTransform*/ = SwTransform()) const;

    /// Convenience overload that takes the query position as scalar coordinates.
    SwGraphicsItem* itemAt(double x, double y, const SwTransform& t = SwTransform()) const;

    /**
     * @brief Computes the union of the scene bounding rectangles of all items.
     * @return Bounding rectangle covering every registered item.
     */
    SwRectF itemsBoundingRect() const;

    // ===================================================================
    // Selection
    // ===================================================================
    /// Returns the items whose selected flag is currently set.
    std::vector<SwGraphicsItem*> selectedItems() const;

    /// Returns the path most recently stored as the scene selection area.
    SwPainterPath selectionArea() const;

    /**
     * @brief Replaces the selection area and updates item selection from it.
     * @param path Selection shape expressed in scene coordinates.
     * @param mode Selection mode controlling containment versus intersection semantics.
     */
    void setSelectionArea(const SwPainterPath& path,
                          SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape);

    /// Compatibility overload that currently ignores the device transform parameter.
    void setSelectionArea(const SwPainterPath& path, const SwTransform& /*deviceTransform*/,
                          SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape);

    /// Clears the selected state of all items and emits `selectionChanged` when necessary.
    void clearSelection();

    // ===================================================================
    // Focus
    // ===================================================================
    /// Returns the item that currently owns scene focus, or `nullptr`.
    SwGraphicsItem* focusItem() const;

    /**
     * @brief Moves scene focus from the current item to another item.
     * @param item New focused item, or `nullptr` to clear focus.
     * @param reason Focus reason forwarded to generated focus events.
     */
    void setFocusItem(SwGraphicsItem* item,
                      SwFocusEvent::FocusReason reason = SwFocusEvent::OtherFocusReason);

    bool event(SwEvent* event) override;

    /// Clears scene focus by removing the currently focused item.
    void clearFocus();

    /// Returns `true` when an item currently owns focus in the scene.
    bool hasFocus() const;

    /**
     * @brief Requests scene-level focus.
     * @param reason Reserved focus reason parameter.
     *
     * This placeholder mirrors the Qt API shape. Actual native focus activation
     * is expected to happen at the view or widget layer.
     */
    void setFocus(SwFocusEvent::FocusReason /*reason*/ = SwFocusEvent::OtherFocusReason);

    // ===================================================================
    // Sticky focus  (Qt 5+ API)
    // ===================================================================
    /// Returns whether focus should remain when the user clicks on empty scene space.
    bool stickyFocus() const;
    /// Enables or disables sticky focus behavior.
    void setStickyFocus(bool enabled);

    // ===================================================================
    // Mouse grabber
    // ===================================================================
    /// Returns the item currently grabbing mouse events, if any.
    SwGraphicsItem* mouseGrabberItem() const;

    // ===================================================================
    // Item index method
    // ===================================================================
    /// Returns the indexing strategy currently selected for the scene.
    ItemIndexMethod itemIndexMethod() const;
    /// Selects the indexing strategy used by the scene.
    void setItemIndexMethod(ItemIndexMethod method);

    /// Returns the configured BSP tree depth hint.
    int bspTreeDepth() const;
    /// Sets the BSP tree depth hint.
    void setBspTreeDepth(int depth);

    // ===================================================================
    // Minimum render size
    // ===================================================================
    /// Returns the minimum render size threshold stored on the scene.
    double minimumRenderSize() const;
    /// Sets the minimum render size threshold used by clients that honor it.
    void setMinimumRenderSize(double minSize);

    // ===================================================================
    // Background / foreground
    // ===================================================================
    /// Returns the brush used by the default background drawing implementation.
    SwBrush backgroundBrush() const;
    /// Sets the brush used by the default background drawing implementation.
    void setBackgroundBrush(const SwBrush& brush);

    /// Returns the brush associated with scene foreground decoration.
    SwBrush foregroundBrush() const;
    /// Sets the brush associated with scene foreground decoration.
    void setForegroundBrush(const SwBrush& brush);

    /**
     * @brief Draws the scene background for the given exposed rectangle.
     * @param painter Painter used for rendering.
     * @param rect Rectangle to paint in scene coordinates.
     *
     * The default implementation fills the region when a solid background brush
     * is configured. Subclasses can override this to draw grids or backdrops.
     */
    virtual void drawBackground(SwPainter* painter, const SwRectF& rect);

    /**
     * @brief Draws additional scene content after items have been painted.
     * @param painter Painter used for rendering.
     * @param rect Rectangle to paint in scene coordinates.
     */
    virtual void drawForeground(SwPainter* /*painter*/, const SwRectF& /*rect*/);

    // ===================================================================
    // Font
    // ===================================================================
    /// Returns the default scene font.
    SwFont font() const;
    /// Sets the default scene font and emits a generic scene change notification.
    void setFont(const SwFont& font);

    // ===================================================================
    // Views
    // ===================================================================
    /// Returns the graphics views currently attached to this scene.
    std::vector<SwGraphicsView*> views() const;
    /// Internal helper used by SwGraphicsView to register itself with the scene.
    void addView_(SwGraphicsView* v);
    /// Internal helper used by SwGraphicsView to unregister itself from the scene.
    void removeView_(SwGraphicsView* v);

    // ===================================================================
    // Update / invalidate
    // ===================================================================
    /// Marks the scene as changed and requests dependent views to refresh.
    void update(const SwRectF& /*rect*/ = SwRectF());
    /// Invalidates cached scene content and emits a generic change notification.
    void invalidate(const SwRectF& /*rect*/ = SwRectF(), int /*layers*/ = 0x01 /*AllLayers*/);
    /// Runs the scene advance placeholder and emits a change notification.
    void advance();

    // ===================================================================
    // Render
    // ===================================================================
    /**
     * @brief Renders the scene into an arbitrary painter target.
     * @param painter Destination painter.
     * @param target Optional target rectangle in destination coordinates.
     * @param source Optional source rectangle in scene coordinates.
     * @param aspectRatioMode Reserved aspect ratio policy parameter.
     *
     * This inline version is currently a stub kept for API completeness.
     */
    void render(SwPainter* /*painter*/,
                const SwRectF& /*target*/ = SwRectF(),
                const SwRectF& /*source*/ = SwRectF(),
                int /*aspectRatioMode*/ = 0);

    // ===================================================================
    // Convenience helpers  (same as before)
    // ===================================================================
    /// Creates a rectangle item, applies the supplied pen and brush, adds it to the scene, and returns it.
    SwGraphicsRectItem* addRect(const SwRectF& rect, const SwPen& pen = SwPen(), const SwBrush& brush = SwBrush());
    /// Convenience overload that creates a rectangle item from coordinates and size.
    SwGraphicsRectItem* addRect(double x, double y, double w, double h,
                                const SwPen& pen = SwPen(), const SwBrush& brush = SwBrush());

    /// Creates an ellipse item, applies the supplied pen and brush, adds it to the scene, and returns it.
    SwGraphicsEllipseItem* addEllipse(const SwRectF& rect, const SwPen& pen = SwPen(), const SwBrush& brush = SwBrush());
    /// Convenience overload that creates an ellipse item from coordinates and size.
    SwGraphicsEllipseItem* addEllipse(double x, double y, double w, double h,
                                      const SwPen& pen = SwPen(), const SwBrush& brush = SwBrush());

    /// Creates a line item, applies the supplied pen, adds it to the scene, and returns it.
    SwGraphicsLineItem* addLine(const SwLineF& line, const SwPen& pen = SwPen());
    /// Convenience overload that creates a line item from scalar endpoints.
    SwGraphicsLineItem* addLine(double x1, double y1, double x2, double y2, const SwPen& pen = SwPen());

    /// Creates a text item, applies the supplied font, adds it to the scene, and returns it.
    SwGraphicsTextItem* addText(const SwString& text, const SwFont& font = SwFont());

    /// Creates a simple text item, applies the supplied font, adds it to the scene, and returns it.
    SwGraphicsSimpleTextItem* addSimpleText(const SwString& text, const SwFont& font = SwFont());

    /// Creates a pixmap item, adds it to the scene, and returns it.
    SwGraphicsPixmapItem* addPixmap(const SwPixmap& pixmap);

    /// Creates a path item, applies the supplied pen and brush, adds it to the scene, and returns it.
    SwGraphicsPathItem* addPath(const SwPainterPath& path, const SwPen& pen = SwPen(), const SwBrush& brush = SwBrush());

    /// Creates a polygon item, applies the supplied pen and brush, adds it to the scene, and returns it.
    SwGraphicsPolygonItem* addPolygon(const SwPolygonF& polygon, const SwPen& pen = SwPen(), const SwBrush& brush = SwBrush());

    /// Wraps a widget in a proxy item, adds it to the scene, and returns the proxy.
    SwGraphicsProxyWidget* addWidget(SwWidget* widget);

    // ===================================================================
    // Event dispatch  (called by SwGraphicsView)
    // ===================================================================
    /**
     * @brief Dispatches a mouse press that originated from an attached view.
     * @param scenePos Mouse position in scene coordinates.
     * @param button Button that triggered the event.
     * @param modifiers Keyboard modifier bitmask.
     */
    void mousePressEvent_(const SwPointF& scenePos, const SwPoint& screenPos,
                          SwMouseButton button, int modifiers);

    /**
     * @brief Dispatches a mouse move that originated from an attached view.
     * @param scenePos Mouse position in scene coordinates.
     * @param buttons Currently pressed mouse buttons as a bitmask.
     * @param modifiers Keyboard modifier bitmask.
     */
    void mouseMoveEvent_(const SwPointF& scenePos, const SwPoint& screenPos,
                         int buttons, int modifiers);

    /**
     * @brief Dispatches a mouse release that originated from an attached view.
     * @param scenePos Mouse position in scene coordinates.
     * @param button Button that triggered the release.
     * @param modifiers Keyboard modifier bitmask.
     */
    void mouseReleaseEvent_(const SwPointF& scenePos, const SwPoint& screenPos,
                            SwMouseButton button, int modifiers);

    /**
     * @brief Dispatches a mouse double-click that originated from an attached view.
     * @param scenePos Mouse position in scene coordinates.
     * @param button Button that triggered the event.
     * @param modifiers Keyboard modifier bitmask.
     */
    void mouseDoubleClickEvent_(const SwPointF& scenePos, const SwPoint& screenPos,
                                SwMouseButton button, int modifiers);

    /**
     * @brief Dispatches a wheel event that originated from an attached view.
     * @param scenePos Mouse position in scene coordinates.
     * @param delta Wheel delta value.
     * @param modifiers Keyboard modifier bitmask.
     */
    void wheelEvent_(const SwPointF& scenePos, const SwPoint& screenPos,
                     int delta, int modifiers);

    /// Forwards a key press to the keyboard grabber item or the focused item.
    void keyPressEvent_(KeyEvent* event);

    /// Forwards a key release to the keyboard grabber item or the focused item.
    void keyReleaseEvent_(KeyEvent* event);

    /**
     * @brief Dispatches a context-menu request that originated from an attached view.
     * @param scenePos Trigger position in scene coordinates.
     * @param modifiers Keyboard modifier bitmask.
     */
    void contextMenuEvent_(const SwPointF& scenePos, const SwPoint& screenPos, int modifiers);

    // ===================================================================
    // Grab management  (called by SwGraphicsItem)
    // ===================================================================
    /// Internal helper used by items to claim or release mouse grabbing.
    void setMouseGrabberItem_(SwGraphicsItem* item);
    /// Internal helper used by items to claim or release keyboard grabbing.
    void setKeyboardGrabberItem_(SwGraphicsItem* item);
    /// Returns the item currently grabbing keyboard events, if any.
    SwGraphicsItem* keyboardGrabberItem() const;

signals:
    SW_SIGNAL_VOID(changed);                    ///< Emitted when scene content or scene-wide visual state changes.
    SW_SIGNAL_VOID(selectionChanged);           ///< Emitted after the set of selected items changes.
    SW_SIGNAL(sceneRectChanged, const SwRectF&); ///< Emitted when an explicit scene rectangle is assigned.
    SW_SIGNAL_VOID(focusItemChanged);           ///< Emitted after focus moves to another scene item or is cleared.

private:
    bool dispatchGraphicsSceneEvent_(SwGraphicsSceneDispatchEvent* event);

    bool handleGraphicsSceneEvent_(SwGraphicsSceneEvent* event);

    bool handleMousePressEvent_(SwGraphicsSceneMouseEvent* event);

    bool handleMouseMoveEvent_(SwGraphicsSceneMouseEvent* event);

    bool handleMouseReleaseEvent_(SwGraphicsSceneMouseEvent* event);

    bool handleMouseDoubleClickEvent_(SwGraphicsSceneMouseEvent* event);

    bool handleWheelEvent_(SwGraphicsSceneWheelEvent* event);

    bool handleContextMenuEvent_(SwGraphicsSceneContextMenuEvent* event);

    bool handleKeyEvent_(KeyEvent* event, SwGraphicsSceneKeyDispatchType dispatchType);

    bool dispatchSceneEventToItem_(SwGraphicsItem* target, SwGraphicsSceneEvent* event);
    void sortItemsByZ_(std::vector<SwGraphicsItem*>& v, int order) const;

private:
    // What the class keeps (SwGraphicsScene_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

#pragma pop_macro("FocusOut")
#pragma pop_macro("FocusIn")
