/* Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include "SwFont.h"
#include "graphics/SwImage.h"
#include "SwString.h"
struct SwTextRaster {
    SwImage image; // white glyph coverage in straight alpha; two-pixel padding
    int advance{0}, baseline{0}, capHeight{0};
    SwString resolvedFamily;
};
// Native platform fonts only. Does not load files or invent missing glyphs.
class SW_GUI_EXPORT SwTextRasterizer {
  public:
    static bool available();
    static bool rasterize(const SwString &, const SwFont &, SwTextRaster &, SwString &error);
};
