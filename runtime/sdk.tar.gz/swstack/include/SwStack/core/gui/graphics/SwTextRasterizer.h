/* Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include "SwFont.h"
#include "graphics/SwImage.h"
#include "SwString.h"
struct SwTextRaster {
    SwImage image; // white glyph coverage in straight alpha; two-pixel padding
    int advance{0}, baseline{0}, capHeight{0};
    SwString resolvedFamily;
};
// Native platform fonts only. Does not load files or invent missing glyphs.
class SW_GUI_EXPORT SwTextRasterizer {
  public:
    static bool available();
    static bool rasterize(const SwString &, const SwFont &, SwTextRaster &, SwString &error);
    // Windows upload density: the image has native pixels and two native pixels
    // of padding. Font sizes and advance/baseline/capHeight remain logical.
    // Other backends support the existing density of one.
    static bool rasterize(const SwString &, const SwFont &, double pixelsPerDip,
                          SwTextRaster &, SwString &error);
};
