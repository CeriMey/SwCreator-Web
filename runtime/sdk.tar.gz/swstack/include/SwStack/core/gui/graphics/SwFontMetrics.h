#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwFontMetrics.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwFontMetrics in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the font metrics interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwFontMetrics.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Declares text measurement helpers for SwFont.
 *
 * SwFontMetrics centralizes the small amount of font measurement logic needed by
 * widgets, text items, and layout code. It uses native Win32 metrics when
 * available and falls back to deterministic approximations on other platforms,
 * which keeps the API usable even when no platform text backend is wired yet.
 */

#include "SwFont.h"
#include "SwString.h"
#include "Sw.h"


#include <algorithm>

/**
 * @brief Computes bounding information for text rendered with a given font.
 *
 * The class intentionally exposes only a narrow API: line height, horizontal
 * advance, and a simple bounding rectangle. Those queries cover the current
 * needs of the stack while keeping the implementation easy to port.
 */
class SW_GUI_EXPORT SwFontMetrics {
public:
    /**
     * @brief Constructs a `SwFontMetrics` instance.
     * @param font Font value used by the operation.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwFontMetrics(const SwFont& font);

    /**
     * @brief Returns the current height.
     * @return The current height.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int height() const;

    /**
     * @brief Performs the `horizontalAdvance` operation.
     * @param text Value passed to the method.
     * @return The requested horizontal Advance.
     */
    int horizontalAdvance(const SwString& text) const;

    /** Returns a single line that fits maxWidth, ending in an ellipsis when shortened.
     * UTF-8 characters are kept whole. Returns empty when even the ellipsis does not fit. */
    SwString elidedText(const SwString& text, int maxWidth) const;

    /**
     * @brief Performs the `boundingRect` operation.
     * @param text Value passed to the method.
     * @return The requested bounding Rect.
     */
    SwRect boundingRect(const SwString& text) const;

private:
    int fallbackHeight_() const;

    int fallbackWidth_(const SwString& text) const;

public:
    ~SwFontMetrics();
public:
    SwFontMetrics(const SwFontMetrics& other);
    SwFontMetrics& operator=(const SwFontMetrics& other);
private:
    // What the class keeps (SwFontMetrics_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
