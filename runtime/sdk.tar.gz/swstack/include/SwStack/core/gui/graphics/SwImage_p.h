#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwImage.h"

struct SwImage::Data : SwSharedData {
    // Members are mutable so that const accessors may materialize into the handle: the value
    // of the image is unchanged by that, only its representation.
    mutable std::shared_ptr<SwImageStorage> m_storage;
    mutable std::vector<SwImageOp> m_ops;
    mutable SwRect m_view{0, 0, 0, 0};
    mutable SwImageLayout m_layout;
    mutable SwColorSpace m_colorSpace{SwColorSpace::Undefined};
    SwImageRotation m_orientation{SwImageRotation::Identity};
};
