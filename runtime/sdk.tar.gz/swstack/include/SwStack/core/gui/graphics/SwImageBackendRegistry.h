#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImageBackendRegistry.h
 * @ingroup core_graphics
 * @brief Declares the SwImageBackendRegistry singleton in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the backend registry interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwImageBackendRegistry.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Process-wide, thread-safe registry of image backends (an SwObject singleton).
 *
 * The CPU backend is registered first and remains registered until explicit shutdown.
 * Unless SW_IMAGE_NO_PLATFORM_BACKENDS is defined,
 * the per-platform aggregator header (platform/win, platform/linux, platform/android) is included
 * at the bottom of this file under an OS guard and `__has_include`, and its
 * `swRegisterPlatformImageBackends(SwImageBackendRegistry&)` is called from the constructor.
 * This is the single place where core/gui/graphics reaches into the platform headers, mirroring
 * SwPlatformFactory.h and SwVideoWidget.h.
 *
 * The registry is an SwObject: it emits `backendRegistered(id)` and exposes the forced backend as
 * the `ForcedBackend` property (with its `ForcedBackendChanged` signal). It is created lazily on
 * first use, works without an SwCoreApplication, and is intentionally never destroyed so that
 * backends used from worker threads are not torn down during static destruction. An application
 * may release the registry's backend references explicitly at final, quiescent shutdown.
 */

#include "SwImageBackend.h"
#include "SwImageCpuBackend.h"
#include "SwObject.h"
#include "SwString.h"
#include "SwDebug.h"

#include <algorithm>
#include <memory>
#include <mutex>
#include <vector>

static constexpr const char* kSwLogCategory_SwImageBackendRegistry = "sw.gui.swimagebackendregistry";

/**
 * @brief Singleton registry of SwImageBackend instances, priority-sorted, thread-safe.
 */
class SW_GUI_EXPORT SwImageBackendRegistry : public SwObject {
    SW_OBJECT(SwImageBackendRegistry, SwObject)

public:
    /**
     * @brief Returns the process-wide registry (created on first call, never destroyed).
     * @return The registry.
     */
    static SwImageBackendRegistry& instance();

    /**
     * @brief Releases the registry's backend references at final application shutdown.
     *
     * Stop image operations and all registration activity before calling this method. It is
     * idempotent and terminal: the singleton survives, subsequent registration is ignored,
     * and backend queries return empty results. References already held by plans, images,
     * fences or callers remain valid; backend devices and consumer handles are not reset.
     * Backend destruction occurs outside the registry mutex and may wait on platform drivers.
     */
    void shutdown();

    /**
     * @brief Shuts down an existing registry without creating it or platform backends.
     * @return True if the singleton already exists, including when it was already shut down.
     *
     * Requires the same final, quiescent state as shutdown(). A false result leaves lazy
     * initialization untouched; it does not prohibit a later first call to instance().
     */
    static bool shutdownIfInitialized();

    /**
     * @brief Registers a backend and emits backendRegistered(id).
     *
     * A backend whose id is already registered is ignored (a warning is logged) so that the
     * registration order stays deterministic; null backends and registration after final
     * shutdown are ignored silently.
     *
     * @param backend Backend to register.
     */
    void registerBackend(const std::shared_ptr<SwImageBackend>& backend);

    /**
     * @brief Returns the available backends, highest priority first (stable for equal priorities).
     * @return Available backends.
     */
    std::vector<std::shared_ptr<SwImageBackend> > backends() const;

    /**
     * @brief Returns every registered backend (available or not), highest priority first.
     * @return Registered backends.
     */
    std::vector<std::shared_ptr<SwImageBackend> > allBackends() const;

    /**
     * @brief Looks a backend up by id (available or not).
     * @param id Backend id such as "cpu" or "d3d11".
     * @return The backend or null.
     */
    std::shared_ptr<SwImageBackend> backend(const SwString& id) const;

    /**
     * @brief Returns the CPU backend, or null after final shutdown.
     * @return The CPU backend while the registry is active.
     */
    std::shared_ptr<SwImageBackend> cpuBackend() const;

    /**
     * @brief Returns the forced backend id ("" = automatic, the planner decides). Thread-safe.
     * @return The forced backend id.
     */
    SwString forcedBackend() const;

    /**
     * @brief Returns the number of registered backends.
     * @return Count.
     */
    std::size_t count() const;

    /**
     * @brief Property ForcedBackend: "" = auto, else the id of the only backend the planner may use
     * for ops (transfers stay allowed). setForcedBackend() / getForcedBackend() are generated;
     * forcedBackend() is the thread-safe reader used by the planner.
     */
    SW_PROPERTY_D(SwString, ForcedBackend);
private:
protected:

signals:
    SW_SIGNAL(backendRegistered, const SwString&)

private:
    SwImageBackendRegistry();   // defined at the bottom of this file, after the platform includes

    static bool priorityGreater_(const std::shared_ptr<SwImageBackend>& a,
                                 const std::shared_ptr<SwImageBackend>& b);

public:
    ~SwImageBackendRegistry();
private:
    // What the class keeps (SwImageBackendRegistry_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

/**
 * @brief Registers the CPU backend, then the platform backends (unless opted out).
 */
