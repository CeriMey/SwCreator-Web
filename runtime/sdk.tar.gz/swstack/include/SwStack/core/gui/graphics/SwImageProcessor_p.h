#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwImageProcessor.h"

// The worker owns this state independently of the SwObject. A synchronous
// terminal signal may destroy the processor without destroying the running job.
struct SwImageProcessor::WorkerState {
    mutable std::mutex mutex;
    std::condition_variable queueCv, drainCv;
    std::deque<Job_> queue;
    bool stopRequested{false}, busy{false};
    int droppedCount{0};
};

struct SwImageProcessor::Data {
    SwImageRecipe m_Recipe = SwImageRecipe();
    bool m_Recipe_registered_ = sw_register_Recipe_();
    SwString m_Backend = SwString();
    bool m_Backend_registered_ = sw_register_Backend_();
    bool m_Asynchronous = true;
    bool m_Asynchronous_registered_ = sw_register_Asynchronous_();
    int m_MaxQueueDepth = 2;
    bool m_MaxQueueDepth_registered_ = sw_register_MaxQueueDepth_();
    SwImageResidency m_OutputResidency = SwImageResidency::Cpu;
    bool m_OutputResidency_registered_ = sw_register_OutputResidency_();
    std::shared_ptr<WorkerState> m_work{std::make_shared<WorkerState>()};
    std::thread m_worker;
    std::shared_ptr<int> m_callbackGuard{std::make_shared<int>(0)};
};
