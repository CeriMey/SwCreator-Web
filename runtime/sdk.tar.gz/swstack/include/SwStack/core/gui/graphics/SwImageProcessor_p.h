#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwImageProcessor.h"

struct SwImageProcessor::Data {
    SwImageRecipe m_Recipe = SwImageRecipe();
    bool m_Recipe_registered_ = sw_register_Recipe_();
    SwString m_Backend = SwString();
    bool m_Backend_registered_ = sw_register_Backend_();
    bool m_Asynchronous = true;
    bool m_Asynchronous_registered_ = sw_register_Asynchronous_();
    int m_MaxQueueDepth = 2;
    bool m_MaxQueueDepth_registered_ = sw_register_MaxQueueDepth_();
    SwImageResidency m_OutputResidency = SwImageResidency::Cpu;
    bool m_OutputResidency_registered_ = sw_register_OutputResidency_();
    mutable std::mutex m_mutex;
    std::condition_variable m_queueCv;
    std::condition_variable m_drainCv;
    std::deque<Job_> m_queue;
    std::thread m_worker;
    bool m_stopRequested{false};
    bool m_busy{false};
    int m_droppedCount{0};
    std::shared_ptr<int> m_callbackGuard{std::make_shared<int>(0)};
};
