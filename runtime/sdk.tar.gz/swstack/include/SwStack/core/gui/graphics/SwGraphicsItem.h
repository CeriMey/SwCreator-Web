#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwGraphicsItem.h
 * @ingroup core_graphics
 * @brief Declares the public interface exposed by SwGraphicsItem in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the graphics item interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwItemSelectionMode, SwGraphicsItemChange,
 * SwGraphicsCacheMode, SwGraphicsPanelModality, and SwGraphicsItem.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/***************************************************************************************************
 * SwGraphicsItem  —  Qt-like QGraphicsItem with full API coverage.
 *
 * - Transforms (rotation, per-item scale, arbitrary SwTransform, origin point)
 * - Event handlers (mouse, hover, key, wheel, drag-drop, focus, context menu)
 * - Coordinate mapping (mapToScene, mapFromScene, mapToItem, mapFromItem, …)
 * - Shape / collision detection
 * - Opacity, cursor, tooltip, enabled, focus, grab
 * - Custom data (key → variant via SwAny)
 * - Item change notifications
 **************************************************************************************************/

/**
 * @file
 * @brief Declares the base item type used by the retained-mode graphics scene.
 *
 * SwGraphicsItem is the central abstraction behind the graphics-view subsystem.
 * It combines hierarchy management, geometry mapping, visibility, selection,
 * transforms, hit testing, and virtual paint or event hooks in a single base
 * class that concrete scene items can derive from.
 *
 * The goal is to let higher-level code build interactive scene graphs without
 * coupling item implementations to a specific platform widget backend.
 */

#include "graphics/SwGraphicsTypes.h"
#include "graphics/SwGraphicsSceneEvent.h"
#include "SwString.h"
#include "SwWidget.h"
#include "Sw.h"

#include <algorithm>
#include <functional>
#include <map>
#include <vector>

// Xlib defines FocusIn and FocusOut as macros; here they name SwGraphicsSceneEventType values.
// Set aside for this header and restored at its end, whatever was included before it.
#pragma push_macro("FocusIn")
#pragma push_macro("FocusOut")
#undef FocusIn
#undef FocusOut

class SwPainter;
class SwPainterPath;
class SwGraphicsScene;
class SwGraphicsItemGroup;
struct SwGraphicsRenderContext;

// ---------------------------------------------------------------------------
// Forward-declare SwAny-like variant for data()  (if SwAny.h not included)
// ---------------------------------------------------------------------------
#ifndef SW_ANY_FORWARD_DECLARED
#define SW_ANY_FORWARD_DECLARED
class SwAny;
#endif

// ---------------------------------------------------------------------------
// Item selection / collision mode  (matches Qt::ItemSelectionMode)
// ---------------------------------------------------------------------------
enum class SwItemSelectionMode {
    IntersectsItemShape,
    ContainsItemShape,
    IntersectsItemBoundingRect,
    ContainsItemBoundingRect
};

// ---------------------------------------------------------------------------
// GraphicsItemChange  (matches QGraphicsItem::GraphicsItemChange)
// ---------------------------------------------------------------------------
enum class SwGraphicsItemChange {
    ItemPositionChange,
    ItemPositionHasChanged,
    ItemTransformChange,
    ItemTransformHasChanged,
    ItemRotationChange,
    ItemRotationHasChanged,
    ItemScaleChange,
    ItemScaleHasChanged,
    ItemTransformOriginPointChange,
    ItemTransformOriginPointHasChanged,
    ItemSelectedChange,
    ItemSelectedHasChanged,
    ItemVisibleChange,
    ItemVisibleHasChanged,
    ItemEnabledChange,
    ItemEnabledHasChanged,
    ItemParentChange,
    ItemParentHasChanged,
    ItemChildAddedChange,
    ItemChildRemovedChange,
    ItemSceneChange,
    ItemSceneHasChanged,
    ItemCursorChange,
    ItemCursorHasChanged,
    ItemToolTipChange,
    ItemToolTipHasChanged,
    ItemFlagsChange,
    ItemFlagsHasChanged,
    ItemZValueChange,
    ItemZValueHasChanged,
    ItemOpacityChange,
    ItemOpacityHasChanged,
    ItemScenePositionHasChanged
};

// ---------------------------------------------------------------------------
// CacheMode  (matches QGraphicsItem::CacheMode)
// ---------------------------------------------------------------------------
enum class SwGraphicsCacheMode {
    NoCache,
    ItemCoordinateCache,
    DeviceCoordinateCache
};

// ---------------------------------------------------------------------------
// PanelModality
// ---------------------------------------------------------------------------
enum class SwGraphicsPanelModality {
    NonModal,
    PanelModal,
    SceneModal
};

// ---------------------------------------------------------------------------
// SwGraphicsItem
// ---------------------------------------------------------------------------
/**
 * @brief Base class for all drawable and interactive objects stored in a scene.
 */
class SW_WIDGETS_EXPORT SwGraphicsItem {
public:
    // --- Flags (matches QGraphicsItem::GraphicsItemFlag) ---
    enum GraphicsItemFlag {
        ItemIsMovable                        = 0x1,
        ItemIsSelectable                     = 0x2,
        ItemIsFocusable                      = 0x4,
        ItemClipsToShape                     = 0x8,
        ItemClipsChildrenToShape             = 0x10,
        ItemIgnoresTransformations           = 0x20,
        ItemIgnoresParentOpacity             = 0x40,
        ItemDoesntPropagateOpacityToChildren = 0x80,
        ItemStacksBehindParent               = 0x100,
        ItemUsesExtendedStyleOption          = 0x200,
        ItemHasNoContents                    = 0x400,
        ItemSendsGeometryChanges             = 0x800,
        ItemAcceptsInputMethod               = 0x1000,
        ItemNegativeZStacksBehindParent      = 0x2000,
        ItemIsPanel                          = 0x4000,
        ItemSendsScenePositionChanges        = 0x8000,
        ItemContainsChildrenInShape          = 0x10000
    };

    // --- Type ---
    enum { Type = 1 };
    /**
     * @brief Returns the current type.
     * @return The current type.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual int type() const;

    // ===================================================================
    // Construction / destruction
    // ===================================================================
    /**
     * @brief Constructs a `SwGraphicsItem` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwGraphicsItem(SwGraphicsItem* parent = nullptr);

    /**
     * @brief Destroys the `SwGraphicsItem` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    virtual ~SwGraphicsItem();

    /**
     * @brief Constructs a `SwGraphicsItem` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwGraphicsItem(const SwGraphicsItem&) = delete;
    /**
     * @brief Performs the `operator=` operation.
     * @return The requested operator =.
     */
    SwGraphicsItem& operator=(const SwGraphicsItem&) = delete;

    // ===================================================================
    // Position
    // ===================================================================
    /**
     * @brief Sets the pos.
     * @param x Horizontal coordinate.
     * @param y Vertical coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPos(double x, double y);
    /**
     * @brief Sets the pos.
     * @param y Vertical coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPos(const SwPointF& p);
    /**
     * @brief Returns the current pos.
     * @return The current pos.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF pos() const;
    /**
     * @brief Returns the current x.
     * @return The current x.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double x() const;
    /**
     * @brief Returns the current y.
     * @return The current y.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double y() const;
    /**
     * @brief Sets the x.
     * @param y Vertical coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setX(double v);
    /**
     * @brief Sets the y.
     * @param v Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setY(double v);

    /**
     * @brief Performs the `moveBy` operation.
     * @param dx Value passed to the method.
     * @param dy Value passed to the method.
     */
    void moveBy(double dx, double dy);

    /**
     * @brief Returns the current scene Pos.
     * @return The current scene Pos.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF scenePos() const;

    // ===================================================================
    // Z ordering
    // ===================================================================
    /**
     * @brief Sets the zValue.
     * @param m_z Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setZValue(double z);
    /**
     * @brief Returns the current z Value.
     * @return The current z Value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double zValue() const;

    /**
     * @brief Performs the `stackBefore` operation.
     * @param sibling Value passed to the method.
     */
    void stackBefore(const SwGraphicsItem* sibling);

    // ===================================================================
    // Visibility
    // ===================================================================
    /**
     * @brief Sets the visible.
     * @param m_visible Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setVisible(bool on);
    /**
     * @brief Returns whether the object reports visible.
     * @return `true` when the object reports visible; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isVisible() const;
    /**
     * @brief Performs the `show` operation.
     * @param true Value passed to the method.
     */
    void show();
    /**
     * @brief Performs the `hide` operation.
     * @param false Value passed to the method.
     */
    void hide();

    // ===================================================================
    // Enabled
    // ===================================================================
    /**
     * @brief Sets the enabled.
     * @param m_enabled Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setEnabled(bool on);
    /**
     * @brief Returns whether the object reports enabled.
     * @return `true` when the object reports enabled; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isEnabled() const;

    // ===================================================================
    // Selection
    // ===================================================================
    /**
     * @brief Sets the selected.
     * @param m_selected Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSelected(bool on);
    /**
     * @brief Returns whether the object reports selected.
     * @return `true` when the object reports selected; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isSelected() const;

    // ===================================================================
    // Flags
    // ===================================================================
    /**
     * @brief Sets the flags.
     * @param m_flags Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFlags(int flags);
    /**
     * @brief Returns the current flags.
     * @return The current flags.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int flags() const;
    /**
     * @brief Sets the flag.
     * @param flag Value passed to the method.
     * @param enabled Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFlag(GraphicsItemFlag flag, bool enabled = true);
    /**
     * @brief Performs the `testFlag` operation.
     * @return `true` on success; otherwise `false`.
     */
    bool testFlag(GraphicsItemFlag flag) const;

    // ===================================================================
    // Opacity
    // ===================================================================
    /**
     * @brief Sets the opacity.
     * @param m_opacity Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOpacity(double opacity);
    /**
     * @brief Returns the current opacity.
     * @return The current opacity.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double opacity() const;
    /**
     * @brief Returns the current effective Opacity.
     * @return The current effective Opacity.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double effectiveOpacity() const;

    // ===================================================================
    // Transform
    // ===================================================================
    /**
     * @brief Sets the rotation.
     * @param m_rotation Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRotation(double angle);
    /**
     * @brief Returns the current rotation.
     * @return The current rotation.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double rotation() const;

    /**
     * @brief Sets the scale.
     * @param m_scaleFactor Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setScale(double factor);
    /**
     * @brief Returns the current scale.
     * @return The current scale.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double scale() const;

    /**
     * @brief Sets the transform Origin Point.
     * @param ox Value passed to the method.
     * @param m_transformOrigin Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTransformOriginPoint(double ox, double oy);
    /**
     * @brief Sets the transform Origin Point.
     * @param y Vertical coordinate.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTransformOriginPoint(const SwPointF& origin);
    /**
     * @brief Returns the current transform Origin Point.
     * @return The current transform Origin Point.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPointF transformOriginPoint() const;

    /**
     * @brief Sets the transform.
     * @param t Value passed to the method.
     * @param combine Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTransform(const SwTransform& t, bool combine = false);
    /**
     * @brief Returns the current transform.
     * @return The current transform.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwTransform transform() const;
    /**
     * @brief Resets the object to a baseline state.
     * @param m_rotation Value passed to the method.
     */
    void resetTransform();

    /**
     * @brief Returns the current scene Transform.
     * @return The current scene Transform.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwTransform sceneTransform() const;

    /**
     * @brief Performs the `deviceTransform` operation.
     * @param viewTransform Value passed to the method.
     * @return The requested device Transform.
     */
    SwTransform deviceTransform(const SwTransform& viewTransform) const;

    /**
     * @brief Performs the `itemTransform` operation.
     * @param other Value passed to the method.
     * @param ok Optional flag updated to report success.
     * @return The requested item Transform.
     */
    SwTransform itemTransform(const SwGraphicsItem* other, bool* ok = nullptr) const;

    // ===================================================================
    // Coordinate mapping
    // ===================================================================
    /**
     * @brief Performs the `mapToScene` operation.
     * @param point Point used by the operation.
     * @return The requested map To Scene.
     */
    SwPointF mapToScene(const SwPointF& point) const;
    /**
     * @brief Performs the `mapToScene` operation.
     * @param x Horizontal coordinate.
     * @return The requested map To Scene.
     */
    SwPointF mapToScene(double x, double y) const;
    /**
     * @brief Performs the `mapRectToScene` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map Rect To Scene.
     */
    SwRectF mapRectToScene(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapToScene` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map To Scene.
     */
    SwPolygonF mapToScene(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapToScene` operation.
     * @param polygon Value passed to the method.
     * @return The requested map To Scene.
     */
    SwPolygonF mapToScene(const SwPolygonF& polygon) const;

    /**
     * @brief Performs the `mapFromScene` operation.
     * @param point Point used by the operation.
     * @return The requested map From Scene.
     */
    SwPointF mapFromScene(const SwPointF& point) const;
    /**
     * @brief Performs the `mapFromScene` operation.
     * @param x Horizontal coordinate.
     * @return The requested map From Scene.
     */
    SwPointF mapFromScene(double x, double y) const;
    /**
     * @brief Performs the `mapRectFromScene` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map Rect From Scene.
     */
    SwRectF mapRectFromScene(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapFromScene` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map From Scene.
     */
    SwPolygonF mapFromScene(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapFromScene` operation.
     * @param polygon Value passed to the method.
     * @return The requested map From Scene.
     */
    SwPolygonF mapFromScene(const SwPolygonF& polygon) const;

    /**
     * @brief Performs the `mapToParent` operation.
     * @param point Point used by the operation.
     * @return The requested map To Parent.
     */
    SwPointF mapToParent(const SwPointF& point) const;
    /**
     * @brief Performs the `mapToParent` operation.
     * @param x Horizontal coordinate.
     * @return The requested map To Parent.
     */
    SwPointF mapToParent(double x, double y) const;
    /**
     * @brief Performs the `mapRectToParent` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map Rect To Parent.
     */
    SwRectF mapRectToParent(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapToParent` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map To Parent.
     */
    SwPolygonF mapToParent(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapToParent` operation.
     * @param polygon Value passed to the method.
     * @return The requested map To Parent.
     */
    SwPolygonF mapToParent(const SwPolygonF& polygon) const;

    /**
     * @brief Performs the `mapFromParent` operation.
     * @param point Point used by the operation.
     * @return The requested map From Parent.
     */
    SwPointF mapFromParent(const SwPointF& point) const;
    /**
     * @brief Performs the `mapFromParent` operation.
     * @param x Horizontal coordinate.
     * @return The requested map From Parent.
     */
    SwPointF mapFromParent(double x, double y) const;
    /**
     * @brief Performs the `mapRectFromParent` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map Rect From Parent.
     */
    SwRectF mapRectFromParent(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapFromParent` operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map From Parent.
     */
    SwPolygonF mapFromParent(const SwRectF& rect) const;
    /**
     * @brief Performs the `mapFromParent` operation.
     * @param polygon Value passed to the method.
     * @return The requested map From Parent.
     */
    SwPolygonF mapFromParent(const SwPolygonF& polygon) const;

    /**
     * @brief Performs the `mapToItem` operation.
     * @param item Item affected by the operation.
     * @param point Point used by the operation.
     * @return The requested map To Item.
     */
    SwPointF mapToItem(const SwGraphicsItem* item, const SwPointF& point) const;
    /**
     * @brief Performs the `mapToItem` operation.
     * @param item Item affected by the operation.
     * @param x Horizontal coordinate.
     * @return The requested map To Item.
     */
    SwPointF mapToItem(const SwGraphicsItem* item, double x, double y) const;
    /**
     * @brief Performs the `mapRectToItem` operation.
     * @param item Item affected by the operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map Rect To Item.
     */
    SwRectF mapRectToItem(const SwGraphicsItem* item, const SwRectF& rect) const;
    /**
     * @brief Performs the `mapToItem` operation.
     * @param item Item affected by the operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map To Item.
     */
    SwPolygonF mapToItem(const SwGraphicsItem* item, const SwRectF& rect) const;
    /**
     * @brief Performs the `mapToItem` operation.
     * @param item Item affected by the operation.
     * @param polygon Value passed to the method.
     * @return The requested map To Item.
     */
    SwPolygonF mapToItem(const SwGraphicsItem* item, const SwPolygonF& polygon) const;

    /**
     * @brief Performs the `mapFromItem` operation.
     * @param item Item affected by the operation.
     * @param point Point used by the operation.
     * @return The requested map From Item.
     */
    SwPointF mapFromItem(const SwGraphicsItem* item, const SwPointF& point) const;
    /**
     * @brief Performs the `mapFromItem` operation.
     * @param item Item affected by the operation.
     * @param x Horizontal coordinate.
     * @return The requested map From Item.
     */
    SwPointF mapFromItem(const SwGraphicsItem* item, double x, double y) const;
    /**
     * @brief Performs the `mapRectFromItem` operation.
     * @param item Item affected by the operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map Rect From Item.
     */
    SwRectF mapRectFromItem(const SwGraphicsItem* item, const SwRectF& rect) const;
    /**
     * @brief Performs the `mapFromItem` operation.
     * @param item Item affected by the operation.
     * @param rect Rectangle used by the operation.
     * @return The requested map From Item.
     */
    SwPolygonF mapFromItem(const SwGraphicsItem* item, const SwRectF& rect) const;
    /**
     * @brief Performs the `mapFromItem` operation.
     * @param item Item affected by the operation.
     * @param polygon Value passed to the method.
     * @return The requested map From Item.
     */
    SwPolygonF mapFromItem(const SwGraphicsItem* item, const SwPolygonF& polygon) const;

    // ===================================================================
    // Parent / children
    // ===================================================================
    /**
     * @brief Returns the current parent Item.
     * @return The current parent Item.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsItem* parentItem() const;

    /**
     * @brief Sets the parent Item.
     * @param parent Optional parent object that owns this instance.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setParentItem(SwGraphicsItem* parent);

    /**
     * @brief Returns the current top Level Item.
     * @return The current top Level Item.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsItem* topLevelItem() const;

    /**
     * @brief Returns the current child Items.
     * @return The current child Items.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const std::vector<SwGraphicsItem*>& childItems() const;

    // ===================================================================
    // Group
    // ===================================================================
    /**
     * @brief Returns the current group.
     * @return The current group.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsItemGroup* group() const;
    /**
     * @brief Sets the group.
     * @param group Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setGroup(SwGraphicsItemGroup* group);  // implemented after SwGraphicsItemGroup definition

    // ===================================================================
    // Scene
    // ===================================================================
    /**
     * @brief Returns the current scene.
     * @return The current scene.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsScene* scene() const;

    // ===================================================================
    // Geometry (pure virtual)
    // ===================================================================
    /**
     * @brief Returns the current bounding Rect.
     * @return The current bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual SwRectF boundingRect() const = 0;

    /**
     * @brief Returns the current shape.
     * @return The current shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    virtual SwPainterPath shape() const;  // implemented after SwPainterPath is available

    /**
     * @brief Performs the `contains` operation.
     * @param localPoint Value passed to the method.
     * @return The requested contains.
     */
    virtual bool contains(const SwPointF& localPoint) const;

    /**
     * @brief Returns whether the object reports obscured By.
     * @return The requested obscured By.
     *
     * @details This query does not modify the object state.
     */
    virtual bool isObscuredBy(const SwGraphicsItem* /*item*/) const;
    /**
     * @brief Returns whether the object reports obscured.
     * @return `true` when the object reports obscured; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isObscured(const SwRectF& /*rect*/ = SwRectF()) const;

    /**
     * @brief Returns the current scene Bounding Rect.
     * @return The current scene Bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF sceneBoundingRect() const;

    /**
     * @brief Returns the current children Bounding Rect.
     * @return The current children Bounding Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRectF childrenBoundingRect() const;

    /**
     * @brief Performs the `containsScenePoint` operation.
     * @param scenePoint Value passed to the method.
     * @return `true` when the object reports contains Scene Point; otherwise `false`.
     */
    bool containsScenePoint(const SwPointF& scenePoint) const;

    // ===================================================================
    // Collision detection
    // ===================================================================
    /**
     * @brief Performs the `collidesWithItem` operation.
     * @param other Value passed to the method.
     * @param mode Mode value that controls the operation.
     * @return The requested collides With Item.
     */
    virtual bool collidesWithItem(const SwGraphicsItem* other,
                                 SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape) const;

    /**
     * @brief Performs the `collidesWithPath` operation.
     * @param SwItemSelectionMode Value passed to the method.
     * @return The requested collides With Path.
     */
    virtual bool collidesWithPath(const SwPainterPath& /*path*/,
                                  SwItemSelectionMode /*mode*/ = SwItemSelectionMode::IntersectsItemShape) const;

    /**
     * @brief Performs the `collidingItems` operation.
     * @param mode Mode value that controls the operation.
     * @return The requested colliding Items.
     */
    std::vector<SwGraphicsItem*> collidingItems(
        SwItemSelectionMode mode = SwItemSelectionMode::IntersectsItemShape) const;  // needs scene

    /**
     * @brief Returns whether the object reports under Mouse.
     * @return `true` when the object reports under Mouse; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isUnderMouse() const;

    // ===================================================================
    // Cursor
    // ===================================================================
    /**
     * @brief Sets the cursor.
     * @param cursor Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCursor(CursorType cursor);
    /**
     * @brief Returns the current cursor.
     * @return The current cursor.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    CursorType cursor() const;
    /**
     * @brief Returns whether the object reports cursor.
     * @return `true` when the object reports cursor; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasCursor() const;
    /**
     * @brief Performs the `unsetCursor` operation.
     */
    void unsetCursor();

    // ===================================================================
    // Tooltip
    // ===================================================================
    /**
     * @brief Sets the tool Tip.
     * @param tip Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setToolTip(const SwString& tip);
    /**
     * @brief Returns the current tool Tip.
     * @return The current tool Tip.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString toolTip() const;

    // ===================================================================
    // Focus
    // ===================================================================
    /**
     * @brief Returns whether the object reports focus.
     * @return `true` when the object reports focus; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasFocus() const;
    /**
     * @brief Sets the focus.
     * @param reason Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFocus(SwFocusEvent::FocusReason reason = SwFocusEvent::OtherFocusReason);  // needs scene
    /**
     * @brief Clears the current object state.
     */
    void clearFocus();  // needs scene

    // ===================================================================
    // Hover
    // ===================================================================
    /**
     * @brief Sets the accept Hover Events.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAcceptHoverEvents(bool on);
    /**
     * @brief Returns the current accept Hover Events.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool acceptHoverEvents() const;

    // ===================================================================
    // Drop
    // ===================================================================
    /**
     * @brief Sets the accept Drops.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAcceptDrops(bool on);
    /**
     * @brief Returns the current accept Drops.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool acceptDrops() const;

    // ===================================================================
    // Grab
    // ===================================================================
    /**
     * @brief Performs the `grabMouse` operation.
     */
    void grabMouse();    // needs scene
    /**
     * @brief Performs the `ungrabMouse` operation.
     */
    void ungrabMouse();  // needs scene
    /**
     * @brief Performs the `grabKeyboard` operation.
     */
    void grabKeyboard();    // needs scene
    /**
     * @brief Performs the `ungrabKeyboard` operation.
     */
    void ungrabKeyboard();  // needs scene

    // ===================================================================
    // Touch / input method  (stubs for API completeness)
    // ===================================================================
    /**
     * @brief Sets the accept Touch Events.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAcceptTouchEvents(bool on);
    /**
     * @brief Returns the current accept Touch Events.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool acceptTouchEvents() const;
    /**
     * @brief Sets the filters Child Events.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFiltersChildEvents(bool on);
    /**
     * @brief Returns the current filters Child Events.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool filtersChildEvents() const;

    // ===================================================================
    // Panel / modality
    // ===================================================================
    /**
     * @brief Returns whether the object reports panel.
     * @param ItemIsPanel Value passed to the method.
     * @return `true` when the object reports panel; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isPanel() const;
    /**
     * @brief Returns the current panel Modality.
     * @return The current panel Modality.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsPanelModality panelModality() const;
    /**
     * @brief Sets the panel Modality.
     * @param modality Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPanelModality(SwGraphicsPanelModality modality);
    /**
     * @brief Returns whether the object reports blocked By Modal Panel.
     * @return `true` when the object reports blocked By Modal Panel; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isBlockedByModalPanel(SwGraphicsItem** /*blockingPanel*/ = nullptr) const;

    /**
     * @brief Returns whether the object reports active.
     * @return `true` when the object reports active; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isActive() const;
    /**
     * @brief Sets the active.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setActive(bool on);

    /**
     * @brief Returns the current panel.
     * @return The current panel.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsItem* panel() const;

    /**
     * @brief Performs the `window` operation.
     * @return The requested window.
     */
    SwGraphicsItem* window() const;

    /**
     * @brief Returns the current focus Proxy.
     * @return The current focus Proxy.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsItem* focusProxy() const;
    /**
     * @brief Sets the focus Proxy.
     * @param item Item affected by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFocusProxy(SwGraphicsItem* item);
    /**
     * @brief Returns the current focus Item.
     * @return The current focus Item.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsItem* focusItem() const;

    // ===================================================================
    // Cache mode
    // ===================================================================
    /**
     * @brief Returns the current cache Mode.
     * @return The current cache Mode.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwGraphicsCacheMode cacheMode() const;
    /**
     * @brief Sets the cache Mode.
     * @param mode Mode value that controls the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCacheMode(SwGraphicsCacheMode mode, const SwSize& /*logicalCacheSize*/ = {0, 0});

    // ===================================================================
    // Custom data
    // ===================================================================
    /**
     * @brief Sets the data.
     * @param key Value passed to the method.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setData(int key, const SwString& value);
    /**
     * @brief Performs the `data` operation.
     * @param key Value passed to the method.
     * @return The requested data.
     */
    SwString data(int key) const;

    // ===================================================================
    // Update / geometry change
    // ===================================================================
    /**
     * @brief Updates the update managed by the object.
     */
    void update(const SwRectF& /*rect*/ = SwRectF());
    /**
     * @brief Performs the `prepareGeometryChange` operation.
     */
    void prepareGeometryChange();

    // ===================================================================
    // Scene event filter
    // ===================================================================
    /**
     * @brief Performs the `installSceneEventFilter` operation.
     * @param filterItem Value passed to the method.
     */
    void installSceneEventFilter(SwGraphicsItem* filterItem);
    /**
     * @brief Removes the specified scene Event Filter.
     * @param filterItem Value passed to the method.
     */
    void removeSceneEventFilter(SwGraphicsItem* filterItem);

    // ===================================================================
    // Painting (pure virtual)
    // ===================================================================
    /**
     * @brief Performs the `paint` operation.
     * @param painter Value passed to the method.
     * @param ctx Value passed to the method.
     * @return The requested paint.
     */
    virtual void paint(SwPainter* painter, const SwGraphicsRenderContext& ctx) = 0;

    // ===================================================================
    // ensureVisible
    // ===================================================================
    /**
     * @brief Performs the `ensureVisible` operation.
     * @param rect Rectangle used by the operation.
     * @param xmargin Value passed to the method.
     * @param ymargin Value passed to the method.
     */
    void ensureVisible(const SwRectF& rect = SwRectF(), int xmargin = 50, int ymargin = 50);  // needs scene/view

protected:
    friend class SwGraphicsScene;
    friend class SwGraphicsView;
    friend class SwGraphicsItemGroup;

    // --- Internal setters used by SwGraphicsScene ---
    /**
     * @brief Sets the scene.
     * @param scene Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setScene_(SwGraphicsScene* scene);
    /**
     * @brief Sets the change Callback.
     * @param m_changeCallback Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setChangeCallback_(std::function<void()> cb);
    /**
     * @brief Sets the is Under Mouse.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setIsUnderMouse_(bool on);
    /**
     * @brief Sets the has Focus.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHasFocus_(bool on);

    // --- Event handlers (virtual, override in subclasses) ---
    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @return The requested mouse Press Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mousePressEvent(SwGraphicsSceneMouseEvent* event);
    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @return The requested mouse Move Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mouseMoveEvent(SwGraphicsSceneMouseEvent* event);
    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @return The requested mouse Release Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mouseReleaseEvent(SwGraphicsSceneMouseEvent* event);
    /**
     * @brief Handles the mouse Double Click Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested mouse Double Click Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void mouseDoubleClickEvent(SwGraphicsSceneMouseEvent* event);

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @return The requested wheel Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void wheelEvent(SwGraphicsSceneWheelEvent* event);

    /**
     * @brief Handles the hover Enter Event forwarded by the framework.
     * @return The requested hover Enter Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void hoverEnterEvent(SwGraphicsSceneHoverEvent* event);
    /**
     * @brief Handles the hover Move Event forwarded by the framework.
     * @return The requested hover Move Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void hoverMoveEvent(SwGraphicsSceneHoverEvent* event);
    /**
     * @brief Handles the hover Leave Event forwarded by the framework.
     * @return The requested hover Leave Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void hoverLeaveEvent(SwGraphicsSceneHoverEvent* event);

    /**
     * @brief Handles the key Press Event forwarded by the framework.
     * @return The requested key Press Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void keyPressEvent(KeyEvent* event);
    virtual void keyPressEvent(SwGraphicsSceneKeyEvent* event);
    /**
     * @brief Handles the key Release Event forwarded by the framework.
     * @return The requested key Release Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void keyReleaseEvent(KeyEvent* event);
    virtual void keyReleaseEvent(SwGraphicsSceneKeyEvent* event);

    /**
     * @brief Handles the focus In Event forwarded by the framework.
     * @return The requested focus In Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void focusInEvent(SwFocusEvent* event);
    /**
     * @brief Handles the focus Out Event forwarded by the framework.
     * @return The requested focus Out Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void focusOutEvent(SwFocusEvent* event);

    /**
     * @brief Handles the context Menu Event forwarded by the framework.
     * @return The requested context Menu Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void contextMenuEvent(SwGraphicsSceneContextMenuEvent* event);

    /**
     * @brief Handles the drag Enter Event forwarded by the framework.
     * @return The requested drag Enter Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void dragEnterEvent(SwGraphicsSceneDragDropEvent* event);
    /**
     * @brief Handles the drag Move Event forwarded by the framework.
     * @return The requested drag Move Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void dragMoveEvent(SwGraphicsSceneDragDropEvent* event);
    /**
     * @brief Handles the drag Leave Event forwarded by the framework.
     * @return The requested drag Leave Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void dragLeaveEvent(SwGraphicsSceneDragDropEvent* event);
    /**
     * @brief Handles the drop Event forwarded by the framework.
     * @return The requested drop Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual void dropEvent(SwGraphicsSceneDragDropEvent* event);

    /**
     * @brief Performs the `sceneEventFilter` operation.
     * @return The requested scene Event Filter.
     */
    virtual bool sceneEventFilter(SwGraphicsItem* /*watched*/, SwGraphicsSceneEvent* /*event*/);
    /**
     * @brief Handles the scene Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     * @return The requested scene Event.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    virtual bool sceneEvent(SwGraphicsSceneEvent* event);

    // --- Item change notification (override in subclass) ---
    /**
     * @brief Performs the `itemChange` operation.
     * @param SwGraphicsItemChange Value passed to the method.
     * @return The requested item Change.
     */
    virtual void itemChange(SwGraphicsItemChange /*change*/, const SwPointF& /*value*/);

private:
    void notifyChanged_();

    SwTransform itemTransform_() const;

private:
    // What the class keeps (SwGraphicsItem_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;

protected:
    // Reserved for the virtual functions a later 1.x adds (docs/BINARY_COMPATIBILITY.md): a class
    // that reimplements it handles its own ids and passes the others to its base.
    virtual void virtual_hook(int id, void* data);
};

#pragma pop_macro("FocusOut")
#pragma pop_macro("FocusIn")
