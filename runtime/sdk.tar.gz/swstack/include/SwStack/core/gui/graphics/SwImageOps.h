#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImageOps.h
 * @ingroup core_graphics
 * @brief Declares the closed image-operation vocabulary and SwImageRecipe in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the image operation interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwImageFilter, SwImageBorder, SwImageBlend,
 * SwImageOpKind, SwImageRemapMesh, SwImageOp and SwImageRecipe.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief The closed vocabulary of image operations understood by every backend.
 *
 * Conventions are fixed here and adapted by backends, never by callers:
 * - scale / warp sample with pixel centres at +0.5;
 * - `Area` is box filtering when downscaling and equals `Linear` when upscaling;
 * - YUV <-> RGB uses BT.601 limited range when the colour space is Undefined and the tagged
 *   space (limited range) otherwise;
 * - rounding is `(x + 128) >> 8` style with clamping;
 * - `Composite` alpha is straight (non-premultiplied) BGRA.
 *
 * `Tile` is not an op: `SwImage::tiles()` produces zero-copy views instead.
 */

#include "SwPixelFormat.h"
#include "Sw.h"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

class SwImageStorage;
class SwImage;

/**
 * @brief Interpolation filter of scale / warp / remap ops.
 */
enum class SwImageFilter {
    Nearest,
    Linear,
    Area,
    Cubic
};

/**
 * @brief Out-of-range sampling rule of warp / remap ops.
 */
enum class SwImageBorder {
    Clamp,
    Constant,
    Reflect,
    Wrap
};

/**
 * @brief Blend mode of the Composite op.
 */
enum class SwImageBlend {
    Copy,
    SourceOver
};

/**
 * @brief Kind of an SwImageOp.
 */
enum class SwImageOpKind {
    Convert,
    Crop,
    Scale,
    Flip,
    Rotate,
    WarpAffine,
    WarpPerspective,
    Remap,
    Composite
};

/**
 * @brief Number of enumerators in SwImageOpKind (for bit masks).
 */
static const int kSwImageOpKindCount = static_cast<int>(SwImageOpKind::Composite) + 1;

/**
 * @brief Returns a stable name for an op kind.
 * @param kind Op kind.
 * @return Static string such as "Scale".
 */
inline const char* SwImageOpKindName(SwImageOpKind kind) {
    switch (kind) {
    case SwImageOpKind::Convert: return "Convert";
    case SwImageOpKind::Crop: return "Crop";
    case SwImageOpKind::Scale: return "Scale";
    case SwImageOpKind::Flip: return "Flip";
    case SwImageOpKind::Rotate: return "Rotate";
    case SwImageOpKind::WarpAffine: return "WarpAffine";
    case SwImageOpKind::WarpPerspective: return "WarpPerspective";
    case SwImageOpKind::Remap: return "Remap";
    case SwImageOpKind::Composite: return "Composite";
    }
    return "Unknown";
}

/**
 * @brief Dense per-destination-pixel lookup table for the Remap op.
 *
 * `mapX[y * width + x]` / `mapY[...]` give the source coordinates (pixel centres at +0.5)
 * sampled for destination pixel (x, y).
 */
struct SW_GUI_EXPORT SwImageRemapMesh {
    int width{0};
    int height{0};
    std::vector<float> mapX;
    std::vector<float> mapY;

    /**
     * @brief Returns whether the mesh is consistent.
     * @return `true` when both tables hold width * height entries.
     */
    bool isValid() const;
};

/**
 * @brief One operation of a lazy op chain.
 *
 * Plain data except for the two shared_ptr members (`mesh`, `source`). Only the fields relevant
 * to `kind` are meaningful; the static constructors fill them.
 */
struct SW_GUI_EXPORT SwImageOp {
    SwImageOpKind kind;

    // Convert
    SwPixelFormat format{SwPixelFormat::Unknown};
    SwColorSpace colorSpace{SwColorSpace::Undefined};

    // Crop (in source pixels of the op input)
    SwRect rect{0, 0, 0, 0};

    // Scale / warp output size and filter
    int width{0};
    int height{0};
    SwImageFilter filter{SwImageFilter::Linear};

    // Flip
    bool horizontal{false};
    bool vertical{false};

    // Rotate (pixels are physically rotated; this is not the orientation hint)
    SwImageRotation rotation{SwImageRotation::Identity};

    // WarpAffine (matrix[0..5]) / WarpPerspective (matrix[0..8]); mapping is DESTINATION -> SOURCE,
    // pixel centres at +0.5, row-major. border + borderValue (BGRA packed) for out-of-range samples.
    double matrix[9];
    SwImageBorder border{SwImageBorder::Clamp};
    std::uint32_t borderValue{0};

    // Remap
    std::shared_ptr<const SwImageRemapMesh> mesh;

    // Composite: draw `source` (already materialized storage) over the op input at dstRect using srcRect
    std::shared_ptr<const SwImageStorage> source;
    SwRect srcRect{0, 0, 0, 0};
    SwRect dstRect{0, 0, 0, 0};
    float alpha{1.0f};
    SwImageBlend blend{SwImageBlend::SourceOver};

    /**
     * @brief Constructs a Convert op with a zeroed matrix.
     */
    SwImageOp();

    /**
     * @brief Builds a Convert op.
     * @param fmt Target pixel format.
     * @param cs Colour space tag of the result (Undefined keeps the input tag).
     * @return The op.
     */
    static SwImageOp convert(SwPixelFormat fmt, SwColorSpace cs = SwColorSpace::Undefined);

    /**
     * @brief Builds a Crop op.
     * @param r Rectangle in pixels of the op input.
     * @return The op.
     */
    static SwImageOp crop(const SwRect& r);

    /**
     * @brief Builds a Scale op.
     * @param w Output width.
     * @param h Output height.
     * @param f Interpolation filter.
     * @return The op.
     */
    static SwImageOp scale(int w, int h, SwImageFilter f = SwImageFilter::Linear);

    /**
     * @brief Builds a Flip op.
     * @param h Mirror horizontally.
     * @param v Mirror vertically.
     * @return The op.
     */
    static SwImageOp flip(bool h, bool v);

    /**
     * @brief Builds a Rotate op (physical rotation of the pixels, clockwise).
     * @param rot Rotation.
     * @return The op.
     */
    static SwImageOp rotate(SwImageRotation rot);

    /**
     * @brief Builds a WarpAffine op.
     * @param m6 Row-major 2x3 destination -> source matrix.
     * @param w Output width.
     * @param h Output height.
     * @param f Interpolation filter.
     * @param b Border rule.
     * @param bv Border colour (packed BGRA) for SwImageBorder::Constant.
     * @return The op.
     */
    static SwImageOp warpAffine(const double m6[6], int w, int h,
                                SwImageFilter f = SwImageFilter::Linear,
                                SwImageBorder b = SwImageBorder::Clamp,
                                std::uint32_t bv = 0);

    /**
     * @brief Builds a WarpPerspective op.
     * @param m9 Row-major 3x3 destination -> source homography.
     * @param w Output width.
     * @param h Output height.
     * @param f Interpolation filter.
     * @param b Border rule.
     * @param bv Border colour (packed BGRA) for SwImageBorder::Constant.
     * @return The op.
     */
    static SwImageOp warpPerspective(const double m9[9], int w, int h,
                                     SwImageFilter f = SwImageFilter::Linear,
                                     SwImageBorder b = SwImageBorder::Clamp,
                                     std::uint32_t bv = 0);

    /**
     * @brief Builds a Remap op.
     * @param m Lookup mesh (its size is the output size).
     * @param f Interpolation filter.
     * @param b Border rule.
     * @return The op.
     */
    static SwImageOp remap(std::shared_ptr<const SwImageRemapMesh> m,
                           SwImageFilter f = SwImageFilter::Linear,
                           SwImageBorder b = SwImageBorder::Clamp);

    /**
     * @brief Builds a Composite op.
     * @param src Materialized storage drawn over the op input.
     * @param srcR Rectangle of `src` to draw (empty = whole source).
     * @param dstR Destination rectangle in the op input (size differing from srcR scales).
     * @param a Straight alpha multiplier.
     * @param bl Blend mode.
     * @return The op.
     */
    static SwImageOp composite(std::shared_ptr<const SwImageStorage> src, const SwRect& srcR,
                               const SwRect& dstR, float a = 1.0f,
                               SwImageBlend bl = SwImageBlend::SourceOver);

    /**
     * @brief Field-wise equality (shared_ptr members compare by pointer).
     * @param o Other op.
     * @return `true` when equal.
     */
    bool operator==(const SwImageOp& o) const;

    /**
     * @brief Negation of operator==.
     * @param o Other op.
     * @return `true` when different.
     */
    bool operator!=(const SwImageOp& o) const;

private:
    static bool rectEquals_(const SwRect& a, const SwRect& b);
};

/**
 * @brief Computes the layout of the result of applying `op` to an image with layout `input`.
 *
 * Pure geometry: the result is always the canonical layout (SwDescribeImageLayout) of the
 * output format and size. Used by SwImage::layout() and by the planner.
 *
 * @param input Layout of the op input.
 * @param op Operation.
 * @return Layout of the op output.
 */
inline SwImageLayout SwImageOpResultLayout(const SwImageLayout& input, const SwImageOp& op) {
    switch (op.kind) {
    case SwImageOpKind::Convert:
        return SwDescribeImageLayout(op.format, input.width, input.height);
    case SwImageOpKind::Crop:
        return SwDescribeImageLayout(input.format, op.rect.width, op.rect.height);
    case SwImageOpKind::Scale:
    case SwImageOpKind::WarpAffine:
    case SwImageOpKind::WarpPerspective:
        return SwDescribeImageLayout(input.format, op.width, op.height);
    case SwImageOpKind::Flip:
        return SwDescribeImageLayout(input.format, input.width, input.height);
    case SwImageOpKind::Rotate:
        if (SwImageRotationSwapsAxes(op.rotation)) {
            return SwDescribeImageLayout(input.format, input.height, input.width);
        }
        return SwDescribeImageLayout(input.format, input.width, input.height);
    case SwImageOpKind::Remap:
        if (op.mesh) {
            return SwDescribeImageLayout(input.format, op.mesh->width, op.mesh->height);
        }
        return SwDescribeImageLayout(input.format, op.width, op.height);
    case SwImageOpKind::Composite:
        return SwDescribeImageLayout(input.format, input.width, input.height);
    }
    return SwDescribeImageLayout(input.format, input.width, input.height);
}

/**
 * @brief Returns whether a rectangle origin is aligned to the chroma subsampling of every plane.
 *
 * A crop / view whose origin is not aligned cannot alias the source bytes (and, for the packed
 * YUY2 macropixel format, would swap the U / V samples), so it must be materialized by a copy.
 *
 * @param format Pixel format.
 * @param r Rectangle in pixels.
 * @return `true` when `r.x` / `r.y` are multiples of every plane's subsampling factor.
 */
inline bool SwImageRectIsPlaneAligned(SwPixelFormat format, const SwRect& r) {
    if (r.width <= 0 || r.height <= 0 || r.x < 0 || r.y < 0) {
        return false;
    }
    const int planes = SwPixelFormatPlaneCount(format);
    for (int p = 0; p < planes; ++p) {
        int sx = 0, sy = 0, bps = 0;
        SwPixelFormatPlaneGeometry(format, p, sx, sy, bps);
        if ((r.x & ((1 << sx) - 1)) != 0 || (r.y & ((1 << sy) - 1)) != 0) {
            return false;
        }
    }
    if (format == SwPixelFormat::YUY2 && (r.x & 1) != 0) {
        return false;
    }
    return true;
}

/**
 * @brief An op chain without a source; a value type.
 *
 * Used as the Recipe property of SwImageProcessor and by SwImage::applied().
 */
class SW_GUI_EXPORT SwImageRecipe {
public:
    /**
     * @brief Constructs an empty recipe.
     */
    SwImageRecipe();

    /**
     * @brief Appends a Convert op.
     * @param fmt Target pixel format.
     * @param cs Colour space tag.
     * @return `*this` for chaining.
     */
    SwImageRecipe& converted(SwPixelFormat fmt, SwColorSpace cs = SwColorSpace::Undefined);

    /**
     * @brief Appends a Crop op.
     * @param r Rectangle in input pixels.
     * @return `*this` for chaining.
     */
    SwImageRecipe& cropped(const SwRect& r);

    /**
     * @brief Appends a Scale op.
     * @param w Output width.
     * @param h Output height.
     * @param f Interpolation filter.
     * @return `*this` for chaining.
     */
    SwImageRecipe& scaled(int w, int h, SwImageFilter f = SwImageFilter::Linear);

    /**
     * @brief Appends a Flip op.
     * @param h Mirror horizontally.
     * @param v Mirror vertically.
     * @return `*this` for chaining.
     */
    SwImageRecipe& flipped(bool h, bool v);

    /**
     * @brief Appends a Rotate op.
     * @param rot Rotation.
     * @return `*this` for chaining.
     */
    SwImageRecipe& rotated(SwImageRotation rot);

    /**
     * @brief Appends a WarpAffine op.
     * @param m Row-major 2x3 destination -> source matrix.
     * @param w Output width.
     * @param h Output height.
     * @param f Interpolation filter.
     * @param b Border rule.
     * @param bv Border colour (packed BGRA).
     * @return `*this` for chaining.
     */
    SwImageRecipe& warpedAffine(const double m[6], int w, int h,
                                SwImageFilter f = SwImageFilter::Linear,
                                SwImageBorder b = SwImageBorder::Clamp,
                                std::uint32_t bv = 0);

    /**
     * @brief Appends a WarpPerspective op.
     * @param m Row-major 3x3 destination -> source homography.
     * @param w Output width.
     * @param h Output height.
     * @param f Interpolation filter.
     * @param b Border rule.
     * @param bv Border colour (packed BGRA).
     * @return `*this` for chaining.
     */
    SwImageRecipe& warpedPerspective(const double m[9], int w, int h,
                                     SwImageFilter f = SwImageFilter::Linear,
                                     SwImageBorder b = SwImageBorder::Clamp,
                                     std::uint32_t bv = 0);

    /**
     * @brief Appends a Remap op.
     * @param mesh Lookup mesh.
     * @param f Interpolation filter.
     * @param b Border rule.
     * @return `*this` for chaining.
     */
    SwImageRecipe& remapped(std::shared_ptr<const SwImageRemapMesh> mesh,
                            SwImageFilter f = SwImageFilter::Linear,
                            SwImageBorder b = SwImageBorder::Clamp);

    /**
     * @brief Appends a Composite op drawing `src` at `dst`. Defined at the end of SwImage.h.
     * @param src Image drawn over the input (materialized before being captured).
     * @param dst Destination rectangle.
     * @param alpha Straight alpha multiplier.
     * @param blend Blend mode.
     * @return `*this` for chaining.
     */
    SwImageRecipe& composited(const SwImage& src, const SwRect& dst, float alpha = 1.0f,
                              SwImageBlend blend = SwImageBlend::SourceOver);

    /**
     * @brief Appends an already built op.
     * @param op Operation.
     * @return `*this` for chaining.
     */
    SwImageRecipe& append(const SwImageOp& op);

    /**
     * @brief Returns the ops in order.
     * @return The op chain.
     */
    const std::vector<SwImageOp>& ops() const;

    /**
     * @brief Returns whether the recipe holds no op.
     * @return `true` when empty.
     */
    bool isEmpty() const;

    /**
     * @brief Removes every op.
     */
    void clear();

    /**
     * @brief Element-wise equality.
     * @param o Other recipe.
     * @return `true` when both chains are equal.
     */
    bool operator==(const SwImageRecipe& o) const;

    /**
     * @brief Negation of operator==.
     * @param o Other recipe.
     * @return `true` when different.
     */
    bool operator!=(const SwImageRecipe& o) const;

private:
public:
    ~SwImageRecipe();
public:
    SwImageRecipe(const SwImageRecipe& other);
    SwImageRecipe& operator=(const SwImageRecipe& other);
private:
    // What the class keeps (SwImageOps_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
