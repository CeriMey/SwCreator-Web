#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/graphics/SwGraphicsItems.h"

struct SwGraphicsEllipseItem::Data {
    SwRectF m_rect{};
    SwPen m_pen{};
    SwBrush m_brush{};
    int m_startAngle{0};
    int m_spanAngle{5760}; // 360 * 16 (Qt convention)
};
struct SwGraphicsItemGroup::Data {
    std::vector<SwGraphicsItem*> m_groupItems;
};
struct SwGraphicsLineItem::Data {
    SwLineF m_line{};
    SwPen m_pen{};
};
struct SwGraphicsPathItem::Data {
    SwPainterPath m_path{};
    SwPen m_pen{};
    SwBrush m_brush{};
};
struct SwGraphicsPixmapItem::Data {
    SwPixmap m_pixmap{};
    SwPointF m_offset{};
    ShapeMode m_shapeMode{MaskShape};
    int m_transformationMode{0}; // 0 = FastTransformation, 1 = SmoothTransformation
};
struct SwGraphicsPolygonItem::Data {
    SwPolygonF m_polygon{};
    SwPen m_pen{};
    SwBrush m_brush{};
    SwPainterPath::FillRule m_fillRule{SwPainterPath::OddEvenFill};
};
struct SwGraphicsProxyWidget::Data {
    SwWidget* m_widget{nullptr};
    int m_baseWidth{0};
    int m_baseHeight{0};
};
struct SwGraphicsRectItem::Data {
    SwRectF m_rect{};
    SwPen m_pen{};
    SwBrush m_brush{};
};
struct SwGraphicsSimpleTextItem::Data {
    SwString m_text{};
    SwFont m_font{};
    SwPen m_pen{};
    SwBrush m_brush{};
};
struct SwGraphicsTextItem::Data {
    SwString m_text{};
    SwString m_html{};
    SwColor m_color{30, 30, 30};
    SwFont m_font{};
    double m_textWidth{-1.0};
    int m_textInteractionFlags{0};
    bool m_openExternalLinks{false};
    bool m_tabChangesFocus{false};
};
