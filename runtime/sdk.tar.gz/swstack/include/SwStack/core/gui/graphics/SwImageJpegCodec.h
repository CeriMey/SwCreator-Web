/**
 * @file src/core/gui/graphics/SwImageJpegCodec.h
 * @ingroup core_graphics
 * @brief Declares the built-in baseline JPEG codec in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the JPEG codec interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwImageJpegCodec.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Baseline sequential DCT JPEG decoder and encoder (CPU, no dependencies).
 *
 * Decoder: SOF0 / SOF1 with 8-bit precision, 1 or 3 components, Huffman tables (DHT), quantization
 * tables (DQT, 8 or 16-bit), restart intervals (DRI), interleaved and non-interleaved baseline
 * scans, sampling factors 1x1 / 2x1 / 1x2 / 2x2 (4:4:4, 4:2:2, 4:4:0, 4:2:0). JFIF / EXIF / other
 * APPn and COM segments are skipped (Adobe APP14 is honoured for RGB-coded images). Progressive,
 * lossless, hierarchical and arithmetic-coded frames are rejected with an explicit error. The
 * inverse DCT is the separable integer Loeffler-Ligtenberg-Moschytz variant (libjpeg "islow",
 * 13-bit constants) evaluated in 64-bit so garbage coefficients never overflow, and YCbCr → RGB
 * follows the JFIF full-range formula. Output is BGRA32 (Gray8 for single-component images).
 * Hardened: every length and dimension is validated, no allocation exceeds 1 GiB, truncated scans
 * are rejected, random bytes never trigger undefined behaviour.
 *
 * Encoder: baseline 4:2:0 YCbCr (or single-component gray for Gray8 sources) with the Annex K
 * quantization tables scaled by quality (IJG scaling), the standard Annex K Huffman tables,
 * no restart interval, JFIF APP0 header. Any source is accepted through the BGRA32 legacy view.
 *
 * Include-order note: no `#pragma once`; "SwImageCodec.h" is included first, outside the body
 * guard (see SwImageCodec.h).
 */

#include "SwImageCodec.h"

#ifndef SW_IMAGE_JPEG_CODEC_H_BODY
#define SW_IMAGE_JPEG_CODEC_H_BODY

#include "../../SwStackExport.h"

#include "SwString.h"
#include "SwByteArray.h"
#include "SwDebug.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

static constexpr const char* kSwLogCategory_SwImageJpegCodec = "sw.gui.swimagejpegcodec";

/**
 * @brief Built-in baseline JPEG codec (priority 0).
 */
class SW_GUI_EXPORT SwImageJpegCodec : public SwImageCodec {
public:
    /**
     * @brief Returns "jpeg".
     * @return The id.
     */
    const SwString& id() const override;

    /**
     * @brief Built-in priority.
     * @return 0.
     */
    int priority() const override;

    /**
     * @brief Sniffs the SOI marker followed by another marker prefix (FF D8 FF).
     * @param magic Stream start.
     * @param n Bytes available.
     * @return `true` for a JPEG stream.
     */
    bool canDecode(const std::uint8_t* magic, std::size_t n) const override;

    /**
     * @brief Encodes "jpeg" only.
     * @param format Normalized format name.
     * @return `true` for "jpeg".
     */
    bool canEncode(const SwString& format) const override;

    /**
     * @brief Decodes a baseline JPEG into BGRA32 (Gray8 for single-component streams).
     * @param bytes Encoded bytes.
     * @param size Byte count.
     * @param out Receives the image.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool decode(const std::uint8_t* bytes, std::size_t size, SwImage& out, SwString* error) override;

    /**
     * @brief Encodes the image as baseline 4:2:0 JPEG (gray for Gray8 sources).
     * @param image Image to encode.
     * @param format Normalized format name ("jpeg").
     * @param options `jpegQuality` (1..100) selects the quantization scaling.
     * @param out Receives the file bytes.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    bool encode(const SwImage& image, const SwString& format, const SwImageCodecOptions& options,
                SwByteArray& out, SwString* error) override;

private:
    static const std::uint64_t kMaxBytes_ = static_cast<std::uint64_t>(1) << 30;   // 1 GiB
    static const std::uint64_t kMaxPixels_ = static_cast<std::uint64_t>(1) << 28;  // 268 Mpixels

    // ---------------------------------------------------------------------------------------
    // Shared tables
    // ---------------------------------------------------------------------------------------

    /** @brief Natural (row-major) index of every zig-zag position. */
    static const std::uint8_t* zigzag_();

    static std::uint8_t clamp255_(std::int64_t v);

    static std::uint16_t readU16_(const std::uint8_t* p);

    /**
     * @brief Huffman table shared by the decoder (lookup) and the encoder (code/size per symbol).
     */
    struct SW_GUI_EXPORT HuffTable_ {
        bool present{false};
        std::uint8_t bits[17];
        std::uint8_t vals[256];
        int count{0};
        // decoder side
        int mincode[17];
        int maxcode[18];
        int valptr[17];
        std::uint16_t look[512];   // (len << 8) | value for codes up to 9 bits, 0 = not resolved
        // encoder side
        std::uint16_t ehufco[256];
        std::uint8_t ehufsi[256];

        HuffTable_();

        /**
         * @brief Builds the tables from BITS / HUFFVAL (ITU-T T.81 Annex C).
         * @return `false` when the code lengths are not a valid prefix code.
         */
        bool build();

        void setStandard(const std::uint8_t* b, const std::uint8_t* v, int n);
    };

    struct SW_GUI_EXPORT QuantTable_ {
        bool present{false};
        std::uint16_t q[64];   // zig-zag order
        QuantTable_();
    };

    /**
     * @brief Separable integer IDCT (libjpeg jidctint, CONST_BITS = 13, PASS1_BITS = 2) in 64-bit.
     * @param in Dequantized coefficients in natural order.
     * @param dst Top-left sample of the destination block.
     * @param stride Destination row stride in bytes.
     */
    static void idct_(const std::int64_t* in, std::uint8_t* dst, std::size_t stride);

    // ---------------------------------------------------------------------------------------
    // Decoder
    // ---------------------------------------------------------------------------------------

    class SW_GUI_EXPORT Decoder_ {
    public:
        Decoder_(const std::uint8_t* in, std::size_t n);

        bool run(std::string& err);

        bool produce(SwImage& out, std::string& err) const;

    private:
        struct Component_ {
            int id{0};
            int h{1};
            int v{1};
            int tq{0};
            int dcTable{0};
            int acTable{0};
            int dcPred{0};
            bool scanned{false};
            std::size_t planeW{0};
            std::size_t planeH{0};
            std::vector<std::uint8_t> plane;
        };

        bool allScanned_() const;

        bool parseSof_(const std::uint8_t* seg, std::size_t segLen, std::string& err);

        bool parseDht_(const std::uint8_t* seg, std::size_t segLen, std::string& err);

        bool parseDqt_(const std::uint8_t* seg, std::size_t segLen, std::string& err);

        // --- entropy-coded segment reader (MSB first, FF00 unstuffing, stops at markers) ---

        void fill_();

        void need_(int k);

        bool consume_(int k);

        bool bits_(int k, int& v);

        bool receiveExtend_(int s, int& v);

        bool decodeHuff_(const HuffTable_& t, int& v);

        void resetReader_();

        bool decodeBlock_(Component_& c, const HuffTable_& dc, const HuffTable_& ac, const QuantTable_& q,
                          std::uint8_t* dst, std::size_t stride, std::string& err);

        bool restart_(std::string& err);

        bool decodeScan_(const std::uint8_t* seg, std::size_t segLen, std::string& err);

        const std::uint8_t* m_in;
        std::size_t m_n;
        std::size_t m_pos;
        std::uint32_t m_buf;
        int m_cnt;
        int m_padBits;
        bool m_markerHit;

        int m_width;
        int m_height;
        int m_ncomp;
        int m_hmax;
        int m_vmax;
        int m_mcusX;
        int m_mcusY;
        int m_restartInterval;
        int m_adobeTransform;
        bool m_haveFrame;
        Component_ m_comps[4];
        HuffTable_ m_dc[4];
        HuffTable_ m_ac[4];
        QuantTable_ m_quant[4];
    };

    // ---------------------------------------------------------------------------------------
    // Encoder
    // ---------------------------------------------------------------------------------------

    class SW_GUI_EXPORT Encoder_ {
    public:
        Encoder_(SwByteArray& out, const std::uint8_t* src, std::size_t srcStride, int width, int height, bool gray, int quality);

        void run();

    private:
        void writeByte_(std::uint8_t b);
        void writeU16_(std::uint16_t v);
        void writeMarker_(std::uint8_t m);

        void writeDqt_(int id, const std::uint8_t* natural);

        void writeDht_(int tcth, const HuffTable_& t);

        void putBits_(std::uint32_t value, int size);

        void flushBits_();

        static int category_(int v);

        void encodeBlock_(const int* zz, int& pred, const HuffTable_& dc, const HuffTable_& ac);

        /** @brief Forward DCT + quantization of an 8x8 sample block, output in zig-zag order. */
        void transform_(const std::uint8_t* block, const std::uint8_t* q, int* zz) const;

        void encodeGray_();

        void encodeColor_();

        SwByteArray& m_out;
        const std::uint8_t* m_src;
        std::size_t m_srcStride;
        int m_width;
        int m_height;
        bool m_gray;
        std::uint32_t m_buf;
        int m_cnt;
        std::uint8_t m_qLum[64];
        std::uint8_t m_qChr[64];
        HuffTable_ m_dcLum;
        HuffTable_ m_dcChr;
        HuffTable_ m_acLum;
        HuffTable_ m_acChr;
        double m_cos[8][8];
    };
};

#endif // SW_IMAGE_JPEG_CODEC_H_BODY
