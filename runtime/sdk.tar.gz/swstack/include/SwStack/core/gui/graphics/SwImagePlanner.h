#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/gui/graphics/SwImagePlanner.h
 * @ingroup core_graphics
 * @brief Declares the op-chain planner of the image pipeline in the CoreSw graphics layer.
 *
 * This header belongs to the CoreSw graphics layer. It provides geometry types, painting
 * primitives, images, scene-graph helpers, and rendering support consumed by widgets and views.
 *
 * Within that layer, this file focuses on the image planner interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwImagePlanStep, SwImagePlan and SwImagePlanner.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * Graphics-facing declarations here define the data flow from high-level UI state to lower-level
 * rendering backends.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

/**
 * @file
 * @brief Fuses / segments an op chain into backend steps and transfers.
 *
 * `simplify` is pure code (no backend involved): it folds the view into a leading Crop, merges
 * consecutive Crops, drops no-op Converts, cancels Flip pairs, merges Rotates (mod 360) and merges
 * consecutive Nearest / Linear Scales when the intermediate is not smaller than the final size.
 *
 * `plan` is greedy: for the current residency choose the highest-priority available backend that
 * accepts the next op; extend the segment while the same backend supports the following ops and
 * fuses chains; when nothing accepts the op at this residency insert a transfer (download to CPU,
 * or upload to the highest-priority backend that supports it); finish with a transfer to the
 * preferred residency when needed. A forced backend restricts op steps to that backend; transfers
 * may still use whichever backend owns the residency.
 *
 * `execute` walks a plan. It is what SwImage::materialize() runs after simplify + plan.
 */

#include "SwImageBackend.h"
#include "SwImageOps.h"
#include "SwImageStorage.h"
#include "SwPixelFormat.h"
#include "SwString.h"
#include "SwDebug.h"
#include "Sw.h"

#include <cstddef>
#include <memory>
#include <vector>

static constexpr const char* kSwLogCategory_SwImagePlanner = "sw.gui.swimageplanner";

/**
 * @brief One step of a plan: either an op segment on a backend or a residency transfer.
 */
struct SW_GUI_EXPORT SwImagePlanStep {
    std::shared_ptr<SwImageBackend> backend;
    std::vector<SwImageOp> ops;
    bool transferOnly{false};
    SwImageResidency inputResidency{SwImageResidency::Cpu};
    SwImageResidency outputResidency{SwImageResidency::Cpu};
};

/**
 * @brief An ordered list of steps; inspectable through describe().
 */
struct SW_GUI_EXPORT SwImagePlan {
    std::vector<SwImagePlanStep> steps;

    /**
     * @brief Returns whether the plan has no step.
     * @return `true` when empty.
     */
    bool isEmpty() const;

    /**
     * @brief Returns whether the plan contains at least one residency transfer.
     * @return `true` when a transfer step exists.
     */
    bool hasTransfer() const;

    /**
     * @brief Renders the plan as "cpu{Crop,Convert} -> d3d11:upload(cpu->d3d11) -> ...".
     * @return Human-readable description.
     */
    SwString describe() const;
};

/**
 * @brief Static planner: simplify, plan, execute.
 */
class SW_GUI_EXPORT SwImagePlanner {
public:
    /**
     * @brief Folds the view and algebraically simplifies an op chain (pure, no backend).
     * @param view Region of interest of the source ({0,0,0,0} = whole image).
     * @param src Layout of the source storage.
     * @param ops Pending ops.
     * @return The simplified chain (a leading Crop when the view is not the whole image).
     */
    static std::vector<SwImageOp> simplify(const SwRect& view, const SwImageLayout& src,
                                           const std::vector<SwImageOp>& ops);

    /**
     * @brief Builds a plan for `ops` on `src`, ending in `preferred` residency.
     * @param src Source storage.
     * @param view Region of interest of `src` ({0,0,0,0} = whole image).
     * @param ops Pending ops.
     * @param preferred Residency of the result; Auto = wherever the last step leaves it.
     * @param out Receives the plan (cleared first).
     * @param error Receives a reason on failure (may be null).
     * @return `true` when a plan exists.
     */
    static bool plan(const std::shared_ptr<SwImageStorage>& src, const SwRect& view,
                     const std::vector<SwImageOp>& ops, SwImageResidency preferred,
                     SwImagePlan& out, SwString* error);

    /**
     * @brief Executes one transfer step.
     * @param step Step with transferOnly == true.
     * @param in Input storage.
     * @param out Receives the transferred storage.
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    static bool executeTransfer(const SwImagePlanStep& step, const std::shared_ptr<SwImageStorage>& in,
                                std::shared_ptr<SwImageStorage>& out, SwString* error);

    /**
     * @brief Executes a plan step by step (the view is already folded into the ops).
     * @param plan Plan produced by plan().
     * @param src Source storage.
     * @param out Receives the final storage (aliases `src` when the plan is empty).
     * @param error Receives a reason on failure (may be null).
     * @return `true` on success.
     */
    static bool execute(const SwImagePlan& plan, const std::shared_ptr<SwImageStorage>& src,
                        std::shared_ptr<SwImageStorage>& out, SwString* error);

private:
    static void setError_(SwString* error, const SwString& message);

    static SwRect clampRect_(const SwRect& r, int w, int h);

    /**
     * @brief Appends a download step (residency `from` -> CPU) for a storage of layout `layout`.
     *
     * The owning backend of a Vendor storage (`vendorBackendId`) comes first, then the backend
     * whose results live at `from`. For a foreign residency (DmaBuf) only a backend whose
     * inputFormatMask accepts `layout.format` is eligible, so an import the engine cannot
     * perform is refused here at planning time instead of failing inside execute().
     */
    static bool addDownload_(const std::vector<std::shared_ptr<SwImageBackend> >& available,
                             SwImageResidency from, const SwImageLayout& layout, const SwString& vendorBackendId,
                             SwImagePlan& out, SwString* error);

    static bool addUpload_(const std::shared_ptr<SwImageBackend>& target, SwImagePlan& out, SwString* error);
};

// ---------------------------------------------------------------------------------------------
// plan() needs the complete registry. The registry header ends by including the platform
// backends, and on Linux one of them completes SwImage (which uses this planner): the registry
// is therefore included only here, once the SwImagePlanner class above is complete, so that
// every include order (SwImage.h, the registry or this header as the entry point) compiles.
// ---------------------------------------------------------------------------------------------
#include "SwImageBackendRegistry.h"

