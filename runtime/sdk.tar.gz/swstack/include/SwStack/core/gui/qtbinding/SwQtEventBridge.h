#pragma once

/**
 * @file src/core/gui/qtbinding/SwQtEventBridge.h
 * @ingroup qtbinding
 * @brief Runs SwStack inside a Qt application's event loop, woken by SwStack itself.
 *
 * A Qt application and an SwStack application can share one thread: QApplication owns the loop,
 * SwCoreApplication (or SwGuiApplication) is its guest, and this bridge is all that joins them.
 *
 * @code
 * QApplication qt(argc, argv);     // first: Qt sets up COM and the thread the way it needs
 * SwGuiApplication sw;             // never sw.exec(): Qt's loop is the one that runs
 * SwQtEventBridge bridge(&sw);
 * return qt.exec();
 * @endcode
 *
 * Nothing polls. SwStack signals a native handle whenever work is posted to it — from any thread —
 * and Qt waits on that handle with the rest of its sources (QWinEventNotifier on Windows,
 * QSocketNotifier on the eventfd elsewhere). When it fires, the bridge lets SwStack work for a
 * bounded time, then asks it when it next needs to run and arms one single-shot timer for that.
 * An idle pair costs no CPU, and a timer or a post in SwStack is served as soon as Qt's loop turns.
 *
 * Two rules keep the pair healthy:
 * - SwStack is never dispatched from inside SwStack. A Qt modal loop opened from an SwStack slot
 *   (QDialog::exec(), QMenu::exec()) runs on one of SwStack's fibers; the bridge sees
 *   SwCoreApplication::isDispatching() and leaves SwStack alone until that slot returns.
 * - Each wake-up is budgeted (four milliseconds by default), so a busy SwStack cannot starve Qt's
 *   painting and input, nor the other way round.
 *
 * Qt is the master because its nested loops (modal dialogs, menus, drag and drop) run its own
 * dispatcher, which keeps waiting on SwStack's handle; the other way round those loops would bypass
 * SwStack's scheduler entirely.
 *
 * Header-only, and only for code that already includes Qt: it uses QtCore and nothing else.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwCoreApplication.h"

#include <QObject>
#include <QTimer>
#if defined(_WIN32)
#  include <QWinEventNotifier>
#else
#  include <QSocketNotifier>
#  include <unistd.h>
#endif

#include <cstdint>
#include <limits>

class SwQtEventBridge : public QObject {
public:
    /**
     * @brief Makes @p application the guest of the running Qt event loop.
     * @param application The SwStack application of this thread; the current one by default.
     */
    explicit SwQtEventBridge(SwCoreApplication* application = SwCoreApplication::instance(false),
                             QObject* parent = nullptr)
        : QObject(parent), app_(application) {
        if (!app_) {
            return;
        }
        // Posts from this thread must signal the handle too: SwStack no longer waits on it itself.
        app_->setForeignEventLoop(true);
#if defined(_WIN32)
        notifier_ = new QWinEventNotifier(static_cast<Qt::HANDLE>(app_->nativeWakeHandle()), this);
        QObject::connect(notifier_, &QWinEventNotifier::activated, this, [this]() { drain_(); });
#else
        notifier_ = new QSocketNotifier(app_->nativeWakeHandle(), QSocketNotifier::Read, this);
        QObject::connect(notifier_, &QSocketNotifier::activated, this, [this]() {
            // The eventfd counts wake-ups until it is read; read it or it stays readable.
            std::uint64_t count = 0;
            const ssize_t n = ::read(app_->nativeWakeHandle(), &count, sizeof(count));
            (void)n;
            drain_();
        });
#endif
        next_.setSingleShot(true);
        next_.setTimerType(Qt::PreciseTimer);
        QObject::connect(&next_, &QTimer::timeout, this, [this]() { drain_(); });
        // Work posted before the bridge existed is not lost: run once as soon as Qt's loop turns.
        next_.start(0);
    }

    ~SwQtEventBridge() override {
        if (app_) {
            app_->setForeignEventLoop(false);
        }
    }

    SwQtEventBridge(const SwQtEventBridge&) = delete;
    SwQtEventBridge& operator=(const SwQtEventBridge&) = delete;

    /** @brief How long SwStack may run per wake-up before Qt gets the thread back. */
    void setBudgetMicroseconds(int microseconds) { budgetUs_ = microseconds > 0 ? microseconds : 1; }
    int budgetMicroseconds() const { return budgetUs_; }

    /** @brief Wake-ups served so far: a measure of how busy the pair is, for diagnostics. */
    std::uint64_t drainCount() const { return drains_; }

private:
    void drain_() {
        if (!app_ || app_->isDispatching()) {
            // Woken inside SwStack (a Qt modal loop opened from an SwStack slot): the dispatch in
            // progress picks the work up when that slot returns.
            return;
        }
        ++drains_;
        const std::int64_t nextUs = app_->processEventsFor(budgetUs_);
        if (nextUs < 0) {
            next_.stop();   // nothing scheduled: the wake handle is enough
            return;
        }
        const std::int64_t ms = (nextUs + 999) / 1000;
        next_.start(static_cast<int>(ms > (std::numeric_limits<int>::max)()
                                         ? (std::numeric_limits<int>::max)()
                                         : ms));
    }

    SwCoreApplication* app_ = nullptr;
#if defined(_WIN32)
    QWinEventNotifier* notifier_ = nullptr;
#else
    QSocketNotifier* notifier_ = nullptr;
#endif
    QTimer next_;
    int budgetUs_ = 4000;
    std::uint64_t drains_ = 0;
};
