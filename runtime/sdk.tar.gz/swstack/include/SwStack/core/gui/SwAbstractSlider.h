﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwAbstractSlider.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwAbstractSlider in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the abstract slider interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwAbstractSlider, SwHorizontalSlider, and
 * SwVerticalSlider.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * Header-only sliders with a video player inspired look.
 *
 * SwAbstractSlider factors the common behaviour (range handling, scrubbing logic and painting) and
 * SwHorizontalSlider / SwVerticalSlider simply pick the orientation.
 **************************************************************************************************/

#include "SwWidget.h"
#include "SwPainter.h"

#include <algorithm>
#include <cmath>

class SW_WIDGETS_EXPORT SwAbstractSlider : public SwWidget {
    SW_OBJECT(SwAbstractSlider, SwWidget)

public:
    enum class Orientation {
        Horizontal,
        Vertical
    };

    /**
     * @brief Constructs a `SwAbstractSlider` instance.
     * @param orientation Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwAbstractSlider(Orientation orientation, SwWidget* parent = nullptr);

    /**
     * @brief Sets the range.
     * @param minimum Value passed to the method.
     * @param maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRange(double minimum, double maximum);

    /**
     * @brief Sets the minimum.
     * @param minimum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMinimum(double minimum);

    /**
     * @brief Sets the maximum.
     * @param maximum Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMaximum(double maximum);

    /**
     * @brief Returns the current minimum.
     * @return The current minimum.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double minimum() const;
    /**
     * @brief Returns the current maximum.
     * @return The current maximum.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double maximum() const;

    /**
     * @brief Sets the value.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setValue(double value);

    /**
     * @brief Returns the current value.
     * @return The current value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double value() const;

    /**
     * @brief Sets the step.
     * @param step Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStep(double step);

    /**
     * @brief Returns the current step.
     * @return The current step.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double step() const;

    /**
     * @brief Sets the buffered Value.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBufferedValue(double value);

    /**
     * @brief Returns the current buffered Value.
     * @return The current buffered Value.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    double bufferedValue() const;

    /**
     * @brief Sets the accent Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAccentColor(const SwColor& color);

    /**
     * @brief Sets the track Colors.
     * @param base Value passed to the method.
     * @param border Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTrackColors(const SwColor& base, const SwColor& border);

    /**
     * @brief Sets the buffered Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setBufferedColor(const SwColor& color);

    /**
     * @brief Sets the handle Colors.
     * @param fill Value passed to the method.
     * @param border Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHandleColors(const SwColor& fill, const SwColor& border);

    /**
     * @brief Returns the current orientation.
     * @return The current orientation.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Orientation orientation() const;

    SW_SIGNAL(valueChanged, double);

protected:
    /**
     * @brief Returns the current track Rect.
     * @return The current track Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRect trackRect() const;

    /**
     * @brief Returns the current progress Rect.
     * @return The current progress Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRect progressRect() const;

    /**
     * @brief Returns the current buffered Rect.
     * @return The current buffered Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRect bufferedRect() const;

    /**
     * @brief Returns the current handle Rect.
     * @return The current handle Rect.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRect handleRect() const;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Performs the `valueFromPosition` operation.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     * @return The requested value From Position.
     */
    double valueFromPosition(int px, int py) const;

    /**
     * @brief Performs the `clampValue` operation.
     * @param value Value passed to the method.
     * @return The requested clamp Value.
     */
    double clampValue(double value) const;

    /**
     * @brief Performs the `valueRatio` operation.
     * @param value Value passed to the method.
     * @return The requested value Ratio.
     */
    double valueRatio(double value) const;

    /**
     * @brief Returns the current visual Track Thickness.
     * @return The current visual Track Thickness.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int visualTrackThickness() const;

    /**
     * @brief Returns the current visual Handle Radius.
     * @return The current visual Handle Radius.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int visualHandleRadius() const;

    /**
     * @brief Performs the `lighten` operation.
     * @param c Value passed to the method.
     * @param delta Value passed to the method.
     * @return The requested lighten.
     */
    SwColor lighten(const SwColor& c, int delta) const;

private:
    double clampToRange(double value) const;

public:
    ~SwAbstractSlider();
private:
    // What the class keeps (SwAbstractSlider_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwHorizontalSlider : public SwAbstractSlider {
    SW_OBJECT(SwHorizontalSlider, SwAbstractSlider)

public:
    ~SwHorizontalSlider() override;
    /**
     * @brief Constructs a `SwHorizontalSlider` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwHorizontalSlider(SwWidget* parent = nullptr);
};

class SW_WIDGETS_EXPORT SwVerticalSlider : public SwAbstractSlider {
    SW_OBJECT(SwVerticalSlider, SwAbstractSlider)

public:
    ~SwVerticalSlider() override;
    /**
     * @brief Constructs a `SwVerticalSlider` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwVerticalSlider(SwWidget* parent = nullptr);
};

