#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file
 * @ingroup core_gui
 * @brief Declares `SwChart`, the in-memory chart model used by chart widgets.
 *
 * `SwChart` owns the series and presentation state that describe a chart scene.
 * Views such as `SwChartView` consume this object to render axes, titles, legends,
 * and data series without coupling the drawing code to a specific dataset type.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAbstractSeries.h"
#include "SwString.h"
#include "SwValueAxis.h"
#include "SwVector.h"

class SW_CHARTS_EXPORT SwChart : public SwObject {
    SW_OBJECT(SwChart, SwObject)

public:
    /**
     * @brief Constructs a `SwChart` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwChart(SwObject* parent = nullptr);

    /**
     * @brief Returns the current axis X.
     * @return The current axis X.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwValueAxis* axisX() const;
    /**
     * @brief Returns the current axis Y.
     * @return The current axis Y.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwValueAxis* axisY() const;

    /**
     * @brief Returns the current series.
     * @return The current series.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwVector<SwAbstractSeries*>& series() const;

    /**
     * @brief Sets the title.
     * @param title Title text applied by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTitle(const SwString& title);

    /**
     * @brief Returns the current title.
     * @return The current title.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString title() const;

    /**
     * @brief Adds the specified series.
     * @param serie Value passed to the method.
     */
    void addSeries(SwAbstractSeries* serie);

    /**
     * @brief Removes the specified series.
     * @param serie Value passed to the method.
     */
    void removeSeries(SwAbstractSeries* serie);

    /**
     * @brief Removes the specified all Series.
     */
    void removeAllSeries();

    /**
     * @brief Creates the requested default Axes.
     */
    void createDefaultAxes();

    SW_SIGNAL_VOID(changed);
    SW_SIGNAL(seriesAdded, SwAbstractSeries*);
    SW_SIGNAL(seriesRemoved, SwAbstractSeries*);

private:
    int indexOfSeries_(SwAbstractSeries* serie) const;

    void onSeriesChanged_();

    void onAxisChanged_();

public:
    ~SwChart();
private:
    // What the class keeps (SwChart_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
