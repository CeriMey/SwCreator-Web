﻿#pragma once

#include "../SwStackExport.h"
#include "../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

/**
 * @file src/core/gui/SwWidgetSnapshot.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwWidgetSnapshot in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the widget snapshot interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwWidgetSnapshot.
 *
 * Widget-oriented declarations here usually capture persistent UI state, input handling, layout
 * participation, and paint-time behavior while keeping platform-specific rendering details behind
 * lower layers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwWidget.h"
#include "graphics/SwImage.h"

#include "core/io/SwFile.h"
#include "core/types/SwByteArray.h"

#include <cstdint>
#include <vector>


#if SW_PLATFORM_X11
struct _XDisplay;
#endif

class SW_WIDGETS_EXPORT SwWidgetSnapshot {
public:
    /**
     * Renders a visible widget and its children into an owned, top-down CPU BGRA32 image.
     * The image is opaque, including when the native painter leaves alpha undefined.
     * A zero output dimension uses the widget's corresponding native dimension; positive
     * dimensions scale the rendered pixels without changing the widget or its layout.
     * Call on the GUI thread, with a widget belonging to that thread. Invalid dimensions,
     * unavailable backends, or source/output images exceeding 64 MiB return a null image.
     */
    static SwImage capture(SwWidget* widget, int width = 0, int height = 0);

    /**
     * @brief Performs the `savePng` operation on the associated resource.
     * @param widget Widget associated with the operation.
     * @param filePath Path of the target file.
     * @return The requested png.
     */
    static bool savePng(SwWidget* widget, const SwString& filePath);

private:
    static void appendU8(SwByteArray& out, std::uint8_t value);

    static void appendU16LE(SwByteArray& out, std::uint16_t value);

    static void appendU32BE(SwByteArray& out, std::uint32_t value);

    static std::uint32_t crc32TableEntry(std::uint32_t index);

    static const std::uint32_t* crc32Table();

    static std::uint32_t crc32Update(std::uint32_t crc,
                                     const std::uint8_t* data,
                                     std::uint32_t length);

    static void appendChunk(SwByteArray& out, const char type[4], const SwByteArray& data);

    static void deflateStoreFlush(SwByteArray& out, SwByteArray& block, bool finalBlock);

    static SwByteArray encodeZlibStoreRgb24(const std::uint8_t* bgrxPixels,
                                            int width,
                                            int height,
                                            int strideBytes);

    static SwByteArray encodePngRgb24(const std::uint8_t* bgrxPixels,
                                      int width,
                                      int height,
                                      int strideBytes);

#if defined(_WIN32)
    struct SW_WIDGETS_EXPORT RenderBuffer_ {
        HDC      dc{nullptr};
        HBITMAP  bitmap{nullptr};
        HBITMAP  prevBitmap{nullptr};
        void*    bits{nullptr};
        int      width{0};
        int      height{0};

        static RenderBuffer_& instance();

        bool ensure(int w, int h);

        void release();

        ~RenderBuffer_();
    };
#endif

#if SW_PLATFORM_X11
    static int maskShiftX11_(unsigned long mask);

    static int maskBitsX11_(unsigned long mask);

    static std::uint8_t expandMaskComponentX11_(unsigned long value, int bits);

    static bool copyPixmapToBgrxX11_(_XDisplay* display,   // Xlib's Display
                                     unsigned long pixmap,   // a Pixmap (an XID)
                                     int width,
                                     int height,
                                     std::vector<std::uint8_t>& outPixels);

    static bool savePngX11_(SwWidget* widget,
                            const SwString& filePath,
                            int width,
                            int height);
#endif
};
