#pragma once

#include "core/gui/SwJoystick.h"
#include "core/threeD/Sw3DScene.h"

// Internal, per-widget scene. The fixed socket and moving assembly share a
// camera and depth buffer; the assembly rotates around the socket pivot.
class SwJoystick3D {
public:
    SwJoystick3D();
    bool render(SwJoystick::Type type, float heightMillimetres,
                float tiltX, float tiltY, SwImage& image, int side);

private:
    void rebuild(SwJoystick::Type type, float heightMillimetres);
    Sw3DScene scene_;
    Sw3DCamera camera_;
    Sw3DRenderer renderer_;
    Sw3DNode* moving_{nullptr};
    Sw3DNode* ball_{nullptr};
    float ballCenter_{0};
    SwJoystick::Type type_{SwJoystick::Type::Gamepad};
    float height_{-1.0f};
};
