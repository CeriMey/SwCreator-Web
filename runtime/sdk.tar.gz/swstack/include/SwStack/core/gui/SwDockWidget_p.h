// Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0
#pragma once
// Private docking-slot bookkeeping; not part of the public widget API.
#include "SwDockWidget.h"
#include "SwLayout.h"
#include "SwPointer.h"
#include "SwSplitter.h"
#include "SwTabWidget.h"
#include <algorithm>
#include <vector>

class SwDockHome final : public SwObject {
  public:
    explicit SwDockHome(SwWidget *owner) : SwObject(owner), owner_(owner) {}
    ~SwDockHome() override {
        closing = true;
        for (auto &slot : slots_) {
            auto *dock = dynamic_cast<SwDockWidget *>(slot.widget.data());
            if (dock && dock->isFloating())
                delete dock;
        }
    }
    static SwDockHome *forWidget(SwWidget *owner) {
        if (!owner)
            return nullptr;
        for (auto *child : owner->children())
            if (auto *home = dynamic_cast<SwDockHome *>(child))
                return home;
        return new SwDockHome(owner);
    }
    void detach(SwWidget *widget) {
        if (!owner_)
            return;
        bool pending = false;
        for (const auto &slot : slots_)
            pending |= slot.detached && bool(slot.widget);
        if (!pending)
            capture();
        // Clients can add new panels while another panel is floating.
        // Register newly added panels too, so their ownership and home slot survive.
        const auto known = std::find_if(slots_.begin(), slots_.end(), [widget](const Slot &slot) {
            return slot.widget.data() == widget;
        });
        if (known == slots_.end()) {
            Slot slot{SwPointer<SwWidget>(widget)};
            if (auto *tabs = dynamic_cast<SwTabWidget *>(owner_.data()))
                slot.label = tabs->tabText(tabs->indexOf(widget));
            else if (auto *splitter = dynamic_cast<SwSplitter *>(owner_.data())) {
                const int i = splitter->indexOf(widget);
                const auto sizes = splitter->sizes();
                slot.size = i >= 0 && i < sizes.size() ? sizes[i] : 1;
                slot.collapsible = splitter->isCollapsible(i);
            }
            slots_.push_back(slot);
        }
        for (auto &slot : slots_)
            if (slot.widget.data() == widget)
                slot.detached = true;
        if (auto *tabs = dynamic_cast<SwTabWidget *>(owner_.data())) {
            tabs->takeTab(tabs->indexOf(widget));
            if (!tabs->count()) {
                tabs->hide();
                outer_ = forWidget(dynamic_cast<SwWidget *>(tabs->parent()));
                if (outer_)
                    static_cast<SwDockHome *>(outer_.data())->detach(tabs);
            }
        } else if (auto *splitter = dynamic_cast<SwSplitter *>(owner_.data())) {
            splitter->removeWidget(widget);
        } else if (auto *layout = dynamic_cast<SwBoxLayout *>(owner_->layout())) {
            layout->removeWidget(widget);
        }
    }
    void restore(SwWidget *widget) {
        if (closing || !owner_)
            return;
        if (outer_) {
            static_cast<SwDockHome *>(outer_.data())->restore(owner_);
            outer_ = nullptr;
        }
        owner_->show();
        int index = 0;
        for (auto &slot : slots_) {
            if (!slot.widget)
                continue;
            if (slot.widget.data() == widget) {
                slot.detached = false;
                if (auto *tabs = dynamic_cast<SwTabWidget *>(owner_.data())) {
                    const int inserted = tabs->insertTab(index, widget, slot.label);
                    tabs->setCurrentIndex(inserted);
                } else if (auto *splitter = dynamic_cast<SwSplitter *>(owner_.data())) {
                    splitter->insertWidget(index, widget);
                    splitter->setCollapsible(index, slot.collapsible);
                    SwVector<int> sizes;
                    for (const auto &item : slots_)
                        if (item.widget && !item.detached)
                            sizes.push_back(item.size);
                    splitter->setSizes(sizes);
                } else if (auto *layout = dynamic_cast<SwBoxLayout *>(owner_->layout())) {
                    layout->insertWidget(index, widget, slot.size);
                }
                return;
            }
            if (!slot.detached)
                ++index;
        }
    }
    SwWidget *owner() const { return owner_.data(); }
    SwString tabLabel(SwWidget *widget) const {
        for (const auto &slot : slots_)
            if (slot.widget.data() == widget)
                return slot.label;
        return {};
    }
    void forget(SwWidget *widget) {
        for (auto &slot : slots_)
            if (slot.widget.data() == widget) {
                slot.widget = nullptr;
                slot.detached = false;
            }
    }
    void ensureVisible() {
        if (!owner_ || closing)
            return;
        if (outer_) {
            static_cast<SwDockHome *>(outer_.data())->restore(owner_);
            outer_ = nullptr;
        }
        owner_->show();
    }
    SwRect containerRect() const {
        if (!owner_)
            return {};
        if (outer_)
            return static_cast<SwDockHome *>(outer_.data())->previewRect(owner_);
#if SW_PLATFORM_WIN32
        // Dock proposals share the owner's root client logical coordinates.
        // Convert to physical screen pixels only when moving the native preview.
        SwWidget* root = owner_;
        while (auto* parent = dynamic_cast<SwWidget*>(root->parent())) root = parent;
        const auto p = owner_->mapTo(root, {0, 0});
#else
        const auto p = owner_->mapToGlobal({0, 0});
#endif
        return {p.x, p.y, owner_->width(), owner_->height()};
    }
    SwRect previewRect(SwWidget *widget) const {
        const auto area = containerRect();
        auto *splitter = dynamic_cast<SwSplitter *>(owner_.data());
        if (!splitter)
            return area;
        int count = 0, total = 0, preceding = 0, size = 0;
        bool found = false;
        for (const auto &slot : slots_) {
            if (!slot.widget || (slot.detached && slot.widget.data() != widget))
                continue;
            const int weight = std::max(1, slot.size);
            if (slot.widget.data() == widget) {
                size = weight;
                found = true;
            } else if (!found)
                preceding += weight;
            total += weight;
            ++count;
        }
        if (!found || !total)
            return {};
        const bool horizontal = splitter->orientation() == SwSplitter::Orientation::Horizontal;
        const int length = horizontal ? area.width : area.height;
        const int available = std::max(0, length - (count - 1) * splitter->handleWidth());
        int handlesBefore = 0;
        for (const auto &slot : slots_) {
            if (slot.widget.data() == widget)
                break;
            if (slot.widget && !slot.detached)
                ++handlesBefore;
        }
        const int position =
            available * preceding / total + handlesBefore * splitter->handleWidth();
        const int extent = std::max(1, available * size / total);
        return horizontal ? SwRect{area.x + position, area.y, extent, area.height}
                          : SwRect{area.x, area.y + position, area.width, extent};
    }
    void adopt(SwWidget *widget, const SwString &label, bool trailing, int extent) {
        if (!owner_ || closing)
            return;
        ensureVisible();
        if (auto *tabs = dynamic_cast<SwTabWidget *>(owner_.data())) {
            tabs->setCurrentIndex(tabs->addTab(widget, label));
        } else if (auto *splitter = dynamic_cast<SwSplitter *>(owner_.data())) {
            const auto before = splitter->sizes();
            const int index = trailing ? splitter->count() : 0;
            splitter->insertWidget(index, widget);
            const bool horizontal = splitter->orientation() == SwSplitter::Orientation::Horizontal;
            const int available = (horizontal ? splitter->width() : splitter->height()) -
                                  (splitter->count() - 1) * splitter->handleWidth();
            extent = std::clamp(extent, 1, std::max(1, available));
            int total = 0;
            for (const int size : before)
                total += size;
            SwVector<int> sizes;
            for (int i = 0; i < splitter->count(); ++i)
                sizes.push_back(i == index ? extent
                                           : before[i < index ? i : i - 1] * (available - extent) /
                                                 std::max(1, total));
            splitter->setSizes(sizes);
        }
        bool pending = false;
        for (const auto &slot : slots_)
            pending |= slot.detached && bool(slot.widget);
        if (!pending)
            capture();
        else {
            Slot slot{SwPointer<SwWidget>(widget), label, std::max(1, extent)};
            if (!trailing && dynamic_cast<SwSplitter *>(owner_.data()))
                slots_.insert(slots_.begin(), slot);
            else
                slots_.push_back(slot);
        }
    }
    bool closing{false};

  private:
    struct Slot {
        SwPointer<SwWidget> widget;
        SwString label;
        int size{1};
        bool collapsible{false}, detached{false};
    };
    void capture() {
        slots_.clear();
        if (auto *tabs = dynamic_cast<SwTabWidget *>(owner_.data())) {
            for (int i = 0; i < tabs->count(); ++i)
                slots_.push_back({SwPointer<SwWidget>(tabs->widget(i)), tabs->tabText(i)});
        } else if (auto *splitter = dynamic_cast<SwSplitter *>(owner_.data())) {
            const auto sizes = splitter->sizes();
            for (int i = 0; i < splitter->count(); ++i)
                slots_.push_back({SwPointer<SwWidget>(splitter->widget(i)),
                                  {},
                                  i < sizes.size() ? sizes[i] : 1,
                                  splitter->isCollapsible(i)});
        } else if (auto *layout = dynamic_cast<SwBoxLayout *>(owner_->layout())) {
            int i = 0;
            layout->forEachManagedWidget([&](SwWidget *widget) {
                slots_.push_back({SwPointer<SwWidget>(widget), {}, layout->stretch(i++)});
            });
        } else {
            for (auto *child : owner_->children())
                if (auto *widget = dynamic_cast<SwWidget *>(child))
                    slots_.push_back({SwPointer<SwWidget>(widget)});
        }
    }
    SwPointer<SwWidget> owner_;
    // SwDockHome is incomplete here; keep the guarded base pointer until it is used.
    SwPointer<SwObject> outer_;
    std::vector<Slot> slots_;
};
