#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextDocument.h"

#include <algorithm>

// ---------------------------------------------------------------------------
// SwTextCursor — navigation and editing API (Qt6 QTextCursor equivalent)
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextCursor {
public:
    SwTextCursor();

    explicit SwTextCursor(SwTextDocument* doc);

    // --- Position ---
    int position() const;
    int anchor() const;

    void setPosition(int pos, bool keepAnchor = false);

    // --- Selection ---
    bool hasSelection() const;

    int selectionStart() const;
    int selectionEnd() const;

    SwString selectedText() const;

    void select(int start, int end);

    void clearSelection();

    void selectAll();

    // --- Movement ---
    enum MoveOperation {
        NoMove,
        Start,          // beginning of document
        End,            // end of document
        Left,           // one character left
        Right,          // one character right
        Up,             // one line up
        Down,           // one line down
        StartOfLine,
        EndOfLine,
        StartOfBlock,
        EndOfBlock,
        NextBlock,
        PreviousBlock,
        WordLeft,
        WordRight
    };

    enum MoveMode {
        MoveAnchor = 0,  // moves anchor with cursor
        KeepAnchor = 1   // keeps anchor = creates/extends selection
    };

    bool movePosition(MoveOperation op, MoveMode mode = MoveAnchor, int n = 1);

    // --- Insertion ---
    void insertText(const SwString& text);

    void insertText(const SwString& text, const SwTextCharFormat& fmt);

    void insertBlock();

    void insertBlock(const SwTextBlockFormat& blockFmt, const SwTextCharFormat& charFmt = SwTextCharFormat());

    void insertHtml(const SwString& html);

    // --- Tables ---
    SwTextTable* insertTable(int rows, int cols, const SwTextTableFormat& fmt = SwTextTableFormat());

    // --- Lists ---
    SwTextList* insertList(const SwTextListFormat& fmt);

    SwTextList* createList(const SwTextListFormat& fmt);

    // Add a new item to the current list (inserts a new block attached to the list)
    void insertListItem(SwTextList* list);

    // --- Images ---
    void insertImage(const SwTextImageFormat& imgFmt);

    // --- Deletion ---
    void removeSelectedText();

    void deleteChar();

    void deletePreviousChar();

    // --- Formatting ---
    void setCharFormat(const SwTextCharFormat& fmt);

    void mergeCharFormat(const SwTextCharFormat& fmt);

    SwTextCharFormat charFormat() const;

    void setBlockFormat(const SwTextBlockFormat& fmt);

    SwTextBlockFormat blockFormat() const;

    // --- Current block info ---
    SwTextBlock currentBlock() const;

    int blockNumber() const;

    int positionInBlock() const;

    // --- Document ---
    SwTextDocument* document() const;

    // --- Comparison ---
    bool operator==(const SwTextCursor& o) const;
    bool operator!=(const SwTextCursor& o) const;
    bool operator<(const SwTextCursor& o) const;

    bool atStart() const;
    bool atEnd() const;
    bool isNull() const;

private:

    int clampPos(int pos) const;
public:
    ~SwTextCursor();
public:
    SwTextCursor(const SwTextCursor& other);
    SwTextCursor& operator=(const SwTextCursor& other);
private:
    // What the class keeps (SwTextCursor_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
