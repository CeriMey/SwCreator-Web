#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwLineEdit.h"
#include "core/gui/graphics/SwTextLayout_p.h"

struct SwLineEdit::Data {
    mutable swTextLayout::LineCache m_lineGeometry;
    SwString m_Text = SwString();
    bool m_Text_registered_ = sw_register_Text_();
    SwString m_DisplayText = SwString();
    bool m_DisplayText_registered_ = sw_register_DisplayText_();
    EchoModeEnum m_EchoMode = EchoModeEnum::NormalEcho;
    bool m_EchoMode_registered_ = sw_register_EchoMode_();
    SwString m_Placeholder = SwString();
    bool m_Placeholder_registered_ = sw_register_Placeholder_();
    bool m_ReadOnly = false;
    bool m_ReadOnly_registered_ = sw_register_ReadOnly_();
    size_t cursorPos;          // Position du curseur
    size_t selectionStart;     // DÃ©but de la sÃ©lection
    size_t selectionEnd;       // Fin de la sÃ©lection
    bool isSelecting;          // Indique si une sÃ©lection est en cours
    bool capsLockActive{false};
    SwTimer* monitorTimer{nullptr};
    bool m_caretVisible{true};
    size_t firstVisibleCharacter{0};
    SwColor m_focusAccent{59, 130, 246};
    bool m_pendingMultiClick{false};
    SwPoint m_lastDoubleClickPos{};
    std::chrono::steady_clock::time_point m_lastDoubleClickTime{};
    // Undo and redo: the text and cursor before each edit. A run of typed, or of deleted,
    // characters is one step (m_undoRun: 0 none, 1 typing, 2 deleting).
    struct UndoState {
        SwString text;
        size_t cursor{0};
    };
    std::vector<UndoState> m_undo;
    std::vector<UndoState> m_redo;
    int m_undoRun{0};
};
