/*
 * Copyright (c) 2025-2026 Ariya Consulting.
 * SPDX-License-Identifier: Apache-2.0
 * Licensed under the Apache License, Version 2.0. See LICENSE in SwStack.
 */

#pragma once
#include "SwWidget.h"
#include "core/threeD/Sw3DScene.h"
#include "core/threeD/Sw3DPathTracer.h"
#include <memory>

// A regular widget. The scene may be shared with an offscreen renderer or another view.
class SW_WIDGETS_EXPORT Sw3DView : public SwWidget {
    SW_OBJECT(Sw3DView, SwWidget)
  public:
    explicit Sw3DView(SwWidget *parent = nullptr);
    ~Sw3DView() override;
    void setScene(const std::shared_ptr<Sw3DScene> &scene);
    std::shared_ptr<Sw3DScene> scene() const;
    Sw3DCamera &camera();
    void setBackgroundColor(std::uint32_t color);
    void setAntialiasingEnabled(bool enabled);
    bool isAntialiasingEnabled() const;
    void setEnvironment(const Sw3DEnvironmentSettings &environment);
    Sw3DEnvironmentSettings environment() const;
    // Progressive preview runs only after 250 ms without navigation and on a bounded CPU worker.
    void setPathTracingEnabled(bool enabled);
    bool isPathTracingEnabled() const;
    void setPathTracingSettings(const Sw3DPathTracer::Settings &settings,
                                double maxRenderMs = 5000, std::size_t maxPreviewPixels = 262144,
                                double stepBudgetMs = 20);
    Sw3DPathTracer::Stats pathTracingStats() const;
    double pathTracingProgress() const;
    std::string pathTracingLastError() const;
    bool frameScene();
    void setViewOrientation(double yawDegrees, double pitchDegrees, bool orthographic = false);
    // Camera rotations around the current screen axes. Positive roll is clockwise.
    void rotateView(double horizontalDegrees, double verticalDegrees, double rollDegrees = 0);
    void orbitBy(double horizontalDegrees, double verticalDegrees);
    void panPixels(double dx, double dy);
    enum NavigationMode { Orbit, Pan, Zoom };
    void setNavigationMode(NavigationMode mode);
    NavigationMode navigationMode() const;
    void setOrthographic(bool enabled);
    bool isOrthographic() const;
    // Vertical field of view of the perspective camera, in degrees (default 45). A narrower one
    // looks closer to a parallel projection; framing keeps the scene the same size on screen.
    void setFieldOfView(double degrees);
    double fieldOfView() const;
    void zoomBy(double factor);
    bool zoomWindow(const SwRect &rectangle);
    void setOrbitCenter(const Sw3DVec3 &center);
    Sw3DVec3 orbitCenter() const;
    void setFreeOrbit(bool enabled);
    bool isFreeOrbit() const;
    void setPerspectiveWithOrthoFaces(bool enabled);
    bool isPerspectiveWithOrthoFaces() const;
    // Wheel forward zooms in (default) or out.
    void setWheelZoomReversed(bool reversed);
    bool isWheelZoomReversed() const;
    // The point under the pointer stays in place while the wheel zooms.
    void setZoomTowardCursor(bool enabled);
    bool isZoomTowardCursor() const;
    // Orbits turn around @p pivot, which keeps its place on screen; without one they turn around
    // the orbit centre.
    void setOrbitPivot(const Sw3DVec3 &pivot);
    void clearOrbitPivot();
    bool hasOrbitPivot() const;
    // The portable software renderer instead of the GPU path (driver issues, comparisons).
    void setSoftwareRendering(bool enabled);
    bool isSoftwareRendering() const;
    // Reuse the last image when scene, camera and dimensions are unchanged.
    void setFrameCachingEnabled(bool enabled);
    bool isFrameCachingEnabled() const;
    std::uint64_t renderedFrameCount() const;
    std::uint64_t cachedFrameCount() const;
    Sw3DPickResult pickAt(double x, double y) const;
    const Sw3DFrameStats &frameStats() const;
    const std::string &lastError() const;
    SW_SIGNAL_VOID(cameraChanged);

  protected:
    void paintEvent(PaintEvent *) override;
    void mousePressEvent(MouseEvent *) override;
    void mouseMoveEvent(MouseEvent *) override;
    void mouseReleaseEvent(MouseEvent *) override;
    void wheelEvent(WheelEvent *) override;
    void showEvent(Event *) override;
    void hideEvent(Event *) override;

  private:
    void orbit_();
    void invalidateProgressive_();
    void progressiveTick_();
    struct Data;
    std::unique_ptr<Data> d_;
};
