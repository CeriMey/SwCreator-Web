#pragma once

#include "SwPlainTextEdit.h"
#include "SwLineEdit.h"
#include "SwJsonObject.h"

// Plain text mail widgets. They never load remote HTML content or execute mail markup.
class SW_WIDGETS_EXPORT SwMailMessageView : public SwPlainTextEdit {
public:
    explicit SwMailMessageView(SwWidget* parent = nullptr);
    ~SwMailMessageView() override;
    void setLabels(const SwJsonObject& labels);
    void setMessage(const SwJsonObject& message);
private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};

class SW_WIDGETS_EXPORT SwMailComposer : public SwWidget {
public:
    explicit SwMailComposer(SwWidget* parent = nullptr);
    ~SwMailComposer() override;
    void setLabels(const SwJsonObject& labels);
    void setMessage(const SwJsonObject& message);
    SwJsonObject message() const;
    void setReadOnly(bool readOnly);
protected:
    void resizeEvent(ResizeEvent* event) override;
private:
    struct Data;
    SwObjectDataPointer<Data> d_;
};
