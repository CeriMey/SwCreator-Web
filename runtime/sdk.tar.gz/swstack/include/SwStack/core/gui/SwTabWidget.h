﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwTabWidget.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwTabWidget in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the tab widget interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwTabWidget.
 *
 * Widget-oriented declarations here usually capture persistent UI state, input handling, layout
 * participation, and paint-time behavior while keeping platform-specific rendering details behind
 * lower layers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwWidget.h"
#include "SwVector.h"

class SW_WIDGETS_EXPORT SwTabWidget : public SwWidget {
    SW_OBJECT(SwTabWidget, SwWidget)

public:
    SW_SIGNAL(currentChanged, int);
    SW_SIGNAL(tabCloseRequested, int);
    SW_SIGNAL(tabMoved, int, int);

    enum class TabPosition {
        Top,
        Bottom,
        Left,
        Right
    };

    enum class TabStyle {
        Segmented,
        Underline,
        Pills
    };

    /**
     * @brief Constructs a `SwTabWidget` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwTabWidget(SwWidget* parent = nullptr);

    SW_PROPERTY_D(bool, TabsClosable);
private:
protected:

public:

    /**
     * @brief Performs the `tabsClosable` operation.
     * @return `true` on success; otherwise `false`.
     */
    bool tabsClosable() const;

    SW_PROPERTY_D(bool, Movable);
private:
protected:

public:

    /**
     * @brief Performs the `movable` operation.
     * @return `true` on success; otherwise `false`.
     */
    bool movable() const;
    /**
     * @brief Returns whether the object reports movable.
     * @return `true` when the object reports movable; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool isMovable() const;

    /**
     * @brief Adds the specified tab.
     * @param page Value passed to the method.
     * @param label Value passed to the method.
     * @return The requested tab.
     */
    int addTab(SwWidget* page, const SwString& label);

    int insertTab(int index, SwWidget* page, const SwString& label);
    int indexOf(SwWidget* page) const;
    // Removes a page without deleting or reparenting it. The caller retains ownership.
    SwWidget* takeTab(int index);

    /**
     * @brief Performs the `widget` operation.
     * @param index Value passed to the method.
     * @return The requested widget.
     */
    SwWidget* widget(int index) const;

    /**
     * @brief Performs the `tabText` operation.
     * @param index Value passed to the method.
     * @return The requested tab Text.
     */
    SwString tabText(int index) const;

    /**
     * @brief Sets the tab Text.
     * @param index Value passed to the method.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTabText(int index, const SwString& text);

    /**
     * @brief Removes the specified tab.
     * @param index Value passed to the method.
     */
    void removeTab(int index);

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Sets the tab Position.
     * @param position Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTabPosition(TabPosition position);

    /**
     * @brief Returns the current tab Position.
     * @return The current tab Position.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    TabPosition tabPosition() const;

    /**
     * @brief Sets the tab Style.
     * @param style Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTabStyle(TabStyle style);

    /**
     * @brief Returns the current tab Style.
     * @return The current tab Style.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    TabStyle tabStyle() const;

    /**
     * @brief Sets the accent Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAccentColor(const SwColor& color);

    /**
     * @brief Returns the current accent Color.
     * @return The current accent Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor accentColor() const;

    /**
     * @brief Sets the tabs Fill Space.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTabsFillSpace(bool on);

    /**
     * @brief Returns the current tabs Fill Space.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool tabsFillSpace() const;

    /**
     * @brief Sets the uses Scroll Buttons.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setUsesScrollButtons(bool on);

    /**
     * @brief Returns the current uses Scroll Buttons.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool usesScrollButtons() const;

    /**
     * @brief Returns the current count.
     * @return The current count.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int count() const;

    /**
     * @brief Returns the current current Index.
     * @return The current current Index.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int currentIndex() const;

    /**
     * @brief Returns the current current Widget.
     * @return The current current Widget.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwWidget* currentWidget() const;

    /**
     * @brief Sets the current Index.
     * @param index Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCurrentIndex(int index);

protected:
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the wheel Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void wheelEvent(WheelEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

private:
    struct Tab {
        SwString text;
        SwWidget* page{nullptr};
        SwRect rect;
    };

    static SwColor mix(const SwColor& a, const SwColor& b, int t0_100);

    static SwRect insetRect(const SwRect& r, int dx, int dy);

    static SwRect insetRect(const SwRect& r, int left, int top, int right, int bottom);

    static bool parseBool_(const SwString& value, bool fallback);

    static int parsePixelValue_(const SwString& value, int defaultValue);

    SwString styleProp_(const char* propName) const;

    SwString styleSubControlProp_(const char* subControl, const char* propName) const;

    static bool isStyleNoneValue_(const SwString& value);

    bool parseColorValue_(const SwString& value, SwColor& out, float* alphaOut = nullptr) const;

    bool applyStyleSheetOverrides_();

    static bool containsPoint(const SwRect& r, int px, int py);

    static int roundRadiusForRect(const SwRect& r);

    SwRect outerRect(const SwRect& widgetRect) const;

    SwRect innerRect(const SwRect& widgetRect) const;

    SwRect layoutRect(const SwRect& widgetRect) const;

    bool isHorizontalTabs() const;

    int tabBarThickness() const;

    SwRect tabBarRect(const SwRect& widgetRect) const;

    SwRect contentRect(const SwRect& widgetRect) const;

    SwRect contentClipRect(const SwRect& widgetRect) const;

    SwRect pageRectForLayout(const SwRect& widgetRect) const;

    SwRect mapLocalRectToAbsolute_(const SwRect& localRect) const;

    void updateLayout();

    void recalcTabRects(const SwRect& widgetRect);

    int tabIndexAt(int px, int py) const;

    SwFont fontForTab(bool selected) const;

    DrawTextFormats tabTextFormats() const;

    SwRect tabTextRect(const SwRect& tabRect) const;

    void paintContainer(SwPainter* painter, const SwRect& widgetRect);

    void paintFrameBorder_(SwPainter* painter, const SwRect& outer, int radius);

    void tabCornerRadii_(int tabIndex,
                         const SwRect& tabRect,
                         const SwRect& areaRect,
                         int& radiusTL,
                         int& radiusTR,
                         int& radiusBR,
                         int& radiusBL) const;

    void paintTabs(SwPainter* painter, const SwRect& widgetRect);

    SwRect tabCloseRect_(const SwRect& tabRect) const;

    void paintTabCloseButton_(SwPainter* painter,
                              int tabIndex,
                              const SwColor& onSurface,
                              const SwColor& muted,
                              const SwColor& hoverBg);

    void paintScrollButtons_(SwPainter* painter,
                             const SwColor& onSurface,
                             const SwColor& muted,
                             const SwColor& hoverBg);

    void scrollTabsBy_(int deltaPixels);

    int scrollStepPixels_() const;

    void ensureTabVisible_(int index);

    void moveTab_(int from, int to);

private:

public:
    ~SwTabWidget();
private:
    // What the class keeps (SwTabWidget_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

