﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwCheckBox.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwCheckBox in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the check box interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwCheckBox.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwCheckBox - checkbox widget.
 *
 * API goals:
 * - Familiar naming (setChecked/isChecked, setText/text, stateChanged/toggled/clicked).
 * - Minimal dependencies (prefer Sw* types, avoid std:: in widget code).
 **************************************************************************************************/

#include "SwWidget.h"
#include "graphics/SwFontMetrics.h"

class SW_WIDGETS_EXPORT SwCheckBox : public SwWidget {
    SW_OBJECT(SwCheckBox, SwWidget)

public:
    enum CheckState {
        Unchecked = 0,
        PartiallyChecked = 1,
        Checked = 2
    };

    /**
     * @brief Constructs a `SwCheckBox` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwCheckBox(SwWidget* parent = nullptr);

    /**
     * @brief Constructs a `SwCheckBox` instance.
     * @param text Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwCheckBox(const SwString& text, SwWidget* parent = nullptr);

    /**
     * @brief Sets the accent Color.
     * @param color Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setAccentColor(const SwColor& color);

    /**
     * @brief Returns the current accent Color.
     * @return The current accent Color.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwColor accentColor() const;

    /**
     * @brief Sets the tristate.
     * @param on Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setTristate(bool on);

    /**
     * @brief Returns whether the object reports tristate.
     * @return `true` when the object reports tristate; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isTristate() const;

    /**
     * @brief Sets the check State.
     * @param state Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setCheckState(CheckState state);

    /**
     * @brief Returns the current check State.
     * @return The current check State.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    CheckState checkState() const;

    /**
     * @brief Sets the checked.
     * @param Unchecked Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setChecked(bool checked);
    /**
     * @brief Returns whether the object reports checked.
     * @return `true` when the object reports checked; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isChecked() const;

    /**
     * @brief Performs the `toggle` operation.
     */
    void toggle();

    /**
     * @brief Performs the `text` operation.
     * @return The requested text.
     */
    SwString text() const;

    SW_SIGNAL(stateChanged, int);
    SW_SIGNAL(toggled, bool);
    SW_SIGNAL(clicked, bool);

protected:
    SW_PROPERTY_D(SwString, Text);
private:
protected:

    SW_PROPERTY_D(bool, Pressed);
private:
protected:

    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

private:
    void initDefaults();

public:
    ~SwCheckBox();
private:
    // What the class keeps (SwCheckBox_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
