#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwToolTip.h"
#include "core/object/SwPointer.h"

struct SwToolTip::Data : SwSharedData {
    // Dialogs own their tooltip popup and can disappear before the next input event
    // or the delayed hover timer. Keep lifetime guards for every retained object.
    SwPointer<SwWidget> m_root;
    SwPointer<Popup> m_popup;
    SwPointer<SwTimer> m_timer;
    SwPointer<SwWidget> m_pendingWidget;
    SwString m_pendingText;
    int m_lastX{0};
    int m_lastY{0};
    int m_delayMs{700};
};
