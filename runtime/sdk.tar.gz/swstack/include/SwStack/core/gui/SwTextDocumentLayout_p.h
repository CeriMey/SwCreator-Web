#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwTextDocumentLayout.h"

struct SwTextDocumentLayout::Data : SwSharedData {
    SwTextDocument* m_document{nullptr};
    int m_pageWidth{595};
    int m_pageHeight{842};
    int m_marginTop{72};
    int m_marginRight{72};
    int m_marginBottom{72};
    int m_marginLeft{72};
    int m_indentSize{24};
    int m_pageCount{1};
    bool m_dirty{true};
    SwFont m_defaultFont;
    std::vector<BlockLayout> m_blockLayouts;
    std::vector<int> m_pageBreaks; // block index where each page starts
};
