#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwTextDocument.h"
#include "SwTextDecorationRenderer.h"
#include "SwPainter.h"
#include "graphics/SwFontMetrics.h"

#include <algorithm>
#include <cmath>
#include <vector>

// ---------------------------------------------------------------------------
// SwTextDocumentLayout — layout engine and renderer for SwTextDocument
//
// Computes bounding rects for each block, handles word-wrapping, pagination,
// and rendering of the document via SwPainter.
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwTextDocumentLayout {
public:
    SwTextDocumentLayout();

    void setDocument(SwTextDocument* doc);
    SwTextDocument* document() const;

    void setPageSize(int width, int height);
    int pageWidth() const;
    int pageHeight() const;

    void setMargins(int top, int right, int bottom, int left);

    int contentWidth() const;
    int contentHeight() const;

    void setDefaultFont(const SwFont& font);
    SwFont defaultFont() const;

    // --- Layout computation ---
    void layout();

    int pageCount() const;

    // --- Rendering ---
    void draw(SwPainter* painter, int page = -1) const;

    // --- Draw onto a specific rect (for widget use) ---
    void drawInRect(SwPainter* painter, const SwRect& rect, int scrollY = 0) const;

    // --- Hit testing ---
    int hitTest(int x, int y) const;

    // --- Block geometry ---
    SwRect blockBoundingRect(int blockIndex) const;

    int blockPage(int blockIndex) const;

    int blockLineHeight(int blockIndex) const;

    struct LineRange { int startOffset; int length; };
    std::vector<LineRange> blockLines(int blockIndex) const;

    // --- Total document height ---
    int documentHeight() const;

private:

    struct SW_GUI_EXPORT LinePart {
        int startOffset{0};   // offset within the block
        int length{0};        // character count

        LinePart();

        LinePart(int start, int len);
    };

    struct BlockLayout {
        int blockIndex{0};
        SwRect rect{0, 0, 0, 0};
        int lineHeight{20};
        int page{0};
        std::vector<LinePart> lines;
        bool isTable{false};
        SwTextTable* table{nullptr};
    };


    int headingFontSize(int level) const;

    SwFont fontForBlock(const SwTextBlock& block) const;

    SwFont fontForFormat(const SwTextCharFormat& fmt) const;

    // --- Word wrapping ---
    std::vector<LinePart> wrapText(const SwTextBlock& block, int maxWidth) const;

    // --- Draw a single wrapped line ---
    void drawLine(SwPainter* painter, const SwTextBlock& block, const LinePart& line,
                  int x, int y, int width, int lineHeight,
                  SwTextBlockFormat::Alignment align) const;

    // --- Table layout ---
    int layoutTable(SwTextTable* table, int x, int y, int availWidth) const;

    void drawTable(SwPainter* painter, SwTextTable* table, const SwRect& rect) const;

    // --- Estimate text width (without platform metrics for portability) ---
    // Helvetica glyph widths (per 1000 units, standard AFM data)
    static int helveticaGlyphWidth_(unsigned char ch);

    int estimateTextWidth(const SwString& text, const SwFont& font = SwFont()) const;

    int estimateCharAtX(const SwTextBlock& block, const LinePart& line, int relX) const;
public:
    ~SwTextDocumentLayout();
public:
    SwTextDocumentLayout(const SwTextDocumentLayout& other);
    SwTextDocumentLayout& operator=(const SwTextDocumentLayout& other);
private:
    // What the class keeps (SwTextDocumentLayout_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
