﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwFrame.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwFrame in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the frame interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwFrame.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwFrame - frame/container widget.
 **************************************************************************************************/

#include "SwWidget.h"

class SW_WIDGETS_EXPORT SwFrame : public SwWidget {
    SW_OBJECT(SwFrame, SwWidget)

public:
    enum class Shape {
        NoFrame,
        Box,
        Panel,
        StyledPanel,
        HLine,
        VLine
    };

    enum class Shadow {
        Plain,
        Raised,
        Sunken
    };

    /**
     * @brief Constructs a `SwFrame` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwFrame(SwWidget* parent = nullptr);

    /**
     * @brief Sets the frame Shape.
     * @param shape Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFrameShape(Shape shape);

    /**
     * @brief Returns the current frame Shape.
     * @return The current frame Shape.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Shape frameShape() const;

    /**
     * @brief Sets the frame Shadow.
     * @param shadow Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFrameShadow(Shadow shadow);

    /**
     * @brief Returns the current frame Shadow.
     * @return The current frame Shadow.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Shadow frameShadow() const;

    /**
     * @brief Sets the line Width.
     * @param width Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLineWidth(int width);

    /**
     * @brief Returns the current line Width.
     * @return The current line Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int lineWidth() const;

    /**
     * @brief Sets the mid Line Width.
     * @param width Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setMidLineWidth(int width);

    /**
     * @brief Returns the current mid Line Width.
     * @return The current mid Line Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int midLineWidth() const;

    /**
     * @brief Returns the current frame Width.
     * @return The current frame Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int frameWidth() const;

protected:
    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

protected:
    /**
     * @brief Performs the `paintRoundedRectWithCorners` operation.
     * @param painter Value passed to the method.
     * @param rect Rectangle used by the operation.
     * @param tl Value passed to the method.
     * @param tr Value passed to the method.
     * @param br Value passed to the method.
     * @param bl Value passed to the method.
     * @param fill Value passed to the method.
     * @param border Value passed to the method.
     * @param borderWidth Value passed to the method.
     * @return The requested paint Rounded Rect With Corners.
     */
    static void paintRoundedRectWithCorners(SwPainter* painter,
                                           const SwRect& rect,
                                           int tl,
                                           int tr,
                                           int br,
                                           int bl,
                                           const SwColor& fill,
                                           const SwColor& border,
                                           int borderWidth);

    // clampInt, clampColor, parsePixelValue, resolveBackground, resolveBorder,
    // resolveBorderCornerRadii â€” inherited from SwWidget

    /**
     * @brief Performs the `paintChildren` operation.
     * @param event Event object forwarded by the framework.
     */
    void paintChildren(PaintEvent* event);

private:
    void initDefaults();

public:
    ~SwFrame();
private:
    // What the class keeps (SwFrame_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

