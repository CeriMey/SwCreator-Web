/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "SwSharedData.h"
#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwInteractiveConsoleApplication.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwInteractiveConsoleApplication in the CoreSw
 * GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the interactive console application interface. The
 * declarations exposed here define the stable surface that adjacent code can rely on while the
 * implementation remains free to evolve behind the header.
 *
 * The main declarations in this header are NonBlockingReader and SwInteractiveConsoleApplication.
 *
 * Application-oriented declarations here define the top-level lifecycle surface for startup,
 * shutdown, event processing, and integration with the rest of the framework.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


#include <SwCommandLineParser.h>
#include <SwCommandLineOption.h>
#include <SwJsonDocument.h>
#include <SwString.h>
#include <SwList.h>
#include <SwMap.h>
#include <SwTimer.h>
#include <functional>
#include <sstream>
#include <string>
#include <iostream>
static constexpr const char* kSwLogCategory_SwInteractiveConsoleApplication = "sw.core.gui.swinteractiveconsoleapplication";

class SW_WIDGETS_EXPORT NonBlockingReader {
public:
    /**
     * @brief Constructs a `NonBlockingReader` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    NonBlockingReader();

    /**
     * @brief Destroys the `NonBlockingReader` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~NonBlockingReader();

    /**
     * @brief Returns the current line Non Blocking.
     * @return The current line Non Blocking.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    std::string readLineNonBlocking();

private:
public:
    NonBlockingReader(const NonBlockingReader& other);
    NonBlockingReader& operator=(const NonBlockingReader& other);
private:
    // What the class keeps (SwInteractiveConsoleApplication_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

/**
 * Interactive console application to navigate through a JSON document.
 *
 * - Object nodes are considered sub-menus.
 * - Leaf nodes (values) are displayed with their value and an indicator [R] or [R/W].
 *   - [R] if no action is registered for that value.
 *   - [R/W] if an action (command) is registered via registerCommand().
 *
 * Supported commands:
 *  - help : Show help
 *  - pwd : Show current path
 *  - dir : List sub-elements of the current path
 *  - cd <name> : Navigate into a sub-node
 *  - cd.. : Go up one level
 *
 * Example of how to modify a leaf value:
 *
 *    interactiveApp.registerCommand("settings/display/brightness", [&](const SwString &value) {
 *        swCDebug(kSwLogCategory_SwInteractiveConsoleApplication) << "Current brightness: " << value.toStdString() << "\n";
 *        swCDebug(kSwLogCategory_SwInteractiveConsoleApplication) << "Enter a new value (q to quit without changing): ";
 *        std::string newVal = waitForNewValue("settings/display/brightness", "q");
 *        if (!newVal.empty()) {
 *            swCDebug(kSwLogCategory_SwInteractiveConsoleApplication) << "New brightness: " << newVal << "\n";
 *        } else {
 *            swCDebug(kSwLogCategory_SwInteractiveConsoleApplication) << "Value unchanged.\n";
 *        }
 *    });
 *
 * Additionally, when single line mode is enabled with setSingleLineMode(true),
 * the user input is always taken from the first line. After each command, the screen
 * is cleared and the new info is displayed below the prompt.
 */
class SW_WIDGETS_EXPORT SwInteractiveConsoleApplication: public SwObject {
public:

    /**
     * @brief Constructs the interactive console application.
     *
     * Initializes the JSON document @p config, ensuring the root node is an object, then starts an internal timer 
     * to poll standard input. This constructor also registers the built-in commands and displays the initial prompt.
     *
     * @param config Reference to the JSON document to be explored and possibly modified.
     */
    SwInteractiveConsoleApplication(SwJsonDocument &config);

    /**
     * @brief Registers a custom command (callback) for a specified JSON path.
     *
     * This method allows you to associate a callback (lambda, function, etc.) with a particular value node in the JSON document.
     * When the user inputs that JSON path in the console, the registered action is triggered. This feature enables 
     * read/write operations on leaf nodes as well as complex business logic.
     *
     * @param path The full JSON path to the value (e.g., "settings/display/brightness").
     * @param action A function that takes the current node value as an argument. Within this function, you can 
     *               display the current value, prompt the user for a new value (using @c waitForNewValue()), 
     *               or perform other modifications.
     */
    void registerCommand(const SwString &path, std::function<void(const SwString &value)> action);

    /**
     * @brief Adds a comment to a given JSON path.
     *
     * Registered comments can be displayed when showing the help (via @c help) or upon entering a node (during navigation).
     * This provides contextual information about certain paths.
     *
     * @param path The JSON path to annotate.
     * @param comment The comment string associated with the given path.
     */
    void addComment(const SwString &path, const SwString &comment);

    /**
     * @brief Waits for the user to input a new value for a specified node.
     *
     * Prompts the user to enter a new value. If the entered value differs from the escape command @p esc, 
     * it is written to the JSON document (via @c setValue()). If the user enters the escape command, 
     * no changes are applied.
     *
     * @param path The JSON path to modify. If empty, the function simply returns the user's input without updating the document.
     * @param esc The escape command (e.g., "q") that cancels the operation. If empty, all user input is considered valid.
     * @return The new user-entered value, or an empty string if the operation was canceled or an error occurred.
     */
    std::string waitForNewValue(const SwString &path = "", const SwString &esc = "");

    /**
     * @brief Updates the value of a JSON node.
     *
     * Attempts to write a new value to a given node. If the path is invalid, or the node is an object (not a leaf),
     * no update is performed.
     *
     * @param path The full JSON path to the node to be updated.
     * @param newValue The new value to set.
     * @return @c true if the value was successfully updated, @c false otherwise.
     */
    bool setValue(const SwString &path, const SwString &newValue);

    /**
     * @brief Enables or disables single-line mode.
     *
     * In single-line mode, the application clears the screen after each input and repositions the cursor 
     * so that the prompt always appears on the first line and command results follow below it.
     *
     * @param enabled @c true to enable single-line mode, @c false to disable it.
     */
    void setSingleLineMode(bool enabled);

private:

    /**
     * @brief Internal method, invoked regularly by the timer, to read and process user input.
     *
     * This function polls standard input (stdin) and, if a line is available, processes it via @c processLine(). 
     * If single-line mode is active, the screen is cleared and the prompt is repositioned before and after processing.
     */
    void pollInput();

    /**
     * @brief Processes a single line of user input.
     *
     * Analyzes the input line and performs the corresponding action:
     * - Executes built-in commands (help, pwd, dir, cd, cd..)
     * - Navigates to a specified JSON node
     * - Displays or modifies a JSON value
     * - Executes a custom registered command if available
     *
     * @param line The line of user input.
     * @return A string representing the output to display in the console (result, error message, etc.).
     */
    std::string processLine(const SwString &line);

    /**
     * @brief Registers built-in commands (help, pwd, dir, cd, etc.) and associates comments with them.
     *
     * Called from the constructor to provide contextual information in the help menu and navigation.
     */
    void registerNativeCommands();

    /**
     * @brief Lists the sub-elements of the current JSON node.
     *
     * Iterates over the current JSON node and lists its keys. For each key:
     * - If the node is an object, it is considered a sub-menu.
     * - If it is a leaf value, it displays the value and shows [R/W] if a command is associated 
     *   with that node, or [R] if it is read-only.
     *
     * @return A string describing the sub-elements of the current node.
     */
    std::string listCurrentNode();

    /**
     * @brief Navigates up one level in the JSON hierarchy.
     *
     * If already at the root, it prints a message indicating that you cannot go higher.
     *
     * @return A string indicating the current path after navigation.
     */
    std::string navigateUp();

    /**
     * @brief Navigates to a child node via @c cd <path>.
     *
     * Moves directly to a specified child node. If the node does not exist or is not an object, 
     * an error message is returned.
     *
     * @param target The name or path of the sub-node to navigate to.
     * @return A string indicating the current path after navigation.
     */
    std::string navigateTo(const SwString &target);

    /**
     * @brief Displays the help information for the application.
     *
     * Builds the help output recursively by traversing the JSON hierarchy. It shows comments attached to paths 
     * as well as details about commands and nodes. Both built-in and custom-annotated nodes are presented.
     *
     * @return A string containing the complete help text.
     */
    std::string printHelp();

     /**
     * @brief A helper function for recursive help display.
     *
     * Recursively walks through the JSON tree starting from @p node and builds a full @p path.
     * It displays associated comments, and if the node is an object, it calls itself recursively for its children.
     *
     * @param node The current JSON node.
     * @param path The current JSON path.
     * @param output The output stream used to build the help text.
     */
    void printHelpRecursive(const SwJsonValue &node, const SwString &path, std::ostringstream &output);

    /**
     * @brief Prints the prompt in the console.
     *
     * By default, the prompt is simply "> ".
     */
    void printPrompt();

    /**
     * @brief Clears the console screen.
     *
     * Uses the appropriate system command depending on the platform. On Windows, it executes @c cls, 
     * and on other systems @c clear.
     */
    void clearScreen();

public:
    ~SwInteractiveConsoleApplication();
private:
    // What the class keeps (SwInteractiveConsoleApplication_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
