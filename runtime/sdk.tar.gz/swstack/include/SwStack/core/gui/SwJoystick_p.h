#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwJoystick.h"
#include "core/gui/SwJoystick3D_p.h"

#include <memory>

struct SwJoystick::Data {
    float m_tiltX;
    float m_tiltY;
    Type m_Type{Type::Gamepad};
    bool m_Type_registered_ = sw_register_Type_();
    float m_StickHeight{12.0f};
    bool m_StickHeight_registered_ = sw_register_StickHeight_();
    bool m_customStickHeight{false};
    bool m_dragging;
    int m_pressX{0};
    int m_pressY{0};
    float m_pressTiltX{0.0f};
    float m_pressTiltY{0.0f};
    RepeatMode m_repeatMode;
    int m_repeatInterval;
    SwTimer* m_repeatTimer;
    bool m_dirty;
    std::unique_ptr<SwJoystick3D> m_renderer;
};
