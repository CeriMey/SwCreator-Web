﻿/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwSplitter.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwSplitter in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the splitter interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwSplitter.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwSplitter - splitter widget.
 *
 * Minimal implementation:
 * - Supports N children arranged in a row/column with draggable handles.
 * - Stores pixel sizes and keeps the sum consistent when dragging a handle.
 **************************************************************************************************/

#include "SwWidget.h"
#include "SwVector.h"

class SW_WIDGETS_EXPORT SwSplitter : public SwWidget {
    SW_OBJECT(SwSplitter, SwWidget)

    SW_PROPERTY_D(bool, ChildrenCollapsible);
private:
protected:

public:
    enum class Orientation {
        Horizontal,
        Vertical
    };

    /**
     * @brief Constructs a `SwSplitter` instance.
     * @param orientation Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @param orientation Value passed to the method.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwSplitter(Orientation orientation = Orientation::Horizontal, SwWidget* parent = nullptr);

    /**
     * @brief Sets the orientation.
     * @param orientation Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOrientation(Orientation orientation);

    /**
     * @brief Returns the current orientation.
     * @return The current orientation.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Orientation orientation() const;

    /**
     * @brief Sets the handle Width.
     * @param width Width value.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHandleWidth(int width);

    /**
     * @brief Returns the current handle Width.
     * @return The current handle Width.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int handleWidth() const;

    /**
     * @brief Sets the opaque Resize.
     * @param enabled Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOpaqueResize(bool enabled);

    /**
     * @brief Returns the current opaque Resize.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool opaqueResize() const;

    /**
     * @brief Adds the specified widget.
     * @param widget Widget associated with the operation.
     */
    void addWidget(SwWidget* widget);

    /**
     * @brief Performs the `insertWidget` operation.
     * @param index Value passed to the method.
     * @param widget Widget associated with the operation.
     */
    void insertWidget(int index, SwWidget* widget);

    // Releases a managed slot without deleting or reparenting its widget.
    void removeWidget(SwWidget* widget);
    int indexOf(SwWidget* widget) const;

    /**
     * @brief Performs the `count` operation.
     * @return The current count value.
     */
    int count() const;

    /**
     * @brief Performs the `widget` operation.
     * @param index Value passed to the method.
     * @return The requested widget.
     */
    SwWidget* widget(int index) const;

    /**
     * @brief Sets the sizes.
     * @param sizes Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSizes(const SwVector<int>& sizes);

    /**
     * @brief Returns the current sizes.
     * @return The current sizes.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwVector<int> sizes() const;

    void setCollapsible(int index, bool collapsible);

    bool isCollapsible(int index) const;

    SW_SIGNAL(splitterMoved, int, int);

protected:
    SwSize sizeHint() const override;

    SwSize minimumSizeHint() const override;

    /**
     * @brief Handles the resize Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void resizeEvent(ResizeEvent* event) override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;

    /**
     * @brief Handles the mouse Press Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mousePressEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Move Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseMoveEvent(MouseEvent* event) override;

    /**
     * @brief Handles the mouse Release Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void mouseReleaseEvent(MouseEvent* event) override;

private:
    static SwRect unionRect_(const SwRect& a, const SwRect& b);

    static bool containsPoint(const SwRect& r, int px, int py);

    struct HandleStyle_ {
        SwColor handleColor{236, 236, 236};
        SwColor handleColorHover{220, 224, 232};
        SwColor handleColorPressed{210, 216, 228};
        SwColor handleBorderColor{210, 210, 210};
        SwColor handleBorderColorHover{180, 186, 198};
        SwColor handleBorderColorPressed{160, 168, 182};
        SwColor gripColor{150, 150, 150};
        SwColor gripColorHover{138, 144, 154};
        SwColor gripColorPressed{125, 132, 144};
        int visualWidth{-1};
        int borderWidth{-1};
        int radius{-1};
    };

    int primaryLength(const SwRect& r) const;

    int handleCount() const;

    int sizesSum() const;

    void normalizeCollapsedSizes_();

    int effectiveMinimumPrimarySize_(int index) const;

    int collapseSnapThreshold_(int visibleMinimum) const;

    void ensureSizesInitialized(int available);

    void enforceMinimumSizes_(int available);

    int handleAt(int px, int py) const;

    int radiusFor_(const SwRect& r, int explicitRadius) const;

    HandleStyle_ resolveHandleStyle_() const;

    int prefixSize(int widgetIndex) const;

    SwRect handleRect(int handleIndex) const;

    SwRect visualHandleRect_(int handleIndex, const HandleStyle_& style, int extraPrimaryThickness = 0) const;

    SwRect hoverHitRect_(int handleIndex, const HandleStyle_& style) const;

    void invalidateRect_(const SwRect& r);

    void invalidateHandle_(int handleIdx);

    void cancelHoverReset_();

    void scheduleHoverReset_();

    void updateLayout();

    void dragHandle(int handleIdx, int axisPos);

    void initDefaults();

    int childMinimumPrimarySize_(int index) const;

    SwSize splitterSizeHint_(bool minimum) const;

    static SwString styleValue_(const StyleSheet* sheet,
                                const SwList<SwString>& hierarchy,
                                const char* propertyName);

    static bool tryParseColor_(const StyleSheet* sheet, const SwString& value, SwColor& out);


public:
    ~SwSplitter();
private:
    // What the class keeps (SwSplitter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

