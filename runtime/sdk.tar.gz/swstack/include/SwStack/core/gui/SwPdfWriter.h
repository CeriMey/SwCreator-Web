#pragma once

#include "SwSharedData.h"
#include "../SwStackExport.h"

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "../types/SwString.h"
#include "../types/SwList.h"
#include "../types/Sw.h"
#include "SwFont.h"

#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// SwPdfWriter — low-level PDF file generator
//
// Generates valid PDF 1.4 files with text rendering, lines, rectangles,
// and font embedding (using the 14 standard PDF fonts).
//
// Usage:
//   SwPdfWriter pdf("output.pdf");
//   pdf.setPageSize(595, 842);  // A4 in points (72 dpi)
//   pdf.beginPage();
//   pdf.setFont("Helvetica", 12);
//   pdf.drawText(72, 750, "Hello World!");
//   pdf.endPage();
//   pdf.save();
// ---------------------------------------------------------------------------

class SW_GUI_EXPORT SwPdfWriter {
public:
    explicit SwPdfWriter(const SwString& filename);

    ~SwPdfWriter();

    // --- Page setup ---
    void setPageSize(int widthPt, int heightPt);

    void setPageSizeA4();
    void setPageSizeLetter();

    void setMargins(int top, int right, int bottom, int left);

    int pageWidth() const;
    int pageHeight() const;

    int contentWidth() const;
    int contentHeight() const;

    // --- Page management ---
    void beginPage();

    void endPage();

    int pageCount() const;

    // --- Font ---
    void setFont(const std::string& name, int size);

    void setFontFromSwFont(const SwFont& font);

    // --- Colors ---
    void setFillColor(const SwColor& c);

    void setStrokeColor(const SwColor& c);

    void setLineWidth(float w);

    // --- Drawing primitives ---
    // Note: PDF coordinates have (0,0) at bottom-left, Y goes up.
    // These methods accept top-left coordinates and convert internally.

    void drawText(int x, int y, const SwString& text);

    void drawTextAt(int x, int y, const SwString& text, const SwFont& font, const SwColor& color);

    void drawLine(int x1, int y1, int x2, int y2);

    void drawLine(int x1, int y1, int x2, int y2, const SwColor& color, int width);

    void drawRect(int x, int y, int w, int h);

    void drawRect(int x, int y, int w, int h, const SwColor& borderColor, int borderWidth);

    void fillRect(int x, int y, int w, int h);

    void fillRect(int x, int y, int w, int h, const SwColor& color);

    // --- Save state / Restore state ---
    void save();

    void restore();

    // --- Write the PDF file ---
    bool writePdf();

private:

    int registerFont(const std::string& name);

    // Decode a UTF-8 string into WinAnsiEncoding (single-byte per character),
    // then PDF-escape the result. Type1 fonts with /WinAnsiEncoding expect
    // single-byte character codes, not raw UTF-8 multi-byte sequences.
    static std::string escapePdfString(const std::string& s);

    // Map a Unicode code point to the WinAnsiEncoding byte value.
    // Returns 0 if the character has no WinAnsi mapping.
    static unsigned char unicodeToWinAnsi(unsigned int cp);
public:
    SwPdfWriter(const SwPdfWriter& other);
    SwPdfWriter& operator=(const SwPdfWriter& other);
private:
    // What the class keeps (SwPdfWriter_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
