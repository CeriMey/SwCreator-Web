#pragma once

// Internal native frame shared by modern and tabbed windows. No public inheritance.
#include "SwMainWindow.h"
#include "SwCoreApplication.h"
#include "SwPointer.h"
#include <algorithm>
#include <functional>
#include <memory>
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#include "platform/win/SwWin32Dpi_p.h"
#include <commctrl.h>
#endif

class SwCustomWindowFrame final {
public:
    SwMainWindow* window;
    SwWidget* header;
    SwPushButton* maximize;
    std::function<bool(const SwPoint&)> captionAt;
    bool customCaption{false};

    SwCustomWindowFrame(SwMainWindow* owner, SwWidget* bar, SwPushButton* max,
                        std::function<bool(const SwPoint&)> caption)
        : window(owner), header(bar), maximize(max), captionAt(std::move(caption)) {}
    SwCustomWindowFrame(const SwCustomWindowFrame&) = delete;
    SwCustomWindowFrame& operator=(const SwCustomWindowFrame&) = delete;
    ~SwCustomWindowFrame() {
        lifetime.reset();
#if defined(_WIN32)
        if (handle && IsWindow(handle)) RemoveWindowSubclass(handle, procedure, subclassId);
#endif
    }
    void attach() {
#if defined(_WIN32)
        handle = static_cast<HWND>(window->platformHandle().nativeHandle);
        customCaption = handle && SetWindowSubclass(handle, procedure, subclassId, reinterpret_cast<DWORD_PTR>(this));
        if (customCaption) SetWindowPos(handle, nullptr, 0, 0, 0, 0,
            SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
#endif
    }
    bool isMaximized() const {
#if defined(_WIN32)
        return handle && IsZoomed(handle);
#else
        return false;
#endif
    }
    bool requestClose() {
#if defined(_WIN32)
        if (handle) { PostMessageW(handle, WM_CLOSE, 0, 0); return true; }
#endif
        return false;
    }
    void resizeNativeWindow(const SwSize& size) {
#if defined(_WIN32)
        RECT frame{}, client{};
        if (customCaption && GetWindowRect(handle, &frame) && GetClientRect(handle, &client)) {
            const auto minimum = window->minimumSizeHint();
            const UINT dpi = swWin32Dpi::dpiForWindow(handle);
            SetWindowPos(handle, nullptr, 0, 0,
                swWin32Dpi::toNative(std::max(size.width, minimum.width), dpi) + frame.right - frame.left - client.right,
                swWin32Dpi::toNative(std::max(size.height, minimum.height), dpi) + frame.bottom - frame.top - client.bottom,
                SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
            if (GetClientRect(handle, &client)) window->SwWidget::resize(
                swWin32Dpi::toLogical(client.right, dpi), swWin32Dpi::toLogical(client.bottom, dpi));
            return;
        }
#endif
        window->SwMainWindow::resizeNativeWindow(size);
    }
private:
    bool closeQueued{false}, dispatchingClose{false};
    std::shared_ptr<int> lifetime{std::make_shared<int>(0)};
#if defined(_WIN32)
    HWND handle{nullptr};
    static constexpr UINT_PTR subclassId = 0x53574D57;
    static bool contains(const SwRect& r, const SwPoint& p) {
        return p.x >= r.x && p.y >= r.y && p.x < r.x+r.width && p.y < r.y+r.height;
    }
    static LRESULT CALLBACK procedure(HWND handle, UINT message, WPARAM wp, LPARAM lp, UINT_PTR, DWORD_PTR data) {
        auto* state = reinterpret_cast<SwCustomWindowFrame*>(data);
        if (message == WM_NCCALCSIZE && wp) {
            auto* params = reinterpret_cast<NCCALCSIZE_PARAMS*>(lp);
            const RECT proposed = params->rgrc[0];
            const auto result = DefSubclassProc(handle, message, wp, lp);
            params->rgrc[0].top = proposed.top + (IsZoomed(handle) ? params->rgrc[0].left - proposed.left : 0);
            return result;
        }
        if (message == WM_NCHITTEST) {
            const auto result = DefSubclassProc(handle, message, wp, lp);
            if (result != HTCLIENT) return result;
            POINT point{static_cast<short>(LOWORD(lp)), static_cast<short>(HIWORD(lp))};
            point = swWin32Dpi::screenToClient(handle, point);
            if (!IsZoomed(handle) && point.y < 5) {
                if (point.x < 16) return HTTOPLEFT;
                if (point.x >= state->window->width()-16) return HTTOPRIGHT;
                return HTTOP;
            }
            const SwPoint local = state->header->mapFrom(state->window, {point.x,point.y});
            if (state->maximize->isVisibleInHierarchy() && contains(state->maximize->geometry(),local)) return HTMAXBUTTON;
            return state->captionAt({point.x,point.y}) ? HTCAPTION : HTCLIENT;
        }
        // Preserve Snap discovery, while normal SwStack input owns presses and capture.
        if ((message == WM_NCLBUTTONDOWN || message == WM_NCLBUTTONDBLCLK || message == WM_NCLBUTTONUP) && wp == HTMAXBUTTON) {
            POINT point{static_cast<short>(LOWORD(lp)), static_cast<short>(HIWORD(lp))};
            ScreenToClient(handle, &point);
            const bool release = message == WM_NCLBUTTONUP;
            WPARAM buttons = release ? 0 : MK_LBUTTON;
            if (GetKeyState(VK_CONTROL)&0x8000) buttons |= MK_CONTROL;
            if (GetKeyState(VK_SHIFT)&0x8000) buttons |= MK_SHIFT;
            return DefSubclassProc(handle, release ? WM_LBUTTONUP : WM_LBUTTONDOWN, buttons, MAKELPARAM(point.x,point.y));
        }
        if (message == WM_NCMOUSEMOVE || message == WM_NCMOUSELEAVE) {
            state->maximize->setHover(message == WM_NCMOUSEMOVE && wp == HTMAXBUTTON);
            if (message == WM_NCMOUSEMOVE) {
                TRACKMOUSEEVENT track{sizeof(TRACKMOUSEEVENT),TME_NONCLIENT|TME_LEAVE,handle,0}; TrackMouseEvent(&track);
            }
            if (message == WM_NCMOUSELEAVE || wp == HTMAXBUTTON) return 0;
        }
        if (message == WM_CLOSE && !state->dispatchingClose) {
            if (auto* app = SwCoreApplication::instance(false)) {
                if (!state->closeQueued) {
                    state->closeQueued = true;
                    const std::weak_ptr<int> alive = state->lifetime;
                    app->postEvent([state,alive,handle] {
                        if (alive.expired() || state->handle != handle) return;
                        state->dispatchingClose = true;
                        SendMessageW(handle,WM_CLOSE,0,0);
                        if (!alive.expired()) { state->dispatchingClose = false; state->closeQueued = false; }
                    });
                }
                return 0;
            }
        }
        if (message == WM_GETMINMAXINFO) {
            const auto result = DefSubclassProc(handle,message,wp,lp);
            auto* limits = reinterpret_cast<MINMAXINFO*>(lp);
            RECT frame{},client{};
            if (limits && GetWindowRect(handle,&frame) && GetClientRect(handle,&client)) {
                const auto minimum = state->window->minimumSizeHint();
                const UINT dpi = swWin32Dpi::dpiForWindow(handle);
                // Subtract the native caption removed by WM_NCCALCSIZE.
                using MetricsForDpi = int (WINAPI*)(int, UINT);
                static auto metricsForDpi = reinterpret_cast<MetricsForDpi>(
                    GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetSystemMetricsForDpi"));
                const int caption = metricsForDpi ? metricsForDpi(SM_CYCAPTION, dpi) : GetSystemMetrics(SM_CYCAPTION);
                limits->ptMinTrackSize.y = std::max(limits->ptMinTrackSize.y-caption,
                    swWin32Dpi::toNative(minimum.height, dpi)+(frame.bottom-frame.top)-client.bottom);
            }
            return result;
        }
        if (message == WM_NCDESTROY) {
            RemoveWindowSubclass(handle,procedure,subclassId);
            state->handle = nullptr; state->customCaption = false;
        }
        // DefSubclassProc may destroy the owner through application callbacks.
        const std::weak_ptr<int> alive = state->lifetime;
        const auto result = DefSubclassProc(handle,message,wp,lp);
        if (!alive.expired() && (message == WM_SIZE || message == WM_SETTEXT)) state->header->update();
        return result;
    }
#endif
};
