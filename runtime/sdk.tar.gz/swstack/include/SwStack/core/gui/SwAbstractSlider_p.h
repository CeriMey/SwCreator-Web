#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwAbstractSlider.h"

struct SwAbstractSlider::Data {
    Orientation m_orientation;
    double m_minimum;
    double m_maximum;
    double m_value;
    double m_step;
    double m_bufferValue;
    bool m_dragging;
    int m_trackThickness;
    int m_handleRadius;
    int m_padding;
    SwColor m_trackColor;
    SwColor m_trackBorder;
    SwColor m_bufferColor;
    SwColor m_progressColor;
    SwColor m_handleColor;
    SwColor m_handleBorder;
};
