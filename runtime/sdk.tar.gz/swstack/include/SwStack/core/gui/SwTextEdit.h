﻿#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwTextEdit.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwTextEdit in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the text edit interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwTextEdit.
 *
 * The declarations in this header are intended to make the subsystem boundary explicit: callers
 * interact with stable types and functions, while implementation details remain confined to
 * source files and private helpers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwPlainTextEdit.h"
#include "SwTextDocument.h"
#include "SwTextCursor.h"
#include "SwTextDocumentWriter.h"

#include <algorithm>
#include <cctype>
#include <cstddef>
#include <sstream>
#include <string>
#include <vector>

class SW_WIDGETS_EXPORT SwTextEdit : public SwPlainTextEdit {
    SW_OBJECT(SwTextEdit, SwPlainTextEdit)

public:
    /**
     * @brief Constructs a `SwTextEdit` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwTextEdit(SwWidget* parent = nullptr);

    /**
     * @brief Sets the text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setText(const SwString& text);

    /**
     * @brief Sets the plain Text.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setPlainText(const SwString& text);
    /**
     * @brief Performs the `appendPlainText` operation.
     * @param text Value passed to the method.
     */
    void appendPlainText(const SwString& text);
    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Sets the html.
     * @param html Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHtml(const SwString& html);
    /**
     * @brief Returns the current to Html.
     * @return The current to Html.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString toHtml() const;

    // --- Document model integration (Qt-compatible API) ---
    SwTextDocument* document() const;
    void setDocument(SwTextDocument* doc);
    SwTextCursor textCursor() const;

    // --- PDF export ---
    bool print(const SwString& pdfFilename, const SwFont& font = SwFont()) const;

protected:
    /**
     * @brief Returns the current capture Edit State.
     * @return The current capture Edit State.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    EditState captureEditState() const override;

    /**
     * @brief Handles the paint Event forwarded by the framework.
     * @param event Event object forwarded by the framework.
     *
     * @details Override this hook when the default framework behavior needs to be extended or replaced.
     */
    void paintEvent(PaintEvent* event) override;
    void wheelEvent(WheelEvent* event) override;
    /**
     * @brief Updates the cursor From Position managed by the object.
     * @param px Value passed to the method.
     * @param py Value passed to the method.
     */
    void updateCursorFromPosition(int px, int py) override;

    /**
     * @brief Performs the `insertTextAt` operation.
     * @param pos Position used by the operation.
     * @param text Value passed to the method.
     */
    void insertTextAt(size_t pos, const SwString& text) override;
    /**
     * @brief Performs the `eraseTextAt` operation.
     * @param pos Position used by the operation.
     * @param len Value passed to the method.
     */
    void eraseTextAt(size_t pos, size_t len) override;

private:
    struct SW_WIDGETS_EXPORT TextFormat {
        bool bold{false};
        bool italic{false};
        bool underline{false};
        bool strikethrough{false};
        bool hasColor{false};
        SwColor color{0, 0, 0};
        bool hasBgColor{false};
        SwColor bgColor{255, 255, 255};
        int fontSize{0};            // 0 = inherit from widget font
        std::string fontFamily;     // empty = inherit
        std::string href;           // non-empty = hyperlink

        bool operator==(const TextFormat& other) const;
        bool operator!=(const TextFormat& other) const;
    };

    struct Run {
        SwString text;
        TextFormat format;
    };

    struct LineFormat {
        int headingLevel{0};        // 0=normal, 1-6 = h1-h6
        enum ListType { NoList, Unordered, Ordered };
        ListType listType{NoList};
        int listIndex{0};           // 1-based for ordered lists
        int indentLevel{0};
        enum Align { AlignLeft, AlignCenter, AlignRight };
        Align alignment{AlignLeft};
        bool isHr{false};           // horizontal rule
    };


    static std::string toLower(std::string s);
    static std::string trim(std::string s);

    static SwString escapeHtmlWithLineBreaks(const SwString& text);
    static SwString colorToCss(const SwColor& c);
    static bool parseInt(const std::string& s, int& out);
    static bool parseCssColor(const std::string& color, SwColor& out);
    static SwString decodeHtmlEntities(const std::string& in);
    static TextFormat parseInlineStyle(const std::string& style, TextFormat base);
    static std::string extractAttribute(const std::string& attrs, const std::string& name);
    static std::vector<Run> parseHtml(const SwString& html);

    void normalizeRuns();
    void rebuildRunsFromPlainText();
    bool runsMatchPlainText() const;
    void ensureRunsInSync() const;

    TextFormat formatForInsertionAt(size_t pos) const;
    TextFormat formatAtChar(size_t pos) const;
    SwFont fontForFormat(const TextFormat& fmt) const;

    void insertIntoRuns(size_t pos, char ch, const TextFormat& fmt);
    void eraseFromRuns(size_t pos);

    void drawRichLine(SwPainter* painter,
                      const SwRect& inner,
                      int y,
                      int lh,
                      size_t lineStart,
                      size_t lineLen,
                      const SwColor& defaultTextColor) const;
    int richTextWidth(size_t start, size_t length, int defaultWidth) const;
    size_t richCharacterIndexAtPosition(size_t lineStart, size_t lineLen, int relativeX, int defaultWidth) const;

    int lineHeightForLine(int lineIndex) const;
    int yOffsetForLine(int lineIndex, int firstVisible) const;
    int lineIndexAtY(int relativeY, int firstVisible) const;
    int visibleLineCount(int firstVisible, int availableHeight) const;
    LineFormat lineFormatAt(int lineIndex) const;
    int headingFontSize(int headingLevel) const;
    int listIndentPx() const;

    struct TableCell {
        SwString text;
        TextFormat format;
        bool isHeader{false};
        bool hasBg{false};
        SwColor bgColor{255,255,255};
    };
    struct SW_WIDGETS_EXPORT EmbeddedTable {
        int lineIndex{-1};          // which logical line this table sits on
        int borderWidth{1};
        int cellPadding{4};
        SwColor borderColor{100,100,100};
        bool hasBg{false};
        SwColor bgColor{255,255,255};
        std::vector<std::vector<TableCell>> rows;
        int columns() const;
    };

    struct ParseResult {
        std::vector<Run> runs;
        std::vector<LineFormat> lineFormats;
        std::vector<EmbeddedTable> tables;
    };
    static ParseResult parseHtmlFull(const SwString& html);

    const EmbeddedTable* tableForLogicalLine(int logicalLine) const;

    size_t documentLength_() const;

    bool documentIsEmpty_() const;

    SwString documentText_() const;

    int logicalLineCount_() const;

    size_t logicalLineStart_(int lineIndex) const;

    size_t logicalLineLength_(int lineIndex) const;

    SwString logicalLineText_(int lineIndex) const;

    const EmbeddedTable* tableForLine(int visualLineIndex) const;

    int tableHeight(const EmbeddedTable& tbl) const;
public:
    ~SwTextEdit();
private:
    // What the class keeps (SwTextEdit_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

// ---------------------------------------------------------------------------
// SwTextDocument integration
// ---------------------------------------------------------------------------

