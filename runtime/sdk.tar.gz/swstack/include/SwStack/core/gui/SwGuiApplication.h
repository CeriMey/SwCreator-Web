/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwGuiApplication.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwGuiApplication in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the GUI application interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwGuiApplication.
 *
 * Application-oriented declarations here define the top-level lifecycle surface for startup,
 * shutdown, event processing, and integration with the rest of the framework.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwGuiApplication now acts as a thin wrapper around the platform abstraction layer.
 ***************************************************************************************************/

/**
 * @file
 * @brief Declares the GUI application entry point for the SwStack widget runtime.
 *
 * SwGuiApplication extends SwCoreApplication with the pieces needed by visual
 * applications: it creates the active platform integration, lets that backend
 * pump native window-system events, and interleaves those events with the core
 * event loop maintained by SwCoreApplication.
 */

#include "SwCoreApplication.h"
#include "SwWidgetPlatformAdapter.h"
#include "platform/SwPlatformFactory.h"
#include "platform/SwPlatformIntegration.h"

#include <algorithm>
#include <chrono>
#include <memory>
#include <stdexcept>
#include <thread>

/**
 * @brief Coordinates the core event loop with the selected GUI platform backend.
 *
 * A SwGuiApplication owns the process-wide platform integration object and keeps
 * native input, paint, and windowing events flowing alongside the framework's
 * own timers, posted events, and waitable objects.
 */
class SW_GUI_EXPORT SwGuiApplication : public SwCoreApplication {
public:
    /**
     * @brief Constructs a `SwGuiApplication` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwGuiApplication();

    SwGuiApplication(int argc, char* argv[]);

    /**
     * @brief Destroys the `SwGuiApplication` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwGuiApplication() override;

    /**
     * @brief Performs the `instance` operation.
     * @param create Value passed to the method.
     * @return The requested instance.
     */
    static SwGuiApplication*& instance(bool create = true);

    /**
     * @brief One turn of the GUI loop for a foreign event loop: see SwCoreApplication::processEventsFor().
     *
     * @details What exec() does per iteration, minus the waiting: the work that is due, then the
     * damage flushed into one repaint per window. On Windows the foreign loop is also the one that
     * dispatches this thread's messages, SwStack's windows included, so SwStack must not pump them
     * itself: that would dispatch the host's messages from inside SwStack and swallow its WM_QUIT.
     * Elsewhere SwStack's own display connection is not a source the host knows, so it is read here,
     * and the host is asked back at frame rate while nothing else is due.
     */
    std::int64_t processEventsFor(int maxMicroseconds) override;

    /**
     * @brief Performs the `exec` operation.
     * @param maxDurationMicroseconds Value passed to the method.
     * @return The requested exec.
     */
    int exec(int maxDurationMicroseconds = 0) override;

    /**
     * @brief Returns the current platform Integration.
     * @return The current platform Integration.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwPlatformIntegration* platformIntegration() const;

    /// Parent for GUI resources that must be destroyed before the platform integration.
    SwObject* graphicsResourceOwner();

private:
private:
    // What the class keeps (SwGuiApplication_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
