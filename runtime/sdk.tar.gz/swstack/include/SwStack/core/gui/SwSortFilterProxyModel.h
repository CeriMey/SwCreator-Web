/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#pragma once

#include <memory>
#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwSortFilterProxyModel.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwSortFilterProxyModel in the CoreSw GUI layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the sort filter proxy model interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwSortFilterProxyModel.
 *
 * Model-oriented declarations here define the data contract consumed by views, delegates, or
 * algorithms, with an emphasis on stable roles, ownership, and update flow rather than on
 * presentation details.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */


/***************************************************************************************************
 * SwSortFilterProxyModel - sort/filter proxy model.
 *
 * Scope (v1):
 * - Wraps a source SwAbstractItemModel.
 * - Provides row filtering (fixed string or regex) and per-parent sorting.
 * - Emits modelReset on invalidation (simple + robust for the current MVC stack).
 **************************************************************************************************/

#include "SwAbstractItemModel.h"

#include "core/types/SwList.h"
#include "core/types/SwRegularExpression.h"
#include "core/types/SwString.h"

#include <algorithm>
#include <unordered_map>

class SW_CORE_EXPORT SwSortFilterProxyModel : public SwAbstractItemModel {
    SW_OBJECT(SwSortFilterProxyModel, SwAbstractItemModel)

public:
    /**
     * @brief Constructs a `SwSortFilterProxyModel` instance.
     * @param parent Optional parent object that owns this instance.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    explicit SwSortFilterProxyModel(SwObject* parent = nullptr);

    /**
     * @brief Sets the source Model.
     * @param source Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSourceModel(SwAbstractItemModel* source);

    /**
     * @brief Returns the current source Model.
     * @return The current source Model.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwAbstractItemModel* sourceModel() const;

    /**
     * @brief Sets the filter Fixed String.
     * @param text Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFilterFixedString(const SwString& text);

    /**
     * @brief Returns the current filter Fixed String.
     * @return The current filter Fixed String.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString filterFixedString() const;

    /**
     * @brief Sets the filter Regular Expression.
     * @param re Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFilterRegularExpression(const SwRegularExpression& re);

    /**
     * @brief Returns the current filter Regular Expression.
     * @return The current filter Regular Expression.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwRegularExpression filterRegularExpression() const;

    /**
     * @brief Sets the filter Case Sensitivity.
     * @param cs Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFilterCaseSensitivity(Sw::CaseSensitivity cs);

    /**
     * @brief Returns the current filter Case Sensitivity.
     * @return The current filter Case Sensitivity.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Sw::CaseSensitivity filterCaseSensitivity() const;

    /**
     * @brief Sets the filter Key Column.
     * @param column Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFilterKeyColumn(int column);

    /**
     * @brief Returns the current filter Key Column.
     * @return The current filter Key Column.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int filterKeyColumn() const;

    /**
     * @brief Sets the filter Role.
     * @param role Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFilterRole(SwItemDataRole role);

    /**
     * @brief Returns the current filter Role.
     * @return The current filter Role.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwItemDataRole filterRole() const;

    /**
     * @brief Sets the sort Role.
     * @param role Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSortRole(SwItemDataRole role);

    /**
     * @brief Returns the current sort Role.
     * @return The current sort Role.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwItemDataRole sortRole() const;

    /**
     * @brief Sets the sort Case Sensitivity.
     * @param cs Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setSortCaseSensitivity(Sw::CaseSensitivity cs);

    /**
     * @brief Returns the current sort Case Sensitivity.
     * @return The current sort Case Sensitivity.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Sw::CaseSensitivity sortCaseSensitivity() const;

    /**
     * @brief Performs the `invalidate` operation.
     */
    void invalidate();

    /**
     * @brief Performs the `mapToSource` operation.
     * @param proxyIndex Value passed to the method.
     * @return The requested map To Source.
     */
    SwModelIndex mapToSource(const SwModelIndex& proxyIndex) const;

    /**
     * @brief Performs the `mapFromSource` operation.
     * @param sourceIndex Value passed to the method.
     * @return The requested map From Source.
     */
    SwModelIndex mapFromSource(const SwModelIndex& sourceIndex) const;

    // SwAbstractItemModel overrides
    /**
     * @brief Performs the `index` operation.
     * @param row Value passed to the method.
     * @param column Value passed to the method.
     * @param parent Optional parent object that owns this instance.
     * @return The requested index.
     */
    SwModelIndex index(int row, int column, const SwModelIndex& parent = SwModelIndex()) const override;

    /**
     * @brief Performs the `parent` operation.
     * @param child Value passed to the method.
     * @return The requested parent.
     */
    SwModelIndex parent(const SwModelIndex& child) const override;

    /**
     * @brief Performs the `rowCount` operation.
     * @param parent Optional parent object that owns this instance.
     * @return The requested row Count.
     */
    int rowCount(const SwModelIndex& parent = SwModelIndex()) const override;

    /**
     * @brief Performs the `columnCount` operation.
     * @param parent Optional parent object that owns this instance.
     * @return The requested column Count.
     */
    int columnCount(const SwModelIndex& parent = SwModelIndex()) const override;

    /**
     * @brief Performs the `data` operation.
     * @param index Value passed to the method.
     * @param role Value passed to the method.
     * @return The requested data.
     */
    SwAny data(const SwModelIndex& index, SwItemDataRole role = SwItemDataRole::DisplayRole) const override;

    /**
     * @brief Sets the data.
     * @param index Value passed to the method.
     * @param value Value passed to the method.
     * @param role Value passed to the method.
     * @return `true` on success; otherwise `false`.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    bool setData(const SwModelIndex& index, const SwAny& value, SwItemDataRole role = SwItemDataRole::EditRole) override;

    /**
     * @brief Performs the `headerData` operation.
     * @param section Value passed to the method.
     * @param orientation Value passed to the method.
     * @param role Value passed to the method.
     * @return The requested header Data.
     */
    SwAny headerData(int section,
                     SwOrientation orientation,
                     SwItemDataRole role = SwItemDataRole::DisplayRole) const override;

    /**
     * @brief Performs the `flags` operation.
     * @param index Value passed to the method.
     * @return The requested flags.
     */
    SwItemFlags flags(const SwModelIndex& index) const override;

    /**
     * @brief Performs the `sort` operation.
     * @param column Value passed to the method.
     * @param order Value passed to the method.
     */
    void sort(int column, SwSortOrder order = SwSortOrder::AscendingOrder) override;

private:
    struct Node {
        void* parentKey{nullptr};
        SwModelIndex sourceParent;
        SwList<int> sourceRows;
        bool built{false};
    };

    void invalidateInternal_(bool clearNodeCache);

    void ensureCaches_() const;

    void buildSourceIndexMapRecursive_(const SwModelIndex& parent) const;

    Node& nodeForSourceParent_(const SwModelIndex& sourceParent) const;

    bool filterAcceptsRow_(int sourceRow, const SwModelIndex& sourceParent) const;

    SwString sortKeyForRow_(int sourceRow, const SwModelIndex& sourceParent) const;

    void buildNode_(Node& node) const;

    SwModelIndex mapFromSourceInternal_(const SwModelIndex& sourceIndex) const;

public:
    ~SwSortFilterProxyModel();
private:
    // What the class keeps (SwSortFilterProxyModel_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
