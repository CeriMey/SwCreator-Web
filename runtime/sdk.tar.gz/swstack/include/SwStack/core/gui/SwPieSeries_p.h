#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwPieSeries.h"

struct SwPieSeries::Data {
    SwVector<Slice> m_slices{};
    double m_holeSize{0.0};
    double m_startAngleDegrees{-90.0}; // nicer default (start at top)
    int m_paletteIndex{0};
};
