#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwSyntaxHighlighter.h"
#include <cctype>

struct SW_CODEEDITOR_EXPORT SwPythonSyntaxTheme {
    SwTextCharFormat keywordFormat;
    SwTextCharFormat builtinFormat;
    SwTextCharFormat commentFormat;
    SwTextCharFormat stringFormat;
    SwTextCharFormat numberFormat;
    SwTextCharFormat decoratorFormat;
    SwTextCharFormat selfFormat;
    SwTextCharFormat functionFormat;
    SwTextCharFormat classNameFormat;
    SwTextCharFormat magicFormat;
};

inline SwTextCharFormat swPythonMakeFormat_(const SwColor& color,
                                             FontWeight weight = Normal,
                                             bool italic = false) {
    SwTextCharFormat format;
    format.setForeground(color);
    if (weight != Normal) {
        format.setFontWeight(weight);
    }
    if (italic) {
        format.setFontItalic(true);
    }
    return format;
}

inline SwPythonSyntaxTheme swPythonSyntaxThemeVsCodeDark() {
    SwPythonSyntaxTheme theme;
    theme.keywordFormat   = swPythonMakeFormat_(SwColor{197, 134, 192}, Medium);
    theme.builtinFormat   = swPythonMakeFormat_(SwColor{220, 220, 170});
    theme.commentFormat   = swPythonMakeFormat_(SwColor{106, 153, 85}, Normal, true);
    theme.stringFormat    = swPythonMakeFormat_(SwColor{206, 145, 120});
    theme.numberFormat    = swPythonMakeFormat_(SwColor{181, 206, 168});
    theme.decoratorFormat = swPythonMakeFormat_(SwColor{220, 220, 170});
    theme.selfFormat      = swPythonMakeFormat_(SwColor{86, 156, 214}, Normal, true);
    theme.functionFormat  = swPythonMakeFormat_(SwColor{220, 220, 170});
    theme.classNameFormat = swPythonMakeFormat_(SwColor{78, 201, 176});
    theme.magicFormat     = swPythonMakeFormat_(SwColor{86, 156, 214});
    return theme;
}

class SW_CODEEDITOR_EXPORT SwPythonSyntaxHighlighter : public SwSyntaxHighlighter {
    SW_OBJECT(SwPythonSyntaxHighlighter, SwSyntaxHighlighter)

public:
    explicit SwPythonSyntaxHighlighter(SwTextDocument* document = nullptr);

    void setTheme(const SwPythonSyntaxTheme& theme);

protected:
    void highlightBlock(const SwString& text) override;

private:
    enum BlockState {
        NormalBlockState = 0,
        TripleSingleState = 1,
        TripleDoubleState = 2
    };

    static bool isWordStart_(char ch);

    static bool isWordChar_(char ch);

    static int findClosingQuote_(const SwString& text, int start, char quote);

    static int findTripleQuoteEnd_(const SwString& text, int start, char quote);

    static int parseNumber_(const SwString& text, int start);

    static bool isMagic_(const SwString& word);

    static bool isKeyword_(const SwString& word);

    static bool isBuiltin_(const SwString& word);

public:
    ~SwPythonSyntaxHighlighter();
private:
    // What the class keeps (SwPythonSyntaxHighlighter_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
