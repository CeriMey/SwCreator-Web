#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/gui/SwWidgetPlatformAdapter.h
 * @ingroup core_gui
 * @brief Declares the public interface exposed by SwWidgetPlatformAdapter in the CoreSw GUI
 * layer.
 *
 * This header belongs to the CoreSw GUI layer. It defines widgets, dialogs, models, delegates,
 * styling helpers, and application integration for the native UI stack.
 *
 * Within that layer, this file focuses on the widget platform adapter interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwWidgetPlatformHandle and SwWidgetPlatformAdapter.
 *
 * Widget-oriented declarations here usually capture persistent UI state, input handling, layout
 * participation, and paint-time behavior while keeping platform-specific rendering details behind
 * lower layers.
 *
 * GUI-facing declarations here are expected to cooperate with event delivery, layout, painting,
 * focus, and parent-child ownership rules.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "Sw.h"
#include "SwFont.h"
#include "SwString.h"
#include "SwWidgetPerfTrace.h"
#include "core/runtime/SwCoreApplication.h"
#include "platform/SwPlatformTarget.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdint>
#include <map>
#include <tuple>
#include <mutex>
#include <unordered_set>
#include <codecvt>
#include <locale>
#include <sstream>

enum class SwMouseButton;

enum class SwMouseButton;

struct SW_GUI_EXPORT SwWidgetPlatformHandle {
    void* nativeHandle{nullptr};
    void* nativeDisplay{nullptr};

    /**
     * @brief Returns the current bool.
     * @return The current bool.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    explicit operator bool() const;
};

enum class SwKey; // SwKeySequence.h

class SW_GUI_EXPORT SwWidgetPlatformAdapter {
public:
    /**
     * @brief Performs the `fromNativeHandle` operation.
     * @param handle Value passed to the method.
     * @param display Value passed to the method.
     * @return The requested from Native Handle.
     */
    static SwWidgetPlatformHandle fromNativeHandle(void* handle, void* display = nullptr);

    template <typename T>
    /**
     * @brief Performs the `nativeHandleAs` operation.
     * @param handle Value passed to the method.
     * @return The requested native Handle As.
     */
    static T nativeHandleAs(const SwWidgetPlatformHandle& handle) {
        return reinterpret_cast<T>(handle.nativeHandle);
    }

    /**
     * @brief Sets the cursor.
     * @param cursor Value passed to the method.
     * @return The requested cursor.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setCursor(CursorType cursor);
    static void setDamageThrottleSuppressed(const SwWidgetPlatformHandle& handle, bool suppressed);
    static void setInteractiveResizeActive(const SwWidgetPlatformHandle& handle, bool active);
    /**
     * @brief Performs the `invalidateRect` operation.
     * @param handle Value passed to the method.
     * @param rect Rectangle used by the operation.
     * @return The requested invalidate Rect.
     */
    static void invalidateRect(const SwWidgetPlatformHandle& handle, const SwRect& rect);
    static void flushDamage(bool forceImmediate = false);
    static void notePainted(const SwWidgetPlatformHandle& handle);
    /**
     * @brief Performs the `clientRect` operation.
     * @param handle Value passed to the method.
     * @return The requested client Rect.
     */
    static SwRect clientRect(const SwWidgetPlatformHandle& handle);
    /**
     * @brief Returns the client-area origin in screen coordinates.
     * @param handle Value passed to the method.
     * @return The requested client origin on screen.
     */
    static SwPoint clientOriginOnScreen(const SwWidgetPlatformHandle& handle);
#if SW_PLATFORM_WIN32
    /// Converts logical client units to physical screen pixels (including negative monitors).
    static SwPoint clientToScreen(const SwWidgetPlatformHandle& handle, const SwPoint& logicalPoint);
    /// Converts physical screen pixels to logical client units.
    static SwPoint screenToClient(const SwWidgetPlatformHandle& handle, const SwPoint& screenPoint);
#endif
    /**
     * @brief Returns the native window frame rectangle in screen coordinates.
     * @param handle Value passed to the method.
     * @return The requested window frame rect on screen.
     */
    static SwRect windowFrameRect(const SwWidgetPlatformHandle& handle);

    /**
     * @brief Captures the pointer for a native window during an existing button drag.
     * @details Registers the held button and screen position so native capture loss,
     * deactivation and missing button-up events also cancel a transferred drag.
     * @return True when capture succeeds; false on unsupported platforms or invalid input.
     */
    static bool captureMouse(const SwWidgetPlatformHandle& handle, SwMouseButton heldButton,
                             const SwPoint& globalPosition);

    /// Ends the native pointer capture of the window, if it holds it; false when it did not.
    static bool releaseMouse(const SwWidgetPlatformHandle& handle);

    /**
     * @brief Performs the `characterIndexAtPosition` operation.
     * @param handle Value passed to the method.
     * @param text Value passed to the method.
     * @param font Font value used by the operation.
     * @param relativeX Value passed to the method.
     * @param defaultWidth Value passed to the method.
     * @return The requested character Index At Position.
     */
    static size_t characterIndexAtPosition(const SwWidgetPlatformHandle& handle,
                                           const SwString& text,
                                           SwFont font,
                                           int relativeX,
                                           int defaultWidth);
    /**
     * @brief Performs the `textWidthUntil` operation.
     * @param handle Value passed to the method.
     * @param text Value passed to the method.
     * @param font Font value used by the operation.
     * @param length Value passed to the method.
     * @param defaultWidth Value passed to the method.
     * @return The requested text Width Until.
     */
    static int textWidthUntil(const SwWidgetPlatformHandle& handle,
                              const SwString& text,
                              SwFont font,
                              size_t length,
                              int defaultWidth);

    /**
     * @brief Returns whether the object reports backspace Key.
     * @param keyCode Value passed to the method.
     * @return The requested backspace Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isBackspaceKey(int keyCode);
    /**
     * @brief Returns whether the object reports delete Key.
     * @param keyCode Value passed to the method.
     * @return The requested delete Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isDeleteKey(int keyCode);
    /**
     * @brief Returns whether the object reports left Arrow Key.
     * @param keyCode Value passed to the method.
     * @return The requested left Arrow Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isLeftArrowKey(int keyCode);
    /**
     * @brief Returns whether the object reports right Arrow Key.
     * @param keyCode Value passed to the method.
     * @return The requested right Arrow Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isRightArrowKey(int keyCode);
    /**
     * @brief Returns whether the object reports up Arrow Key.
     * @param keyCode Value passed to the method.
     * @return The requested up Arrow Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isUpArrowKey(int keyCode);
    /**
     * @brief Returns whether the object reports down Arrow Key.
     * @param keyCode Value passed to the method.
     * @return The requested down Arrow Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isDownArrowKey(int keyCode);
    /**
     * @brief Returns whether the object reports home Key.
     * @param keyCode Value passed to the method.
     * @return The requested home Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isHomeKey(int keyCode);
    /**
     * @brief Returns whether the object reports end Key.
     * @param keyCode Value passed to the method.
     * @return The requested end Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isEndKey(int keyCode);
    /// Whether @p keyCode is Page Up (Win32 VK_PRIOR, X11 XK_Prior), as SwKey::PageUp names it.
    static bool isPageUpKey(int keyCode);
    /// Whether @p keyCode is Page Down (Win32 VK_NEXT, X11 XK_Next), as SwKey::PageDown names it.
    static bool isPageDownKey(int keyCode);
    /// Tab, including the X11 keysym used for Shift+Tab.
    static bool isTabKey(int keyCode);
    /// Puts the top-level native window of @p handle above the other windows, without activating it
    /// (SwWidget::raise() of a window); lowerWindow() puts it below them.
    static void raiseWindow(const SwWidgetPlatformHandle& handle);
    static void lowerWindow(const SwWidgetPlatformHandle& handle);
    /**
     * @brief Returns whether the object reports return Key.
     * @param keyCode Value passed to the method.
     * @return The requested return Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isFunctionKey(int keyCode, int number);

    /// The platform's code for @p key, as a KeyEvent carries it: the inverse of isEscapeKey() and
    /// its siblings. 0 for SwKey::Unknown and SwKey::Character, whose code depends on the letter.
    static int nativeKeyCode(SwKey key);
    static bool isReturnKey(int keyCode);
    /**
     * @brief Returns whether the object reports escape Key.
     * @param keyCode Value passed to the method.
     * @return The requested escape Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isEscapeKey(int keyCode);
    /**
     * @brief Returns whether the object reports caps Lock Key.
     * @param keyCode Value passed to the method.
     * @return The requested caps Lock Key.
     *
     * @details This query does not modify the object state.
     */
    static bool isCapsLockKey(int keyCode);
    /**
     * @brief Performs the `matchesShortcutKey` operation.
     * @param keyCode Value passed to the method.
     * @param letter Value passed to the method.
     * @return The requested matches Shortcut Key.
     */
    static bool matchesShortcutKey(int keyCode, char letter);
    /**
     * @brief Performs the `translateCharacter` operation.
     * @param keyCode Value passed to the method.
     * @param shiftPressed Value passed to the method.
     * @param capsLock Value passed to the method.
     * @param outChar Output value filled by the method.
     * @return The requested translate Character.
     */
    static bool translateCharacter(int keyCode, bool shiftPressed, bool capsLock, char& outChar);
    /**
     * @brief Returns whether the object reports shift Modifier Active.
     * @return The current shift Modifier Active.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static bool isShiftModifierActive();
    /**
     * @brief Makes a native window report the mouse leaving it (Windows: TrackMouseEvent), and
     *        stops doing so; nothing elsewhere. For hosts of widgets in foreign windows.
     */
    static void ensureMouseLeaveTracking(void* nativeWindow);
    static void clearMouseLeaveTracking(void* nativeWindow);
#if SW_PLATFORM_X11
    /**
     * @brief Performs the `requestSyntheticExpose` operation.
     * @param window Value passed to the method.
     * @return The requested request Synthetic Expose.
     */
    static bool requestSyntheticExpose(unsigned long window);   // an X11 Window (XID)
    /**
     * @brief Performs the `finishSyntheticExpose` operation.
     * @param window Value passed to the method.
     * @return The requested finish Synthetic Expose.
     */
    static void finishSyntheticExpose(unsigned long window);
    /// Forgets the repaint still pending for @p window, as it is destroyed: nothing is sent to it after.
    static void discardSyntheticExpose(unsigned long window);
#endif

private:
#if SW_PLATFORM_X11
    struct LinuxExposeTracker;   // SwWidgetPlatformAdapter_p.h
    static LinuxExposeTracker& exposeTracker();
#endif
    static size_t approximateIndex(const SwString& text, int relativeX, int defaultWidth);
    static int approximateWidth(const SwString& text, size_t length, int defaultWidth);
};
