#pragma once
#include "core/gui/SwPainter.h"

// Hook payloads kept private so extending drawing does not add virtual slots to the 1.x ABI. A
// painter that draws a request itself sets `handled`; otherwise SwPainter falls back on its own.
class SwPainterPath;
enum SwPainterHook {
    SwPainterHookDrawPath = 1,      // SwPainterPathRequest
    SwPainterHookStrokePath = 2,    // SwPainterStrokeRequest
    SwPainterHookFillPath = 3,      // SwPainterFillRequest
    SwPainterHookDrawRotatedText = 4 // SwPainterRotatedTextRequest
};
struct SwPainterPathRequest {
    const SwPainterPath* path;
    const SwColor* color;
    int width;
    bool handled{false};
};
struct SwPainterStrokeRequest {
    const SwPainterPath* path;
    const SwColor* color;
    double width;
    double opacity;
    bool handled{false};
};
struct SwPainterFillRequest {
    const SwPainterPath* path;
    const SwColor* color;
    double opacity;
    bool handled{false};
};
struct SwPainterRotatedTextRequest {
    SwPoint origin;               // top-left corner of the line before it turns
    const SwString* text;
    double angle;                 // degrees, clockwise on screen
    const SwColor* color;
    const SwFont* font;
    bool handled{false};
};

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwPainter.h"

struct SwOffsetPainter::Data : SwSharedData {
    SwPainter* m_base{nullptr};
    int m_dx{0};
    int m_dy{0};
};
