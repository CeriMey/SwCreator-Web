#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwPdfWriter.h"

struct SwPdfWriter::Data : SwSharedData {
    std::string m_filename;
    int m_pageWidth{595};
    int m_pageHeight{842};
    int m_marginTop{72};
    int m_marginRight{72};
    int m_marginBottom{72};
    int m_marginLeft{72};
    std::string m_currentPageContent;
    bool m_pageStarted{false};
    std::vector<std::string> m_pages;
    // Fonts
    std::vector<std::string> m_fonts;
    std::string m_currentFontName{"Helvetica"};
    int m_currentFontSize{12};
};
