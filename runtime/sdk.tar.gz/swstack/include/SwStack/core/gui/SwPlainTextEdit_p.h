#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/gui/SwPlainTextEdit.h"

struct SwPlainTextEdit::Data {
    // ─── Data members ───────────────────────────────────────────────────
    mutable SwPieceTable m_pieceTable;
    SwString m_placeholder;
    SwVector<VisualLine> m_visualLines;   // only used when word wrap is on
    int m_visualWrapWidth{-1};
    size_t m_cursorPos{0};
    size_t m_selectionStart{0};
    size_t m_selectionEnd{0};
    bool m_isSelecting{false};
    int m_firstVisibleLine{0};
    bool m_readOnly{false};
    bool m_undoRedoEnabled{true};
    size_t m_undoLimit{200};
    SwVector<EditState> m_undoStack;
    SwVector<EditState> m_redoStack;
    UndoMergeKind m_lastUndoMergeKind{UndoMergeKind::NoMerge};
    size_t m_lastUndoMergeCursorPos{static_cast<size_t>(-1)};
    bool m_caretVisible{true};
    SwTimer* m_blinkTimer{nullptr};
    SwColor m_focusAccent{59, 130, 246};
    bool m_wordWrapEnabled{false};
};
