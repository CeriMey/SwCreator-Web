#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwDebug.h"
#include "SwMailService.h"
#include "SwMutex.h"
#include "SwObject.h"
#include "SwString.h"
#include "auth/SwHttpAuthRecoveryCodeStore.h"
#include "auth/SwHttpAuthStore.h"
#include "auth/SwHttpAuthTemplateRenderer.h"
#include "http/SwHttpContext.h"

class SW_AUTH_EXPORT SwHttpAuthService : public SwObject {
    SW_OBJECT(SwHttpAuthService, SwObject)

public:
    explicit SwHttpAuthService(SwObject* parent = nullptr);

    ~SwHttpAuthService() override;

    void setConfig(const SwHttpAuthConfig& config);
    const SwHttpAuthConfig& config() const;

    void setHooks(const SwHttpAuthHooks& hooks);
    const SwHttpAuthHooks& hooks() const;

    void setMailService(SwMailService* mailService);
    SwMailService* mailService();
    const SwMailService* mailService() const;

    SwHttpAuthStore& store();
    const SwHttpAuthStore& store() const;

    bool start(SwString* outError = nullptr);
    void stop();
    bool isStarted() const;

    SwString extractRequestToken(const SwString& cookieHeader, const SwString& authorizationHeader) const;
    void applyIdentityToContext(SwHttpContext& ctx, const SwHttpAuthIdentity& identity) const;
    bool resolveIdentityFromToken(const SwString& rawToken,
                                  SwHttpAuthIdentity* outIdentity,
                                  SwString* outError = nullptr);

    SwDbStatus registerAccount(const SwString& email,
                               const SwString& password,
                               const SwJsonValue& payload,
                               SwHttpAuthAccount* outAccount,
                               SwJsonValue* outSubject,
                               bool* outPendingEmailVerification,
                               SwString* outError = nullptr);
    SwDbStatus login(const SwString& email,
                     const SwString& password,
                     const SwString& userAgent,
                     bool viaTls,
                     SwString* outRawToken,
                     SwHttpAuthIdentity* outIdentity,
                     SwString* outPasswordResetToken = nullptr,
                     SwString* outError = nullptr,
                     SwHttpAuthMfaLoginChallenge* outMfaChallenge = nullptr);
    SwDbStatus verifyTotpLogin(const SwString& challengeToken,
                               const SwString& code,
                               const SwString& userAgent,
                               bool viaTls,
                               SwString* outRawToken,
                               SwHttpAuthIdentity* outIdentity,
                               SwString* outError = nullptr);
    SwDbStatus beginTotpSetup(const SwString& rawToken,
                              const SwString& currentPassword,
                              SwHttpAuthMfaTotpSetup* outSetup,
                              SwString* outError = nullptr);
    SwDbStatus confirmTotpSetup(const SwString& rawToken,
                                const SwString& setupToken,
                                const SwString& code,
                                SwHttpAuthIdentity* outIdentity = nullptr,
                                SwString* outError = nullptr);
    SwDbStatus disableTotp(const SwString& rawToken,
                           const SwString& currentPassword,
                           SwHttpAuthIdentity* outIdentity = nullptr,
                           SwString* outError = nullptr);
    SwDbStatus getRecoveryCodeStatus(const SwString& rawToken,
                                     SwHttpAuthRecoveryCodeStatus* outStatus,
                                     SwString* outError = nullptr);
    SwDbStatus generateRecoveryCodes(const SwString& rawToken,
                                     const SwString& currentPassword,
                                     SwHttpAuthRecoveryCodeGeneration* outGeneration,
                                     SwString* outError = nullptr);
    SwDbStatus clearRecoveryCodes(const SwString& rawToken,
                                  const SwString& currentPassword,
                                  SwHttpAuthRecoveryCodeStatus* outStatus = nullptr,
                                  SwString* outError = nullptr);
    SwDbStatus logout(const SwString& rawToken);
    SwDbStatus requestEmailVerification(const SwString& email, SwString* outError = nullptr);
    SwDbStatus verifyEmail(const SwString& code,
                           const SwString& token,
                           SwHttpAuthAccount* outAccount,
                           SwJsonValue* outSubject,
                           SwString* outError = nullptr);
    SwDbStatus requestPasswordReset(const SwString& email, SwString* outError = nullptr);
    SwDbStatus requestPasswordChange(const SwString& rawToken,
                                     const SwString& currentPassword,
                                     SwString* outError = nullptr);
    SwDbStatus resetPassword(const SwString& code,
                             const SwString& token,
                             const SwString& newPassword,
                             SwString* outError = nullptr);
    SwDbStatus changePassword(const SwString& rawToken,
                              const SwString& currentPassword,
                              const SwString& newPassword,
                              SwHttpAuthIdentity* outIdentity = nullptr,
                              SwString* outError = nullptr);
    SwDbStatus requestEmailChange(const SwString& rawToken,
                                  const SwString& currentPassword,
                                  const SwString& newEmail,
                                  SwString* outError = nullptr);
    SwDbStatus confirmEmailChange(const SwString& rawToken,
                                  const SwString& code,
                                  const SwString& token,
                                  SwHttpAuthIdentity* outIdentity = nullptr,
                                  SwString* outError = nullptr);
    bool loadSubjectView(const SwString& subjectId,
                         SwJsonValue* outSubject,
                         SwString* outError = nullptr) const;

public slots:
    void publishSessionCreated(const SwHttpAuthAccount& account,
                               const SwHttpAuthSession& session,
                               const SwJsonValue& subject);

signals:
    SW_SIGNAL(sessionCreated,
                   const SwHttpAuthAccount&,
                   const SwHttpAuthSession&,
                   const SwJsonValue&)
    SW_SIGNAL(emailVerified, const SwHttpAuthAccount&, const SwJsonValue&)
    SW_SIGNAL(emailChanged, const SwHttpAuthAccount&, const SwJsonValue&)
    SW_SIGNAL(passwordChanged, const SwHttpAuthAccount&, const SwJsonValue&)
    SW_SIGNAL(mfaTotpEnabled, const SwHttpAuthAccount&, const SwJsonValue&)
    SW_SIGNAL(mfaTotpDisabled, const SwHttpAuthAccount&, const SwJsonValue&)

private:
    struct ThrottleState_ {
        int failures = 0;
        long long windowStartMs = 0;
    };

    bool validateConfig_(SwString& outError) const;
    bool validateMailConfig_(SwString& outError) const;
    static bool validateMailTemplate_(const SwHttpAuthMailTemplate& mailTemplate);
    bool hasInternalMailDelivery_() const;
    bool throttleAllows_(const SwString& key);
    // Lockout-on-failure throttle (login): peek without incrementing, then
    // register a failure or clear the counter on success — so a legitimate
    // user signing in repeatedly is never locked out, only repeated failures.
    bool throttlePeekBlocked_(const SwString& key);
    void throttleRegisterFailure_(const SwString& key);
    void throttleClear_(const SwString& key);
    SwDbStatus lookupChallenge_(const SwString& purpose,
                                const SwString& code,
                                const SwString& token,
                                SwHttpAuthChallenge* outChallenge);
    static SwDbStatus validateChallenge_(const SwHttpAuthChallenge& challenge);
    SwDbStatus sendChallengeForAccount_(const SwHttpAuthAccount& account,
                                        const SwString& purpose,
                                        bool swallowDeliveryErrors,
                                        SwString* outError);
    SwString buildChallengeUrl_(const SwString& purpose,
                                const SwString& rawToken,
                                const SwString& configuredTemplate,
                                const SwString& email = SwString()) const;
    bool sendMail_(const SwHttpAuthOutgoingMail& mail, SwString* outError);
    bool sendViaMailService_(const SwHttpAuthOutgoingMail& mail, SwString* outError);
    static SwByteArray buildMimeMessage_(const SwMailConfig& mailConfig, const SwHttpAuthOutgoingMail& mail);

private:
    // What the class keeps (SwHttpAuthService_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

namespace swHttpAuthServiceDetail {

inline SwJsonObject accountToJson_(const SwHttpAuthAccount& account) {
    SwJsonObject object;
    object["accountId"] = account.accountId;
    object["subjectId"] = account.subjectId;
    object["email"] = account.email;
    object["emailVerified"] = !account.emailVerifiedAt.trimmed().isEmpty();
    object["emailVerifiedAt"] = account.emailVerifiedAt;
    object["passwordResetRequired"] = account.passwordResetRequired;
    object["suspended"] = account.suspended;
    object["mfaTotpEnabled"] = account.mfaTotpEnabled;
    object["mfaTotpEnabledAt"] = account.mfaTotpEnabledAt;
    object["createdAt"] = account.createdAt;
    object["updatedAt"] = account.updatedAt;
    return object;
}

}

