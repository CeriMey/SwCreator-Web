#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/auth/SwHttpAuthService.h"

struct SwHttpAuthService::Data {
    SwHttpAuthConfig m_config;
    SwHttpAuthHooks m_hooks;
    SwHttpAuthStore m_store;
    SwHttpAuthRecoveryCodeStore m_recoveryCodes;
    SwMailService* m_mailService = nullptr;
    mutable SwMutex m_mutex;
    SwMap<SwString, ThrottleState_> m_throttle;
    bool m_started = false;
};
