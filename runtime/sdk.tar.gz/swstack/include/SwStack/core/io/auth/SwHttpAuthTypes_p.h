#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/auth/SwHttpAuthTypes.h"

#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>

namespace swHttpAuthDetail {

inline SwString normalizeEmail(const SwString& email) {
    SwString value = email.trimmed().toLower();
    const std::size_t displayStart = value.lastIndexOf("<");
    const std::size_t displayEnd = value.lastIndexOf(">");
    if (displayStart != std::string::npos && displayEnd != std::string::npos && displayEnd > displayStart) {
        value = value.mid(static_cast<int>(displayStart + 1),
                          static_cast<int>(displayEnd - displayStart - 1)).trimmed().toLower();
    }
    return value;
}

inline bool splitEmail(const SwString& email, SwString& outLocalPart, SwString& outDomain) {
    outLocalPart.clear();
    outDomain.clear();
    const SwString normalized = normalizeEmail(email);
    const int atPos = normalized.indexOf("@");
    if (atPos <= 0 || static_cast<std::size_t>(atPos + 1) >= normalized.size()) {
        return false;
    }
    if (normalized.indexOf("@", atPos + 1) >= 0) {
        return false;
    }
    outLocalPart = normalized.left(atPos);
    outDomain = normalized.mid(atPos + 1);
    return !outLocalPart.isEmpty() && !outDomain.isEmpty() && !outDomain.contains(" ");
}

inline long long currentEpochMs() {
    return static_cast<long long>(std::chrono::duration_cast<std::chrono::milliseconds>(
                                      std::chrono::system_clock::now().time_since_epoch())
                                      .count());
}

inline SwString isoTimestampFromUnixSeconds(std::time_t utcSeconds) {
    std::tm utcTime {};
#if defined(_WIN32)
    gmtime_s(&utcTime, &utcSeconds);
#else
    gmtime_r(&utcSeconds, &utcTime);
#endif
    std::ostringstream stream;
    stream << std::setfill('0')
           << std::setw(4) << (utcTime.tm_year + 1900)
           << "-" << std::setw(2) << (utcTime.tm_mon + 1)
           << "-" << std::setw(2) << utcTime.tm_mday
           << "T" << std::setw(2) << utcTime.tm_hour
           << ":" << std::setw(2) << utcTime.tm_min
           << ":" << std::setw(2) << utcTime.tm_sec
           << "Z";
    return SwString(stream.str());
}

inline SwString currentIsoTimestamp() {
    return isoTimestampFromUnixSeconds(std::time(nullptr));
}

inline SwString normalizeRoutePrefix(const SwString& routePrefix) {
    SwString normalized = routePrefix.trimmed();
    if (normalized.isEmpty()) {
        normalized = "/api/auth";
    }
    if (!normalized.startsWith("/")) {
        normalized.prepend("/");
    }
    while (normalized.size() > 1 && normalized.endsWith("/")) {
        normalized.chop(1);
    }
    return normalized;
}

inline SwString normalizeBaseUrl(const SwString& baseUrl) {
    SwString normalized = baseUrl.trimmed();
    while (normalized.size() > 1 && normalized.endsWith("/")) {
        normalized.chop(1);
    }
    return normalized;
}

inline SwString generateId(const SwString& prefix) {
    static SwMutex mutex;
    static unsigned long long counter = 0;
    unsigned long long localCounter = 0;
    {
        SwMutexLocker locker(&mutex);
        ++counter;
        localCounter = counter;
    }
    return prefix + "-" + SwString::number(currentEpochMs()) + "-" + SwString::number(localCounter);
}

inline bool fillRandomBytes(std::vector<unsigned char>& outBytes, std::size_t byteCount) {
    outBytes.assign(byteCount, 0);
    if (byteCount == 0) {
        return true;
    }
    return RAND_bytes(outBytes.data(), static_cast<int>(byteCount)) == 1;
}

inline SwString hexEncodeBytes(const std::vector<unsigned char>& bytes) {
    static const char* digits = "0123456789abcdef";
    std::string encoded;
    encoded.reserve(bytes.size() * 2);
    for (std::size_t i = 0; i < bytes.size(); ++i) {
        const unsigned char value = bytes[i];
        encoded.push_back(digits[(value >> 4) & 0x0f]);
        encoded.push_back(digits[value & 0x0f]);
    }
    return SwString(encoded);
}

inline SwString randomHexToken(std::size_t byteCount = 32) {
    std::vector<unsigned char> bytes;
    if (!fillRandomBytes(bytes, byteCount)) {
        return SwString();
    }
    return hexEncodeBytes(bytes);
}

inline SwString hashSha256(const SwString& value) {
    return SwString(SwCrypto::hashSHA256(value.toStdString()));
}

inline bool isModernPasswordHash(const SwString& storedHash) {
    return storedHash.startsWith("pbkdf2_sha256$");
}

inline SwString makeLegacySha1PasswordHash(const SwString& password) {
    const std::vector<unsigned char> sha = SwCrypto::generateHashSHA1(password.toStdString());
    return SwString(SwCrypto::base64Encode(sha));
}

inline SwString makePasswordHash(const SwString& password, int iterations = 120000) {
    if (password.isEmpty()) {
        return SwString();
    }
    std::vector<unsigned char> saltBytes;
    if (!fillRandomBytes(saltBytes, 16)) {
        return SwString();
    }

    SwByteArray derived;
    derived.resize(32);
    const std::string passwordUtf8 = password.toStdString();
    if (PKCS5_PBKDF2_HMAC(passwordUtf8.c_str(),
                          static_cast<int>(passwordUtf8.size()),
                          saltBytes.data(),
                          static_cast<int>(saltBytes.size()),
                          iterations,
                          EVP_sha256(),
                          static_cast<int>(derived.size()),
                          reinterpret_cast<unsigned char*>(derived.data())) != 1) {
        return SwString();
    }

    const SwByteArray saltArray(reinterpret_cast<const char*>(saltBytes.data()), saltBytes.size());
    return "pbkdf2_sha256$" +
           SwString::number(iterations) +
           "$" + SwString(saltArray.toBase64().toStdString()) +
           "$" + SwString(derived.toBase64().toStdString());
}

inline bool constantTimeEquals(const SwByteArray& lhs, const SwByteArray& rhs) {
    if (lhs.size() != rhs.size()) {
        return false;
    }
    unsigned char diff = 0;
    for (std::size_t i = 0; i < lhs.size(); ++i) {
        diff |= static_cast<unsigned char>(lhs.at(i) ^ rhs.at(i));
    }
    return diff == 0;
}

inline bool verifyPasswordHash(const SwString& storedHash, const SwString& password) {
    if (!isModernPasswordHash(storedHash)) {
        const SwByteArray lhs(storedHash.toUtf8());
        const SwByteArray rhs(makeLegacySha1PasswordHash(password).toUtf8());
        return constantTimeEquals(lhs, rhs);
    }

    const SwList<SwString> parts = storedHash.split('$');
    if (parts.size() != 4 || parts[0] != "pbkdf2_sha256") {
        return false;
    }

    bool ok = false;
    const int iterations = parts[1].toInt(&ok);
    if (!ok || iterations <= 0) {
        return false;
    }

    const SwByteArray salt = SwByteArray::fromBase64(SwByteArray(parts[2].toStdString()));
    const SwByteArray expected = SwByteArray::fromBase64(SwByteArray(parts[3].toStdString()));
    if (salt.isEmpty() || expected.isEmpty()) {
        return false;
    }

    SwByteArray derived;
    derived.resize(expected.size());
    const std::string passwordUtf8 = password.toStdString();
    if (PKCS5_PBKDF2_HMAC(passwordUtf8.c_str(),
                          static_cast<int>(passwordUtf8.size()),
                          reinterpret_cast<const unsigned char*>(salt.constData()),
                          static_cast<int>(salt.size()),
                          iterations,
                          EVP_sha256(),
                          static_cast<int>(derived.size()),
                          reinterpret_cast<unsigned char*>(derived.data())) != 1) {
        return false;
    }

    return constantTimeEquals(expected, derived);
}

inline SwString base32EncodeBytes(const std::vector<unsigned char>& bytes) {
    static const char* kAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    SwString encoded;
    int buffer = 0;
    int bitsLeft = 0;
    for (std::size_t i = 0; i < bytes.size(); ++i) {
        buffer = (buffer << 8) | static_cast<int>(bytes[i]);
        bitsLeft += 8;
        while (bitsLeft >= 5) {
            encoded.append(kAlphabet[(buffer >> (bitsLeft - 5)) & 0x1f]);
            bitsLeft -= 5;
        }
    }
    if (bitsLeft > 0) {
        encoded.append(kAlphabet[(buffer << (5 - bitsLeft)) & 0x1f]);
    }
    return encoded;
}

inline bool base32DecodeBytes(const SwString& encoded, std::vector<unsigned char>& outBytes) {
    outBytes.clear();
    int buffer = 0;
    int bitsLeft = 0;
    const std::string text = encoded.toStdString();
    for (std::size_t i = 0; i < text.size(); ++i) {
        const unsigned char raw = static_cast<unsigned char>(text[i]);
        if (raw == '=' || raw == ' ' || raw == '-' || raw == '\t' || raw == '\r' || raw == '\n') {
            continue;
        }

        int value = -1;
        const unsigned char c = static_cast<unsigned char>(std::toupper(raw));
        if (c >= 'A' && c <= 'Z') {
            value = c - 'A';
        } else if (c >= '2' && c <= '7') {
            value = 26 + (c - '2');
        }
        if (value < 0) {
            outBytes.clear();
            return false;
        }

        buffer = (buffer << 5) | value;
        bitsLeft += 5;
        if (bitsLeft >= 8) {
            outBytes.push_back(static_cast<unsigned char>((buffer >> (bitsLeft - 8)) & 0xff));
            bitsLeft -= 8;
        }
    }
    return !outBytes.empty();
}

inline SwString generateTotpSecret(std::size_t byteCount = 20) {
    std::vector<unsigned char> bytes;
    if (!fillRandomBytes(bytes, byteCount)) {
        return SwString();
    }
    return base32EncodeBytes(bytes);
}

inline SwString normalizeTotpCode(const SwString& code) {
    SwString normalized;
    const std::string text = code.toStdString();
    for (std::size_t i = 0; i < text.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        if (std::isdigit(c)) {
            normalized.append(static_cast<char>(c));
            continue;
        }
        if (c == ' ' || c == '-') {
            continue;
        }
        return SwString();
    }
    return normalized;
}

inline SwString totpCodeForCounter(const std::vector<unsigned char>& secretBytes,
                                   unsigned long long counter,
                                   int digits = 6) {
    if (secretBytes.empty() || digits < 6 || digits > 8) {
        return SwString();
    }

    unsigned char counterBytes[8] = {0};
    for (int i = 7; i >= 0; --i) {
        counterBytes[i] = static_cast<unsigned char>(counter & 0xff);
        counter >>= 8;
    }

    unsigned char digest[EVP_MAX_MD_SIZE] = {0};
    unsigned int digestLen = 0;
    unsigned char* hmac = HMAC(EVP_sha1(),
                               secretBytes.data(),
                               static_cast<int>(secretBytes.size()),
                               counterBytes,
                               sizeof(counterBytes),
                               digest,
                               &digestLen);
    if (!hmac || digestLen < 20) {
        return SwString();
    }

    const int offset = digest[digestLen - 1] & 0x0f;
    if (offset + 3 >= static_cast<int>(digestLen)) {
        return SwString();
    }

    const unsigned int binary =
        ((static_cast<unsigned int>(digest[offset]) & 0x7f) << 24) |
        ((static_cast<unsigned int>(digest[offset + 1]) & 0xff) << 16) |
        ((static_cast<unsigned int>(digest[offset + 2]) & 0xff) << 8) |
        (static_cast<unsigned int>(digest[offset + 3]) & 0xff);

    unsigned int modulo = 1;
    for (int i = 0; i < digits; ++i) {
        modulo *= 10;
    }
    const unsigned int code = binary % modulo;
    std::ostringstream stream;
    stream << std::setfill('0') << std::setw(digits) << code;
    return SwString(stream.str());
}

inline bool verifyTotpCode(const SwString& secret,
                           const SwString& code,
                           long long nowMs = currentEpochMs(),
                           int allowedWindow = 1,
                           int periodSeconds = 30,
                           int digits = 6) {
    const SwString normalizedCode = normalizeTotpCode(code);
    if (normalizedCode.size() != static_cast<std::size_t>(digits) || periodSeconds <= 0 || allowedWindow < 0) {
        return false;
    }

    std::vector<unsigned char> secretBytes;
    if (!base32DecodeBytes(secret.trimmed(), secretBytes)) {
        return false;
    }

    const long long currentCounter = (nowMs / 1000ll) / static_cast<long long>(periodSeconds);
    for (int drift = -allowedWindow; drift <= allowedWindow; ++drift) {
        const long long candidateCounter = currentCounter + static_cast<long long>(drift);
        if (candidateCounter < 0) {
            continue;
        }
        const SwString expected = totpCodeForCounter(secretBytes,
                                                     static_cast<unsigned long long>(candidateCounter),
                                                     digits);
        if (!expected.isEmpty() &&
            constantTimeEquals(SwByteArray(normalizedCode.toUtf8()), SwByteArray(expected.toUtf8()))) {
            return true;
        }
    }
    return false;
}

inline SwString urlEncodeComponent(const SwString& value) {
    std::ostringstream stream;
    const std::string text = value.toStdString();
    stream << std::uppercase << std::hex;
    for (std::size_t i = 0; i < text.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        if ((c >= 'A' && c <= 'Z') ||
            (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            stream << static_cast<char>(c);
        } else {
            stream << '%' << std::setw(2) << std::setfill('0') << static_cast<int>(c);
        }
    }
    return SwString(stream.str());
}

inline SwString buildTotpOtpAuthUri(const SwString& issuer,
                                    const SwString& label,
                                    const SwString& secret,
                                    int digits = 6,
                                    int periodSeconds = 30) {
    const SwString normalizedIssuer = issuer.trimmed().isEmpty() ? SwString("SwStack") : issuer.trimmed();
    const SwString normalizedLabel = label.trimmed().isEmpty() ? SwString("account") : label.trimmed();
    const SwString accountLabel = normalizedIssuer + ":" + normalizedLabel;
    return "otpauth://totp/" +
           urlEncodeComponent(accountLabel) +
           "?secret=" + urlEncodeComponent(secret.trimmed()) +
           "&issuer=" + urlEncodeComponent(normalizedIssuer) +
           "&algorithm=SHA1&digits=" + SwString::number(digits) +
           "&period=" + SwString::number(periodSeconds);
}

inline SwString generateChallengeCode(std::size_t length = 8) {
    static const char* kAlphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    std::vector<unsigned char> bytes;
    if (!fillRandomBytes(bytes, length)) {
        return SwString();
    }
    SwString code;
    for (std::size_t i = 0; i < bytes.size(); ++i) {
        code += kAlphabet[bytes[i] % 32];
    }
    return code;
}

inline SwString parseCookieValue(const SwString& cookieHeader, const SwString& cookieName) {
    const SwList<SwString> parts = cookieHeader.split(';');
    for (std::size_t i = 0; i < parts.size(); ++i) {
        const SwString part = parts[i].trimmed();
        const int equals = part.indexOf('=');
        if (equals <= 0) {
            continue;
        }
        const SwString key = part.left(equals).trimmed();
        if (key == cookieName) {
            return part.mid(equals + 1).trimmed();
        }
    }
    return SwString();
}

inline SwString extractBearerToken(const SwString& authorizationHeader) {
    const SwString trimmed = authorizationHeader.trimmed();
    if (!trimmed.toLower().startsWith("bearer ")) {
        return SwString();
    }
    return trimmed.mid(7).trimmed();
}

inline SwString buildSessionCookie(const SwString& cookieName,
                                   const SwString& token,
                                   long long maxAgeSeconds,
                                   bool secure) {
    SwString cookie = cookieName + "=" + token + "; Path=/; HttpOnly; SameSite=Lax";
    if (secure) {
        cookie += "; Secure";
    }
    if (maxAgeSeconds >= 0) {
        cookie += "; Max-Age=" + SwString::number(maxAgeSeconds);
    }
    return cookie;
}

inline SwJsonArray toJsonArray(const SwList<SwString>& values) {
    SwJsonArray array;
    for (std::size_t i = 0; i < values.size(); ++i) {
        array.append(values[i]);
    }
    return array;
}

inline SwString accountKey(const SwString& accountId) {
    return "auth/account/" + accountId;
}

inline SwString accountsByEmailSecondaryKey(const SwString& email) {
    return normalizeEmail(email);
}

inline SwString sessionsByAccountSecondaryKey(const SwString& accountId, const SwString& sessionId) {
    return accountId + "\x1f" + sessionId;
}

inline SwString challengeByAccountPurposeSecondaryKey(const SwString& accountId,
                                                      const SwString& purpose,
                                                      const SwString& challengeId) {
    return accountId + "\x1f" + purpose + "\x1f" + challengeId;
}

inline SwString challengeByTokenSecondaryKey(const SwString& tokenHash) {
    return tokenHash;
}

inline SwString challengeByCodeSecondaryKey(const SwString& purpose,
                                            const SwString& code,
                                            const SwString& challengeId) {
    return purpose + "\x1f" + code + "\x1f" + challengeId;
}

inline SwByteArray jsonToBytes(const SwJsonObject& object) {
    return SwByteArray(SwJsonDocument(object).toJson(SwJsonDocument::JsonFormat::Compact).toStdString());
}

inline bool parseJsonObject(const SwByteArray& bytes, SwJsonObject& outObject) {
    SwString error;
    const SwJsonDocument document = SwJsonDocument::fromJson(bytes.toStdString(), error);
    if (!error.isEmpty() || !document.isObject()) {
        return false;
    }
    outObject = document.object();
    return true;
}

inline SwString replaceTemplatePlaceholders(const SwString& source,
                                            const SwString& code,
                                            const SwString& url) {
    SwString rendered = source;
    rendered.replace("{{code}}", code);
    rendered.replace("{{url}}", url);
    return rendered;
}

inline SwString replaceUrlTemplateToken(const SwString& source,
                                        const SwString& token,
                                        const SwString& email = SwString()) {
    SwString rendered = source;
    rendered.replace("{{token}}", token);
    rendered.replace("{{email}}", urlEncodeComponent(email.trimmed()));
    return rendered;
}

inline SwString safeJsonString(const SwJsonValue& value) {
    return SwString(value.toJsonString());
}

} // namespace swHttpAuthDetail
