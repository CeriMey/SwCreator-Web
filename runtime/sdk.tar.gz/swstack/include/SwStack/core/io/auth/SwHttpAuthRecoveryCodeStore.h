#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwEmbeddedDb.h"
#include "SwMutex.h"
#include "auth/SwHttpAuthTypes.h"

#include <algorithm>
#include <cctype>
#include <vector>

struct SW_AUTH_EXPORT SwHttpAuthRecoveryCodeStatus {
    int totalCodes = 0;
    int remainingCodes = 0;
    SwString generatedAt;
};

struct SW_AUTH_EXPORT SwHttpAuthRecoveryCodeGeneration {
    SwList<SwString> codes;
    SwHttpAuthRecoveryCodeStatus status;
};

class SW_AUTH_EXPORT SwHttpAuthRecoveryCodeStore {
public:
    SwHttpAuthRecoveryCodeStore();

    void setConfig(const SwHttpAuthConfig& config);

    SwDbStatus open();

    void close();

    bool isOpen() const;

    SwDbStatus statusForAccount(const SwString& accountId, SwHttpAuthRecoveryCodeStatus* outStatus);

    SwDbStatus replaceCodes(const SwString& accountId,
                            int requestedCount,
                            SwHttpAuthRecoveryCodeGeneration* outGeneration);

    SwDbStatus consumeCode(const SwString& accountId, const SwString& code);

    SwDbStatus removeCodesForAccount(const SwString& accountId);

private:
    struct RecoveryCodeRecord_ {
        SwString accountId;
        SwString codeId;
        SwString codeHash;
        SwString usedAt;
        SwString createdAt;
        SwString updatedAt;
    };

    static SwString normalizeCode_(const SwString& code);

    static SwString hashCode_(const SwString& accountId, const SwString& normalizedCode);

    static SwString generateCode_();

    static bool containsCode_(const SwList<SwString>& codes, const SwString& code);

    static SwByteArray primaryKey_(const RecoveryCodeRecord_& record);

    static SwByteArray accountIndexKey_(const SwString& accountId, const SwString& codeId);

    SwDbIterator scanAccountLocked_(const SwString& accountId);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeys_(const RecoveryCodeRecord_& record);

    static SwJsonObject recordToJson_(const RecoveryCodeRecord_& record);

    static RecoveryCodeRecord_ recordFromJson_(const SwJsonObject& object);

    static bool parseRecord_(const SwByteArray& bytes, RecoveryCodeRecord_& outRecord);

    void appendAccountDeletesLocked_(const SwString& accountId, SwDbWriteBatch& batch);

    SwHttpAuthRecoveryCodeStatus statusForAccountLocked_(const SwString& accountId);

public:
    ~SwHttpAuthRecoveryCodeStore();
private:
    // What the class keeps (SwHttpAuthRecoveryCodeStore_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
