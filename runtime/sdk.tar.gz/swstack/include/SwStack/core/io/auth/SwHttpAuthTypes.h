#pragma once

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwCrypto.h"
#include "SwEmbeddedDb.h"
#include "SwJsonArray.h"
#include "SwJsonDocument.h"
#include "SwJsonObject.h"
#include "SwJsonValue.h"
#include "SwList.h"
#include "SwMap.h"
#include "SwMutex.h"
#include "SwString.h"

#include <chrono>
#include <cctype>
#include <cstdint>
#include <ctime>
#include <functional>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>


static constexpr const char* kSwLogCategory_SwHttpAuth = "sw.core.io.swhttpauth";

struct SW_AUTH_EXPORT SwHttpAuthMailTemplate {
    SwString subject;
    SwString textBody;
    SwString htmlBody;

    bool isEmpty() const;
};

struct SW_AUTH_EXPORT SwHttpAuthMailConfig {
    SwString fromAddress;
    // Nom affiché de l'expéditeur (« Produit <noreply@…> »). Vide : adresse nue.
    SwString fromName;
    SwHttpAuthMailTemplate verificationTemplate;
    SwHttpAuthMailTemplate resetPasswordTemplate;
    // Vide : gabarit intégré du service.
    SwHttpAuthMailTemplate changeEmailTemplate;
    SwString verificationUrlTemplate;
    SwString resetPasswordUrlTemplate;
};

struct SW_AUTH_EXPORT SwHttpAuthConfig {
    SwString routePrefix = "/api/auth";
    SwString storageDir = "auth";
    SwEmbeddedDbOptions dbOptions;
    SwString sessionCookieName = "sw_auth";
    unsigned long long sessionTtlMs = 7ull * 24ull * 60ull * 60ull * 1000ull;
    int passwordMinLength = 8;
    bool requireVerifiedEmailForLogin = true;
    bool verificationRequired = true;
    unsigned long long verificationCodeTtlMs = 15ull * 60ull * 1000ull;
    unsigned long long resetCodeTtlMs = 15ull * 60ull * 1000ull;
    unsigned long long mfaChallengeTtlMs = 5ull * 60ull * 1000ull;
    SwString mfaIssuer = "SwStack";
    SwString publicBaseUrl;
    SwHttpAuthMailConfig mail;
};

struct SW_AUTH_EXPORT SwHttpAuthApiOptions {
    SwString routePrefix = "/api/auth";
};

struct SW_AUTH_EXPORT SwHttpAuthAccount {
    SwString accountId;
    SwString subjectId;
    SwString email;
    SwString passwordHash;
    SwString emailVerifiedAt;
    bool passwordResetRequired = false;
    bool suspended = false;
    bool mfaTotpEnabled = false;
    SwString mfaTotpSecret;
    SwString mfaTotpEnabledAt;
    SwString createdAt;
    SwString updatedAt;
};

struct SW_AUTH_EXPORT SwHttpAuthSession {
    SwString sessionId;
    SwString accountId;
    SwString tokenHash;
    long long expiresAtMs = 0;
    SwString userAgent;
    bool viaTls = false;
    SwString createdAt;
    SwString updatedAt;
};

struct SW_AUTH_EXPORT SwHttpAuthChallenge {
    SwString challengeId;
    SwString purpose;
    SwString accountId;
    SwString code;
    SwString tokenHash;
    SwJsonValue payload;
    long long expiresAtMs = 0;
    SwString consumedAt;
    SwString createdAt;
    SwString updatedAt;
};

struct SW_AUTH_EXPORT SwHttpAuthOutgoingMail {
    SwString purpose;
    SwString accountId;
    SwString email;
    SwString fromAddress;
    SwString fromName;
    SwList<SwString> to;
    SwString subject;
    SwString textBody;
    SwString htmlBody;
    SwString code;
    SwString url;
};

struct SW_AUTH_EXPORT SwHttpAuthIdentity {
    bool authenticated = false;
    bool emailVerified = false;
    SwHttpAuthAccount account;
    SwHttpAuthSession session;
    SwJsonValue subject;
};

struct SW_AUTH_EXPORT SwHttpAuthMfaLoginChallenge {
    SwString challengeToken;
    SwString email;
    long long expiresAtMs = 0;
};

struct SW_AUTH_EXPORT SwHttpAuthMfaTotpSetup {
    SwString setupToken;
    SwString secret;
    SwString otpauthUri;
    SwString issuer;
    SwString label;
    int digits = 6;
    int periodSeconds = 30;
    long long expiresAtMs = 0;
};

using SwHttpAuthRegisterSubjectHook =
    std::function<bool(const SwString&, const SwJsonValue&, SwString&, SwJsonValue&, SwString&)>;
using SwHttpAuthLoadSubjectHook =
    std::function<bool(const SwString&, SwJsonValue&, SwString&)>;
using SwHttpAuthDeliverMailHook =
    std::function<bool(const SwHttpAuthOutgoingMail&, SwString&)>;

struct SW_AUTH_EXPORT SwHttpAuthHooks {
    SwHttpAuthRegisterSubjectHook registerSubject;
    SwHttpAuthLoadSubjectHook loadSubject;
    SwHttpAuthDeliverMailHook deliverMail;
};

