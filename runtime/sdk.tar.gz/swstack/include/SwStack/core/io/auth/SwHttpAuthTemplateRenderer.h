#pragma once

#include "../../SwStackExport.h"

#include "auth/SwHttpAuthTypes.h"

struct SW_AUTH_EXPORT SwHttpAuthRenderedTemplate {
    SwString subject;
    SwString textBody;
    SwString htmlBody;
};

class SW_AUTH_EXPORT SwHttpAuthTemplateRenderer {
public:
    static SwHttpAuthRenderedTemplate render(const SwHttpAuthMailTemplate& mailTemplate,
                                             const SwString& code,
                                             const SwString& url);

    static SwString renderUrl(const SwString& urlTemplate,
                              const SwString& token,
                              const SwString& email = SwString());

private:
    // Une URL placée dans un attribut HTML y porte ses « & » sous forme d'entité :
    // « &email= » brut est du HTML invalide.
    static SwString htmlAttributeText_(const SwString& value);
};
