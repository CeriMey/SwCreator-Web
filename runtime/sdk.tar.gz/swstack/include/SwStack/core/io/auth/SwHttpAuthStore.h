#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwDebug.h"
#include "SwEmbeddedDb.h"
#include "auth/SwHttpAuthTypes.h"

#define SW_HTTP_AUTH_RETURN_IF_NOT_OPEN_() \
    if (!m_opened) { \
        return SwDbStatus(SwDbStatus::NotOpen, "Auth store not open"); \
    }

class SW_AUTH_EXPORT SwHttpAuthStore {
public:
    SwHttpAuthStore();

    void setConfig(const SwHttpAuthConfig& config);

    const SwHttpAuthConfig& config() const;

    SwDbStatus open();

    void close();

    bool isOpen() const;

    SwDbStatus createAccount(const SwString& email,
                             const SwString& password,
                             const SwString& subjectId,
                             SwHttpAuthAccount* createdOut = nullptr);

    SwDbStatus createAccountWithoutPassword(const SwString& email,
                                             const SwString& subjectId,
                                             SwHttpAuthAccount* createdOut = nullptr);

    SwDbStatus createImportedAccount(const SwHttpAuthAccount& importedAccount,
                                     SwHttpAuthAccount* createdOut = nullptr);

    SwDbStatus removeAccount(const SwString& accountId);

    SwDbStatus getAccountById(const SwString& accountId, SwHttpAuthAccount* outAccount);

    SwDbStatus getAccountByEmail(const SwString& email, SwHttpAuthAccount* outAccount);

    SwDbStatus setAccountSubjectId(const SwString& accountId, const SwString& subjectId);

    SwDbStatus setAccountEmail(const SwString& accountId,
                               const SwString& email,
                               const SwString& verifiedAt);

    SwDbStatus setAccountPassword(const SwString& accountId, const SwString& password);

    SwDbStatus setAccountPasswordResetRequired(const SwString& accountId, bool passwordResetRequired);

    SwDbStatus setAccountEmailVerifiedAt(const SwString& accountId, const SwString& verifiedAt);

    SwDbStatus setAccountSuspended(const SwString& accountId, bool suspended);

    SwDbStatus setAccountTotp(const SwString& accountId,
                              const SwString& secret,
                              const SwString& enabledAt);

    SwList<SwHttpAuthAccount> listAccounts();

    bool verifyPassword(const SwHttpAuthAccount& account, const SwString& password) const;

    SwDbStatus createSession(const SwString& accountId,
                             const SwString& userAgent,
                             bool viaTls,
                             unsigned long long ttlMs,
                             SwString* outRawToken,
                             SwHttpAuthSession* outSession);

    SwDbStatus getSessionByToken(const SwString& rawToken, SwHttpAuthSession* outSession);

    SwList<SwHttpAuthSession> listSessionsByAccount(const SwString& accountId);

    SwDbStatus removeSessionByToken(const SwString& rawToken);

    SwDbStatus removeSessionsForAccount(const SwString& accountId, const SwString& keepSessionId = SwString());

    SwDbStatus removeChallengesForAccount(const SwString& accountId);

    SwDbStatus createChallenge(const SwString& purpose,
                               const SwString& accountId,
                               unsigned long long ttlMs,
                               SwString* outRawToken,
                               SwHttpAuthChallenge* outChallenge,
                               const SwJsonValue& payload = SwJsonValue());

    SwDbStatus getChallengeByToken(const SwString& rawToken, SwHttpAuthChallenge* outChallenge);

    SwDbStatus getChallengeByCode(const SwString& purpose,
                                  const SwString& code,
                                  SwHttpAuthChallenge* outChallenge);

    SwList<SwHttpAuthChallenge> listChallenges();

    SwDbStatus consumeChallenge(const SwString& challengeId);

    SwDbStatus removeChallenge(const SwString& challengeId);

private:

    static SwByteArray toPrimaryKey_(const SwString& key);

    static SwByteArray toSecondaryKey_(const SwString& key);

    static SwString accountPrimaryKey_(const SwString& accountId);

    static SwString sessionPrimaryKey_(const SwString& tokenHash);

    static SwString challengePrimaryKey_(const SwString& challengeId);

    SwDbStatus writeAccountLocked_(const SwHttpAuthAccount& account);

    SwDbStatus writeChallengeLocked_(const SwHttpAuthChallenge& challenge);

    SwDbStatus loadAccountByIdLocked_(const SwString& accountId, SwHttpAuthAccount& outAccount);

    SwDbStatus loadAccountByEmailLocked_(const SwString& normalizedEmail, SwHttpAuthAccount& outAccount);

    SwDbStatus loadSessionByTokenHashLocked_(const SwString& tokenHash, SwHttpAuthSession& outSession);

    SwDbStatus loadChallengeByIdLocked_(const SwString& challengeId, SwHttpAuthChallenge& outChallenge);

    SwList<SwHttpAuthSession> listSessionsByAccountUnlocked_(const SwString& accountId);

    SwList<SwHttpAuthChallenge> listChallengesByAccountPurposeUnlocked_(const SwString& accountId,
                                                                         const SwString& purpose);

    static SwJsonObject accountToJson_(const SwHttpAuthAccount& account);

    static SwHttpAuthAccount accountFromJson_(const SwJsonObject& object);

    static SwJsonObject sessionToJson_(const SwHttpAuthSession& session);

    static SwHttpAuthSession sessionFromJson_(const SwJsonObject& object);

    static SwJsonObject challengeToJson_(const SwHttpAuthChallenge& challenge);

    static SwHttpAuthChallenge challengeFromJson_(const SwJsonObject& object);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForAccount_(const SwHttpAuthAccount& account);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForSession_(const SwHttpAuthSession& session);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForChallenge_(const SwHttpAuthChallenge& challenge);
public:
    ~SwHttpAuthStore();
private:
    // What the class keeps (SwHttpAuthStore_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

#undef SW_HTTP_AUTH_RETURN_IF_NOT_OPEN_
