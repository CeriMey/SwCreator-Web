#ifndef SWQUICFRAMECODEC_H
#define SWQUICFRAMECODEC_H

#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicVarIntCodec.h"

#include <cstddef>
#include <limits>
#include <utility>
#include <vector>

class SW_QUIC_EXPORT SwQuicFrameCodec {
public:
    static bool encodeFrame(const SwQuicFrame& frame,
                            SwByteArray& outPayload,
                            SwString* error = nullptr);

    static bool decodeFrame(const SwByteArray& payload,
                            std::size_t& offset,
                            SwQuicFrame& outFrame,
                            SwString* error = nullptr);

    static bool encodeFrames(const SwVector<SwQuicFrame>& frames,
                             SwByteArray& outPayload,
                             SwString* error = nullptr);

    static bool decodeFrames(const SwByteArray& payload,
                             SwVector<SwQuicFrame>& outFrames,
                             SwString* error = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static void appendByte_(SwByteArray& outBytes, std::uint8_t value);

    static bool readByte_(const SwByteArray& bytes,
                          std::size_t& offset,
                          std::uint8_t& outValue,
                          SwString* error);

    static bool appendVarInt_(std::uint64_t value, SwByteArray& outPayload, SwString* error);

    static bool readVarInt_(const SwByteArray& payload,
                            std::size_t& offset,
                            std::uint64_t& outValue,
                            SwString* error);

    static bool ensureSizeFits_(std::uint64_t value, SwString* error);

    static bool readSlice_(const SwByteArray& payload,
                           std::size_t& offset,
                           std::uint64_t length,
                           SwByteArray& outSlice,
                           SwString* error);

    static bool encodeAck_(const SwQuicFrame& frame, SwByteArray& outPayload, SwString* error);

    static bool encodeResetStream_(const SwQuicFrame& frame,
                                   SwByteArray& outPayload,
                                   SwString* error);

    static bool encodeResetStreamAt_(const SwQuicFrame& frame,
                                     SwByteArray& out,
                                     SwString* error);

    static bool encodeStopSending_(const SwQuicFrame& frame,
                                   SwByteArray& outPayload,
                                   SwString* error);

    static bool encodeCrypto_(const SwQuicFrame& frame, SwByteArray& outPayload, SwString* error);

    static bool encodeNewToken_(const SwQuicFrame& frame, SwByteArray& outPayload, SwString* error);

    static bool encodeStream_(const SwQuicFrame& frame, SwByteArray& outPayload, SwString* error);

    static bool encodeNewConnectionId_(const SwQuicFrame& frame,
                                       SwByteArray& outPayload,
                                       SwString* error);

    static bool encodePathData_(const SwQuicFrame& frame, SwByteArray& outPayload, SwString* error);

    static bool encodeConnectionClose_(const SwQuicFrame& frame,
                                       SwByteArray& outPayload,
                                       SwString* error);

    static bool encodeDatagram_(const SwQuicFrame& frame, SwByteArray& outPayload, SwString* error);

    static bool decodeAck_(bool hasEcn,
                           const SwByteArray& payload,
                           std::size_t& offset,
                           SwQuicFrame& outFrame,
                           SwString* error);

    static bool decodeResetStream_(const SwByteArray& payload,
                                   std::size_t& offset,
                                   SwQuicFrame& outFrame,
                                   SwString* error);

    static bool decodeResetStreamAt_(const SwByteArray& payload,
                                     std::size_t& offset,
                                     SwQuicFrame& outFrame,
                                     SwString* error);

    static bool decodeStopSending_(const SwByteArray& payload,
                                   std::size_t& offset,
                                   SwQuicFrame& outFrame,
                                   SwString* error);

    static bool decodeCrypto_(const SwByteArray& payload,
                              std::size_t& offset,
                              SwQuicFrame& outFrame,
                              SwString* error);

    static bool decodeNewToken_(const SwByteArray& payload,
                                std::size_t& offset,
                                SwQuicFrame& outFrame,
                                SwString* error);

    static bool decodeStream_(std::uint8_t frameType,
                              const SwByteArray& payload,
                              std::size_t& offset,
                              SwQuicFrame& outFrame,
                              SwString* error);

    static bool decodeMaxData_(const SwByteArray& payload,
                               std::size_t& offset,
                               SwQuicFrame& outFrame,
                               SwString* error);

    static bool decodeMaxStreamData_(const SwByteArray& payload,
                                     std::size_t& offset,
                                     SwQuicFrame& outFrame,
                                     SwString* error);

    static bool decodeMaxStreams_(bool bidirectional,
                                  const SwByteArray& payload,
                                  std::size_t& offset,
                                  SwQuicFrame& outFrame,
                                  SwString* error);

    static bool decodeDataBlocked_(const SwByteArray& payload,
                                   std::size_t& offset,
                                   SwQuicFrame& outFrame,
                                   SwString* error);

    static bool decodeStreamDataBlocked_(const SwByteArray& payload,
                                         std::size_t& offset,
                                         SwQuicFrame& outFrame,
                                         SwString* error);

    static bool decodeStreamsBlocked_(bool bidirectional,
                                      const SwByteArray& payload,
                                      std::size_t& offset,
                                      SwQuicFrame& outFrame,
                                      SwString* error);

    static bool decodeNewConnectionId_(const SwByteArray& payload,
                                       std::size_t& offset,
                                       SwQuicFrame& outFrame,
                                       SwString* error);

    static bool decodeRetireConnectionId_(const SwByteArray& payload,
                                          std::size_t& offset,
                                          SwQuicFrame& outFrame,
                                          SwString* error);

    static bool decodePathData_(bool response,
                                const SwByteArray& payload,
                                std::size_t& offset,
                                SwQuicFrame& outFrame,
                                SwString* error);

    static bool decodeConnectionClose_(bool applicationClose,
                                       const SwByteArray& payload,
                                       std::size_t& offset,
                                       SwQuicFrame& outFrame,
                                       SwString* error);

    static bool decodeDatagram_(bool hasLength,
                                const SwByteArray& payload,
                                std::size_t& offset,
                                SwQuicFrame& outFrame,
                                SwString* error);
};

#endif
