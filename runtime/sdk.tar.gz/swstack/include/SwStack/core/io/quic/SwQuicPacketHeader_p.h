#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicPacketHeader.h"

struct SwQuicPacketHeader::Data : SwSharedData {
    Form m_form;
    LongPacketType m_longPacketType;
    std::uint32_t m_version;
    SwQuicConnectionId m_destinationConnectionId;
    SwQuicConnectionId m_sourceConnectionId;
    SwByteArray m_token;
    std::uint64_t m_payloadLength;
    std::uint64_t m_packetNumber;
    std::uint8_t m_packetNumberLength;
};
