#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicLossRecovery.h"

struct SwQuicLossRecovery::Data : SwSharedData {
    bool m_handshakeConfirmed;
    bool m_firstSample;
    double m_latestRttMs;
    double m_minRttMs;
    double m_smoothedRttMs;
    double m_rttVarMs;
    std::uint64_t m_largestAckedPacket;
    bool m_haveLargestAcked;
    SwMap<std::uint64_t, SentPacket> m_sent;
};
