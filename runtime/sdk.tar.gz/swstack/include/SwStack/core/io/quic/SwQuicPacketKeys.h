#ifndef SWQUICPACKETKEYS_H
#define SWQUICPACKETKEYS_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicInitialSecrets.h"

// Derives a QUIC packet-protection key set (key, iv, header-protection key) from
// a TLS 1.3 traffic secret, for cipher suite TLS_AES_128_GCM_SHA256 (RFC 9001
// section 5.1). The Initial keys use exactly this derivation from the Initial
// secret; the Handshake and 1-RTT levels use it from the TLS handshake and
// application traffic secrets respectively.
class SW_QUIC_EXPORT SwQuicPacketKeys {
public:
    static bool deriveAes128(const SwByteArray& trafficSecret,
                             SwQuicInitialKeys& outKeys,
                             SwString* error = nullptr);

    // Key update for 1-RTT (RFC 9001 section 6.1): next generation secret =
    // HKDF-Expand-Label(secret, "quic ku", "", Hash.length).
    static bool nextGeneration(const SwByteArray& trafficSecret,
                               SwByteArray& outNextSecret,
                               SwString* error = nullptr);
};

#endif
