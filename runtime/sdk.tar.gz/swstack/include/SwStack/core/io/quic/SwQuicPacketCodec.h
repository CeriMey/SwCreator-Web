#ifndef SWQUICPACKETCODEC_H
#define SWQUICPACKETCODEC_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicPacketHeader.h"
#include "quic/SwQuicVarIntCodec.h"

#include <limits>

class SW_QUIC_EXPORT SwQuicPacketCodec {
public:
    static bool encodeInitialPacket(const SwQuicPacketHeader& header,
                                    const SwByteArray& payload,
                                    SwByteArray& outPacket,
                                    SwString* error = nullptr);

    static bool decodeInitialPacket(const SwByteArray& packet,
                                    SwQuicPacketHeader& outHeader,
                                    SwByteArray& outPayload,
                                    SwString* error = nullptr);

    // RFC 9000 appendix A.3: reconstruct a full packet number from its
    // truncated wire encoding and the largest packet number received so far in
    // the same packet number space. Callers that have not received any packet
    // yet pass hasLargestReceived=false, in which case the truncated value is
    // already the full packet number.
    static std::uint64_t expandPacketNumber(std::uint64_t largestReceived,
                                            bool hasLargestReceived,
                                            std::uint64_t truncated,
                                            std::uint8_t packetNumberLength);

    // When outConsumed is non-null the packet may be followed by coalesced
    // packets in the same datagram: only this packet is decoded and the number
    // of bytes it occupied is reported. When it is null the whole buffer must be
    // exactly one Initial packet.
    static bool decodeInitialPacket(const SwByteArray& packet,
                                    SwQuicPacketHeader& outHeader,
                                    SwByteArray& outPayload,
                                    std::size_t* outConsumed,
                                    SwString* error);

private:
    static void setError_(SwString* error, const char* message);

    static void appendByte_(SwByteArray& outBytes, std::uint8_t value);

    static void appendU32_(SwByteArray& outBytes, std::uint32_t value);

    static bool readByte_(const SwByteArray& bytes,
                          std::size_t& offset,
                          std::uint8_t& outValue,
                          SwString* error);

    static bool readU32_(const SwByteArray& bytes,
                         std::size_t& offset,
                         std::uint32_t& outValue,
                         SwString* error);

    static bool readSlice_(const SwByteArray& bytes,
                           std::size_t& offset,
                           std::size_t length,
                           SwByteArray& outSlice,
                           SwString* error);

    static bool appendPacketNumber_(const SwQuicPacketHeader& header,
                                    SwByteArray& outPacket,
                                    SwString* error);

    static bool readPacketNumber_(const SwByteArray& packet,
                                  std::size_t& offset,
                                  std::uint8_t packetNumberLength,
                                  std::uint64_t& outPacketNumber,
                                  SwString* error);
};

#endif
