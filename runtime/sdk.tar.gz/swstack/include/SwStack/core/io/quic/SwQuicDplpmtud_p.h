#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicDplpmtud.h"

struct SwQuicDplpmtud::Data : SwSharedData {
    State m_state = State::Disabled;
    int m_low = kBasePmtu;
    int m_high = kBasePmtu;
    int m_pmtu = kBasePmtu;
    int m_probeSize = 0;
    int m_probeCount = 0;
};
