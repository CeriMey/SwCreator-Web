#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicFlowControl.h"

struct SwQuicConnectionFlowControl::Data : SwSharedData {
    std::uint64_t m_initialWindow;
    std::uint64_t m_maxDataLimit;
    std::uint64_t m_bytesReceived;
    std::uint64_t m_bytesConsumed;
    std::uint64_t m_peerMaxData;
};
struct SwQuicStreamFlowControl::Data : SwSharedData {
    std::uint64_t m_initialWindow;
    std::uint64_t m_maxDataLimit;
    std::uint64_t m_highestReceivedOffset;
    std::uint64_t m_bytesConsumed;
    std::uint64_t m_peerMaxData;
};
