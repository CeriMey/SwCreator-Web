#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicConnection.h"

struct SwQuicConnection::Data : SwSharedData {
    Role m_role;
    State m_state;
    std::uint32_t m_version;
    bool m_plaintextInitialTx;
    bool m_handshakeConfirmed;
    SwQuicConnectionId m_localConnectionId;
    SwQuicConnectionId m_peerConnectionId;
    SwByteArray m_initialToken;
    SwQuicTransportParameters m_localParams;
    SwQuicTransportParameters m_peerParams;
    bool m_hasPeerParams;
    std::uint64_t m_peerAckDelayExponent;
    std::uint64_t m_peerMaxAckDelayMs;
    std::uint64_t m_effectiveIdleTimeoutMs;
    std::uint64_t m_lastNetworkActivityMs;
    bool m_hasNetworkActivity;
    std::uint64_t m_drainDeadlineMs;
    bool m_hasDrainDeadline;
    std::size_t m_ptoCount;
    bool m_closeQueued;
    bool m_closeSent;
    std::uint64_t m_closeErrorCode;
    SwString m_closeReason;
    bool m_closeIsApplication;
    Space_ m_spaces[3];
    SwQuicCongestionControl m_congestion;
    SwQuicConnectionFlowControl m_connectionFlow;
    SwMap<std::uint64_t, SwQuicStreamFlowControl> m_streamFlow;
    SwMap<std::uint64_t, std::uint64_t> m_peerStreamMaxData;
    std::uint64_t m_peerMaxStreamsBidi;
    std::uint64_t m_peerMaxStreamsUni;
    std::uint64_t m_localMaxStreamsBidi = 100;
    std::uint64_t m_localMaxStreamsUni = 100;
    std::uint64_t m_totalStreamBytesSent = 0;
    SwQuicPacketHeader m_lastInitialHeader;
    SwQuicStreamMap m_streams;
    SwMap<std::uint64_t, SendStream_> m_sendStreams;
    SwMap<std::uint64_t, bool> m_localOpenedStreams;
    SwVector<std::uint64_t> m_touchedStreams;
    std::size_t m_streamSchedulingCursor = 0;
    // ---- 1-RTT key update state (RFC 9001 section 6) ----
    bool m_keyPhase = false;              // Key Phase bit of the current generation
    bool m_hasNextKeys = false;           // next-generation keys precomputed
    bool m_hasPrevRxKeys = false;         // previous-generation receive keys kept
    bool m_currentPhaseTxAcked = false;   // a current-phase packet was acknowledged
    std::uint64_t m_currentPhaseFirstTxPn = 0;
    std::uint64_t m_keyUpdateCount = 0;
    SwQuicInitialKeys m_nextRxKeys;
    SwQuicInitialKeys m_nextTxKeys;
    SwQuicInitialKeys m_prevRxKeys;
    std::size_t m_maxStreamReassemblyBytes = 1024 * 1024;
    std::size_t m_maxStreamReassemblyFragments = 1024;
    std::size_t m_bufferedStreamSendBytes = 0;
    std::size_t m_maxBufferedStreamSendBytes = 16U * 1024U * 1024U;
    SwMap<std::uint64_t, std::uint64_t> m_resetStreams;
    SwMap<std::uint64_t, PendingReliableReset_> m_pendingReliableResets;
    SwMap<std::uint64_t, std::uint64_t> m_streamFinalSize; // established final sizes
    // Compact inclusive stream-number ranges. A single low stream kept open
    // cannot force one tombstone per later completed request.
    SwMap<std::uint64_t, std::uint64_t> m_retiredPeerBidiRanges;
    SwDequeue<SwByteArray> m_datagrams;
    std::size_t m_receivedDatagramBytes = 0;
    std::size_t m_maxReceivedDatagrams = 1024;
    std::size_t m_maxReceivedDatagramBytes = 4U * 1024U * 1024U;
    std::uint64_t m_droppedReceivedDatagrams = 0;
    std::uint64_t m_queuedDatagramFrames = 0;
    std::uint64_t m_encodedDatagramFrames = 0;
    std::uint64_t m_receivedDatagramFrames = 0;
    SwDequeue<SwQuicFrame> m_pendingDatagramFrames;
    std::size_t m_pendingDatagramFrameBytes = 0;
    std::uint64_t m_droppedOutgoingDatagramFrames = 0;
    std::size_t m_maxDatagramsPerBuild = 0;
    std::size_t m_maxPendingDatagramFrames = 0;
    std::size_t m_maxPendingDatagramBytes = 0;
    DatagramQueueOverflowPolicy m_datagramQueueOverflowPolicy =
        DatagramQueueOverflowPolicy::RejectNewest;
    std::size_t m_maximumUdpPayloadSize = SwQuicLimits::maximumUdpPayloadBytes();
    std::size_t m_pacingRatePerMillisecond = 0;
    std::size_t m_pacingMaximumBurst = 0;
    std::uint64_t m_pacingLastRefillMs = 0;
    std::size_t m_pacingTokens = 0;
    SwVector<SwByteArray> m_newTokens;
    SwMap<std::uint64_t, SwByteArray> m_peerIssuedConnectionIds;
    SwMap<std::uint64_t, SwByteArray> m_peerStatelessResetTokens;
    std::uint64_t m_currentPeerConnectionIdSequence = 0;
    SwQuicStream m_cryptoReassembly[3];
    SwByteArray m_cryptoAssembled[3];
    SwByteArray m_lastPathChallenge;
    std::size_t m_receivedPingCount;
    bool m_sawVersionNegotiation;
    bool m_sawRetry;
    // Path validation / migration state (RFC 9000 section 9).
    bool m_pathValidated = true;          // the established path is validated
    bool m_awaitingPathResponse = false;
    bool m_resetCcOnValidation = false;
    SwByteArray m_pathChallengeData;
    std::uint64_t m_bytesReceivedThisPath = 0;
    std::uint64_t m_bytesSentThisPath = 0;
    std::uint64_t m_nextLocalCidSequence = 1; // sequence 0 = the initial CID
    SwMap<std::uint64_t, SwByteArray> m_issuedConnectionIds;
    PathControlEvents* m_pathControlEventsOut = nullptr; // non-owning, seulement pendant receive
    bool m_inspectPathControlOnly = false;
    bool m_inspectedNonPathFrames = false;
    bool m_inspectedPathPacketReplay = false;
    bool m_hasLargestInspectedPathPacketNumber = false;
    std::uint64_t m_largestInspectedPathPacketNumber = 0;
    SwDequeue<std::uint64_t> m_inspectedPathPacketNumbers;
};
