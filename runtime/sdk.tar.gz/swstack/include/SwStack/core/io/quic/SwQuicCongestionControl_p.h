#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicCongestionControl.h"

struct SwQuicCongestionControl::Data : SwSharedData {
    std::uint64_t m_maxDatagramSize;
    std::uint64_t m_congestionWindow;
    std::uint64_t m_bytesInFlight;
    std::uint64_t m_ssthresh;
    std::uint64_t m_recoveryStartTimeMs;
    bool m_started;
};
