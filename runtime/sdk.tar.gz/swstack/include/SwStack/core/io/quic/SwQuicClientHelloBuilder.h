#ifndef SWQUICCLIENTHELLOBUILDER_H
#define SWQUICCLIENTHELLOBUILDER_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicConnectionId.h"
#include "quic/SwQuicInitialSecrets.h"
#include "quic/SwQuicHybridKex.h"
#include "quic/SwQuicLimits.h"
#include "quic/SwQuicPacketKeys.h"
#include "quic/SwQuicTransportParameters.h"
#include "quic/SwQuicVarIntCodec.h"
#include "quic/SwTls13KeySchedule.h"

#include <cstdint>
class SW_QUIC_EXPORT SwQuicClientHelloBuilder {
public:
    // Deterministic probe variant: fixed test X25519 key + deterministic random.
    static bool buildForHttp3(const SwString& serverName,
                              const SwQuicConnectionId& initialSourceConnectionId,
                              SwByteArray& outClientHello,
                              SwString* error = nullptr);

    // Real-key variant: caller supplies the 32-byte X25519 public key and the
    // 32-byte ClientHello random from its own key schedule.
    static bool buildForHttp3(const SwString& serverName,
                              const SwQuicConnectionId& initialSourceConnectionId,
                              const SwByteArray& x25519Public32,
                              const SwByteArray& random32,
                              SwByteArray& outClientHello,
                              SwString* error = nullptr);

    // Generic QUIC ClientHello with one explicit ALPN. The protocol is an
    // opaque TLS ALPN identifier (1..255 bytes), not an HTTP/3 alias.
    static bool buildForAlpn(const SwString& serverName,
                             const SwQuicConnectionId& initialSourceConnectionId,
                             const SwByteArray& x25519Public32,
                             const SwByteArray& random32,
                             const SwByteArray& applicationProtocol,
                             SwByteArray& outClientHello,
                             SwString* error = nullptr,
                             bool rawPublicKey = false,
                             const SwQuicTransportParameters* localParameters = nullptr,
                             const SwByteArray* mlKemPublicKey = nullptr);

    // Resumption ClientHello for 0-RTT (RFC 8446 4.2.11, RFC 9001 4.6). Builds
    // the same ClientHello as buildForHttp3 plus psk_key_exchange_modes,
    // early_data, and a pre_shared_key extension (which MUST be last) carrying
    // the ticket identity and a real PSK binder. Also derives the client early
    // (0-RTT) packet keys from the PSK and the ClientHello transcript.
    static bool buildForHttp3Resumption(const SwString& serverName,
                                        const SwQuicConnectionId& initialSourceConnectionId,
                                        const SwByteArray& x25519Public32,
                                        const SwByteArray& random32,
                                        const SwByteArray& ticket,
                                        std::uint32_t obfuscatedTicketAge,
                                        const SwByteArray& resumptionPsk,
                                        SwByteArray& outClientHello,
                                        SwQuicInitialKeys& outEarlyKeys,
                                        SwString* error = nullptr,
                                        const SwQuicTransportParameters* localParameters = nullptr,
                                        const SwByteArray* mlKemPublicKey = nullptr);

    // Recompute the PSK binder a server expects over a received resumption
    // ClientHello message, for the given PSK. Used to verify the client binder.
    // truncationLength is the number of trailing bytes forming the PskBinderEntry
    // list (2-byte length prefix + list body) that must be stripped before the
    // transcript hash (RFC 8446 4.2.11.2). Pass 0 to assume a single 32-byte
    // binder (35 = 2 + 1 + 32), which is all this library's client ever sends.
    static bool computeExpectedBinder(const SwByteArray& clientHelloMessage,
                                      const SwByteArray& resumptionPsk,
                                      SwByteArray& outBinder,
                                      SwString* error = nullptr,
                                      std::size_t truncationLength = 0);

    // Derive the client early (0-RTT) packet keys a server uses to decrypt
    // 0-RTT packets, from the PSK and the received full ClientHello message.
    static bool deriveServerEarlyKeys(const SwByteArray& clientHelloMessage,
                                      const SwByteArray& resumptionPsk,
                                      SwQuicInitialKeys& outEarlyKeys,
                                      SwString* error = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static void appendU8_(SwByteArray& out, std::uint8_t value);

    static void appendU16_(SwByteArray& out, std::uint16_t value);

    static void appendU24_(SwByteArray& out, std::uint32_t value);

    static void appendU32_(SwByteArray& out, std::uint32_t value);

    // The common ClientHello extensions shared by the fresh and resumption
    // handshakes: SNI, supported_groups, signature_algorithms, ALPN,
    // supported_versions, key_share (X25519MLKEM768 when supplied, plus
    // X25519 fallback), and QUIC transport parameters.
    static bool appendClientExtensions_(const SwString& host,
                                        const SwQuicConnectionId& initialSourceConnectionId,
                                        const SwByteArray& x25519Public32,
                                        const SwByteArray* mlKemPublicKey,
                                        const SwQuicTransportParameters* localParameters,
                                        SwByteArray& extensions,
                                        SwString* error);

    static SwQuicTransportParameters defaultTransportParameters_();

    static bool encodeTransportParameters_(
            const SwQuicConnectionId& initialSourceConnectionId,
            const SwQuicTransportParameters* localParameters,
            SwByteArray& out, SwString* error);

    static void appendExtension_(SwByteArray& extensions,
                                 std::uint16_t type,
                                 const SwByteArray& data);

    static bool appendTransportParameter_(SwByteArray& out,
                                          std::uint64_t id,
                                          const SwByteArray& value,
                                          SwString* error);

    static bool appendVarIntTransportParameter_(SwByteArray& out,
                                                std::uint64_t id,
                                                std::uint64_t value,
                                                SwString* error);

    static SwByteArray x25519TestPublicKey_();

    static void buildDeterministicRandom_(SwByteArray& out);
};

#endif
