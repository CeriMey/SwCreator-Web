#ifndef SWQUICCONGESTIONCONTROL_H
#define SWQUICCONGESTIONCONTROL_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include <cstdint>
#include <cstddef>
#include "quic/SwQuicLimits.h"

// RFC 9002 (QUIC Loss Detection and Congestion Control) section 7 NewReno.
//
// This class implements the NewReno congestion controller described in
// RFC 9002. It tracks the congestion window, the slow start threshold and the
// number of bytes currently in flight, and reacts to acknowledgements, loss
// detection and congestion (ECN or loss) events.
//
// Header-only, C++11, no external dependencies.
class SW_QUIC_EXPORT SwQuicCongestionControl {
public:
    SwQuicCongestionControl();

    // Number of bytes carried by the largest datagram the path allows.
    std::uint64_t maxDatagramSize() const;

    // Current congestion window in bytes (RFC 9002 congestion_window).
    std::uint64_t congestionWindow() const;

    // Bytes sent but not yet acknowledged or declared lost.
    std::uint64_t bytesInFlight() const;

    // Slow start threshold (RFC 9002 ssthresh).
    std::uint64_t ssthresh() const;

    // Start time of the current recovery period (RFC 9002 congestion_recovery_start_time).
    std::uint64_t recoveryStartTimeMs() const;

    // True once a congestion recovery period has been entered at least once.
    bool started() const;

    // RFC 9002 7.5 On Sending a Packet: add the sent bytes to bytes_in_flight.
    void onPacketSent(std::size_t sentBytes);

    // RFC 9002 7.3.1/7.3.2 On Receiving an Acknowledgment for an ack-eliciting
    // packet: remove the acked bytes from flight and grow the window.
    //
    // In slow start (cwnd < ssthresh) the window grows by the number of acked
    // bytes. In congestion avoidance the window grows by
    // maxDatagramSize * ackedBytes / cwnd. Acks for packets sent before the
    // current recovery period do not change the window.
    void onPacketAcked(std::size_t ackedBytes, std::uint64_t sentTimeMs);

    // RFC 9002 7.6 On Congestion Event: halve the window, but only if the event
    // was triggered by a packet sent after the current recovery period began.
    void onCongestionEvent(std::uint64_t sentTimeMs, std::uint64_t nowMs);

    // RFC 9002 7.6 On packets declared lost: remove the lost bytes from flight
    // and enter a congestion recovery period.
    void onPacketsLost(std::size_t lostBytes,
                       std::uint64_t largestLostSentTimeMs,
                       std::uint64_t nowMs);

    // RFC 9002 7.6.2 Persistent Congestion: collapse the window to the minimum.
    void onPersistentCongestion();

    // Whether the controller currently permits sending `bytes` more bytes.
    bool canSend(std::size_t bytes) const;

private:
    static std::uint64_t initialWindow_(std::uint64_t maxDatagramSize);

    // A packet is "after" the current recovery period when it was sent strictly
    // after the recovery period started.
    bool isTimeAfterRecovery_(std::uint64_t sentTimeMs) const;

public:
    ~SwQuicCongestionControl();
public:
    SwQuicCongestionControl(const SwQuicCongestionControl& other);
    SwQuicCongestionControl& operator=(const SwQuicCongestionControl& other);
private:
    // What the class keeps (SwQuicCongestionControl_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
