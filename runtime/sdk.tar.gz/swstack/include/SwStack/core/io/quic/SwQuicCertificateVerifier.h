#ifndef SWQUICCERTIFICATEVERIFIER_H
#define SWQUICCERTIFICATEVERIFIER_H

#include "../../SwStackExport.h"
#include "../../platform/SwWindowsDefs.h"   // Windows' handles, without <windows.h>

#include "SwVector.h"
#include "SwByteArray.h"
#include "SwString.h"

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#endif

// VIGIL links OpenSSL on every supported platform. Windows CryptoAPI remains
// the X.509 verifier; OpenSSL supplies Ed25519 because CNG exposes no stable
// Ed25519 CertificateVerify primitive in the supported SDK baseline.

// Server authentication for the QUIC TLS 1.3 handshake (RFC 8446 sections
// 4.4.2/4.4.3), delegated entirely to the Windows platform crypto:
//
//   * verifyServerChain()      -- X.509 path building, revocation-less trust
//                                 evaluation against the system root store and
//                                 SSL server policy incl. hostname matching,
//                                 via CryptoAPI (crypt32).
//   * verifyCertificateVerify()-- the CertificateVerify signature over the
//                                 handshake transcript, via CNG (bcrypt).
//
// X.509 CertificateVerify supports ECDSA, RSA-PSS and Ed25519. RFC 7250 raw
// public keys remain restricted to Ed25519 (0x0807) and are parsed/verified by
// the dedicated methods below.
class SW_QUIC_EXPORT SwQuicCertificateVerifier {
public:
    // Parse one canonical RFC 8410 Ed25519 SubjectPublicKeyInfo and return the
    // exact 32-byte raw public key. Parameters, BER aliases and trailing data
    // are rejected by a byte-identical DER round-trip.
    static bool extractEd25519RawPublicKey(const SwByteArray& spkiDer,
                                           SwByteArray& outRawPublicKey,
                                           SwString* error = nullptr);

    static bool verifyRawPublicKeyCertificateVerify(
            const SwByteArray& spkiDer,
            std::uint16_t signatureScheme,
            const SwByteArray& signature,
            const SwByteArray& transcriptHash,
            SwString* error = nullptr,
            bool serverContext = true);

    // Extract the canonical DER SubjectPublicKeyInfo carried by one strict DER
    // X.509 certificate. This is X.509/SPKI pinning support: it does not mean
    // that RFC 7250 RawPublicKey was negotiated on the TLS wire.
    static bool extractSubjectPublicKeyInfo(const SwByteArray& certificateDer,
                                            SwByteArray& outSpkiDer,
                                            SwString* error = nullptr);

    // Validate the server certificate chain (leaf first) for `hostName`.
    static bool verifyServerChain(const SwVector<SwByteArray>& chainDer,
                                  const SwString& hostName,
                                  SwString* error = nullptr);

    // Verify the CertificateVerify signature (RFC 8446 section 4.4.3): the
    // signed content is 64 spaces, the context string, a zero byte and the
    // transcript hash up to the Certificate message.
    static bool verifyCertificateVerify(const SwByteArray& leafCertificateDer,
                                        std::uint16_t signatureScheme,
                                        const SwByteArray& signature,
                                        const SwByteArray& transcriptHash,
                                        SwString* error = nullptr,
                                        bool serverContext = true);

private:
    static bool verifyCertificateVerifyOpenSsl_(
            const SwByteArray& leafCertificateDer,
            std::uint16_t signatureScheme,
            const SwByteArray& signature,
            const SwByteArray& transcriptHash,
            SwString* error,
            bool serverContext);

    static bool isStrictDerCertificate_(const SwByteArray& der) noexcept;

    // Validate the structural DER rules needed at this trust boundary: one
    // definite-length TLV tree, minimal tag/length encodings, canonical basic
    // primitive encodings, bounded nesting, and no trailing bytes.
    static bool readStrictDerElement_(const unsigned char* data,
                                      std::size_t available,
                                      std::size_t depth,
                                      std::size_t& consumed) noexcept;

    static void setError_(SwString* error, const char* message);

    static void clearError_(SwString* error);

#if defined(_WIN32)
    static SwVector<wchar_t> toWide_(const SwString& text);

    static const char* policyErrorText_(DWORD policyError);

    static bool hash_(const wchar_t* algorithm,
                      const SwByteArray& data,
                      std::size_t digestLength,
                      SwByteArray& outDigest,
                      SwString* error);

    // TLS carries ECDSA signatures DER encoded (SEQUENCE { INTEGER r, INTEGER s });
    // CNG expects the raw fixed-size r||s concatenation.
    static bool ecdsaDerToRaw_(const SwByteArray& der,
                               std::size_t coordinateSize,
                               SwByteArray& outRaw,
                               SwString* error);

    static bool readDerHeader_(const SwByteArray& der,
                               std::size_t& pos,
                               std::uint8_t& outTag,
                               std::size_t& outLength,
                               SwString* error);

    static bool readDerInteger_(const SwByteArray& der,
                                std::size_t& pos,
                                SwByteArray& outValue,
                                SwString* error);
#endif
};

#endif
