#ifndef SWQUICCLIENTINITIALBUILDER_H
#define SWQUICCLIENTINITIALBUILDER_H

#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicClientHelloBuilder.h"
#include "quic/SwQuicConnectionId.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicFrameCodec.h"
#include "quic/SwQuicInitialSecrets.h"
#include "quic/SwQuicPacketProtector.h"
#include "quic/SwQuicVarIntCodec.h"

#include <algorithm>
#include <cstdint>
#include <vector>

class SW_QUIC_EXPORT SwQuicClientInitialBuilder {
public:
    struct Options {
        SwString serverName;
        SwQuicConnectionId destinationConnectionId;
        SwQuicConnectionId sourceConnectionId;
        // Empty for the first Initial. After a validated Retry this is the
        // exact opaque token carried by the Retry packet (RFC 9000 17.2.5).
        SwByteArray token;
        std::uint64_t packetNumber = 0;
    };

    static bool buildHttp3Initial(const Options& options,
                                  SwByteArray& outPacket,
                                  SwString* error = nullptr);

    // Wraps a caller-provided TLS ClientHello (e.g. one built with a real
    // ephemeral X25519 key) into a padded, protected QUIC Initial packet. Used by
    // the live handshake client; buildHttp3Initial is the deterministic probe path.
    static bool buildFromClientHello(const Options& options,
                                     const SwByteArray& clientHello,
                                     SwByteArray& outPacket,
                                     SwString* error = nullptr);

    // Splits a large ClientHello into independently protected Initial packets.
    // Every packet is a complete UDP datagram, padded to RFC 9000's 1200-byte
    // minimum and capped for paths (such as Vigil's carrier) with a lower MTU.
    static bool buildFlightFromClientHello(const Options& options,
                                           const SwByteArray& clientHello,
                                           SwVector<SwByteArray>& outPackets,
                                           std::size_t maximumDatagramSize = 1350,
                                           SwString* error = nullptr);

private:
    static bool buildFragment_(const Options& options,
                               std::uint64_t cryptoOffset,
                               const SwByteArray& cryptoData,
                               SwByteArray& outPacket,
                               SwString* error);
    static std::size_t minimumInitialDatagramSize_();
    static std::uint8_t packetNumberLength_();

    static void setError_(SwString* error, const char* message);

    static void appendU8_(SwByteArray& out, std::uint8_t value);

    static void appendU32_(SwByteArray& out, std::uint32_t value);

    static void appendPacketNumber_(SwByteArray& out, std::uint64_t packetNumber);

    static bool buildHeader_(const Options& options,
                             std::uint64_t protectedPayloadLength,
                             SwByteArray& outHeader,
                             SwString* error);
};

#endif
