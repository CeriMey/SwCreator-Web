#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicFrame.h"

struct SwQuicFrame::Data : SwSharedData {
    Type m_type;
    std::size_t m_paddingLength;
    std::uint64_t m_largestAcknowledged;
    std::uint64_t m_ackDelay;
    std::uint64_t m_firstAckRange;
    SwVector<AckRange> m_ackRanges;
    bool m_hasEcn;
    std::uint64_t m_ect0Count;
    std::uint64_t m_ect1Count;
    std::uint64_t m_ecnCeCount;
    std::uint64_t m_streamId;
    std::uint64_t m_offset;
    SwByteArray m_data;
    bool m_fin;
    std::uint64_t m_finalSize;
    std::uint64_t m_reliableSize;
    std::uint64_t m_maximum;
    bool m_bidirectional;
    std::uint64_t m_sequenceNumber;
    std::uint64_t m_retirePriorTo;
    SwByteArray m_connectionId;
    SwByteArray m_statelessResetToken;
    std::uint64_t m_errorCode;
    std::uint64_t m_errorFrameType;
    SwString m_reasonPhrase;
    bool m_applicationClose;
};
