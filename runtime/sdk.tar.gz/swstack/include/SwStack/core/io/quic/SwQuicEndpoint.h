#ifndef SWQUICENDPOINT_H
#define SWQUICENDPOINT_H

#include "../../SwStackExport.h"

// SwQuicEndpoint — GENERIC socket-agnostic QUIC engine for SwStack.
//
// This is the proven VIGIL-MESH-2B meshq::QuicEndpoint transport (real QUIC v1 +
// TLS 1.3 handshake via SwQuicHandshakeClient <-> SwQuicHandshakeServer, then a
// key HANDOFF into a sans-IO SwQuicConnection for the data plane) promoted to a
// native SwStack class over SwByteArray/SwString. It carries NO application
// semantics: no VIGIL, no mesh, no 0x3F, no ports. The engine never touches a
// socket — it emits through a send-sink installed by the owner (SwQuicSocket)
// and is fed received datagrams through onUdpPacket(). Demultiplexing of any
// non-QUIC traffic happens above this class, before onUdpPacket() is ever called.
//
// Auth transition: SwQuicAuthMode::RawPublicKey currently wires the
// verifyPeerKey hook onto X.509/SPKI pinning. SwQuic extracts canonical SPKI DER
// from the peer certificate and hands only that SPKI to the decision hook. The
// PKI chain is not validated and CertificateVerify still proves possession.
// RFC 7250 RawPublicKey negotiation is not implemented by this mode yet.
//
// SIGNAL-DRIVEN NOTIFICATION: this layer no longer notifies through std::function
// callbacks. SwQuicConnectionHandle and SwQuicEndpoint are SwObjects and raise
// SwObject signals (DECLARE_SIGNAL) — "data on the UDP -> a signal climbs the
// layers". A datagram deciphered on a connection EMITS datagramReceived(bytes);
// the handshake completing EMITS established(); a fresh server connection accepted
// by listen() EMITS connectionAccepted(conn). The ONLY std::function that remains
// is verifyPeerKey — it is a DECISION (returns bool), not a notification.

#include "SwMap.h"
#include "SwVector.h"
#include "SwObject.h"
#include "SwByteArray.h"
#include "SwString.h"

#include "quic/SwQuicConnection.h"
#include "quic/SwQuicConnectionId.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicHandshakeClient.h"
#include "quic/SwQuicHandshakeServer.h"
#include "quic/SwQuicServerCredential.h"
#include "quic/SwQuicStatelessReset.h"
#include "quic/SwQuicVarIntCodec.h"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>

// ------------------------------------------------------------------- public types

enum class SwQuicAuthMode {
    RawPublicKey  // transitional X.509/SPKI pinning; RFC 7250 wire support pending
};

// Opaque identifier of the network path a datagram arrived on. Generic: the
// engine fills handle from the peer 4-tuple; isCarrier is left to the owner.
struct SW_QUIC_EXPORT SwQuicPathHandle {
    std::uint64_t handle = 0;
    bool isCarrier = false;
};

// The only per-connection hook left is a DECISION, not a notification. Data,
// stream, and establishment events are delivered as SwObject signals instead.
struct SW_QUIC_EXPORT SwQuicCallbacks {
    // Delegated trust decision on the peer's presented key/cert (SPKI DER).
    // Return true to accept. Client-side only.
    std::function<bool(const SwByteArray& spkiDer)> verifyPeerKey;
};

// ------------------------------------------------------------- connection handle

// One QUIC connection. Owns its handshake driver until the 1-RTT keys are handed
// off to an internal SwQuicConnection, then exposes the data-plane API.
//
// It is an SwObject: it does not call back: it EMITS. established() fires once the
// handshake hands off; datagramReceived(bytes) fires per deciphered application
// datagram; streamData(id, bytes) fires per contiguous stream read. Owners connect
// slots with SwObject::connect(conn.get(), &SwQuicConnectionHandle::signal, ...).
class SW_QUIC_EXPORT SwQuicConnectionHandle : public SwObject {
    SW_OBJECT(SwQuicConnectionHandle, SwObject)

public:
    // Return false only when the owner could neither send nor retain the
    // datagram in a bounded backpressure queue.
    using SendSink = std::function<bool(const std::uint8_t* data, std::size_t len,
                                        const SwString& toAddr, std::uint16_t toPort)>;

    SwQuicConnectionHandle();

signals:
    // Handshake handed off to the 1-RTT data plane: the connection is usable.
    SW_SIGNAL_VOID(established);
    // One application QUIC DATAGRAM frame deciphered (RFC 9221) -> climbs as bytes.
    SW_SIGNAL(datagramReceived, SwByteArray);
    // Contiguous stream bytes deciphered for a stream id.
    SW_SIGNAL(streamData, std::uint64_t, SwByteArray);
    SW_SIGNAL(errorOccurred, const SwString&);
    SW_SIGNAL_VOID(closed);
    // Internal/publicly harmless notification used by the socket wrapper to
    // re-arm its one-shot timer when PTO/ACK state changes.
    SW_SIGNAL_VOID(timerChanged);

public:
    // ---- fabrique client : arme le handshake (l'Initial part via startClient_) ----
    void initClient(SendSink sink, const SwString& host, std::uint16_t port,
                    const SwString& alpn, SwQuicAuthMode authMode, SwQuicCallbacks cbs);

    // Émet l'Initial ; la suite du handshake se déroule via handleIncoming().
    bool startClientHandshake();

    // ---- fabrique serveur : un handshake serveur par nouvelle conn cliente ----
    // No accept callback: the owner (SwQuicEndpoint) connects a slot to this
    // connection's established() signal and re-emits connectionAccepted(conn).
    void initServer(SendSink sink, const SwString& fromAddr, std::uint16_t fromPort,
                    const SwString& alpn, SwQuicAuthMode authMode,
                    const SwQuicServerCredential& credential,
                    SwQuicHandshakeServer::StatelessResetTokenProvider resetTokenProvider =
                        SwQuicHandshakeServer::StatelessResetTokenProvider());

    bool hasLocalCid() const;
    const SwQuicConnectionId& localCid() const;

    // Route un datagramme entrant : driver de handshake tant que non établi, puis
    // le SwQuicConnection après handoff.
    void handleIncoming(const SwByteArray& datagram);

    void handleIncoming(const SwByteArray& datagram,
                        const SwString& fromAddr,
                        std::uint16_t fromPort);

    void abort(const SwString& reason);

    // Fait avancer les timers (PTO/idle/ACK) puis flush. No-op tant que non établi.
    void onTick();

    // ------------------------------------------------------- data-plane API ----

    bool isEstablished() const;
    bool isFailed() const;
    bool isClosed() const;
    const SwString& errorString() const;
    std::uint64_t createdMs() const;
    std::uint64_t lastActivityMs() const;
    std::int64_t nextTimeoutMs(std::uint64_t now) const;
    const SwQuicPathHandle& path() const;
    const SwString& peerAddress() const;
    std::uint16_t peerPort() const;

    void setCallbacks(SwQuicCallbacks cbs);

    bool sendDatagram(const std::uint8_t* data, std::size_t len);
    bool sendDatagram(const SwByteArray& data);

    std::uint64_t openStream(std::uint64_t type, bool bidi);

    bool sendStream(std::uint64_t streamId, const std::uint8_t* data, std::size_t len, bool fin);

    void resetStream(std::uint64_t streamId, std::uint64_t appErrorCode);

    SwVector<std::uint8_t> exporter(const SwString& label, std::size_t len) const;

    void close(std::uint64_t appErrorCode);

private:
    static std::uint64_t nowMs_();

    static SwString addrKey_(const SwString& addr, std::uint16_t port);

    static SwByteArray toSwBytes_(const std::uint8_t* data, std::size_t len);

    void resetLifecycle_();

    void fail_(const SwString& error);

    void armHandshakePto_(std::uint64_t now);

    void rememberHandshakeFlight_(const SwVector<SwByteArray>& out);

    bool emit_(const SwVector<SwByteArray>& out);

    void driveHandshake_(const SwByteArray& datagram);

    void handoffClient_();

    void handoffServer_();

    void deliverEstablished_(const SwByteArray& datagram,
                             const SwString& fromAddr,
                             std::uint16_t fromPort);

    static std::uint64_t saturatingTriple_(std::uint64_t value);

    static void saturatingAdd_(std::uint64_t& target, std::uint64_t value);

    std::uint64_t candidateSendBudget_() const;

    bool sendPathControlTo_(bool response,
                            const SwByteArray& data,
                            const SwString& address,
                            std::uint16_t port,
                            std::uint64_t maxWireBytes,
                            std::uint64_t now,
                            std::size_t& sentBytes);

    bool sendCandidatePathControl_(bool response,
                                   const SwByteArray& data,
                                   std::uint64_t now);

    bool sendCandidateChallenge_(std::uint64_t now);

    bool processCandidatePath_(const SwQuicConnection::PathControlEvents& events,
                               std::uint64_t authenticatedBytes,
                               const SwString& address,
                               std::uint16_t port,
                               std::uint64_t now);

    bool serviceCandidateTimer_(std::uint64_t now);

    void clearCandidatePath_(bool cancelConnectionValidation);

    bool flush_();

    void emitClosedIfNeeded_();

    std::uint64_t allocateStreamId_(bool bidi);

public:
    ~SwQuicConnectionHandle();
private:
    // What the class keeps (SwQuicEndpoint_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

// ---------------------------------------------------------------------- endpoint

// The generic QUIC engine. Routes incoming datagrams to their connection by peer
// 4-tuple then by destination connection ID (survives migration), and mints a
// server-role connection for a fresh Initial while listening.
//
// It is an SwObject. When listen() accepts a fresh server connection (its
// handshake completes) it EMITS connectionAccepted(conn); the owner connects a
// slot to wire that connection's own datagramReceived/streamData signals.
class SW_QUIC_EXPORT SwQuicEndpoint : public SwObject {
    SW_OBJECT(SwQuicEndpoint, SwObject)

public:
    using SendSink = SwQuicConnectionHandle::SendSink;

    explicit SwQuicEndpoint(SwObject* parent = nullptr);

signals:
    // A fresh inbound connection finished its handshake and is ready.
    SW_SIGNAL(connectionAccepted, std::shared_ptr<SwQuicConnectionHandle>);
    SW_SIGNAL(connectionRejected, const SwString&, std::uint16_t, const SwString&);
    SW_SIGNAL_VOID(timerDeadlineChanged);

public:
    void setSendSink(SendSink sink);
    void setMaxConnections(std::size_t maximum);
    void setMaxPendingHandshakes(std::size_t maximum);
    void setHandshakeTimeoutMs(std::uint64_t timeoutMs);
    std::size_t connectionCount() const;

    // Delegated-trust DECISION hook (RFC 7250). Stays a std::function because it
    // returns bool — it is NOT a notification. Applied to every client connection.
    void setVerifyPeerKey(std::function<bool(const SwByteArray& spkiDer)> verifier);

    std::shared_ptr<SwQuicConnectionHandle> connect(const SwString& host, std::uint16_t port,
                                                    const SwString& alpn,
                                                    SwQuicAuthMode authMode);

    void listen(const SwString& alpn, SwQuicAuthMode authMode);

    // Feed one received UDP datagram already classified as QUIC by the owner.
    void onUdpPacket(const std::uint8_t* data, std::size_t len,
                     const SwString& fromAddr, std::uint16_t fromPort);

    // Owning socket adapters already hold an SwByteArray. Keep that storage
    // through header parsing/AEAD instead of copying the datagram a second time.
    void onUdpPacket(const SwByteArray& dg,
                     const SwString& fromAddr, std::uint16_t fromPort);

    // Jeton statique du CID : deterministe pour toute la vie du process, donc
    // valable meme apres la purge de la connexion qui a emis ce CID.
    SwByteArray statelessResetTokenForCid(const SwByteArray& cidBytes) const;

    // Purge test/ops : oublie toutes les connexions sans le moindre paquet de
    // fermeture — simule exactement la perte d'etat (idle purge, restart).
    std::size_t dropAllConnectionsSilently();

    void onTick();

    std::int64_t nextTimeoutMs() const;

private:
    static std::uint64_t nowMs_();

    static SwString addrKey_(const SwString& addr, std::uint16_t port);

    static SwString cidKey_(const SwQuicConnectionId& cid);

    static SwByteArray toSwBytes_(const std::uint8_t* data, std::size_t len);

    // Extract the DCID (the CID the peer put in destination = OUR local CID) to
    // route the inbound even if the source address changed (migration).
    static bool extractDcid_(const SwByteArray& dg, SwString& outDcid);

    static bool isValidInitial_(const SwByteArray& dg);

    void wireConnection_(const std::shared_ptr<SwQuicConnectionHandle>& conn,
                         bool acceptedConnection);

    std::size_t pendingHandshakeCount_() const;

    void maybeSendStatelessReset_(const SwByteArray& trigger,
                                  const SwString& dcid,
                                  const SwString& fromAddr,
                                  std::uint16_t fromPort);

    void eraseIndexes_(const std::shared_ptr<SwQuicConnectionHandle>& conn);

    void purgeExpired_(std::uint64_t now);

    void registerPeer_(const std::shared_ptr<SwQuicConnectionHandle>& conn);

    void registerCid_(const std::shared_ptr<SwQuicConnectionHandle>& conn);


    // Stateless reset (RFC 9000 10.3) : cle statique du process — les jetons
    // derives survivent a la purge des connexions, c'est tout l'interet.
    static constexpr std::size_t kMaxStatelessResetsPerSecond = 32;

public:
    ~SwQuicEndpoint();
private:
    // What the class keeps (SwQuicEndpoint_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

#endif // SWQUICENDPOINT_H
