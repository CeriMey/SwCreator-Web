#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicAckTracker.h"

struct SwQuicAckTracker::Data : SwSharedData {
    // Plages inclusives triées de la plus grande vers la plus petite. Le cas
    // normal (numéros croissants) ne touche que m_ranges[0].
    SwVector<LocalAckRange_> m_ranges;
    bool m_ackElicitingPending;
};
