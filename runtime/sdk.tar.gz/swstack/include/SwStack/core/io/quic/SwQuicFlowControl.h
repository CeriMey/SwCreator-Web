#ifndef SWQUICFLOWCONTROL_H
#define SWQUICFLOWCONTROL_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwString.h"

#include <cstdint>

// Flow control for QUIC transport (RFC 9000, section 4).
//
// Two independent flow-control levels are modelled:
//   * SwQuicStreamFlowControl     -- per-stream limits (MAX_STREAM_DATA)
//   * SwQuicConnectionFlowControl -- aggregate connection limit (MAX_DATA)
//
// Each level has a receive side (we advertise a limit, the peer must respect
// it) and a send side (the peer advertises a limit, we must respect it).
// Header-only, C++11, fallible operations return bool with a trailing
// SwString* error out-parameter, matching the surrounding quic/ code.

class SW_QUIC_EXPORT SwQuicStreamFlowControl {
public:
    explicit SwQuicStreamFlowControl(std::uint64_t initialWindow = 262144);

    // ---- receive side (limits we advertise to the peer) -----------------

    std::uint64_t initialWindow() const;
    std::uint64_t maxDataLimit() const;
    std::uint64_t highestReceivedOffset() const;
    std::uint64_t bytesConsumed() const;

    // Called when a STREAM frame is received. Enforces that the peer did not
    // send data beyond the advertised limit (RFC 9000 4.1: FLOW_CONTROL_ERROR).
    bool onDataReceived(std::uint64_t offset,
                        std::uint64_t length,
                        SwString* error = nullptr);

    // Application read data off the stream; frees up receive-window space.
    void consume(std::uint64_t bytes);

    // Autotune: signal a MAX_STREAM_DATA update once the application has
    // consumed past half of the current window.
    bool shouldSendMaxStreamData() const;

    // The new absolute limit to advertise.
    std::uint64_t nextMaxStreamData() const;

    // Adopt nextMaxStreamData() as the advertised limit and return it.
    std::uint64_t applyMaxStreamData();

    // ---- send side (limits the peer advertises to us) -------------------

    void setPeerMaxData(std::uint64_t limit);

    std::uint64_t peerMaxData() const;

    // How many more bytes we may send given what we already sent.
    std::uint64_t sendableBytes(std::uint64_t alreadySent) const;

    // True when we cannot send wantToSend more bytes without exceeding the
    // peer-advertised limit (STREAM_DATA_BLOCKED condition).
    bool isBlocked(std::uint64_t wantToSend, std::uint64_t alreadySent) const;

private:
    static void setError_(SwString* error, const char* message);

public:
    ~SwQuicStreamFlowControl();
public:
    SwQuicStreamFlowControl(const SwQuicStreamFlowControl& other);
    SwQuicStreamFlowControl& operator=(const SwQuicStreamFlowControl& other);
private:
    // What the class keeps (SwQuicFlowControl_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

class SW_QUIC_EXPORT SwQuicConnectionFlowControl {
public:
    explicit SwQuicConnectionFlowControl(std::uint64_t initialWindow = 262144);

    // ---- receive side (aggregate limit we advertise) --------------------

    std::uint64_t initialWindow() const;
    std::uint64_t maxDataLimit() const;
    std::uint64_t bytesReceived() const;
    std::uint64_t bytesConsumed() const;

    // Called with the number of newly received stream bytes across all
    // streams. Enforces the connection-level MAX_DATA limit.
    bool onDataReceived(std::uint64_t length, SwString* error = nullptr);

    void consume(std::uint64_t bytes);

    bool shouldSendMaxData() const;

    std::uint64_t nextMaxData() const;

    std::uint64_t applyMaxData();

    // ---- send side (aggregate limit the peer advertises) ----------------

    void setPeerMaxData(std::uint64_t limit);

    std::uint64_t peerMaxData() const;

    std::uint64_t sendableBytes(std::uint64_t alreadySent) const;

    bool isBlocked(std::uint64_t wantToSend, std::uint64_t alreadySent) const;

private:
    static void setError_(SwString* error, const char* message);

public:
    ~SwQuicConnectionFlowControl();
public:
    SwQuicConnectionFlowControl(const SwQuicConnectionFlowControl& other);
    SwQuicConnectionFlowControl& operator=(const SwQuicConnectionFlowControl& other);
private:
    // What the class keeps (SwQuicFlowControl_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
