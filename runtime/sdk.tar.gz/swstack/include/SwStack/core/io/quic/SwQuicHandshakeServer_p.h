#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicHandshakeServer.h"

struct SwQuicHandshakeServer::Data : SwSharedData {
    State m_state;
    SwString m_error;
    SwQuicServerCredential m_credential;
    CredentialSelector m_credentialSelector;
    SwString m_serverName;
    bool m_requireClientAuth = false;
    bool m_requireRawPublicKeys = false;
    std::function<bool(const SwByteArray&)> m_clientSpkiVerifier;
    SwByteArray m_authenticatedClientSpkiDer;
    SwQuicTransportParameters m_localParams;
    SwQuicTransportParameters m_peerParams;
    bool m_hasPeerParams = false;
    SwByteArray m_applicationProtocol{SwByteArray("h3")};
    ApplicationProtocolSelector m_applicationProtocolSelector;
    StatelessResetTokenProvider m_statelessResetTokenProvider;
    SwQuicConnectionId m_originalDestinationConnectionId;
    SwQuicConnectionId m_initialProtectionDestinationConnectionId;
    SwQuicConnectionId m_retrySourceConnectionId;
    SwQuicConnectionId m_clientConnectionId;
    SwQuicConnectionId m_serverConnectionId;
    bool m_retryUsed = false;
    SwQuicInitialKeys m_clientInitialKeys;
    SwQuicInitialKeys m_serverInitialKeys;
    SwQuicInitialKeys m_clientHandshakeKeys;
    SwQuicInitialKeys m_serverHandshakeKeys;
    SwQuicInitialKeys m_clientApplicationKeys;
    SwQuicInitialKeys m_serverApplicationKeys;
    SwByteArray m_serverRandom;
    SwByteArray m_clientRandomSessionId;
    SwByteArray m_clientX25519Public;
    SwByteArray m_clientX25519MlKem768KeyShare;
    std::uint16_t m_negotiatedKeyExchangeGroup = 0;
    bool m_enableHybridKeyExchange = true;
    SwByteArray m_clientInitialCrypto;
    SwQuicStream m_clientInitialCryptoReassembly;
    SwByteArray m_clientHandshakeCrypto;
    SwQuicStream m_clientHandshakeCryptoReassembly;
    SwByteArray m_clientHelloMessage;
    SwByteArray m_serverHelloMessage;
    SwByteArray m_handshakeSecret;
    SwByteArray m_clientHandshakeTrafficSecret;
    SwByteArray m_serverHandshakeTrafficSecret;
    SwByteArray m_clientApplicationTrafficSecret;
    SwByteArray m_serverApplicationTrafficSecret;
    SwByteArray m_exporterMasterSecret;
    SwByteArray m_transcriptHashServerFinished;
    SwByteArray m_negotiatedAlpn;
    std::uint64_t m_serverInitialPacketNumber;
    std::uint64_t m_serverHandshakePacketNumber;
    SwMap<std::uint64_t, bool> m_clientInitialPns;
    bool m_handshakeComplete;
    bool m_pendingClientInitialAck;
    std::uint64_t m_clientInitialLargest = 0;
    bool m_haveClientInitialLargest = false;
    std::uint64_t m_clientHandshakeLargest = 0;
    bool m_haveClientHandshakeLargest = false;
    SwMap<std::uint64_t, bool> m_clientHandshakePns;
    std::uint64_t m_serverApplicationPacketNumber = 0;
    bool m_confirmationSent = false;
    std::uint64_t m_bytesReceivedFromClient = 0;
    std::uint64_t m_bytesSentToClient = 0;
    SwByteArray m_masterSecret;
    SwByteArray m_transcriptToServerFinished;
    SwByteArray m_resumptionMasterSecret;
    // 0-RTT resumption state.
    SwQuicTicketStore* m_ticketStore = nullptr;
    bool m_resuming = false;
    bool m_acceptEarlyData = false;
    SwByteArray m_resumptionPsk;
    SwQuicInitialKeys m_earlyKeys;
    bool m_hasEarlyKeys = false;
    SwByteArray m_receivedEarlyData;
    SwVector<SwQuicFrame> m_earlyStreamFrames;
    std::uint64_t m_maxEarlyDataSize = 0;
    std::uint64_t m_earlyDataBytesReceived = 0;
    std::uint64_t m_clientEarlyLargest = 0;
    bool m_haveClientEarlyLargest = false;
    SwHash<std::uint64_t, bool> m_clientEarlyPns; // 0-RTT replay dedup
};
