#ifndef SWQUICCONNECTIONID_H
#define SWQUICCONNECTIONID_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"

#include <cstddef>

class SW_QUIC_EXPORT SwQuicConnectionId {
public:
    static const std::size_t kMaxLength = 20;

    SwQuicConnectionId();

    explicit SwQuicConnectionId(const SwByteArray& bytes);

    static bool fromBytes(const SwByteArray& bytes,
                          SwQuicConnectionId& outConnectionId,
                          SwString* error = nullptr);

    bool setBytes(const SwByteArray& bytes, SwString* error = nullptr);

    const SwByteArray& bytes() const;
    std::size_t size() const;
    bool isEmpty() const;

    bool operator==(const SwQuicConnectionId& other) const;

    bool operator!=(const SwQuicConnectionId& other) const;

private:
    static void setError_(SwString* error, const char* message);

public:
    ~SwQuicConnectionId();
public:
    SwQuicConnectionId(const SwQuicConnectionId& other);
    SwQuicConnectionId& operator=(const SwQuicConnectionId& other);
private:
    // What the class keeps (SwQuicConnectionId_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
