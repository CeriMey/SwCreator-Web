#ifndef SWQUICHYBRIDKEX_H
#define SWQUICHYBRIDKEX_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"

#include <cstddef>
#include <cstdint>

// Wire-format helpers for the TLS X25519MLKEM768 NamedGroup. The ordering is
// defined by draft-ietf-tls-ecdhe-mlkem: ML-KEM material first, X25519 second.
class SW_QUIC_EXPORT SwQuicHybridKex {
public:
    static std::uint16_t x25519Group();
    static std::uint16_t x25519MlKem768Group();

    static std::size_t mlKemPublicKeySize();
    static std::size_t mlKemCiphertextSize();
    static std::size_t x25519PublicKeySize();
    static std::size_t componentSecretSize();
    static std::size_t clientKeyShareSize();
    static std::size_t serverKeyShareSize();
    static std::size_t combinedSecretSize();

    static bool buildClientKeyShare(const SwByteArray& mlKemPublicKey,
                                    const SwByteArray& x25519PublicKey,
                                    SwByteArray& out,
                                    SwString* error = nullptr);

    static bool splitClientKeyShare(const SwByteArray& share,
                                    SwByteArray& mlKemPublicKey,
                                    SwByteArray& x25519PublicKey,
                                    SwString* error = nullptr);

    static bool buildServerKeyShare(const SwByteArray& mlKemCiphertext,
                                    const SwByteArray& x25519PublicKey,
                                    SwByteArray& out,
                                    SwString* error = nullptr);

    static bool splitServerKeyShare(const SwByteArray& share,
                                    SwByteArray& mlKemCiphertext,
                                    SwByteArray& x25519PublicKey,
                                    SwString* error = nullptr);

    static bool combineSecrets(const SwByteArray& mlKemSecret,
                               const SwByteArray& x25519Secret,
                               SwByteArray& out,
                               SwString* error = nullptr);

private:
    static bool fail_(SwString* error, const char* message);

    static void clearError_(SwString* error);
};

#endif
