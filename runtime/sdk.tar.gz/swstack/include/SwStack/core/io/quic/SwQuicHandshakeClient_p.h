#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicHandshakeClient.h"

struct SwQuicHandshakeClient::Data : SwSharedData {
    State m_state;
    SwString m_serverName;
    SwString m_error;
    SwByteArray m_clientPrivateKey;
    SwByteArray m_clientPublicKey;
    SwByteArray m_clientMlKemPrivateKey;
    SwByteArray m_clientMlKemPublicKey;
    SwByteArray m_clientRandom;
    std::uint16_t m_negotiatedKeyExchangeGroup = 0;
    bool m_enableHybridKeyExchange = true;
    SwQuicConnectionId m_originalDestinationConnectionId;
    SwQuicConnectionId m_sourceConnectionId;
    SwQuicConnectionId m_serverConnectionId;
    SwQuicConnectionId m_retrySourceConnectionId;
    SwByteArray m_retryToken;
    bool m_retryReceived = false;
    SwQuicInitialKeys m_clientInitialKeys;
    SwQuicInitialKeys m_serverInitialKeys;
    SwQuicInitialKeys m_clientHandshakeKeys;
    SwQuicInitialKeys m_serverHandshakeKeys;
    SwQuicInitialKeys m_clientApplicationKeys;
    SwQuicInitialKeys m_serverApplicationKeys;
    SwByteArray m_clientHelloMessage;
    SwByteArray m_serverHelloMessage;
    SwByteArray m_serverInitialCrypto;
    SwQuicStream m_serverInitialCryptoReassembly;
    SwByteArray m_serverHandshakeCrypto;
    SwQuicStream m_serverHandshakeCryptoReassembly;
    bool m_verifyPeer;
    bool m_verifyChain;
    bool m_requireRawPublicKeys = false;
    SwQuicServerCredential m_credential;
    bool m_serverRequestedClientCertificate = false;
    SwVector<std::uint16_t> m_requestedClientSignatureSchemes;
    std::function<bool(const SwByteArray&)> m_subjectPublicKeyInfoVerifier;
    SwByteArray m_exporterMasterSecret;
    SwByteArray m_resumptionMasterSecret;
    // 0-RTT resumption state.
    bool m_resuming = false;
    SwQuicSessionTicket m_resumptionTicket;
    SwByteArray m_earlyData;
    SwQuicInitialKeys m_earlyKeys;
    bool m_hasEarlyKeys = false;
    bool m_earlyDataAccepted = false;
    bool m_pskAccepted = false;
    std::uint64_t m_clientEarlyPacketNumber = 0;
    SwQuicTransportParameters m_peerTransportParameters;
    SwQuicTransportParameters m_localTransportParameters;
    bool m_hasPeerTransportParameters;
    SwByteArray m_applicationProtocol{SwByteArray("h3")};
    SwByteArray m_negotiatedAlpn;
    SwVector<SwByteArray> m_serverCertificateChain;
    SwByteArray m_handshakeSecret;
    SwByteArray m_clientHandshakeTrafficSecret;
    SwByteArray m_serverHandshakeTrafficSecret;
    SwByteArray m_clientApplicationTrafficSecret;
    SwByteArray m_serverApplicationTrafficSecret;
    SwByteArray m_serverCertificateDer;
    SwByteArray m_authenticatedServerSpkiDer;
    std::uint64_t m_clientInitialPacketNumber;
    std::uint64_t m_clientHandshakePacketNumber;
    SwMap<std::uint64_t, bool> m_receivedInitialPacketNumbers;
    SwMap<std::uint64_t, bool> m_receivedHandshakePacketNumbers;
    bool m_pendingInitialAck = false;
    bool m_pendingHandshakeAck = false;
    bool m_initialKeysDiscarded = false;
    bool m_handshakeComplete;
};
