#ifndef SWQUICHANDSHAKESERVER_H
#define SWQUICHANDSHAKESERVER_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwHash.h"
#include "SwMap.h"
#include "SwVector.h"
#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicClientHelloBuilder.h"
#include "quic/SwQuicCertificateVerifier.h"
#include "quic/SwQuicConnectionId.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicFrameCodec.h"
#include "quic/SwQuicInitialSecrets.h"
#include "quic/SwQuicHybridKex.h"
#include "quic/SwQuicLimits.h"
#include "quic/SwQuicMlKem768.h"
#include "quic/SwQuicPacketProtector.h"
#include "quic/SwQuicPacketKeys.h"
#include "quic/SwQuicRandom.h"
#include "quic/SwQuicServerCredential.h"
#include "quic/SwQuicSessionTicket.h"
#include "quic/SwQuicStream.h"
#include "quic/SwQuicTransportParameters.h"
#include "quic/SwQuicVarIntCodec.h"
#include "quic/SwQuicX25519.h"
#include "quic/SwTls13KeySchedule.h"
#include "quic/SwTls13Messages.h"

#include <cstdint>
#include <functional>

// Server-side driver for the QUIC v1 + TLS 1.3 handshake (RFC 9000 / 9001 /
// 8446), cipher suite TLS_AES_128_GCM_SHA256, ALPN "h3". Transport agnostic:
// processIncomingDatagram() consumes a client datagram and appends datagrams to
// send back. It accepts the client Initial (ClientHello), answers with
// ServerHello + the encrypted Handshake flight (EncryptedExtensions,
// Certificate, CertificateVerify signed by the supplied credential, Finished),
// verifies the client Finished, and derives 1-RTT keys.
//
// The certificate + CertificateVerify signature come from a SwQuicServerCredential
// (see SwQuicEcdsaCredential::createSelfSigned for a self-contained one).
// Optional client authentication sends CertificateRequest and verifies the
// client's chain leaf, CertificateVerify, Finished and delegated SPKI policy.
class SW_QUIC_EXPORT SwQuicHandshakeServer {
public:
    enum class State {
        Idle,
        WaitClientInitial,
        WaitClientFinished,
        Complete,
        Failed
    };

    // Selected after the complete ClientHello has been reassembled, but before
    // the server flight is constructed. This permits one UDP QUIC endpoint to
    // host protocols with different client-authentication policies (for
    // example an anonymous carrier ALPN and an mTLS fleet ALPN) without racing
    // two handshake engines on the same Initial.
    struct ApplicationProtocolPolicy {
        SwByteArray protocol;
        bool requireClientAuthentication = false;
        bool requireRawPublicKeys = false;
        std::function<bool(const SwByteArray&)> clientSpkiVerifier;
        // Optional ALPN-specific snapshot. It is selected only after the
        // complete ClientHello has authenticated its framing and before any
        // ServerHello/Certificate bytes are constructed. An invalid value
        // preserves the credential installed with setCredential().
        SwQuicServerCredential credential;
        SwQuicTransportParameters transportParameters;
        bool hasTransportParameters = false;
    };
    using ApplicationProtocolSelector = std::function<bool(
        const SwVector<SwByteArray>& offered, ApplicationProtocolPolicy& selected)>;
    using CredentialSelector = std::function<bool(
        const SwString& serverName, SwQuicServerCredential& selected)>;

    SwQuicHandshakeServer();

    State state() const;
    bool handshakeComplete() const;
    const SwString& errorString() const;

    const SwQuicInitialKeys& serverHandshakeKeys() const;
    const SwQuicInitialKeys& clientHandshakeKeys() const;
    const SwQuicInitialKeys& serverApplicationKeys() const;
    const SwQuicInitialKeys& clientApplicationKeys() const;
    const SwQuicConnectionId& serverConnectionId() const;
    const SwQuicConnectionId& clientConnectionId() const;
    // DCID observe dans le premier Initial et authentifie indirectement par les
    // transport parameters QUIC standards envoyes au client.
    const SwQuicConnectionId& originalDestinationConnectionId() const;
    // Installs the stateless Retry context before the first token-bearing
    // Initial is processed. Initial protection keys are still derived from
    // retrySourceConnectionId (the packet DCID); ODCID remains the first
    // Initial's DCID and is authenticated into the transport parameters.
    bool setRetryContext(const SwQuicConnectionId& originalDestinationConnectionId,
                         const SwQuicConnectionId& retrySourceConnectionId);
    // Next 1-RTT packet number after the server confirmation flight: a
    // connection taking over the app space must continue from here so it never
    // reuses an AEAD nonce already spent on HANDSHAKE_DONE.
    std::uint64_t serverApplicationPacketNumber() const;
    const SwByteArray& negotiatedAlpn() const;
    std::uint16_t negotiatedKeyExchangeGroup() const;
    bool setHybridKeyExchangeEnabled(bool enabled);
    bool hybridKeyExchangeEnabled() const;
    bool setApplicationProtocol(const SwByteArray& protocol);
    bool setApplicationProtocolSelector(ApplicationProtocolSelector selector);
    // Stateless reset (RFC 9000 10.3) : l'endpoint proprietaire de la cle
    // statique fournit le jeton du SCID que ce handshake vient de choisir.
    // Le jeton part dans les transport parameters ; l'endpoint pourra alors
    // repondre a un CID oublie sans aucun etat de connexion.
    using StatelessResetTokenProvider = std::function<SwByteArray(const SwByteArray& cidBytes)>;
    bool setStatelessResetTokenProvider(StatelessResetTokenProvider provider);
    const SwByteArray& applicationProtocol() const;
    bool hasPeerTransportParameters() const;
    const SwQuicTransportParameters& peerTransportParameters() const;
    // Empty until the client CertificateVerify and Finished have both been
    // authenticated. A received Certificate message alone is not identity.
    const SwByteArray& authenticatedClientSubjectPublicKeyInfo() const;

    // RFC 8446 section 7.5. Keep exporter_master_secret private and expose
    // only labelled derivation after the peer Finished has authenticated.
    bool exportKeyingMaterial(const SwString& label,
                              const SwByteArray& context,
                              std::size_t length,
                              SwByteArray& out,
                              SwString* error = nullptr) const;

    SwQuicTransportParameters& localTransportParameters();
    const SwQuicTransportParameters& localTransportParameters() const;

    // Install the certificate + signing credential the server presents.
    void setCredential(const SwQuicServerCredential& credential);
    void setCredentialSelector(CredentialSelector selector);
    const SwString& serverName() const;

    // Request and require TLS 1.3 client authentication. The verifier receives
    // only canonical DER SubjectPublicKeyInfo and is therefore suitable for a
    // pinned fleet CA/leaf policy. It runs before Finished, while the identity
    // accessor above remains empty until Finished authenticates the transcript.
    void setRequireClientAuthentication(bool required);
    bool requiresClientAuthentication() const;
    void setRequireRawPublicKeys(bool required);
    bool requiresRawPublicKeys() const;
    void setClientSubjectPublicKeyInfoVerifier(
            std::function<bool(const SwByteArray&)> verifier);
    bool hasClientSubjectPublicKeyInfoVerifier() const;

    // Enable session resumption / 0-RTT: on a resumption ClientHello whose PSK
    // is in this store and whose binder verifies, the server accepts the PSK
    // (and the offered 0-RTT if the ticket allows early data).
    void setTicketStore(SwQuicTicketStore* store);

    bool isResuming() const;
    bool acceptedEarlyData() const;
    const SwByteArray& receivedEarlyData() const;
    // The 0-RTT STREAM frames, preserved so a driver can replay them into the
    // established connection (RFC 9001 4.6: early data resumes on 1-RTT streams).
    const SwVector<SwQuicFrame>& earlyStreamFrames() const;

    bool processIncomingDatagram(const SwByteArray& datagram,
                                 SwVector<SwByteArray>& outDatagrams,
                                 SwString* error = nullptr);

private:
    class SW_QUIC_EXPORT SecretGuard_ {
    public:
        explicit SecretGuard_(SwByteArray& secret);
        ~SecretGuard_();

    private:
        SecretGuard_(const SecretGuard_&) = delete;
        SecretGuard_& operator=(const SecretGuard_&) = delete;
        SwByteArray& m_secret;
    };

    static void setError_(SwString* error, const char* message);
    static void clearError_(SwString* error);
    bool fail_(SwString* error);

    static void secureClearKeys_(SwQuicInitialKeys& keys) noexcept;

    void discardCompletedHandshakeSecrets_() noexcept;

    void discardFailedSecrets_() noexcept;

    static SwByteArray rawMessage_(std::uint8_t type, const SwByteArray& body);

    static void appendU16_(SwByteArray& out, std::uint16_t value);
    static void appendU24_(SwByteArray& out, std::uint32_t value);

    // ------------------------------------------------------------ Initial ---

    bool handleClientInitial_(const SwByteArray& packet,
                              std::size_t& consumed,
                              SwString* error);

    // Decrypt a coalesced 0-RTT packet with the early keys and collect its
    // early application data. Only reachable after the ClientHello (which
    // derives the early keys) has been parsed in the same datagram.
    bool handleClientZeroRtt_(const SwByteArray& packet, std::size_t& consumed,
                              SwString* error);

    // Skip a token-less long-header packet using its cleartext length.
    static bool skipLongHeaderNoToken_(const SwByteArray& packet, std::size_t& consumed,
                                       SwString* error);

    bool tryParseClientHello_(SwString* error);

    static bool offersProtocol_(const SwVector<SwByteArray>& protocols,
                                const SwByteArray& target);

    // ---------------------------------------------------- server flight ---

    bool emitServerFlight_(SwVector<SwByteArray>& outDatagrams, SwString* error);

    void buildServerHelloBody_(std::uint16_t selectedGroup,
                               const SwByteArray& serverKeyShare,
                               SwByteArray& outBody);

    bool buildEncryptedExtensionsBody_(SwByteArray& outBody, SwString* error);

    void buildCertificateRequestBody_(SwByteArray& outBody) const;

    void buildCertificateBody_(SwByteArray& outBody);

    bool buildCertificateVerifyBody_(const SwByteArray& transcriptHashToCert,
                                     SwByteArray& outBody,
                                     SwString* error);

    bool buildServerInitialPacket_(const SwByteArray& serverHelloMessage,
                                   std::size_t minPacketSize,
                                   SwByteArray& outPacket,
                                   SwString* error);

    // Fragment the Handshake CRYPTO stream across as many Handshake packets as
    // needed, each with an increasing CRYPTO offset, so a real (multi-KB)
    // certificate chain stays under the path MTU (RFC 9000 19.6). The peer
    // reassembles out-of-order/multi-packet CRYPTO via SwQuicStream.
    bool buildServerHandshakePackets_(const SwByteArray& handshakeCrypto,
                                      SwVector<SwByteArray>& outPackets,
                                      SwString* error);

    void buildLongHeader_(std::uint8_t firstByteBase,
                          std::uint64_t protectedPayloadLength,
                          std::uint8_t pnLen,
                          std::uint64_t packetNumber,
                          bool isInitial,
                          SwByteArray& outHeader);

    // ------------------------------------------------ client Handshake ---

    bool handleClientHandshake_(const SwByteArray& packet,
                                std::size_t& consumed,
                                SwString* error);

    bool tryVerifyClientFinished_(SwString* error);

public:
    const SwByteArray& resumptionMasterSecret() const;

    // Issue a NewSessionTicket: derive the PSK from resumption_master_secret and
    // the nonce, store (ticket -> PSK, early-data limit, transport params) in
    // the ticket store for later 0-RTT, and return the NST message body to send
    // to the client in 1-RTT (RFC 8446 4.6.1).
    bool issueNewSessionTicket(SwQuicTicketStore& store,
                               const SwByteArray& ticket,
                               const SwByteArray& ticketNonce,
                               std::uint32_t ticketLifetimeS,
                               std::uint32_t ticketAgeAdd,
                               std::uint32_t maxEarlyDataSize,
                               SwByteArray& outNewSessionTicketBody,
                               SwString* error = nullptr);

private:

    // Handshake-space ACK of the client Finished + a 1-RTT HANDSHAKE_DONE.
    bool emitHandshakeConfirmation_(SwVector<SwByteArray>& outDatagrams, SwString* error);

    // ---------------------------------------------------------- helpers ---

    static void appendExtension_(SwByteArray& extensions,
                                 std::uint16_t type,
                                 const SwByteArray& data);

    static bool peekInitialDcid_(const SwByteArray& packet,
                                 SwQuicConnectionId& outDcid,
                                 SwString* error);

    SwQuicFrame buildAckFrame_(const SwMap<std::uint64_t, bool>& received);

    void recordClientInitialPn_(std::uint64_t pn);

    void recordClientHandshakePn_(std::uint64_t pn);

#if defined(SW_QUIC_ENABLE_SECRET_LIFETIME_TEST_HOOKS)
public:
    bool transientSecretsDiscardedForTest() const;
#endif
public:
    ~SwQuicHandshakeServer();
public:
    SwQuicHandshakeServer(const SwQuicHandshakeServer& other);
    SwQuicHandshakeServer& operator=(const SwQuicHandshakeServer& other);
private:
    // What the class keeps (SwQuicHandshakeServer_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
