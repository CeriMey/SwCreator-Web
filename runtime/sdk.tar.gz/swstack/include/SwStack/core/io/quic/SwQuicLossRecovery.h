#include "SwSharedData.h"
#include "SwPair.h"
#include "SwMap.h"
#ifndef SWQUICLOSSRECOVERY_H
#define SWQUICLOSSRECOVERY_H

#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwString.h"

#include <cstdint>
#include <cstddef>
#include <cmath>
#include <map>
#include <vector>
#include <utility>

// SwQuicLossRecovery implements RFC 9002 sections 5 (RTT estimation) and 6
// (loss detection + PTO) for a *single* packet-number space.
//
// Internal precision choice:
//   RFC 9002 defines the RTT estimator with the fractions 1/8, 7/8, 1/4 and
//   3/4.  Doing this with integer milliseconds would discard sub-millisecond
//   state on every ACK (e.g. the RFC example second sample yields rttvar=42.5
//   and smoothed=102.5).  To preserve that precision through the EWMA we keep
//   all RTT state as double milliseconds internally.  Public getters expose the
//   double values verbatim; computePtoMs() rounds to the nearest whole
//   millisecond only at the uint64_t API boundary.
class SW_QUIC_EXPORT SwQuicLossRecovery {
public:
    struct SW_QUIC_EXPORT SentPacket {
        std::uint64_t packetNumber;
        std::uint64_t sentTimeMs;
        bool ackEliciting;
        bool inFlight;
        std::size_t sentBytes;

        SentPacket();
    };

    struct AckResult {
        SwVector<std::uint64_t> newlyAcked;
        SwVector<std::uint64_t> lost;
    };

    // RFC 9002 constants.
    static std::uint64_t kPacketThreshold();   // section 6.1.1
    static double kTimeThresholdFactor(); // section 6.1.2
    static double kGranularityMs();          // timer granularity
    static double kInitialRttMs();         // section 6.2.2

    SwQuicLossRecovery();

    // Handshake-confirmed gate: ack delay is only subtracted from RTT samples
    // once the handshake is confirmed (RFC 9002 section 5.3).
    void setHandshakeConfirmed(bool confirmed);
    bool handshakeConfirmed() const;

    // RTT accessors (double milliseconds; see precision note above).
    double latestRttMs() const;
    double minRttMs() const;
    double smoothedRttMs() const;
    double rttVarMs() const;
    bool hasRttSample() const;

    std::size_t inFlightCount() const;

    // Record a packet as sent / tracked in this space.
    void onPacketSent(const SentPacket& packet);

    // Process an incoming ACK frame.  ackedRangesInclusive is a list of
    // [low, high] inclusive packet-number ranges that the peer acknowledged;
    // largestAcked is provided separately and is always treated as acked.
    bool onAckReceived(std::uint64_t largestAcked,
                       std::uint64_t ackDelayMs,
                       const SwVector<SwPair<std::uint64_t, std::uint64_t> >& ackedRangesInclusive,
                       std::uint64_t nowMs,
                       AckResult& out,
                       SwString* error = nullptr);

    // Probe Timeout duration (RFC 9002 section 6.2.1).
    //   PTO = smoothed_rtt + max(4 * rttvar, kGranularity) + max_ack_delay
    // Before the first RTT sample the initial values (smoothed = kInitialRtt,
    // rttvar = kInitialRtt/2) are used.  The double result is rounded to the
    // nearest whole millisecond for this uint64_t API.
    std::uint64_t computePtoMs(std::uint64_t maxAckDelayMs) const;

    // Same computation without rounding, for callers/tests that need the exact
    // fractional-millisecond value.
    double computePtoMsExact(std::uint64_t maxAckDelayMs) const;

private:
    static void setError_(SwString* error, const char* message);

    static bool isAcked_(std::uint64_t pn,
                         std::uint64_t largestAcked,
                         const SwVector<SwPair<std::uint64_t, std::uint64_t> >& ranges);

    // RFC 9002 section 5.3 RTT update.
    void updateRtt_(double latestRtt, double ackDelay);

    // RFC 9002 section 6.1.2 time threshold.
    double lossTimeThresholdMs_() const;

public:
    ~SwQuicLossRecovery();
public:
    SwQuicLossRecovery(const SwQuicLossRecovery& other);
    SwQuicLossRecovery& operator=(const SwQuicLossRecovery& other);
private:
    // What the class keeps (SwQuicLossRecovery_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
