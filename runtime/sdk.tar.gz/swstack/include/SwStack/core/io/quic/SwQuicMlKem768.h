#ifndef SWQUICMLKEM768_H
#define SWQUICMLKEM768_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicRandom.h"


#include <cstddef>
#include <cstdint>

// Portable ML-KEM-768 facade for the TLS X25519MLKEM768 key exchange. The
// underlying implementation is mlkem-native v1.2.0, built once for every
// SwStack consumer. Randomness crosses this boundary explicitly so the
// upstream library never owns a platform RNG.
class SW_QUIC_EXPORT SwQuicMlKem768 {
public:
    static std::size_t publicKeySize();
    static std::size_t privateKeySize();
    static std::size_t ciphertextSize();
    static std::size_t sharedSecretSize();
    static std::size_t keyGenerationSeedSize();
    static std::size_t encapsulationSeedSize();

    static bool keyPair(SwByteArray& publicKey,
                        SwByteArray& privateKey,
                        SwString* error = nullptr);

    static bool keyPairDeterministic(const SwByteArray& seed,
                                     SwByteArray& publicKey,
                                     SwByteArray& privateKey,
                                     SwString* error = nullptr);

    static bool encapsulate(const SwByteArray& publicKey,
                            SwByteArray& ciphertext,
                            SwByteArray& sharedSecret,
                            SwString* error = nullptr);

    static bool encapsulateDeterministic(const SwByteArray& publicKey,
                                         const SwByteArray& seed,
                                         SwByteArray& ciphertext,
                                         SwByteArray& sharedSecret,
                                         SwString* error = nullptr);

    static bool decapsulate(const SwByteArray& privateKey,
                            const SwByteArray& ciphertext,
                            SwByteArray& sharedSecret,
                            SwString* error = nullptr);

    static bool validatePublicKey(const SwByteArray& publicKey,
                                  SwString* error = nullptr);

private:
    static std::uint8_t* bytes_(SwByteArray& value);

    static const std::uint8_t* constBytes_(const SwByteArray& value);

    static bool fail_(SwString* error, const char* message);

    static void clearError_(SwString* error);
};

#endif
