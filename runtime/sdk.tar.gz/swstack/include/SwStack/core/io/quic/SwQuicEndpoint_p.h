#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/quic/SwQuicEndpoint.h"

struct SwQuicConnectionHandle::Data {
    SendSink m_sink;
    SwString m_peerAddr;
    std::uint16_t m_peerPort = 0;
    SwString m_alpn;
    SwQuicAuthMode m_authMode = SwQuicAuthMode::RawPublicKey;
    SwQuicCallbacks m_cbs;
    SwQuicPathHandle m_path;
    bool m_candidateActive = false;
    SwString m_candidateAddr;
    std::uint16_t m_candidatePort = 0;
    SwByteArray m_candidateChallenge;
    std::uint64_t m_candidateBytesReceived = 0;
    std::uint64_t m_candidateBytesSent = 0;
    std::uint64_t m_candidateStartedMs = 0;
    std::uint64_t m_candidateRetryDeadlineMs = 0;
    std::uint64_t m_candidateExpiryMs = 0;
    std::size_t m_candidateChallengeAttempts = 0;
    SwQuicConnection::Role m_role = SwQuicConnection::Role::Client;
    bool m_established = false;
    bool m_failed = false;
    bool m_closedEmitted = false;
    SwString m_error;
    std::uint64_t m_createdMs = 0;
    std::uint64_t m_lastActivityMs = 0;
    std::size_t m_handshakePtoCount = 0;
    std::uint64_t m_handshakePtoDeadlineMs = 0;
    SwVector<SwByteArray> m_lastHandshakeFlight;
    std::unique_ptr<SwQuicHandshakeClient> m_hsClient;
    std::unique_ptr<SwQuicHandshakeServer> m_hsServer;
    std::unique_ptr<SwQuicConnection> m_conn;
    SwQuicConnectionId m_localCid;
    std::uint64_t m_nextBidiStream = 0;
    std::uint64_t m_nextUniStream = 0;
};
struct SwQuicEndpoint::Data {
    SendSink m_sink;
    bool m_listening = false;
    SwString m_listenAlpn;
    SwQuicAuthMode m_listenAuth = SwQuicAuthMode::RawPublicKey;
    std::function<bool(const SwByteArray& spkiDer)> m_verifyPeerKey; // X.509/SPKI decision hook
    SwQuicServerCredential m_credential;
    SwByteArray m_statelessResetKey = SwQuicRandom::bytes(32);
    std::uint64_t m_statelessResetWindowStartMs = 0;
    std::size_t m_statelessResetsInWindow = 0;
    SwMap<SwString, std::shared_ptr<SwQuicConnectionHandle>> m_byPeer;
    SwMap<SwString, std::shared_ptr<SwQuicConnectionHandle>> m_byCid;
    SwVector<std::shared_ptr<SwQuicConnectionHandle>> m_connections;
    std::size_t m_maxConnections = 4096;
    std::size_t m_maxPendingHandshakes = 1024;
    std::uint64_t m_handshakeTimeoutMs = 10000;
};
