#ifndef SWQUICPACKETHEADER_H
#define SWQUICPACKETHEADER_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicConnectionId.h"

#include <cstdint>

class SW_QUIC_EXPORT SwQuicPacketHeader {
public:
    enum class Form {
        Long,
        Short
    };

    enum class LongPacketType {
        Initial,
        ZeroRtt,
        Handshake,
        Retry,
        VersionNegotiation,
        Unknown
    };

    SwQuicPacketHeader();

    static SwQuicPacketHeader makeInitial(const SwQuicConnectionId& destinationConnectionId,
                                          const SwQuicConnectionId& sourceConnectionId);

    Form form() const;
    void setForm(Form form);

    LongPacketType longPacketType() const;
    void setLongPacketType(LongPacketType type);

    std::uint32_t version() const;
    void setVersion(std::uint32_t version);

    const SwQuicConnectionId& destinationConnectionId() const;
    void setDestinationConnectionId(const SwQuicConnectionId& connectionId);

    const SwQuicConnectionId& sourceConnectionId() const;
    void setSourceConnectionId(const SwQuicConnectionId& connectionId);

    const SwByteArray& token() const;
    void setToken(const SwByteArray& token);

    std::uint64_t payloadLength() const;
    void setPayloadLength(std::uint64_t payloadLength);

    std::uint64_t packetNumber() const;
    bool setPacketNumber(std::uint64_t packetNumber, SwString* error = nullptr);

    // For decoded packets whose truncated wire packet number was expanded to
    // the full value (RFC 9000 appendix A.3): the full number may exceed what
    // the wire length can carry, so no fit check applies here. Encoding paths
    // must keep using setPacketNumber().
    void setDecodedPacketNumber(std::uint64_t packetNumber);

    std::uint8_t packetNumberLength() const;
    bool setPacketNumberLength(std::uint8_t packetNumberLength, SwString* error = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static std::uint64_t maxPacketNumberForLength_(std::uint8_t packetNumberLength);

public:
    ~SwQuicPacketHeader();
public:
    SwQuicPacketHeader(const SwQuicPacketHeader& other);
    SwQuicPacketHeader& operator=(const SwQuicPacketHeader& other);
private:
    // What the class keeps (SwQuicPacketHeader_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
