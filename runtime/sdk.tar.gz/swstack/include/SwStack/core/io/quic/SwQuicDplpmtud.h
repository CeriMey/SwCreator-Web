#ifndef SWQUICDPLPMTUD_H
#define SWQUICDPLPMTUD_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include <cstdint>

// SwQuicDplpmtud — Datagram Packetization Layer PMTU Discovery (RFC 8899) pour QUIC (RFC 9000 §14.3).
// Machine à états GÉNÉRIQUE : recherche par dichotomie de la plus grande taille de datagramme qui traverse
// le chemin sans fragmentation, via des paquets-sondes PING+PADDING. L'appelant (la connexion) émet la sonde
// de taille nextProbeSize() ; quand un ACK couvre le numéro de paquet de la sonde -> onProbeAcked(size), quand
// la sonde est perdue -> onProbeLost(size) (jusqu'à kMaxProbes retransmissions avant de conclure « trop grand »).
// Détection de trou noir : onBlackholeDetected() rabat le PMTU confirmé à la base et relance la recherche sous
// la taille fautive. Aucun I/O, aucun temps réel ici : entièrement piloté par événements -> testable.
class SW_QUIC_EXPORT SwQuicDplpmtud {
public:
    enum class State { Disabled, Searching, Complete, Error };

    static const int kBasePmtu  = 1200; // plancher QUuIC (RFC 9000 14.1) : jamais en dessous
    static const int kMaxProbes = 3;    // retransmissions d'une sonde avant de la déclarer perdue

    // Démarre la recherche entre la base (1200) et maxPmtu (borné par max_udp_payload_size du pair).
    void start(int maxPmtu);

    // Taille de la prochaine sonde à émettre (0 si rien à sonder : recherche terminée/désactivée).
    int nextProbeSize();

    // La sonde de `size` a été acquittée : le chemin supporte au moins `size`.
    void onProbeAcked(int size);

    // La sonde de `size` semble perdue. Après kMaxProbes tentatives -> `size` est jugé trop grand.
    void onProbeLost(int size);

    // Un trou noir est détecté (perte soutenue de paquets NON-sondes à la taille confirmée) :
    // on rabat le PMTU à la base et on relance la recherche strictement sous la taille fautive.
    void onBlackholeDetected();

    int   pmtu()  const;   // PLPMTU confirmé (utilisable dès maintenant)
    State state() const;
    int   probeCount() const;

private:
    // Dichotomie : milieu de l'intervalle ouvert (m_low, m_high].
    int candidate_() const;

    void advance_();

public:
    SwQuicDplpmtud();
public:
    ~SwQuicDplpmtud();
public:
    SwQuicDplpmtud(const SwQuicDplpmtud& other);
    SwQuicDplpmtud& operator=(const SwQuicDplpmtud& other);
private:
    // What the class keeps (SwQuicDplpmtud_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif // SWQUICDPLPMTUD_H
