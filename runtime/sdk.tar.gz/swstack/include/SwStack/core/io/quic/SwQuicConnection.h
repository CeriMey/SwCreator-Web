#include "SwSharedData.h"
#include "SwPair.h"
#include "SwMap.h"
#ifndef SWQUICCONNECTION_H
#define SWQUICCONNECTION_H

#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwDequeue.h"
#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicAckTracker.h"
#include "quic/SwQuicStatelessReset.h"
#include "quic/SwQuicCongestionControl.h"
#include "quic/SwQuicFlowControl.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicFrameCodec.h"
#include "quic/SwQuicLossRecovery.h"
#include "quic/SwQuicLimits.h"
#include "quic/SwQuicPacketCodec.h"
#include "quic/SwQuicPacketHeader.h"
#include "quic/SwQuicPacketKeys.h"
#include "quic/SwQuicPacketProtector.h"
#include "quic/SwQuicRandom.h"
#include "quic/SwQuicStream.h"
#include "quic/SwQuicStreamMap.h"
#include "quic/SwQuicTransportParameters.h"

#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <limits>
#include <vector>

// Sans-IO QUIC connection endpoint.
//
// The connection never touches a socket and never reads a clock: the driver
// (SwQuicServer, a client handshake loop, or a test) feeds it received
// datagrams with receiveDatagram(bytes, nowMs), drains outgoing datagrams
// with buildDatagrams(nowMs, out), and schedules a call to onTimeout(nowMs)
// whenever nextTimeoutMs(nowMs) elapses. All RFC 9000/9002 machinery -- packet
// number spaces, ACK generation, loss recovery, congestion control, flow
// control, PTO/idle timers -- lives behind those three calls.
//
// Packet protection is per encryption level: install keys with setLevelKeys()
// as the TLS handshake derives them. Before Initial keys are installed the
// legacy plaintext-Initial mode used by the loopback self-tests keeps working
// through receiveInitialPacket()/buildAckFrame().
class SW_QUIC_EXPORT SwQuicConnection {
public:
    enum class State {
        Open,
        Closing,   // we sent (or are about to send) CONNECTION_CLOSE
        Draining,  // the peer sent CONNECTION_CLOSE; we stay silent
        Closed
    };

    enum class Role {
        Client,
        Server
    };

    enum class Level {
        Initial = 0,
        Handshake = 1,
        Application = 2
    };

    // QUIC DATAGRAM is deliberately unreliable. Generic users keep the
    // historical reject-newest behaviour, while latency-sensitive transports
    // such as WebTransport can prefer fresh data by shedding the oldest
    // datagram without affecting reliable stream/control frames.
    enum class DatagramQueueOverflowPolicy {
        RejectNewest,
        DropOldest
    };

    static std::size_t kLevelCount();
    static std::size_t kMaxUdpPayload();
    static std::uint8_t kPacketNumberLength();
    static std::uint64_t kLocalAckDelayExponent();
    static std::uint64_t kLocalMaxAckDelayMs();
    static std::size_t kMaxPathControlEvents();
    static std::size_t kMaxInspectedPathPacketNumbers();
    static std::size_t kMaxNewTokens_();

    // Événements de validation extraits d'un paquet déjà authentifié. Le
    // driver de socket les émet sur le tuple où ils ont été reçus, au lieu de
    // les laisser rejoindre la file de perte globale du chemin actif.
    struct SW_QUIC_EXPORT PathControlEvents {
        SwVector<SwByteArray> challenges;
        SwVector<SwByteArray> responses;

        void clear();
    };

    explicit SwQuicConnection(Role role = Role::Server);

    // ---- identity / configuration ---------------------------------------

    Role role() const;
    void setRole(Role role);

    std::uint32_t version() const;
    void setVersion(std::uint32_t version);

    // Connection ID the peer uses to address us: its length is needed to
    // parse incoming short-header packets, and it is our SCID in long headers.
    void setLocalConnectionId(const SwQuicConnectionId& connectionId);
    const SwQuicConnectionId& localConnectionId() const;

    // Connection ID we put in the destination field of packets we send.
    void setPeerConnectionId(const SwQuicConnectionId& connectionId);
    const SwQuicConnectionId& peerConnectionId() const;

    void setInitialToken(const SwByteArray& token);

    SwQuicTransportParameters& localTransportParameters();
    const SwQuicTransportParameters& localTransportParameters() const;

    // Install the exact parameters advertised by the handshake before any
    // application packet is processed. Merely mutating localTransportParameters()
    // cannot resize the already-constructed flow controllers.
    void applyLocalTransportParameters(const SwQuicTransportParameters& parameters);

    // Apply the transport parameters the peer sent in its TLS handshake.
    void applyPeerTransportParameters(const SwQuicTransportParameters& parameters);
    bool hasPeerTransportParameters() const;
    const SwQuicTransportParameters& peerTransportParameters() const;

    // ---- packet protection keys ------------------------------------------

    void setLevelKeys(Level level,
                      const SwQuicInitialKeys& rxKeys,
                      const SwQuicInitialKeys& txKeys);

    bool hasLevelKeys(Level level) const;

    // Discard an encryption level (RFC 9001 section 4.9): its keys and its
    // packet-number space state are dropped for good.
    void dropLevelKeys(Level level);

    // Loopback/self-test mode: the Initial space sends unprotected packets
    // through SwQuicPacketCodec instead of requiring Initial keys.
    void setPlaintextInitialMode(bool enabled);

    // Seed the next transmit packet number for a level. Used when a separate
    // handshake driver already spent some 1-RTT packet numbers (e.g. sending
    // HANDSHAKE_DONE) before handing the app space to this connection, so that
    // no AEAD nonce is reused (RFC 9001 5.3).
    void setNextTxPacketNumber(Level level, std::uint64_t packetNumber);

    bool handshakeConfirmed() const;
    void setHandshakeConfirmed(bool confirmed);

    // ---- 1-RTT key update (RFC 9001 section 6) -----------------------------

    bool currentKeyPhase() const;
    std::uint64_t keyUpdateCount() const;
    // False when the installed 1-RTT keys carry no traffic secret (legacy
    // self-test keys): a key update can then be neither sent nor followed.
    bool keyUpdateAvailable() const;

    // Initiate a key update: subsequent 1-RTT packets flip the Key Phase bit
    // and use the next-generation keys. Only allowed once the handshake is
    // confirmed (RFC 9001 6.2) and after a packet protected with the current
    // keys has been acknowledged (RFC 9001 6.1).
    bool initiateKeyUpdate(SwString* error = nullptr);

    // ---- receive path -----------------------------------------------------

    // Feed one received UDP datagram (possibly carrying coalesced packets).
    bool receiveDatagram(const SwByteArray& datagram,
                         std::uint64_t nowMs,
                         SwString* error = nullptr,
                         bool* authenticatedOut = nullptr);

    // Variante utilisée par un driver qui connaît le tuple candidat. Les
    // PATH_CHALLENGE/PATH_RESPONSE sont remontés séparément et ne sont jamais
    // mis dans pendingFrames, donc un PTO du chemin actif ne peut pas les
    // retransmettre vers le mauvais tuple.
    bool receiveDatagramWithPathEvents(const SwByteArray& datagram,
                                       std::uint64_t nowMs,
                                       PathControlEvents& pathEvents,
                                       SwString* error = nullptr,
                                       bool* authenticatedOut = nullptr,
                                       std::uint64_t* authenticatedBytesOut = nullptr);

    // Authenticates and decodes one established 1-RTT packet without
    // committing packet numbers, ACK/loss state, streams, flow control or
    // idle activity. A path driver uses this before admitting a new remote
    // tuple. Non-path frames are reported but deliberately left unacknowledged
    // so QUIC retransmits them after address validation succeeds.
    bool inspectDatagramPathEvents(const SwByteArray& datagram,
                                   std::uint64_t nowMs,
                                   PathControlEvents& pathEvents,
                                   bool& hadNonPathFrames,
                                   SwString* error = nullptr,
                                   bool* authenticatedOut = nullptr,
                                   std::uint64_t* authenticatedBytesOut = nullptr);

    bool receiveDatagramImpl_(const SwByteArray& datagram,
                              std::uint64_t nowMs,
                              SwString* error,
                              bool* authenticatedOut,
                              std::uint64_t* authenticatedBytesOut);

    // Legacy plaintext entry point kept for the loopback self-tests: decodes
    // one unprotected Initial packet and runs it through the same frame
    // machinery as the protected path.
    bool receiveInitialPacket(const SwByteArray& packet, SwString* error = nullptr);

    // ---- application send API ----------------------------------------------

    // Bornes du driver I/O : 0 conserve le comportement historique illimité. Le quota par build
    // empêche une ACK compression / grande cwnd de vider plusieurs Mo vers sendto en une rafale.
    void setMaxDatagramsPerBuild(std::size_t maximum);
    void setDatagramPacing(std::size_t datagramsPerMillisecond,
                           std::size_t maximumBurst);
    void setMaxPendingDatagramFrames(std::size_t maximum);
    void setMaxPendingDatagramBytes(std::size_t maximum);
    void setDatagramQueueOverflowPolicy(DatagramQueueOverflowPolicy policy);
    std::size_t maxPendingDatagramFrames() const;
    std::size_t maxPendingDatagramBytes() const;
    DatagramQueueOverflowPolicy datagramQueueOverflowPolicy() const;
    std::size_t pendingDatagramFrameCount() const;
    std::size_t pendingDatagramFrameBytes() const;
    std::uint64_t droppedOutgoingDatagramFrames() const;
    // Upper bound imposed by the currently selected underlay/virtual carrier.
    // QUIC's peer max_udp_payload_size is also honoured; this local bound lets
    // an embedding transport reserve its own encapsulation budget without
    // changing the globally advertised transport parameter.
    bool setMaximumUdpPayloadSize(std::size_t maximum);
    std::size_t maximumUdpPayloadSize() const;
    void setMaxReceivedDatagrams(std::size_t maximumCount,
                                 std::size_t maximumBytes);
    void setMaxStreamReassemblyBytes(std::size_t maximum);
    void setMaxStreamReassemblyFragments(std::size_t maximum);
    void setMaxBufferedStreamSendBytes(std::size_t maximum);

    // Actual retained STREAM payload across the application send buffers,
    // frames waiting for packetization, and retransmittable sent packets.
    // Counting duplicate retransmissions is intentional: this is a memory
    // pressure measurement, not a logical byte offset.
    std::size_t queuedStreamSendBytes() const;

    std::size_t maxBufferedStreamSendBytes() const;

    std::size_t availableStreamSendBytes() const;

    // Payload retained in this stream's application send buffer, before it is
    // transformed into STREAM frames. A non-zero value after packet building
    // therefore identifies data that flow control (or another staging limit)
    // has not admitted yet. Unknown and already-drained streams return zero.
    std::size_t unstagedStreamSendBytes(std::uint64_t streamId) const;

    // Buffer stream data for transmission; it goes out on the next
    // buildDatagrams() within flow-control and congestion limits.
    bool sendStreamData(std::uint64_t streamId,
                        const SwByteArray& data,
                        bool fin,
                        SwString* error = nullptr);

    // Abort the local send side with RESET_STREAM. Bytes that have not yet
    // reached a packet are discarded; already-sent STREAM frames stop being
    // retransmitted. The reset itself remains retransmittable until ACKed.
    bool resetStream(std::uint64_t streamId,
                     std::uint64_t applicationErrorCode,
                     SwString* error = nullptr);

    // Abort the send side while retaining retransmission of the prefix ending
    // at reliableSize (draft-ietf-quic-reliable-stream-reset). The prefix must
    // already have been handed to QUIC before this operation is requested.
    bool resetStreamAt(std::uint64_t streamId,
                       std::uint64_t applicationErrorCode,
                       std::uint64_t reliableSize,
                       SwString* error = nullptr);

    // Ask the peer to abort its send side. This is intentionally independent
    // from resetStream(): a bidirectional request rejected while its body is
    // still arriving needs both STOP_SENDING and a RESET_STREAM response.
    bool stopReceivingStream(std::uint64_t streamId,
                             std::uint64_t applicationErrorCode,
                             SwString* error = nullptr);

    // Register a locally-created stream whose bytes were sent by a separate
    // handshake driver (notably accepted 0-RTT) before this dataplane existed.
    void registerLocalStream(std::uint64_t streamId);

    // Inject stream data received out-of-band into the receive path, as if it
    // had arrived in a STREAM frame. Used to replay 0-RTT early data (collected
    // by the handshake driver before this connection existed) into the app.
    bool injectEarlyStream(std::uint64_t streamId, std::uint64_t offset,
                           const SwByteArray& data, bool fin, SwString* error = nullptr);

    // Queue an unreliable DATAGRAM frame (RFC 9221).
    bool queueDatagramFrame(const SwByteArray& data, SwString* error = nullptr);

    bool queueDatagramFrame(SwByteArray&& data, SwString* error = nullptr);

    // Queue an arbitrary frame at an encryption level (CRYPTO during the
    // handshake, control frames, ...).
    void queueFrame(Level level, const SwQuicFrame& frame);

    // True while some send stream still holds bytes that were not yet
    // packetized, or sent bytes/FIN not yet acknowledged by the peer. Drivers
    // use it to delay a graceful CONNECTION_CLOSE until queued responses and
    // control-stream frames actually reached the peer.
    bool hasUnacknowledgedSendData() const;

    // Initiate connection close: a CONNECTION_CLOSE goes out on the next
    // buildDatagrams(), then the connection drains.
    void close(std::uint64_t errorCode,
               const SwString& reasonPhrase,
               bool isApplicationClose = true);

    // ---- outgoing datagram assembly -----------------------------------------

    // Drain everything currently sendable into ready-to-write UDP datagrams.
    bool buildDatagrams(std::uint64_t nowMs,
                        SwVector<SwByteArray>& outDatagrams,
                        SwString* error = nullptr);

    // ---- timers ---------------------------------------------------------------

    // Milliseconds until the next timer fires, or -1 when no timer is armed.
    // The driver must call onTimeout(nowMs) once that delay elapsed, then
    // flush buildDatagrams().
    std::int64_t nextTimeoutMs(std::uint64_t nowMs) const;

    // Fire expired timers: PTO probes are queued (drain them with
    // buildDatagrams), idle/drain expiry closes the connection.
    void onTimeout(std::uint64_t nowMs);

    // ---- connection migration / path validation (RFC 9000 section 9) --------

    // Construit exactement un paquet 1-RTT de contrôle de chemin. Le paquet
    // consomme le prochain PN de l'espace Application ordinaire : deux tuples
    // ne peuvent donc jamais réutiliser le même nonce AEAD. La frame ciblée
    // n'est volontairement pas enregistrée comme retransmissible dans la loss
    // queue globale ; son driver possède le retry borné et le tuple de sortie.
    // maxWireBytes borne le budget 3x propre au candidat. UINT64_MAX désactive
    // uniquement cette borne externe (challenge initié localement, non réfléchi).
    bool buildPathControlDatagram(bool response,
                                  const SwByteArray& controlData,
                                  std::uint64_t nowMs,
                                  std::uint64_t maxWireBytes,
                                  SwByteArray& outDatagram,
                                  SwString* error = nullptr);

    // Le driver appelle ceci seulement après un PATH_RESPONSE authentifié sur
    // le tuple candidat. Les PN et la loss map restent communs à la connexion ;
    // seul le contrôleur de congestion est réinitialisé pour le nouveau chemin.
    void commitPathMigration();

    // Starts driver-managed path validation without redirecting the normal
    // send queue. The caller sends the returned challenge on the candidate
    // tuple and calls commitPathMigration() only after a matching authenticated
    // PATH_RESPONSE arrives on that same tuple.
    bool beginPathValidation(std::uint64_t nowMs,
                             SwByteArray& challengeOut,
                             SwString* error = nullptr);

    bool matchesPathResponse(const SwByteArray& data) const;

    void cancelPathValidation();

    // Called by the driver when a packet for this connection arrives from a
    // new peer address (the connection is found by its connection ID, so it
    // survives the address change). This starts path validation: a
    // PATH_CHALLENGE is queued toward the new path, sending on that path is
    // held under the 3x anti-amplification limit until it validates
    // (RFC 9000 9.3), and the congestion controller + RTT are reset once it
    // does (RFC 9000 9.4).
    // receivedBytesOnNewPath is the size of the datagram that triggered the
    // migration: the new path's anti-amplification budget (RFC 9000 8.1/9.3)
    // must count ONLY bytes received on that path, not the connection's whole
    // history, otherwise a spoofed migration turns into a reflection vector.
    bool onPeerAddressChanged(std::uint64_t nowMs,
                              std::uint64_t receivedBytesOnNewPath = 1200,
                              SwString* error = nullptr);

    bool pathValidated() const;
    bool awaitingPathResponse() const;

    // Issue a fresh connection ID to the peer (NEW_CONNECTION_ID, RFC 9000
    // 5.1.1 / 19.15) so it can migrate to a new, unlinkable CID. Returns the
    // issued CID; the driver must route incoming packets addressed to it to
    // this connection.
    SwByteArray issueNewConnectionId(SwString* error = nullptr);

    // ---- state / introspection ---------------------------------------------

    State state() const;
    const SwQuicPacketHeader& lastInitialHeader() const;

    std::size_t receivedPingCount() const;
    std::size_t pendingDatagramCount() const;
    const SwByteArray& lastPathChallenge() const;
    bool sawVersionNegotiation() const;
    bool sawRetry() const;

    std::uint64_t closeErrorCode() const;
    const SwString& closeReason() const;

    SwByteArray takeDatagram();

    const SwQuicStreamMap& streams() const;
    SwQuicStreamMap& streams();

    bool isStreamReceiveReset(std::uint64_t streamId) const;

    bool streamHasFinalSize(std::uint64_t streamId) const;

    bool isStreamSendReset(std::uint64_t streamId) const;

    SwByteArray readStream(std::uint64_t streamId);

    // Return one unit of peer-initiated bidirectional-stream credit after the
    // application consumed the complete receive side and queued its complete
    // response (including FIN), or deliberately reset its send side. This only
    // marks the application half as released. Credit is returned later, once
    // the QUIC send state is terminal: RESET_STREAM ACKed, or FIN ACKed plus
    // every byte below the final offset ACKed.
    //
    // RFC 9000 section 4.6 makes MAX_STREAMS cumulative: every released stream
    // raises the largest stream count the peer may open. Remember released IDs
    // so a repeated HTTP pump cannot grant the same credit twice.
    bool releasePeerBidirectionalStream(std::uint64_t streamId,
                                        SwString* error = nullptr);

    bool isPeerBidirectionalStreamReleased(std::uint64_t streamId) const;

    std::uint64_t localBidirectionalStreamLimit() const;

    std::size_t trackedReceiveStreamCount() const;
    std::size_t trackedSendStreamCount() const;
    std::size_t retiredPeerBidirectionalRangeCount() const;

    // Streams whose receive state changed in the most recent datagram. This
    // lets event-driven adapters avoid scanning every historical stream on
    // every UDP packet.
    SwVector<std::uint64_t> takeTouchedStreamIds();

    // Contiguous CRYPTO data received at a level; the Initial overload keeps
    // the historical accessor shape.
    const SwByteArray& cryptoData() const;
    const SwByteArray& cryptoData(Level level) const;
    SwByteArray takeCryptoData(Level level);

    bool buildAckFrame(SwQuicFrame& outFrame,
                       std::uint64_t ackDelay = 0,
                       SwString* error = nullptr) const;

    const SwQuicLossRecovery& lossRecovery(Level level) const;
    const SwQuicCongestionControl& congestionControl() const;
    const SwQuicConnectionFlowControl& connectionFlowControl() const;

    struct DiagnosticStats {
        std::size_t pendingFrames = 0;
        std::size_t pendingReliableFrames = 0;
        std::size_t pendingDatagramFrames = 0;
        std::size_t pendingDatagramBytes = 0;
        std::size_t sentPackets = 0;
        std::size_t ackElicitingSinceAck = 0;
        std::size_t probesPending = 0;
        std::size_t bufferedStreamSendBytes = 0;
        std::uint64_t congestionWindow = 0;
        std::uint64_t bytesInFlight = 0;
        std::uint64_t nextTxPacketNumber = 0;
        std::uint64_t largestReceivedPacketNumber = 0;
        std::uint64_t ackDeadlineMs = 0;
        std::int64_t nextTimeoutMs = -1;
        bool hasLargestReceivedPacketNumber = false;
        bool hasAckDeadline = false;
        bool hasPendingAck = false;
        bool hasAckElicitingInFlight = false;
        std::uint64_t queuedDatagramFrames = 0;
        std::uint64_t encodedDatagramFrames = 0;
        std::uint64_t receivedDatagramFrames = 0;
        std::uint64_t droppedOutgoingDatagramFrames = 0;
        std::uint64_t droppedReceivedDatagrams = 0;
    };

    DiagnosticStats diagnosticStats(Level level, std::uint64_t nowMs) const;

private:
    struct SW_QUIC_EXPORT SentRecord_ {
        SwVector<SwQuicFrame> retransmittable;
        std::size_t sentBytes;
        std::uint64_t sentTimeMs;
        bool ackEliciting;

        SentRecord_();
    };

    struct SW_QUIC_EXPORT Space_ {
        SwQuicAckTracker ackTracker;
        SwQuicLossRecovery loss;
        SwQuicInitialKeys rxKeys;
        SwQuicInitialKeys txKeys;
        bool hasRxKeys;
        bool hasTxKeys;
        std::uint64_t largestReceivedPn;
        bool hasLargestReceivedPn;
        std::uint64_t nextTxPn;
        SwDequeue<SwQuicFrame> pendingFrames; // FIFO O(1), surface SwStack
        SwMap<std::uint64_t, SentRecord_> sentPackets;
        std::uint64_t ackDeadlineMs;
        bool hasAckDeadline;
        std::uint64_t lastAckElicitingSentMs;
        bool hasAckElicitingInFlight;
        std::uint64_t largestReceivedTimeMs; // arrival time of largestReceivedPn
        std::size_t probesPending;           // PTO probes owed, allowed past cwnd
        std::size_t ackElicitingSinceAck;    // ack-eliciting rx'd since last ACK sent (RFC 9000 13.2.1)

        Space_();
    };

    struct PendingReliableReset_ {
        std::uint64_t errorCode = 0;
        std::uint64_t finalSize = 0;
        std::uint64_t reliableSize = 0;
    };

    struct SW_QUIC_EXPORT SendStream_ {
        SwByteArray buffer;          // queued storage; consumed prefix is retained amortized
        std::size_t bufferOffset;    // first byte not yet handed to a packet
        std::uint64_t nextOffset;    // wire offset of buffer[bufferOffset]
        bool finQueued;
        bool finSent;
        bool finAcked;
        bool resetQueued;
        bool resetAt;
        bool resetAcked;
        std::uint64_t resetReliableSize;
        bool peerCreditPending;
        std::uint64_t contiguousAckedOffset;
        // Disjoint half-open ranges strictly above contiguousAckedOffset.
        // They are merged on every ACK, so reordered/retransmitted packets do
        // not grow this set with duplicate byte ranges.
        SwMap<std::uint64_t, std::uint64_t> ackedRanges;

        SendStream_();
    };

    static void setError_(SwString* error, const char* message);

    // ---- 1-RTT key update internals (RFC 9001 section 6) -------------------

    static bool deriveNextGenerationKeys_(const SwQuicInitialKeys& current,
                                          SwQuicInitialKeys& outNext,
                                          SwString* error);

    // Move both directions one generation forward: our send keys MUST follow
    // the peer's phase (RFC 9001 6.2). The old receive keys stay available for
    // reordered previous-phase packets until the next update replaces them
    // (RFC 9001 6.5 suggests dropping them after 3 PTO; the next update is the
    // hard bound applied here).
    bool advanceKeyPhase_(SwString* error);

    static void clearError_(SwString* error);

    static void mergeDeadline_(bool& any, std::uint64_t& deadline, std::uint64_t candidate);

    // Un datagramme non authentifié est-il un Stateless Reset du pair ?
    // Jetons candidats : celui des transport parameters du handshake (le CID
    // choisi par le serveur) et ceux appris via NEW_CONNECTION_ID.
    bool isPeerStatelessReset_(const SwByteArray& datagram) const;

    static std::uint64_t combineIdleTimeouts_(std::uint64_t local, std::uint64_t peer);

    Space_& space_(Level level);
    const Space_& space_(Level level) const;

    bool hasPendingFrames_(Level level, const Space_& space) const;

    bool pendingDatagramLimitExceeded_(std::size_t nextBytes) const;

    void dropOldestPendingDatagram_();

    void enforcePendingDatagramLimits_();

    bool reservePendingDatagram_(std::size_t bytes, SwString* error);

    void restorePendingFrame_(Level level, SwQuicFrame&& frame);

    // On PTO, resend the retransmittable frames of the oldest unacknowledged
    // packet in the space so a lost packet is recovered directly; if none carry
    // retransmittable data, queue a PING to elicit an ACK.
    void requeueOldestUnacked_(Space_& space);

    // PTO deadline for a space, valid only while ack-eliciting data is in
    // flight. max_ack_delay is included only for the Application space: the
    // peer must not delay Initial/Handshake ACKs (RFC 9002 6.2.1, appendix A.9).
    bool spacePtoDeadline_(Level level, const Space_& space, std::uint64_t& outDeadline) const;

    // ---- receive internals ---------------------------------------------------

    bool packetNumberAlreadyConsumed_(Level level, std::uint64_t packetNumber) const;

    bool receivePacket_(const SwByteArray& packet,
                        std::uint64_t nowMs,
                        std::size_t& outConsumed,
                        bool& outAuthenticated,
                        SwString* error);

    static bool skipLongHeaderPacket_(const SwByteArray& packet,
                                      bool hasToken,
                                      std::size_t& outConsumed,
                                      SwString* error);

    static bool readByteAt_(const SwByteArray& bytes,
                            std::size_t& offset,
                            std::uint8_t& outValue,
                            SwString* error);

    bool processDecodedPacket_(Level level,
                               std::uint64_t packetNumber,
                               const SwByteArray& payload,
                               std::uint64_t nowMs,
                               SwString* error);

    static bool isAckElicitingFrame_(SwQuicFrame::Type type);

    bool processFrame_(Level level,
                       SwQuicFrame& frame,
                       std::uint64_t nowMs,
                       SwString* error);

    Level levelForPathResponse_(Level receivedLevel) const;

    void adoptPeerConnectionIdIfRetired_(const SwQuicFrame& frame);

    bool processAckFrame_(Level level,
                          const SwQuicFrame& frame,
                          std::uint64_t nowMs,
                          SwString* error);

    static double kPersistentCongestionThreshold();

    bool processCryptoFrame_(Level level, const SwQuicFrame& frame, SwString* error);

    // RFC 9000 4.5 / 19.4: a received RESET_STREAM carries the stream's Final
    // Size. Validate it against data already received and any established final
    // size (FINAL_SIZE_ERROR on a decrease/change), and account the reset
    // stream's bytes in connection-level flow control so both peers stay in
    // sync, then credit them as consumed (the data is discarded).
    bool processResetStreamFrame_(const SwQuicFrame& frame, SwString* error);

    // RESET_STREAM_AT is receive-terminal only after the application has
    // consumed the reliable prefix. Until then STREAM retransmissions up to
    // Reliable Size remain admissible and the reset signal is withheld.
    bool processResetStreamAtFrame_(const SwQuicFrame& frame,
                                    SwString* error);

    bool processStreamFrame_(const SwQuicFrame& frame, SwString* error);

    void markStreamTouched_(std::uint64_t streamId);

    bool validateSendStreamState_(std::uint64_t streamId, SwString* error);

    bool validatePeerSendControlStream_(std::uint64_t streamId, SwString* error) const;

    bool isPeerInitiatedBidirectional_(std::uint64_t streamId) const;

    static void acknowledgeSendStreamRange_(SendStream_& stream,
                                            std::uint64_t offset,
                                            std::uint64_t length);

    static bool isSendStreamRangeAcked_(const SendStream_& stream,
                                        std::uint64_t offset,
                                        std::uint64_t length);

    bool shouldRetransmitFrame_(const SwQuicFrame& frame) const;

    void removePendingSendFramesForStream_(std::uint64_t streamId,
                                           bool removeResetFrames);

    void removePendingSendFramesAfterReliableSize_(std::uint64_t streamId,
                                                    std::uint64_t reliableSize);

    bool isRetiredPeerBidirectional_(std::uint64_t streamId) const;

    void markRetiredPeerBidirectional_(std::uint64_t streamId);

    void retirePeerBidirectionalState_(std::uint64_t streamId);

    void retireAcknowledgedPeerStreams_();

    // RFC 9000 4.6: reject a peer-initiated stream whose number exceeds the
    // limit we advertised. Only applies to peer-initiated streams; streams we
    // already track are fine.
    bool enforceStreamLimit_(std::uint64_t streamId, SwString* error);

    SwQuicStreamFlowControl& streamFlowControl_(std::uint64_t streamId);

    std::uint64_t localStreamWindow_(std::uint64_t streamId) const;

    std::uint64_t peerStreamSendLimit_(std::uint64_t streamId) const;

    void creditFlowControl_(std::uint64_t streamId, std::uint64_t bytes);

    void armDrainTimer_(std::uint64_t nowMs);

    void refreshInFlightFlag_(Space_& space);

    // ---- send internals -------------------------------------------------------

    bool levelCanSend_(Level level) const;

    bool buildCloseDatagram_(std::uint64_t nowMs,
                             SwVector<SwByteArray>& outDatagrams,
                             SwString* error);

    bool buildDatagramsForLevel_(Level level,
                                 std::uint64_t nowMs,
                                 SwVector<SwByteArray>& outDatagrams,
                                 SwString* error);

    static bool containsPathFrame_(const SwVector<SwQuicFrame>& frames);

    // RFC 9000 8.1: before a path is validated, an endpoint must not send more
    // than three times the bytes it has received on that path.
    bool amplificationBlocked_(std::size_t nextDatagramSize) const;

    bool stageOneStreamFrame_(SwMap<std::uint64_t, SendStream_>::iterator it,
                              Space_& app);

    // Stage a bounded number of chunks in round-robin order. This both avoids
    // materialising an arbitrarily large pending-frame queue and prevents a
    // low stream id from monopolising the connection window.
    void stageStreamFrames_();

    static std::uint64_t kStreamChunkBytes();
    static std::size_t kMaxStagedStreamFrames_();

    std::size_t packetPayloadBudgetForWire_(Level level, std::size_t wireBytes) const;

    std::size_t effectiveMaximumUdpPayloadSize_() const;

    std::size_t packetPayloadBudget_(Level level) const;

    static std::size_t frameEncodedSize_(const SwQuicFrame& frame);

    bool encodePacket_(Level level,
                       SwVector<SwQuicFrame>& frames,
                       bool ackEliciting,
                       std::uint64_t nowMs,
                       SwByteArray& outDatagram,
                       bool& outAmplificationBlocked,
                       SwString* error,
                       std::uint64_t maxWireBytes = UINT64_MAX,
                       bool trackGlobalLoss = true);

    static bool isRetransmittableFrame_(SwQuicFrame::Type type);

    bool buildLongHeaderBytes_(Level level,
                               std::uint64_t packetNumber,
                               std::size_t plaintextPayloadSize,
                               SwByteArray& outHeader,
                               SwString* error) const;

    // ---- members -----------------------------------------------------------

public:
    ~SwQuicConnection();
public:
    SwQuicConnection(const SwQuicConnection& other);
    SwQuicConnection& operator=(const SwQuicConnection& other);
private:
    // What the class keeps (SwQuicConnection_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
