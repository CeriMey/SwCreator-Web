#ifndef SWQUICFRAME_H
#define SWQUICFRAME_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwByteArray.h"
#include "SwString.h"

#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

class SW_QUIC_EXPORT SwQuicFrame {
public:
    enum class Type {
        Padding,
        Ping,
        Ack,
        ResetStream,
        ResetStreamAt,
        StopSending,
        Crypto,
        NewToken,
        Stream,
        MaxData,
        MaxStreamData,
        MaxStreams,
        DataBlocked,
        StreamDataBlocked,
        StreamsBlocked,
        NewConnectionId,
        RetireConnectionId,
        PathChallenge,
        PathResponse,
        ConnectionClose,
        HandshakeDone,
        Datagram
    };

    struct AckRange {
        std::uint64_t gap;
        std::uint64_t rangeLength;
    };

    static SwQuicFrame padding(std::size_t length = 1);

    static SwQuicFrame ping();

    static SwQuicFrame ack(std::uint64_t largestAcknowledged,
                           std::uint64_t ackDelay,
                           std::uint64_t firstAckRange,
                           const SwVector<AckRange>& ackRanges = SwVector<AckRange>());

    static SwQuicFrame ackWithEcn(std::uint64_t largestAcknowledged,
                                  std::uint64_t ackDelay,
                                  std::uint64_t firstAckRange,
                                  const SwVector<AckRange>& ackRanges,
                                  std::uint64_t ect0Count,
                                  std::uint64_t ect1Count,
                                  std::uint64_t ecnCeCount);

    static SwQuicFrame resetStream(std::uint64_t streamId,
                                   std::uint64_t applicationErrorCode,
                                   std::uint64_t finalSize);

    static SwQuicFrame resetStreamAt(std::uint64_t streamId,
                                     std::uint64_t applicationErrorCode,
                                     std::uint64_t finalSize,
                                     std::uint64_t reliableSize);

    static SwQuicFrame stopSending(std::uint64_t streamId, std::uint64_t applicationErrorCode);

    static SwQuicFrame crypto(std::uint64_t offset, const SwByteArray& data);

    static SwQuicFrame newToken(const SwByteArray& token);

    static SwQuicFrame stream(std::uint64_t streamId,
                              std::uint64_t offset,
                              const SwByteArray& data,
                              bool fin);

    static SwQuicFrame stream(std::uint64_t streamId,
                              std::uint64_t offset,
                              SwByteArray&& data,
                              bool fin);

    static SwQuicFrame maxData(std::uint64_t maximumData);

    static SwQuicFrame maxStreamData(std::uint64_t streamId, std::uint64_t maximumStreamData);

    static SwQuicFrame maxStreams(bool bidirectional, std::uint64_t maximumStreams);

    static SwQuicFrame dataBlocked(std::uint64_t dataLimit);

    static SwQuicFrame streamDataBlocked(std::uint64_t streamId, std::uint64_t streamDataLimit);

    static SwQuicFrame streamsBlocked(bool bidirectional, std::uint64_t streamLimit);

    static SwQuicFrame newConnectionId(std::uint64_t sequenceNumber,
                                       std::uint64_t retirePriorTo,
                                       const SwByteArray& connectionId,
                                       const SwByteArray& statelessResetToken);

    static SwQuicFrame retireConnectionId(std::uint64_t sequenceNumber);

    static SwQuicFrame pathChallenge(const SwByteArray& data);

    static SwQuicFrame pathResponse(const SwByteArray& data);

    static SwQuicFrame connectionClose(std::uint64_t errorCode,
                                       std::uint64_t frameType,
                                       const SwString& reasonPhrase);

    static SwQuicFrame applicationClose(std::uint64_t errorCode, const SwString& reasonPhrase);

    static SwQuicFrame handshakeDone();

    static SwQuicFrame datagram(const SwByteArray& data);

    static SwQuicFrame datagram(SwByteArray&& data);

    Type type() const;
    std::size_t paddingLength() const;

    std::uint64_t largestAcknowledged() const;
    std::uint64_t ackDelay() const;
    std::uint64_t firstAckRange() const;
    const SwVector<AckRange>& ackRanges() const;
    bool hasEcn() const;
    std::uint64_t ect0Count() const;
    std::uint64_t ect1Count() const;
    std::uint64_t ecnCeCount() const;

    std::uint64_t streamId() const;
    std::uint64_t offset() const;
    const SwByteArray& data() const;
    SwByteArray takeData();
    bool fin() const;

    std::uint64_t finalSize() const;
    std::uint64_t reliableSize() const;
    std::uint64_t maximum() const;
    bool isBidirectional() const;

    std::uint64_t sequenceNumber() const;
    std::uint64_t retirePriorTo() const;
    const SwByteArray& connectionId() const;
    const SwByteArray& statelessResetToken() const;

    std::uint64_t errorCode() const;
    std::uint64_t errorFrameType() const;
    const SwString& reasonPhrase() const;
    bool isApplicationClose() const;

private:
    explicit SwQuicFrame(Type type);

public:
    ~SwQuicFrame();
public:
    SwQuicFrame(const SwQuicFrame& other);
    SwQuicFrame& operator=(const SwQuicFrame& other);
private:
    // What the class keeps (SwQuicFrame_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
