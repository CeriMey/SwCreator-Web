#ifndef SWQUICINITIALSECRETS_H
#define SWQUICINITIALSECRETS_H

#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwByteArray.h"
#include "SwCrypto.h"
#include "SwString.h"
#include "quic/SwQuicConnectionId.h"

#include <algorithm>
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <vector>

struct SW_QUIC_EXPORT SwQuicInitialKeys {
    SwByteArray secret;
    SwByteArray key;
    SwByteArray iv;
    SwByteArray headerProtectionKey;
};

class SW_QUIC_EXPORT SwQuicInitialSecrets {
public:
    static bool deriveV1(const SwQuicConnectionId& destinationConnectionId,
                         SwQuicInitialKeys& outClientKeys,
                         SwQuicInitialKeys& outServerKeys,
                         SwString* error = nullptr);

    static bool hkdfExpandLabel(const SwByteArray& secret,
                                const SwString& label,
                                std::size_t outputLength,
                                SwByteArray& outBytes,
                                SwString* error = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static SwByteArray hmacSha256_(const SwByteArray& key, const SwByteArray& data);

    static void appendU16_(SwByteArray& out, std::uint16_t value);

    static bool hkdfExtract_(const SwByteArray& salt,
                             const SwByteArray& inputKeyMaterial,
                             SwByteArray& outSecret,
                             SwString* error);

    static bool hkdfExpand_(const SwByteArray& pseudoRandomKey,
                            const SwByteArray& info,
                            std::size_t outputLength,
                            SwByteArray& outBytes,
                            SwString* error);

    static bool deriveKeySet_(const SwByteArray& secret,
                              SwQuicInitialKeys& outKeys,
                              SwString* error);
};

#endif
