#ifndef SWQUICHANDSHAKECLIENT_H
#define SWQUICHANDSHAKECLIENT_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwMap.h"
#include "SwVector.h"
#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicCertificateVerifier.h"
#include "quic/SwQuicClientHelloBuilder.h"
#include "quic/SwQuicClientInitialBuilder.h"
#include "quic/SwQuicConnectionId.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicFrameCodec.h"
#include "quic/SwQuicInitialSecrets.h"
#include "quic/SwQuicHybridKex.h"
#include "quic/SwQuicLimits.h"
#include "quic/SwQuicMlKem768.h"
#include "quic/SwQuicPacketCodec.h"
#include "quic/SwQuicPacketHeader.h"
#include "quic/SwQuicPacketKeys.h"
#include "quic/SwQuicPacketProtector.h"
#include "quic/SwQuicRandom.h"
#include "quic/SwQuicRetry.h"
#include "quic/SwQuicSessionTicket.h"
#include "quic/SwQuicServerCredential.h"
#include "quic/SwQuicStream.h"
#include "quic/SwQuicTransportParameters.h"
#include "quic/SwQuicVarIntCodec.h"
#include "quic/SwQuicX25519.h"
#include "quic/SwTls13KeySchedule.h"

#include <algorithm>
#include <functional>
#include "quic/SwTls13Messages.h"

#include <cstdint>

// Client-side driver for the QUIC v1 + TLS 1.3 handshake (RFC 9000 / RFC 9001 /
// RFC 8446), cipher suite TLS_AES_128_GCM_SHA256, ALPN "h3". It is transport
// agnostic: start() returns the datagram to send, and processIncomingDatagram()
// consumes a received datagram and returns datagrams to send back. It drives the
// key schedule through Initial -> Handshake -> 1-RTT.
//
// Server authentication: the certificate chain is validated against the
// system trust store with hostname matching, and the CertificateVerify
// signature over the transcript is checked (SwQuicCertificateVerifier). The
// server Finished MAC is verified as well. setVerifyPeer(false) disables the
// PKI checks for loopback self-tests that use synthetic certificates.
// When CertificateRequest is received, a configured credential emits the TLS
// 1.3 client Certificate + CertificateVerify flight before client Finished.
class SW_QUIC_EXPORT SwQuicHandshakeClient {
public:
    enum class State {
        Idle,
        WaitServerHello,
        WaitServerHandshake,
        Complete,
        Failed
    };

    SwQuicHandshakeClient();

    State state() const;
    bool handshakeComplete() const;
    const SwString& errorString() const;
    const SwByteArray& serverCertificateDer() const;
    const SwVector<SwByteArray>& serverCertificateChain() const;
    // Empty until the server CertificateVerify and Finished have both been
    // authenticated. This avoids exposing an unauthenticated identity merely
    // because a Certificate message was received.
    const SwByteArray& authenticatedServerSubjectPublicKeyInfo() const;

    // Client credential used only when the server sends CertificateRequest.
    // SwQuicServerCredential is deliberately role-neutral at the wire level:
    // it is a DER chain plus a CertificateVerify signing callback.
    void setCredential(const SwQuicServerCredential& credential);
    bool hasCredential() const;

    // PKI verification toggle: keep it enabled against real servers; disable
    // it only for loopback tests with synthetic certificates.
    void setVerifyPeer(bool verify);
    bool verifyPeer() const;

    // Chain-policy toggle, independent of the signature check. With a real but
    // self-signed peer (loopback server), set this false to still verify the
    // CertificateVerify signature while skipping the trusted-root requirement.
    void setVerifyCertificateChain(bool verify);
    bool verifyCertificateChain() const;

    // Transitional X.509/SPKI delegated trust. The peer still sends an X.509
    // Certificate message; SwQuic strictly extracts and canonically re-encodes
    // its SubjectPublicKeyInfo, then gives ONLY that SPKI DER to the decision
    // callback instead of validating the X.509 chain. CertificateVerify still
    // proves possession. This is SPKI pinning, not RFC 7250 RawPublicKey wire
    // negotiation. A callback exception rejects the handshake.
    void setSubjectPublicKeyInfoVerifier(
            std::function<bool(const SwByteArray& spkiDer)> verifier);
    bool hasSubjectPublicKeyInfoVerifier() const;

    // RFC 7250 is opt-in and fail-closed: both certificate_type extensions,
    // an Ed25519 RPK credential and the delegated SPKI verifier are required.
    void setRequireRawPublicKeys(bool required);
    bool requiresRawPublicKeys() const;
    void setRawPublicKeyVerifier(std::function<bool(const SwByteArray& spkiDer)> verifier);
    bool hasRawPublicKeyVerifier() const;

    // Enable 0-RTT resumption: the next start() sends a resumption ClientHello
    // for this ticket and, if earlyData is non-empty, a 0-RTT packet carrying
    // it (typically an HTTP/3 request on stream 0). The caller must not resume
    // with a ticket whose allowsEarlyData() is false. start() rejects resumption
    // while an SPKI verifier is installed because tickets are not yet bound to
    // the authenticated peer identity.
    void setResumption(const SwQuicSessionTicket& ticket,
                       const SwByteArray& earlyData = SwByteArray());
    bool isResuming() const;
    bool hasEarlyKeys() const;
    const SwQuicInitialKeys& earlyKeys() const;
    // Next Application packet number after the 0-RTT packets: a 1-RTT
    // connection taking over must continue from here since 0-RTT and 1-RTT
    // share the Application packet-number space (RFC 9001 5.4).
    std::uint64_t clientEarlyPacketNumber() const;
    // True once the server confirmed it accepted the offered 0-RTT (early_data
    // echoed in EncryptedExtensions); false means 0-RTT was rejected and the
    // early data must be resent in 1-RTT.
    bool earlyDataAccepted() const;

    // Peer transport parameters from EncryptedExtensions (RFC 9001 8.2),
    // ready to be applied to a SwQuicConnection.
    bool hasPeerTransportParameters() const;
    const SwQuicTransportParameters& peerTransportParameters() const;
    const SwQuicTransportParameters& localTransportParameters() const;
    bool setLocalTransportParameters(const SwQuicTransportParameters& parameters);
    const SwByteArray& negotiatedAlpn() const;
    bool setApplicationProtocol(const SwByteArray& protocol);
    const SwByteArray& applicationProtocol() const;
    std::uint16_t negotiatedKeyExchangeGroup() const;
    bool setHybridKeyExchangeEnabled(bool enabled);
    bool hybridKeyExchangeEnabled() const;

    const SwByteArray& clientEphemeralPublicKey() const;
    const SwQuicInitialKeys& clientHandshakeKeys() const;
    const SwQuicInitialKeys& serverHandshakeKeys() const;
    const SwQuicInitialKeys& clientApplicationKeys() const;
    const SwQuicInitialKeys& serverApplicationKeys() const;
    const SwQuicConnectionId& destinationConnectionId() const;
    const SwQuicConnectionId& sourceConnectionId() const;
    // DCID du tout premier Initial. Contrairement a destinationConnectionId(),
    // cette valeur ne change pas quand le serveur choisit son SCID.
    const SwQuicConnectionId& originalDestinationConnectionId() const;
    bool retryReceived() const;

    // RFC 8446 section 7.5. The exporter master secret never leaves the
    // handshake driver; callers can only derive labelled keying material.
    bool exportKeyingMaterial(const SwString& label,
                              const SwByteArray& context,
                              std::size_t length,
                              SwByteArray& out,
                              SwString* error = nullptr) const;

    // Compatibility overload for callers that transport a whole QUIC flight
    // in one UDP datagram. New path-aware callers should use the vector form.
    bool start(const SwString& serverName,
               SwByteArray& outInitialDatagram,
               SwString* error = nullptr);

    // Generates ephemeral key material and a bounded Initial flight. A hybrid
    // ClientHello spans multiple independently protected QUIC Initial packets.
    bool start(const SwString& serverName,
               SwVector<SwByteArray>& outInitialDatagrams,
               SwString* error = nullptr);

    // Consumes one received UDP datagram (which may coalesce several QUIC packets)
    // and appends any datagrams that should be sent in response.
    bool processIncomingDatagram(const SwByteArray& datagram,
                                 SwVector<SwByteArray>& outDatagrams,
                                 SwString* error = nullptr);

private:
    // The Initial flight is emitted before some transports can push their
    // live path MTU into the established connection.  Use QUIC's universal
    // 1200-byte floor here so the first flight is valid on every admitted path.
    static std::size_t maximumInitialDatagramSize_();

    class SW_QUIC_EXPORT SecretGuard_ {
    public:
        explicit SecretGuard_(SwByteArray& secret);
        ~SecretGuard_();

    private:
        SecretGuard_(const SecretGuard_&) = delete;
        SecretGuard_& operator=(const SecretGuard_&) = delete;
        SwByteArray& m_secret;
    };

    static void setError_(SwString* error, const char* message);
    static void clearError_(SwString* error);
    bool fail_(SwString* error);

    static void secureClearKeys_(SwQuicInitialKeys& keys) noexcept;

    void discardHandshakeSecrets_() noexcept;

    void discardFailedSecrets_() noexcept;

    static SwByteArray rawMessage_(std::uint8_t type, const SwByteArray& body);

    // ------------------------------------------------------------ Initial ---

    bool handleRetry_(const SwByteArray& packet,
                      std::size_t& consumed,
                      SwVector<SwByteArray>& outDatagrams,
                      SwString* error);

    bool handleServerInitial_(const SwByteArray& packet,
                              std::size_t& consumed,
                              SwString* error);

    bool tryParseServerHello_(SwString* error);

    // ---------------------------------------------------------- Handshake ---

    bool handleServerHandshake_(const SwByteArray& packet,
                                std::size_t& consumed,
                                SwString* error);

    bool processEncryptedExtensions_(const SwByteArray& eeBody, SwString* error);

    // Build a coalesced 0-RTT (long header type 0x10) packet carrying the early
    // application data as a STREAM frame on stream 0, protected with the early
    // keys (RFC 9001 4.6).
    bool buildZeroRttPacket_(const SwByteArray& earlyData,
                             SwByteArray& outPacket,
                             SwString* error);

    bool tryCompleteHandshake_(SwVector<SwByteArray>& outDatagrams, SwString* error);

    // RFC 9001 4.9.1 / 4.9: zeroise the Initial secrets and stop all Initial-space
    // activity. After this, received Initial packets are ignored.
    void discardInitialKeys_();

public:
    // resumption_master_secret, available once the handshake completes.
    const SwByteArray& resumptionMasterSecret() const;

    // Turn a NewSessionTicket (received in 1-RTT) into stored resumption state:
    // both peers derive the same PSK from resumption_master_secret and the
    // ticket nonce (RFC 8446 4.6.1). serverTransportParams should be the params
    // this connection negotiated, remembered for future 0-RTT.
    bool processNewSessionTicket(const SwByteArray& newSessionTicketBody,
                                 const SwByteArray& serverTransportParams,
                                 SwQuicSessionTicket& outTicket,
                                 SwString* error = nullptr);

private:

    bool parseCertificateRequest_(const SwByteArray& body, SwString* error);

    static void appendU16_(SwByteArray& out, std::uint16_t value);

    static void appendU24_(SwByteArray& out, std::uint32_t value);

    void buildClientCertificateBody_(SwByteArray& outBody) const;

    bool buildClientCertificateVerifyBody_(const SwByteArray& transcriptHash,
                                           SwByteArray& outBody,
                                           SwString* error) const;

    // Builds the client's Handshake flight. A persistent certificate chain may
    // span multiple MTU-sized CRYPTO frames; offsets form one TLS byte stream.
    bool buildClientHandshakeFlight_(const SwByteArray& handshakeCrypto,
                                     SwVector<SwByteArray>& outDatagrams,
                                     SwString* error);

    // Builds a small ACK-only Initial or Handshake datagram acknowledging the
    // contiguous run of highest received packet numbers.
    bool buildAckOnlyDatagram_(bool handshakeLevel,
                               const SwQuicInitialKeys& keys,
                               std::uint64_t& packetNumberCounter,
                               const SwMap<std::uint64_t, bool>& received,
                               SwByteArray& outDatagram,
                               SwString* error);

    bool buildInitialHeader_(std::uint64_t protectedPayloadLength,
                             std::uint8_t pnLen,
                             std::uint64_t packetNumber,
                             SwByteArray& outHeader,
                             SwString* error);

    bool buildHandshakeHeader_(std::uint64_t protectedPayloadLength,
                               std::uint8_t pnLen,
                               std::uint64_t packetNumber,
                               SwByteArray& outHeader,
                               SwString* error);

    // Out-of-order CRYPTO reassembly: fragments buffer in an SwQuicStream and
    // only the contiguous prefix is appended to the handshake transcript
    // buffer, so reordered or duplicated frames are handled transparently.
    bool appendCrypto_(SwByteArray& buffer,
                       SwQuicStream& reassembly,
                       const SwQuicFrame& frame,
                       SwString* error);

public:
    // RFC 9001 4.9.1: a client discards its Initial keys as soon as it first sends
    // a Handshake packet. Exposed for tests validating that invariant.
    bool initialKeysDiscarded() const;
#if defined(SW_QUIC_ENABLE_SECRET_LIFETIME_TEST_HOOKS)
    bool transientSecretsDiscardedForTest() const;
#endif
public:
    ~SwQuicHandshakeClient();
public:
    SwQuicHandshakeClient(const SwQuicHandshakeClient& other);
    SwQuicHandshakeClient& operator=(const SwQuicHandshakeClient& other);
private:
    // What the class keeps (SwQuicHandshakeClient_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
