#ifndef SWQUICACKTRACKER_H
#define SWQUICACKTRACKER_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwVector.h"
#include "SwString.h"
#include "quic/SwQuicFrame.h"
#include "quic/SwQuicVarIntCodec.h"

#include <cstdint>
class SW_QUIC_EXPORT SwQuicAckTracker {
public:
    // Upper bound on tracked packet numbers: the lowest entries are pruned
    // beyond this so a long-lived connection cannot grow the set without
    // bound. 1024 packets is far more history than any ACK frame needs.
    static std::size_t kMaxTrackedPackets();

    SwQuicAckTracker();

    void recordReceivedPacket(std::uint64_t packetNumber, bool ackEliciting = true);

    // Consultation sans mutation pour jeter un replay AVANT de retraiter ses
    // frames applicatives. recordReceivedPacket() déduplique les plages d'ACK,
    // mais ne peut pas, à lui seul, empêcher la redélivraison d'un DATAGRAM.
    bool containsReceivedPacket(std::uint64_t packetNumber) const;

    // True when at least one ack-eliciting packet was received since the last
    // ACK frame we sent: only then does an ACK of ours need to go out
    // (RFC 9000 section 13.2.1).
    bool ackElicitingPending() const;

    // Called when an ACK frame built from this tracker was handed to the send
    // path, so pure-ACK traffic does not trigger endless ACK exchanges.
    void onAckSent();

    // Drop state for packets at or below `packetNumber` (e.g. once the peer
    // confirmed reception of an ACK covering them).
    void pruneUpTo(std::uint64_t packetNumber);

    void clear();

    bool isEmpty() const;

    std::uint64_t largestReceivedPacket() const;

    bool buildAckFrame(SwQuicFrame& outFrame,
                       std::uint64_t ackDelay = 0,
                       SwString* error = nullptr) const;

private:
    struct LocalAckRange_ {
        std::uint64_t high;
        std::uint64_t low;
    };

    void trimWindow_();

    static void setError_(SwString* error, const char* message);

    static bool ackValueFits_(std::uint64_t value, SwString* error);

public:
    ~SwQuicAckTracker();
public:
    SwQuicAckTracker(const SwQuicAckTracker& other);
    SwQuicAckTracker& operator=(const SwQuicAckTracker& other);
private:
    // What the class keeps (SwQuicAckTracker_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

#endif
