#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpSeo.h"

struct SwHttpSeo::Data {
    mutable SwMutex m_mutex;
    SwHttpSeoConfig m_config;
    SwList<SwHttpSeoPage> m_pages;
    bool m_configured = false;
};
