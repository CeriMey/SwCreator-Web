#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpContext.h"

struct SwHttpContext::Data : SwSharedData {
    // Given by the constructor: m_request.
    explicit Data(const SwHttpRequest& request)
        : m_request(request) {}

    const SwHttpRequest& m_request;
    SwHttpResponse m_response;
    SwMap<SwString, SwString> m_locals;
    bool m_handled = false;
};
