#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpMiddlewarePack.h"

struct SwHttpMetricsCollector::Data {
    mutable SwMutex m_mutex;
    SwHttpMiddlewareMetrics m_metrics;
};
struct SwHttpRateLimiter::Data {
    mutable SwMutex m_mutex;
    Options m_options;
    SwMap<SwString, Bucket> m_buckets;
    int m_requestCountSincePrune = 0;
};
