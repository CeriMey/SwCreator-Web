#pragma once

#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpSession.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpSession in the CoreSw HTTP server layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP session interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpSession.
 *
 * Session-level interfaces here describe how one client connection advances through parsing,
 * request handling, response production, and connection shutdown without blocking the IO path.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwObject.h"
#include "SwAbstractSocket.h"
#include "SwPointer.h"
#include "SwTcpSocket.h"
#include "SwTimer.h"
#include "SwFile.h"
#include "SwDebug.h"
#include "SwDequeue.h"

#include "http/SwHttpTypes.h"
#include "http/SwHttpParser.h"
#include "http/SwHttpRouter.h"
#include "http/SwHttpMultipart.h"

#include <chrono>
#include <atomic>
#include <cstdio>
#include <functional>
#include <limits>
#include <memory>
#include <utility>

static constexpr const char* kSwLogCategory_SwHttpSession = "sw.core.io.swhttpsession";

class SW_HTTPSERVER_EXPORT SwHttpSession : public SwObject {
    SW_OBJECT(SwHttpSession, SwObject)

public:
    using SwHttpResponseCallback = std::function<void(SwHttpResponse)>;
    using SwHttpRequestHandler = std::function<void(const SwHttpRequest&, const SwHttpResponseCallback&)>;

    /**
     * @brief Constructs a `SwHttpSession` instance.
     * @param socket Socket instance affected by the operation.
     * @param router Value passed to the method.
     * @param limits Limit configuration to apply.
     * @param timeouts Timeout configuration to apply.
     * @param parent Optional parent object that owns this instance.
     * @param timeouts Timeout configuration to apply.
     *
     * @details The instance is initialized and can optionally be attached to a parent object for ownership management.
     */
    SwHttpSession(SwAbstractSocket* socket,
                  SwHttpRouter* router,
                  const SwHttpLimits& limits,
                  const SwHttpTimeouts& timeouts,
                  bool isTls,
                  uint16_t localPort,
                  SwObject* parent = nullptr);

    /**
     * @brief Destroys the `SwHttpSession` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwHttpSession() override;

    /**
     * @brief Sets the finished Callback.
     * @param callback Callback invoked by the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setFinishedCallback(const std::function<void(SwHttpSession*)>& callback);

    /**
     * @brief Adds the specified cleanup Hook.
     * @param hook Value passed to the method.
     */
    void addCleanupHook(const std::function<void()>& hook);

    /**
     * @brief Sets the request Handler.
     * @param handler Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setRequestHandler(const SwHttpRequestHandler& handler);

    void setPendingBytesBudgetCallbacks(
        const std::function<bool(std::size_t)>& reserve,
        const std::function<void(std::size_t)>& release);

    /**
     * @brief Closes the session handled by the object.
     *
     * @details The call affects the runtime state associated with the underlying resource or service.
     */
    void closeSession();

    void startBufferedReadProcessing();

private:
    enum class SendState {
        Idle,
        SendingBody,
        SendingFile,
        SendingChunked
    };

private slots:
    void onReadyRead_();

    void onWriteFinished_();

    void onReadyWrite_();

    void onDeferredWriteFinished_();

    void onDisconnected_();

    void onError_(int);

    void onTimeoutWatch_();

private:
    static void addBufferedBytes_(std::size_t& total, std::size_t value);

    static std::size_t requestBufferedBytes_(const SwHttpRequest& request);

    bool readBackpressureRequired_() const;

    void scheduleReadContinuation_();

    void scheduleTimeout_();

    void scheduleDeferredWriteFinished_();

    bool writeSocket_(const char* data, std::size_t size);

    bool writeSocket_(const SwString& data);

    bool writeSocket_(const SwByteArray& data);

    bool sendPendingContinue_();

    static SwString toHex_(std::size_t value);

    static bool validHeaderName_(const SwString& name);

    bool sendChunkedPart_(const SwByteArray& part);

    static bool statusForbidsResponseBody_(int status);

    static std::size_t responseRepresentationLength_(const SwHttpResponse& response);

    bool sendResponseHeaders_(const SwHttpResponse& response,
                              bool suppressBody,
                              bool statusForbidsBody,
                              std::size_t representationLength);

    void beginResponse_(const SwHttpRequest& request, SwHttpResponse response);

    void sendNextBodyChunk_();

    void sendNextFileChunk_();

    void sendNextChunkedPart_();

    void processNextRequest_();

    void finishDetached_();

    void handoverSocket_();

    void finalizeResponse_();

    void sendErrorAndClose_(int status, const SwString& message);

    void cleanupStreamFile_();

    static void disposeSocketAfterClose_(SwAbstractSocket* socket);

    void releaseBufferedState_();

    void cleanup_();

    void collectRequestTempFiles_(const SwHttpRequest& request);

    static void removeFile_(const SwString& filePath);

    static void cleanupTempFilesForRequest_(const SwHttpRequest& request);

    void cleanupRequestTempFiles_();
private:
    // What the class keeps (SwHttpSession_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};
