#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpMiddlewarePack.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpMiddlewarePack in the CoreSw HTTP server
 * layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP middleware pack interface. The declarations
 * exposed here define the stable surface that adjacent code can rely on while the implementation
 * remains free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpMiddlewareMetrics, SwHttpMetricsCollector,
 * SwHttpRateLimiter, and SwHttpMiddlewarePack.
 *
 * HTTP-facing declarations in this header are intended to make incremental request processing and
 * response generation explicit enough for production hardening and testing.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "../SwHttpApp.h"
#include "SwMutex.h"
#include "SwDateTime.h"
#include "SwDebug.h"

#include <functional>
#include <chrono>
#include <exception>

static constexpr const char* kSwLogCategory_SwHttpMiddlewarePack = "sw.core.io.swhttpmiddlewarepack";

struct SW_HTTPAPP_EXPORT SwHttpMiddlewareMetrics {
    long long totalRequests = 0;
    long long totalLatencyMs = 0;
    long long maxLatencyMs = 0;
    long long totalRequestBodyBytes = 0;
    long long totalResponseBodyBytes = 0;
    SwMap<SwString, long long> statusCounters;
};

class SW_HTTPAPP_EXPORT SwHttpMetricsCollector {
public:
    /**
     * @brief Performs the `record` operation.
     * @param request Request instance associated with the operation.
     * @param response Response instance associated with the operation.
     * @param latencyMs Value passed to the method.
     */
    void record(const SwHttpRequest& request, const SwHttpResponse& response, long long latencyMs);

    /**
     * @brief Returns the current snapshot.
     * @return The current snapshot.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwHttpMiddlewareMetrics snapshot() const;

    /**
     * @brief Resets the object to a baseline state.
     */
    void reset();

private:
    static std::size_t responseBodyBytes_(const SwHttpResponse& response);

public:
    SwHttpMetricsCollector();
public:
    ~SwHttpMetricsCollector();
private:
    // What the class keeps (SwHttpMiddlewarePack_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

class SW_HTTPAPP_EXPORT SwHttpRateLimiter {
public:
    struct Options {
        int maxRequests = 120;
        int windowMs = 60 * 1000;
        int staleBucketMs = 5 * 60 * 1000;
    };

    struct Decision {
        bool allowed = true;
        int limit = 0;
        int remaining = 0;
        int retryAfterSeconds = 0;
    };

    /**
     * @brief Constructs a `SwHttpRateLimiter` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwHttpRateLimiter();

    /**
     * @brief Constructs a `SwHttpRateLimiter` instance.
     * @param options Option set controlling the operation.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwHttpRateLimiter(const Options& options);

    /**
     * @brief Sets the options.
     * @param options Option set controlling the operation.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setOptions(const Options& options);

    /**
     * @brief Returns the current options.
     * @return The current options.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    Options options() const;

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Performs the `acquire` operation.
     * @param rawKey Value passed to the method.
     * @return The requested acquire.
     */
    Decision acquire(const SwString& rawKey);

private:
    struct Bucket {
        double tokens = 0.0;
        long long lastRefillMs = 0;
        long long lastSeenMs = 0;
    };

    static long long nowMs_();

    void refillBucket_(Bucket& bucket, long long nowMs) const;

    void pruneBucketsLocked_(long long nowMs);

public:
    ~SwHttpRateLimiter();
private:
    // What the class keeps (SwHttpMiddlewarePack_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

class SW_HTTPAPP_EXPORT SwHttpMiddlewarePack {
public:
    using SwHttpMiddleware = SwHttpApp::SwHttpMiddleware;
    using SwHttpNext = SwHttpApp::SwHttpNext;
    using SwHttpRecoveryHandler = SwHttpApp::SwHttpRecoveryHandler;

    struct RequestIdOptions {
        SwString requestHeader = "x-request-id";
        SwString responseHeader = "x-request-id";
        bool trustIncomingHeader = true;
        SwString contextLocalKey = "request-id";
    };

    struct StructuredLogOptions {
        SwString requestIdLocalKey = "request-id";
        bool logRequestBytes = true;
        bool logResponseBytes = true;
    };

    struct CorsOptions {
        SwList<SwString> allowedOrigins = SwList<SwString>{ "*" };
        SwString allowMethods = "GET,POST,PUT,PATCH,DELETE,OPTIONS";
        SwString allowHeaders = "content-type,authorization,x-request-id";
        SwString exposeHeaders = "x-request-id";
        bool allowCredentials = false;
        int maxAgeSeconds = 600;
        bool handlePreflight = true;
    };

    struct RateLimitOptions {
        SwString clientKeyHeader = "x-forwarded-for";
        bool keyByPath = false;
        int maxRequests = 120;
        int windowMs = 60 * 1000;
        int staleBucketMs = 5 * 60 * 1000;
        SwString rejectBody = "Too Many Requests";
    };

    struct AuthOptions {
        /**
         * @brief Performs the `function<bool` operation.
         * @return The requested function<bool.
         */
        std::function<bool(SwHttpContext&)> authorize;
        /**
         * @brief Performs the `function<void` operation.
         * @return The requested function<void.
         */
        std::function<void(SwHttpContext&)> onReject;
        bool bypassOptionsPreflight = true;
        int rejectStatus = 401;
        SwString rejectBody = "Unauthorized";
    };

    struct RecoveryOptions {
        int statusCode = 500;
        SwString message = "Internal Server Error";
        bool includeErrorDetails = false;
        bool closeConnection = true;
        bool logException = true;
    };

    struct InstallOptions {
        bool enableRequestId = true;
        bool enableStructuredLogs = true;
        bool enableCors = true;
        bool enableRateLimit = true;
        bool enableAuth = false;
        bool enableMetrics = true;
        bool enableRecoveryHandler = true;
        RequestIdOptions requestId;
        StructuredLogOptions structuredLogs;
        CorsOptions cors;
        RateLimitOptions rateLimit;
        AuthOptions auth;
        RecoveryOptions recovery;
    };

    /**
     * @brief Returns the current request Id.
     * @return The current request Id.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwHttpMiddleware requestId();

    /**
     * @brief Performs the `requestId` operation.
     * @param options Option set controlling the operation.
     * @return The requested request Id.
     */
    static SwHttpMiddleware requestId(const RequestIdOptions& options);

    /**
     * @brief Returns the current structured Logs.
     * @return The current structured Logs.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwHttpMiddleware structuredLogs();

    /**
     * @brief Performs the `structuredLogs` operation.
     * @param options Option set controlling the operation.
     * @return The requested structured Logs.
     */
    static SwHttpMiddleware structuredLogs(const StructuredLogOptions& options);

    /**
     * @brief Returns the current cors.
     * @return The current cors.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwHttpMiddleware cors();

    /**
     * @brief Performs the `cors` operation.
     * @param options Option set controlling the operation.
     * @return The requested cors.
     */
    static SwHttpMiddleware cors(const CorsOptions& options);

    /**
     * @brief Performs the `rateLimit` operation.
     * @param limiter Value passed to the method.
     * @return The requested rate Limit.
     */
    static SwHttpMiddleware rateLimit(SwHttpRateLimiter* limiter);

    /**
     * @brief Performs the `rateLimit` operation.
     * @param limiter Value passed to the method.
     * @param options Option set controlling the operation.
     * @return The requested rate Limit.
     */
    static SwHttpMiddleware rateLimit(SwHttpRateLimiter* limiter,
                                      const RateLimitOptions& options);

    /**
     * @brief Performs the `authHook` operation.
     * @param options Option set controlling the operation.
     * @return The requested auth Hook.
     */
    static SwHttpMiddleware authHook(const AuthOptions& options);

    /**
     * @brief Performs the `metrics` operation.
     * @param collector Value passed to the method.
     * @return The requested metrics.
     */
    static SwHttpMiddleware metrics(SwHttpMetricsCollector* collector);

    /**
     * @brief Returns the current recovery Handler.
     * @return The current recovery Handler.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwHttpRecoveryHandler recoveryHandler();

    /**
     * @brief Performs the `recoveryHandler` operation.
     * @param options Option set controlling the operation.
     * @return The requested recovery Handler.
     */
    static SwHttpRecoveryHandler recoveryHandler(const RecoveryOptions& options);

    /**
     * @brief Performs the `install` operation.
     * @param app Value passed to the method.
     * @param options Option set controlling the operation.
     * @param rateLimiter Value passed to the method.
     * @param metricsCollector Value passed to the method.
     * @return The requested install.
     */
    static void install(SwHttpApp& app,
                        const InstallOptions& options,
                        SwHttpRateLimiter* rateLimiter = nullptr,
                        SwHttpMetricsCollector* metricsCollector = nullptr);

private:
    static SwString resolveAllowedOrigin_(const SwString& origin, const SwList<SwString>& allowedOrigins);

    static std::size_t responseBodyBytes_(const SwHttpResponse& response);

    static SwString jsonEscape_(const SwString& text);

    static SwString generateRequestId_();
};
