#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpParser.h"

struct SwHttpParser::Data : SwSharedData {
    SwHttpLimits m_limits;
    SwByteRingBuffer m_buffer;
    State m_state = State::RequestLine;
    SwHttpRequest m_currentRequest;
    std::size_t m_headerBytes = 0;
    std::size_t m_headerCount = 0;
    std::size_t m_contentLengthRemaining = 0;
    std::size_t m_chunkBytesRemaining = 0;
    bool m_chunkedBody = false;
    std::size_t m_bodyBytesReceived = 0;
    bool m_continueNeeded = false;
    bool m_multipartStreamingActive = false;
    SwHttpMultipartStreamParser m_multipartStreamParser;
    std::size_t m_feedOutputStart = 0;
    int m_errorStatus = 0;
    SwString m_errorMessage;
};
