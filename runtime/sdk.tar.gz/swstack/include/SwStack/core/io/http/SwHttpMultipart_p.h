#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpMultipart.h"

struct SwHttpMultipartStreamParser::Data : SwSharedData {
    State m_state = State::NeedInitialBoundary;
    SwHttpLimits m_limits;
    SwString m_tempDirectory;
    SwByteArray m_delimiter;      // --boundary
    SwByteArray m_boundaryMarker; // \r\n--boundary
    SwByteRingBuffer m_buffer;
    SwList<SwHttpRequest::MultipartPart> m_parts;
    SwMap<SwString, SwString> m_formFields;
    SwHttpRequest::MultipartPart m_currentPart;
    std::size_t m_currentPartBytes = 0;
    std::size_t m_totalInputBytes = 0;
    bool m_hasCurrentPart = false;
    std::uint64_t m_fileCounter = 0;
    SwFile* m_currentFile = nullptr;
};
