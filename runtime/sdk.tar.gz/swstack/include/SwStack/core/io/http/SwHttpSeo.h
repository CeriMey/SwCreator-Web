#pragma once

#include <memory>
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpSeo.h
 * @ingroup core_http
 * @brief SEO and answer-engine discovery primitives for applications served by SwHttpApp.
 *
 * SwHttpSeo keeps an explicit registry of public pages and generates the machine-readable
 * documents that search engines and answer engines use to discover a site.  The registry is
 * deliberately separate from the HTTP router: API, authentication, administration and dynamic
 * route patterns must never become indexable merely because they exist.
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 ***************************************************************************************************/

#include "../../fs/SwMutex.h"
#include "../../types/SwJsonArray.h"
#include "../../types/SwJsonDocument.h"
#include "../../types/SwJsonObject.h"
#include "../../types/SwList.h"
#include "../../types/SwString.h"

#include <cctype>
#include <cstddef>

struct SW_HTTPSERVER_EXPORT SwHttpSeoCrawlerPolicy {
    // Search and answer-engine discovery are enabled by default.
    bool allowGoogleSearch = true;
    bool allowBingSearch = true;
    bool allowOpenAiSearch = true;
    bool allowAnthropicSearch = true;
    bool allowPerplexitySearch = true;

    // User-triggered fetchers are independent from search indexes.
    bool allowChatGptUser = true;
    bool allowClaudeUser = true;
    bool allowPerplexityUser = true;

    // Training/grounding controls remain independently configurable.
    bool allowOpenAiTraining = true;
    bool allowAnthropicTraining = true;
    bool allowGoogleExtended = true;
};

struct SW_HTTPSERVER_EXPORT SwHttpSeoConfig {
    SwString siteUrl;
    SwString siteName;
    SwString defaultTitle;
    SwString defaultDescription;
    SwString defaultLanguage = "fr";
    SwString titleSeparator = " | ";

    SwString organizationName;
    SwString organizationUrl;
    SwString logoUrl;
    SwString defaultSocialImageUrl;

    SwString robotsPath = "/robots.txt";
    SwString sitemapPath = "/sitemap.xml";
    SwString llmsPath = "/llms.txt";

    bool enableRobotsTxt = true;
    bool enableSitemap = true;
    bool enableLlmsTxt = true;
    bool appendSiteNameToTitle = true;

    SwString discoveryCacheControl = "public, max-age=3600";
    std::size_t maxSitemapUrls = 50000;

    SwHttpSeoCrawlerPolicy crawlers;
    SwList<SwString> robotsAllowPaths;
    SwList<SwString> robotsDisallowPaths;
    SwList<SwString> noIndexPrefixes;

    SwHttpSeoConfig();
};

struct SW_HTTPSERVER_EXPORT SwHttpSeoPage {
    SwString path;
    SwString title;
    SwString description;
    SwString language;
    SwString lastModified;
    SwString datePublished;
    SwString authorName;
    SwString schemaType = "WebPage";
    SwString openGraphType = "website";
    SwString socialImageUrl;
    SwString applicationCategory;
    SwString operatingSystem;
    bool indexable = true;
};

class SW_HTTPSERVER_EXPORT SwHttpSeo {
public:
    SwHttpSeo();

    bool configure(const SwHttpSeoConfig& config, SwString* errorOut = nullptr);

    bool isConfigured() const;

    SwHttpSeoConfig config() const;

    bool addPage(const SwHttpSeoPage& page, SwString* errorOut = nullptr);

    bool removePage(const SwString& path);

    void clearPages();

    SwList<SwHttpSeoPage> pages() const;

    bool page(const SwString& path, SwHttpSeoPage& pageOut) const;

    SwString canonicalUrl(const SwString& pagePath) const;

    bool shouldNoIndex(const SwString& requestPath) const;

    SwString robotsText() const;

    SwString sitemapXml() const;

    SwString llmsText() const;

    SwString renderDocument(const SwHttpSeoPage& page,
                            const SwString& bodyHtml,
                            const SwString& extraHeadHtml = SwString()) const;

    SwString renderPage(const SwString& pagePath,
                        const SwString& bodyHtml,
                        const SwString& extraHeadHtml = SwString(),
                        bool* okOut = nullptr) const;

private:
    static void setError_(SwString* errorOut, const SwString& error);

    static bool normalizeConfig_(const SwHttpSeoConfig& input,
                                 SwHttpSeoConfig& output,
                                 SwString& error);

    static bool normalizeEndpointPath_(SwString& path, SwString& error);

    static bool normalizePathList_(SwList<SwString>& paths,
                                   const SwString& fieldName,
                                   SwString& error);

    static bool normalizePage_(SwHttpSeoPage& page, SwString& error);

    static SwString normalizePagePath_(const SwString& rawPath);

    static bool isConcretePath_(const SwString& path);

    static bool isAbsoluteHttpUrl_(const SwString& value);

    static bool isIsoDate_(const SwString& value);

    static bool isTwoDigits_(const SwString& value, std::size_t position);

    static bool pathPrefixMatches_(const SwString& path, const SwString& prefixValue);

    static SwString joinUrl_(const SwString& baseValue, const SwString& pathValue);

    static SwString escapeHtml_(const SwString& value);

    static SwString escapeXml_(const SwString& value);

    static SwString markdownInline_(const SwString& value);

    static SwString markdownLinkLabel_(const SwString& value);

    static SwString markdownLinkUrl_(const SwString& value);

    static void appendCrawlerGroup_(SwString& output,
                                    const SwString& userAgent,
                                    bool allowed,
                                    const SwList<SwString>& allowPaths,
                                    const SwList<SwString>& disallowPaths);

    static void appendBlockedCrawler_(SwString& output,
                                      const SwString& userAgent,
                                      bool allowed);

    void snapshot_(SwHttpSeoConfig& configOut, SwList<SwHttpSeoPage>& pagesOut) const;

    static SwJsonObject jsonIdReference_(const SwString& id);

    static SwString structuredDataJson_(const SwHttpSeoConfig& config,
                                        const SwHttpSeoPage& page,
                                        const SwString& canonical,
                                        const SwString& title,
                                        const SwString& description,
                                        const SwString& language);

    static SwString absoluteAssetUrl_(const SwHttpSeoConfig& config, const SwString& value);

    static SwString renderDocument_(const SwHttpSeoConfig& config,
                                    const SwHttpSeoPage& pageValue,
                                    const SwString& bodyHtml,
                                    const SwString& extraHeadHtml);

public:
    ~SwHttpSeo();
private:
    // What the class keeps (SwHttpSeo_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
