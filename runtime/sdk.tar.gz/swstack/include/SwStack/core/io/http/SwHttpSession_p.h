#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpSession.h"

struct SwHttpSession::Data {
    SwAbstractSocket* m_socket = nullptr;
    SwHttpRouter* m_router = nullptr;
    SwHttpParser m_parser;
    SwHttpLimits m_limits;
    SwHttpTimeouts m_timeouts;
    SwTimer* m_timeoutWatch = nullptr;
    SwDequeue<SwHttpRequest> m_pendingRequests;
    SwDequeue<std::size_t> m_pendingRequestSizes;
    std::size_t m_pendingRequestBytes = 0;
    std::size_t m_activeRequestReservedBytes = 0;
    bool m_handlingResponse = false;
    bool m_waitingAsyncResponse = false;
    bool m_closeAfterWrite = false;
    bool m_responsePayloadDone = false;
    bool m_cleaned = false;
    bool m_inSocketWrite = false;
    bool m_writeFinishedDeferred = false;
    bool m_deferredWriteScheduled = false;
    bool m_readContinuationScheduled = false;
    bool m_readBackpressured = false;
    bool m_handoverAfterWrite = false;
    bool m_expectContinuePending = false;
    SendState m_sendState = SendState::Idle;
    SwFile* m_streamFile = nullptr;
    std::size_t m_streamBytesRemaining = 0;
    std::size_t m_streamChunkBytes = 64 * 1024;
    SwDequeue<SwByteArray> m_chunkParts;
    bool m_chunkTerminatorSent = false;
    SwByteArray m_bodyPayload;
    std::size_t m_bodyOffset = 0;
    SwByteArray m_deferredSocketWrite;
    bool m_waitingSocketWritable = false;
    SwList<SwString> m_requestTempFiles;
    SwHttpRequest m_activeRequest;
    std::function<void(SwAbstractSocket*)> m_socketHandoverCallback;
    std::function<void(SwAbstractSocket*, SwByteArray)> m_socketHandoverWithDataCallback;
    SwByteArray m_handoverInitialData;
    SwHttpRequestHandler m_requestHandler;
    std::function<bool(std::size_t)> m_reservePendingBytes;
    std::function<void(std::size_t)> m_releasePendingBytes;
    std::function<void(SwHttpSession*)> m_onFinished;
    SwList<std::function<void()>> m_cleanupHooks;
    bool m_isTls = false;
    uint16_t m_localPort = 0;
    std::chrono::steady_clock::time_point m_lastReadAt;
    std::chrono::steady_clock::time_point m_requestStartedAt;
    std::chrono::steady_clock::time_point m_waitingResponseAt;
    std::chrono::steady_clock::time_point m_writeStartedAt;
    std::chrono::steady_clock::time_point m_timeoutDeadline;
    bool m_timeoutArmed = false;
};
