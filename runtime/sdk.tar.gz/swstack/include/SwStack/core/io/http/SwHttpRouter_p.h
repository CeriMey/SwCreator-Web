#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http/SwHttpRouter.h"

struct SwHttpRouter::Data : SwSharedData {
    SwList<SwHttpRouteEntry> m_routes;
    SwHttpRouteCallback m_notFoundHandler;
    SwList<SwHttpResponseFilter> m_responseFilters;
    SwMap<SwString, SwString> m_namedPatterns;
    TrailingSlashPolicy m_trailingSlashPolicy = TrailingSlashPolicy::Ignore;
};
