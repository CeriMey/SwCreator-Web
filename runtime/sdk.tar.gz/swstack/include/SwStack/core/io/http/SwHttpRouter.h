#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpRouter.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpRouter in the CoreSw HTTP server layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP router interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpRouter.
 *
 * The routing contract in this header is meant to stay predictable under complex URL patterns,
 * path parameters, and dispatch ordering, without performing socket IO itself.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "http/SwHttpTypes.h"

#include <functional>

using SwHttpRouteCallback = std::function<SwHttpResponse(const SwHttpRequest&)>;
using SwHttpRouteResponder = std::function<void(const SwHttpResponse&)>;
using SwHttpRouteAsyncCallback = std::function<void(const SwHttpRequest&, const SwHttpRouteResponder&)>;
using SwHttpResponseFilter = std::function<void(const SwHttpRequest&, SwHttpResponse&)>;

class SW_HTTPSERVER_EXPORT SwHttpRouter {
public:
    enum class TrailingSlashPolicy {
        Ignore,
        RedirectToNoSlash,
        RedirectToSlash
    };

    /**
     * @brief Registers an HTTP route handler.
     * @param method HTTP method involved in the operation.
     * @param pattern Pattern used by the operation.
     * @param callback Callback invoked by the operation.
     */
    void addRoute(const SwString& method, const SwString& pattern, const SwHttpRouteCallback& callback);

    /**
     * @brief Registers an asynchronous HTTP route handler.
     * @param method HTTP method involved in the operation.
     * @param pattern Pattern used by the operation.
     * @param callback Callback invoked by the operation.
     */
    void addRouteAsync(const SwString& method, const SwString& pattern, const SwHttpRouteAsyncCallback& callback);

    /**
     * @brief Registers a named HTTP route handler.
     * @param routeName Stable route name used by the operation.
     * @param method HTTP method involved in the operation.
     * @param pattern Pattern used by the operation.
     * @param callback Callback invoked by the operation.
     */
    void addNamedRoute(const SwString& routeName,
                       const SwString& method,
                       const SwString& pattern,
                       const SwHttpRouteCallback& callback);

    /**
     * @brief Registers a named asynchronous HTTP route handler.
     * @param routeName Stable route name used by the operation.
     * @param method HTTP method involved in the operation.
     * @param pattern Pattern used by the operation.
     * @param callback Callback invoked by the operation.
     */
    void addNamedRouteAsync(const SwString& routeName,
                            const SwString& method,
                            const SwString& pattern,
                            const SwHttpRouteAsyncCallback& callback);

    /**
     * @brief Returns whether a named route is currently registered.
     * @param routeName Stable route name to look up.
     * @return `true` when the router contains the requested route name; otherwise `false`.
     */
    bool hasRouteName(const SwString& routeName) const;

    /**
     * @brief Returns the normalized pattern registered for a named route.
     * @param routeName Stable route name to resolve.
     * @return The pattern associated with the route, or an empty string when the name is unknown.
     */
    SwString routePattern(const SwString& routeName) const;

    /**
     * @brief Builds a URL from a named route and parameter values.
     * @param routeName Stable route name to resolve.
     * @param pathParams Path parameters used to expand the route template.
     * @param outUrl Output string that receives the generated URL.
     * @param queryParams Query parameters appended after path generation.
     * @return `true` on success; otherwise `false`.
     *
     * @details
     * Route generation reuses the same normalized pattern data that request matching uses, which
     * keeps reverse routing consistent with the registered route table.
     */
    bool buildUrl(const SwString& routeName,
                  const SwMap<SwString, SwString>& pathParams,
                  SwString& outUrl,
                  const SwMap<SwString, SwString>& queryParams = SwMap<SwString, SwString>()) const;

    /**
     * @brief Sets the fallback handler used when no registered route matches a request.
     * @param callback Callback invoked to build the fallback response.
     */
    void setNotFoundHandler(const SwHttpRouteCallback& callback);

    /**
     * @brief Adds a final response filter shared by every transport using this router.
     *
     * Filters run after routing (including redirects, method errors and the not-found
     * handler) and before the response is returned to HTTP/1.x or HTTP/3. They are useful
     * for transport discovery headers such as Alt-Svc and for application-wide response
     * metadata that must not be duplicated in every route.
     */
    void addResponseFilter(const SwHttpResponseFilter& filter);

    void clearResponseFilters();

    void filterResponse(const SwHttpRequest& request, SwHttpResponse& response) const;

    /**
     * @brief Configures how paths that differ only by a trailing slash are handled.
     * @param policy Trailing-slash policy applied during route resolution.
     */
    void setTrailingSlashPolicy(TrailingSlashPolicy policy);

    /**
     * @brief Returns the trailing-slash policy currently used by the router.
     * @return The active trailing-slash handling policy.
     */
    TrailingSlashPolicy trailingSlashPolicy() const;

    /**
     * @brief Matches a request against the registered routes and produces a synchronous response.
     * @param request Request to resolve.
     * @param response Output response filled when a route, redirect, or fallback handler applies.
     * @return `true` when the request was handled; otherwise `false`.
     *
     * @details
     * This method also handles trailing-slash redirects, `405 Method Not Allowed` responses, and
     * fallback dispatch through the configured not-found handler.
     */
    bool route(const SwHttpRequest& request, SwHttpResponse& response) const;

    bool route(const SwHttpRequest& request,
               SwHttpResponse& response,
               bool applyResponseFilters) const;

    /**
     * @brief Matches a request and dispatches its response through the supplied responder callback.
     * @param request Request to resolve.
     * @param responder Callback used to deliver the final response.
     * @return `true` when the request was accepted for synchronous or asynchronous handling;
     *         otherwise `false`.
     *
     * @details
     * The router transparently handles both synchronous and asynchronous route entries. Redirects,
     * `405` responses, and fallback responses are also emitted through `responder`.
     */
    bool routeAsync(const SwHttpRequest& request,
                    const SwHttpRouteResponder& responder) const;

    bool routeAsync(const SwHttpRequest& request,
                    const SwHttpRouteResponder& responder,
                    bool applyResponseFilters) const;

    /**
     * @brief Returns whether the matching route, if any, is asynchronous.
     * @param request Request to probe against the registered route table.
     * @return `true` when the first matching route is asynchronous; otherwise `false`.
     */
    bool willRouteAsync(const SwHttpRequest& request) const;

private:
    enum class SegmentType {
        Literal,
        Parameter,
        Wildcard
    };

    enum class ParamConstraint {
        None,
        Int,
        Alpha,
        Alnum,
        Hex,
        Slug,
        Uuid
    };

    struct RouteSegment {
        SegmentType type = SegmentType::Literal;
        SwString literal;
        SwString name;
        ParamConstraint constraint = ParamConstraint::None;
    };

    struct SwHttpRouteEntry {
        SwString method;
        SwString pattern;
        SwString name;
        SwList<RouteSegment> segments;
        int specificityScore = 0;
        bool isAsync = false;
        SwHttpRouteCallback callback;
        SwHttpRouteAsyncCallback asyncCallback;
    };


    void applyResponseFilters_(const SwHttpRequest& request, SwHttpResponse& response) const;

    static SwString normalizePattern_(const SwString& pattern);

    static SwList<SwString> splitPath_(const SwString& path);

    static bool parseConstraint_(const SwString& token, SwString& nameOut, ParamConstraint& constraintOut);

    static bool compilePattern_(const SwString& pattern, SwList<RouteSegment>& segmentsOut, int& scoreOut);

    static bool checkConstraint_(ParamConstraint constraint, const SwString& value);

    static bool isHex_(char c);

    static bool matchSegments_(const SwList<RouteSegment>& routeSegments,
                               const SwList<SwString>& pathSegments,
                               SwMap<SwString, SwString>& paramsOut);

    bool shouldRedirectTrailingSlash_(const SwHttpRequest& request, SwHttpResponse& response) const;

    static void appendUniqueMethod_(SwList<SwString>& methods, const SwString& method);

    static void appendQueryString_(SwString& url, const SwMap<SwString, SwString>& queryParams);

    static SwString percentEncode_(const SwString& text);

    static char hexDigit_(int value);
public:
    SwHttpRouter();
public:
    ~SwHttpRouter();
public:
    SwHttpRouter(const SwHttpRouter& other);
    SwHttpRouter& operator=(const SwHttpRouter& other);
private:
    // What the class keeps (SwHttpRouter_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
