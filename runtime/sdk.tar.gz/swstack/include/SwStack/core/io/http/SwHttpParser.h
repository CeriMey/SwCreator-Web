#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpParser.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpParser in the CoreSw HTTP server layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP parser interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpParser.
 *
 * This file is especially important for fragmented HTTP input because the public contract has to
 * make parser progress, limits, and parse outcomes explicit across packet boundaries.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "http/SwHttpTypes.h"
#include "http/SwHttpMultipart.h"
#include "SwByteRingBuffer.h"

#include <limits>
#include <utility>

class SW_HTTPSERVER_EXPORT SwHttpParser {
public:
    enum class FeedStatus {
        Ok,
        NeedMoreData,
        Error
    };

    /**
     * @brief Constructs a `SwHttpParser` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwHttpParser();

    /**
     * @brief Sets the limits.
     * @param limits Limit configuration to apply.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLimits(const SwHttpLimits& limits);

    /**
     * @brief Resets the object to a baseline state.
     */
    void reset(bool releaseStorage = false);

    /**
     * @brief Performs the `feed` operation.
     * @param data Value passed to the method.
     * @param outRequests Output value filled by the method.
     * @return The requested feed.
     */
    FeedStatus feed(const SwByteArray& data, SwList<SwHttpRequest>& outRequests);

    FeedStatus feed(const char* data, std::size_t size, SwList<SwHttpRequest>& outRequests);

    /**
     * @brief Returns whether the object reports error.
     * @return `true` when the object reports error; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasError() const;

    /**
     * @brief Returns the current error Status.
     * @return The current error Status.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    int errorStatus() const;

    /**
     * @brief Returns the current error Message.
     * @return The current error Message.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString errorMessage() const;

    /**
     * @brief Returns whether the object reports awaiting Headers.
     * @return `true` when the object reports awaiting Headers; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isAwaitingHeaders() const;

    /**
     * @brief Returns whether the object reports awaiting Body.
     * @return `true` when the object reports awaiting Body; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool isAwaitingBody() const;

    /**
     * @brief Returns whether the object reports partial Request.
     * @return `true` when the object reports partial Request; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool hasPartialRequest() const;

    /**
     * @brief Returns the number of transport bytes retained by the parser.
     *
     * This is primarily useful when HTTP hands the connection to an upgraded
     * protocol and the transport read coalesced bytes after the HTTP headers.
     */
    std::size_t bufferedDataSize() const;

    /**
     * @brief Transfers all bytes not consumed by HTTP framing to the caller.
     */
    SwByteArray takeBufferedData();

    /** Returns and clears the one-shot request to emit an HTTP 100 interim response. */
    bool takeContinueNeeded();

private:
    enum class State {
        RequestLine,
        Headers,
        BodyFixed,
        ChunkSize,
        ChunkData,
        ChunkDataCRLF,
        ChunkTrailers,
        Complete,
        Error
    };

    static std::size_t maxFeedAppendBytes_();

    static bool isTokenCharacter_(char value);

    static bool isValidToken_(const SwString& value);

    static bool isValidHeaderValue_(const SwString& value);

    static bool isValidRequestTarget_(const SwString& target);

    static bool parseDecimalSize_(const SwString& text, std::size_t& outValue);

    static void discardFeedOutputs_(SwList<SwHttpRequest>& outRequests,
                                    std::size_t outputStart);

    FeedStatus drainAvailable_(SwList<SwHttpRequest>& outRequests, bool& progressed);

    void setError_(int status, const SwString& message);

    void resetCurrentRequest();

    bool popLine_(SwString& outLine);

    bool pendingBufferExceedsLimit_(std::size_t usedBytes, std::size_t maxBytes) const;

    bool parseRequestLine_();

    bool parseTarget_(const SwString& target);

    bool parseHeaders_();

    bool finalizeHeaders_();

    bool parseFixedBody_();

    bool parseChunkSize_();

    bool parseChunkData_();

    bool feedMultipartFromBuffer_(std::size_t bytes);

    bool parseChunkDataCrlf_();

    bool parseChunkTrailers_();

    bool prepareMultipartStreaming_();

    bool finalizeMultipartStreaming_();

    void finalizeRequest_(SwList<SwHttpRequest>& outRequests);
public:
    ~SwHttpParser();
public:
    SwHttpParser(const SwHttpParser& other);
    SwHttpParser& operator=(const SwHttpParser& other);
private:
    // What the class keeps (SwHttpParser_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
