#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpStaticFileHandler.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpStaticFileHandler in the CoreSw HTTP
 * server layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP static file handler interface. The
 * declarations exposed here define the stable surface that adjacent code can rely on while the
 * implementation remains free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpStaticFileHandler.
 *
 * Static-file interfaces in this area are expected to cover path normalization, safe file
 * selection, large-file streaming, and HTTP features such as content ranges.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "http/SwHttpTypes.h"
#include "SwDir.h"
#include "SwFile.h"
#include "platform/SwPlatformSelector.h"

class SW_HTTPSERVER_EXPORT SwHttpStaticFileHandler {
public:
    /**
     * @brief Constructs a `SwHttpStaticFileHandler` instance.
     * @param prefix Prefix used by the operation.
     * @param rootDir Root directory used by the operation.
     * @param options Option set controlling the operation.
     * @param options Option set controlling the operation.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwHttpStaticFileHandler(const SwString& prefix,
                            const SwString& rootDir,
                            const SwHttpStaticOptions& options = SwHttpStaticOptions());

    /**
     * @brief Returns whether the object reports handle.
     * @param request Request instance associated with the operation.
     * @return `true` when the object reports handle; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool canHandle(const SwHttpRequest& request) const;

    /**
     * @brief Performs the `tryHandle` operation.
     * @param request Request instance associated with the operation.
     * @param response Response instance associated with the operation.
     * @return `true` on success; otherwise `false`.
     */
    bool tryHandle(const SwHttpRequest& request, SwHttpResponse& response) const;

private:

    static SwString normalizePrefix_(const SwString& prefix);

    SwString relativePathForRequest_(const SwString& requestPath) const;

    static SwString normalizeRelativePath_(const SwString& relativePath);

    static SwString trimTrailingSeparators_(const SwString& relativePath);

    static bool lastSegmentHasExtension_(const SwString& relativePath);

    static bool sanitizeRelativePath_(const SwString& relativePath);

    static SwString buildAbsoluteTarget_(const SwString& absoluteRoot, const SwString& relativePath);

    static SwString resolveAbsoluteTarget_(const SwString& absoluteRoot, const SwString& relativePath);

    static bool isPathInsideRoot_(const SwString& absoluteRoot, const SwString& absoluteTarget);

    static bool parseRange_(const SwString& rangeHeader,
                            std::size_t totalSize,
                            std::size_t& outOffset,
                            std::size_t& outLength,
                            SwString& outContentRange);
public:
    ~SwHttpStaticFileHandler();
public:
    SwHttpStaticFileHandler(const SwHttpStaticFileHandler& other);
    SwHttpStaticFileHandler& operator=(const SwHttpStaticFileHandler& other);
private:
    // What the class keeps (SwHttpStaticFileHandler_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
