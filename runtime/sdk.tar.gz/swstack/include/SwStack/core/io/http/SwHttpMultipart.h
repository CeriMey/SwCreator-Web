#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpMultipart.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpMultipart in the CoreSw HTTP server
 * layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP multipart interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpMultipartStreamParser.
 *
 * HTTP-facing declarations in this header are intended to make incremental request processing and
 * response generation explicit enough for production hardening and testing.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "http/SwHttpTypes.h"
#include "SwByteRingBuffer.h"
#include "SwDir.h"
#include "SwFile.h"
#include "platform/SwPlatformSelector.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <random>
#include <utility>

inline SwString swHttpTrimQuotes_(const SwString& value) {
    SwString out = value.trimmed();
    if (out.size() >= 2 && out.startsWith("\"") && out.endsWith("\"")) {
        out = out.mid(1, static_cast<int>(out.size()) - 2);
    }
    return out;
}

inline void swHttpParseHeaderParams_(const SwString& headerValue,
                                     SwString& mainValue,
                                     SwMap<SwString, SwString>& params) {
    mainValue.clear();
    params.clear();

    SwList<SwString> tokens = headerValue.split(';');
    if (tokens.isEmpty()) {
        return;
    }

    mainValue = tokens[0].trimmed().toLower();
    for (std::size_t i = 1; i < tokens.size(); ++i) {
        SwString token = tokens[i].trimmed();
        if (token.isEmpty()) {
            continue;
        }

        int eq = token.indexOf("=");
        if (eq <= 0) {
            continue;
        }
        SwString key = token.left(eq).trimmed().toLower();
        SwString value = swHttpTrimQuotes_(token.mid(eq + 1));
        if (!key.isEmpty()) {
            params[key] = value;
        }
    }
}

inline bool swHttpExtractMultipartBoundary(const SwString& contentType, SwString& outBoundary) {
    outBoundary.clear();

    SwString mainType;
    SwMap<SwString, SwString> params;
    swHttpParseHeaderParams_(contentType, mainType, params);
    if (mainType != "multipart/form-data") {
        return false;
    }
    if (!params.contains("boundary")) {
        return false;
    }

    SwString boundary = params["boundary"].trimmed();
    if (boundary.isEmpty() || boundary.size() > 70) {
        return false;
    }

    // RFC 2046 bchars: spaces are permitted internally, but not as the final
    // character. Reject controls and punctuation that can alter MIME framing.
    for (std::size_t i = 0; i < boundary.size(); ++i) {
        const unsigned char c = static_cast<unsigned char>(boundary[i]);
        const bool alphaNumeric = (c >= '0' && c <= '9') ||
                                  (c >= 'A' && c <= 'Z') ||
                                  (c >= 'a' && c <= 'z');
        const bool punctuation = c == '\'' || c == '(' || c == ')' || c == '+' ||
                                 c == '_' || c == ',' || c == '-' || c == '.' ||
                                 c == '/' || c == ':' || c == '=' || c == '?';
        if (!alphaNumeric && !punctuation && c != ' ') {
            return false;
        }
    }
    if (boundary[boundary.size() - 1] == ' ') {
        return false;
    }

    outBoundary = boundary;
    return true;
}

inline bool swHttpParseMultipartHeaders_(const SwByteArray& rawHeaders,
                                         const SwHttpLimits& limits,
                                         SwMap<SwString, SwString>& outHeaders,
                                         SwString& outError) {
    outHeaders.clear();
    outError.clear();

    if (rawHeaders.size() > limits.maxMultipartPartHeadersBytes) {
        outError = "Multipart part headers too large";
        return false;
    }

    SwString text(rawHeaders.toStdString());
    SwList<SwString> lines = text.split("\r\n");
    for (std::size_t i = 0; i < lines.size(); ++i) {
        const SwString line = lines[i];
        if (line.isEmpty()) {
            continue;
        }

        int colon = line.indexOf(":");
        if (colon <= 0) {
            outError = "Malformed multipart part header";
            return false;
        }

        const SwString rawKey = line.left(colon);
        if (rawKey.isEmpty()) {
            outError = "Malformed multipart part header";
            return false;
        }
        for (std::size_t j = 0; j < rawKey.size(); ++j) {
            const unsigned char c = static_cast<unsigned char>(rawKey[j]);
            const bool alphaNumeric = (c >= '0' && c <= '9') ||
                                      (c >= 'A' && c <= 'Z') ||
                                      (c >= 'a' && c <= 'z');
            const bool punctuation = c == '!' || c == '#' || c == '$' || c == '%' ||
                                     c == '&' || c == '\'' || c == '*' || c == '+' ||
                                     c == '-' || c == '.' || c == '^' || c == '_' ||
                                     c == '`' || c == '|' || c == '~';
            if (!alphaNumeric && !punctuation) {
                outError = "Malformed multipart part header";
                return false;
            }
        }
        SwString key = rawKey.toLower();
        SwString value = line.mid(colon + 1).trimmed();
        for (std::size_t j = 0; j < value.size(); ++j) {
            const unsigned char c = static_cast<unsigned char>(value[j]);
            if ((c < 0x20u && c != '\t') || c == 0x7fu) {
                outError = "Malformed multipart part header";
                return false;
            }
        }
        if (outHeaders.contains(key)) {
            outError = "Duplicate multipart part header";
            return false;
        }
        outHeaders[key] = value;
    }
    return true;
}

inline void swHttpCleanupMultipartTemporaryFiles(SwHttpRequest& request) {
    for (std::size_t i = 0; i < request.multipartParts.size(); ++i) {
        SwHttpRequest::MultipartPart& part = request.multipartParts[i];
        if (!part.storedOnDisk || part.tempFilePath.isEmpty()) {
            continue;
        }
#if defined(_WIN32)
        const std::wstring widePath = part.tempFilePath.toStdWString();
        (void)_wremove(widePath.c_str());
#else
        (void)std::remove(part.tempFilePath.toStdString().c_str());
#endif
        part.tempFilePath.clear();
        part.storedOnDisk = false;
    }
}

class SW_HTTPSERVER_EXPORT SwHttpMultipartStreamParser {
public:
    /**
     * @brief Constructs a `SwHttpMultipartStreamParser` instance.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwHttpMultipartStreamParser();

    /**
     * @brief Destroys the `SwHttpMultipartStreamParser` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwHttpMultipartStreamParser();

    /**
     * @brief Resets the object to a baseline state.
     */
    void reset();

    /**
     * @brief Performs the `begin` operation.
     * @param boundary Value passed to the method.
     * @param limits Limit configuration to apply.
     * @param tempDirectory Value passed to the method.
     * @param outError Output value filled by the method.
     * @return `true` on success; otherwise `false`.
     */
    bool begin(const SwString& boundary,
               const SwHttpLimits& limits,
               const SwString& tempDirectory,
               SwString& outError);

    /**
     * @brief Performs the `feed` operation.
     * @param bytes Value passed to the method.
     * @param outError Output value filled by the method.
     * @return `true` on success; otherwise `false`.
     */
    bool feed(const SwByteArray& bytes, SwString& outError);

    bool feed(const char* data, std::size_t size, SwString& outError);

    /**
     * @brief Performs the `finish` operation.
     * @param outParts Output value filled by the method.
     * @param outFormFields Output value filled by the method.
     * @param outError Output value filled by the method.
     * @return `true` on success; otherwise `false`.
     */
    bool finish(SwList<SwHttpRequest::MultipartPart>& outParts,
                 SwMap<SwString, SwString>& outFormFields,
                 SwString& outError);

    /**
     * @brief Performs the `cleanupTemporaryFiles` operation.
     */
    void cleanupTemporaryFiles();

private:
    enum class State {
        NeedInitialBoundary,
        NeedPartHeaders,
        NeedPartData,
        Done,
        Error
    };

    bool process_(SwString& outError, bool finalInput);

    bool consumeInitialBoundary_(bool& changed, SwString& outError, bool finalInput);

    bool consumePartHeaders_(bool& changed, SwString& outError);

    bool consumePartData_(bool& changed, SwString& outError, bool finalInput);

    bool appendCurrentData_(const char* data, std::size_t len, SwString& outError);

    bool appendAndConsumeCurrentData_(std::size_t len, SwString& outError);

    bool finalizeCurrentPart_(SwString& outError);

    void closeCurrentFile_();

    void failAndCleanup_();

    SwString makeTempFilePath_();

    static void removeFile_(const SwString& filePath);
public:
    SwHttpMultipartStreamParser(const SwHttpMultipartStreamParser& other);
    SwHttpMultipartStreamParser& operator=(const SwHttpMultipartStreamParser& other);
private:
    // What the class keeps (SwHttpMultipart_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

inline bool swHttpParseMultipartFormData(const SwByteArray& body,
                                         const SwString& boundary,
                                         const SwHttpLimits& limits,
                                         SwList<SwHttpRequest::MultipartPart>& outParts,
                                         SwString& outError) {
    outParts.clear();
    outError.clear();

    SwHttpLimits memoryLimits = limits;
    memoryLimits.enableMultipartFileStreaming = false;

    SwHttpMultipartStreamParser parser;
    if (!parser.begin(boundary, memoryLimits, SwString(), outError)) {
        return false;
    }
    if (!parser.feed(body, outError)) {
        return false;
    }
    SwMap<SwString, SwString> ignoredFormFields;
    return parser.finish(outParts, ignoredFormFields, outError);
}

inline bool swHttpParseMultipartRequest(SwHttpRequest& request,
                                        const SwHttpLimits& limits,
                                        SwString& outError) {
    outError.clear();

    // Request may already be parsed in streaming mode directly by SwHttpParser.
    if (request.isMultipartFormData && (request.body.isEmpty() || !request.multipartParts.isEmpty())) {
        return true;
    }

    request.isMultipartFormData = false;
    request.multipartParts.clear();
    request.formFields.clear();

    if (!request.headers.contains("content-type")) {
        return true;
    }

    SwString contentTypeLower = request.headers["content-type"].toLower();
    if (!contentTypeLower.startsWith("multipart/form-data")) {
        return true;
    }

    SwString boundary;
    if (!swHttpExtractMultipartBoundary(request.headers["content-type"], boundary)) {
        outError = "Missing multipart boundary";
        return false;
    }

    if (!swHttpParseMultipartFormData(request.body, boundary, limits, request.multipartParts, outError)) {
        return false;
    }

    request.isMultipartFormData = true;
    for (std::size_t i = 0; i < request.multipartParts.size(); ++i) {
        const SwHttpRequest::MultipartPart& part = request.multipartParts[i];
        if (part.isFile) {
            continue;
        }
        if (part.name.isEmpty()) {
            continue;
        }
        request.formFields[part.name] = SwString(part.data.toStdString());
    }

    return true;
}
