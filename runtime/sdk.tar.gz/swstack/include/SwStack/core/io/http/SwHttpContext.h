#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

/**
 * @file src/core/io/http/SwHttpContext.h
 * @ingroup core_http
 * @brief Declares the public interface exposed by SwHttpContext in the CoreSw HTTP server layer.
 *
 * This header belongs to the CoreSw HTTP server layer. It exposes the request and response model,
 * parser state machines, routing helpers, per-connection sessions, and static-file helpers used
 * by the non-blocking HTTP stack.
 *
 * Within that layer, this file focuses on the HTTP context interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwHttpContext.
 *
 * Context-level interfaces here collect request-scoped state and helper access so middleware,
 * handlers, and response code can share a consistent view of the active HTTP exchange.
 *
 * HTTP-facing declarations in this area are designed around non-blocking IO, incremental parsing,
 * bounded buffering, and a clear separation between transport work and higher-level request
 * handling.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "http/SwHttpTypes.h"
#include "SwJsonDocument.h"
#include "SwJsonValue.h"
#include "platform/SwPlatformSelector.h"

class SW_HTTPSERVER_EXPORT SwHttpContext {
public:
    /**
     * @brief Constructs a `SwHttpContext` instance.
     * @param request Request instance associated with the operation.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwHttpContext(const SwHttpRequest& request);

    /**
     * @brief Returns the current request.
     * @return The current request.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwHttpRequest& request() const;

    /**
     * @brief Returns the current response.
     * @return The current response.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwHttpResponse& response();

    /**
     * @brief Returns the current response.
     * @return The current response.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    const SwHttpResponse& response() const;

    /**
     * @brief Returns the current handled.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool handled() const;

    /**
     * @brief Sets the handled.
     * @param handled Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHandled(bool handled = true);

    /**
     * @brief Returns the current method.
     * @return The current method.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString method() const;

    /**
     * @brief Returns the current path.
     * @return The current path.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString path() const;

    /** Returns the negotiated request protocol (for example HTTP/1.1 or HTTP/3). */
    SwString protocol() const;

    bool isHttp3() const;

    bool isTls() const;

    uint16_t localPort() const;

    SwString peerAddress() const;

    uint16_t peerPort() const;

    /**
     * @brief Performs the `queryValue` operation.
     * @param key Value passed to the method.
     * @param defaultValue Value passed to the method.
     * @return The requested query Value.
     */
    SwString queryValue(const SwString& key, const SwString& defaultValue = SwString()) const;

    /**
     * @brief Performs the `pathValue` operation.
     * @param key Value passed to the method.
     * @param defaultValue Value passed to the method.
     * @return The requested path Value.
     */
    SwString pathValue(const SwString& key, const SwString& defaultValue = SwString()) const;

    /**
     * @brief Performs the `headerValue` operation.
     * @param key Value passed to the method.
     * @param defaultValue Value passed to the method.
     * @return The requested header Value.
     */
    SwString headerValue(const SwString& key, const SwString& defaultValue = SwString()) const;

    /**
     * @brief Performs the `formValue` operation.
     * @param key Value passed to the method.
     * @param defaultValue Value passed to the method.
     * @return The requested form Value.
     */
    SwString formValue(const SwString& key, const SwString& defaultValue = SwString()) const;

    /**
     * @brief Returns the current body Text.
     * @return The current body Text.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString bodyText() const;

    /**
     * @brief Sets the local.
     * @param key Value passed to the method.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setLocal(const SwString& key, const SwString& value);

    /**
     * @brief Returns whether the object reports local.
     * @param key Value passed to the method.
     * @return `true` when the object reports local; otherwise `false`.
     *
     * @details This query does not modify the object state.
     */
    bool hasLocal(const SwString& key) const;

    /**
     * @brief Performs the `localValue` operation.
     * @param key Value passed to the method.
     * @param defaultValue Value passed to the method.
     * @return The requested local Value.
     */
    SwString localValue(const SwString& key, const SwString& defaultValue = SwString()) const;

    /**
     * @brief Performs the `parseJsonBody` operation.
     * @param outDocument Output value filled by the method.
     * @param outError Output value filled by the method.
     * @return `true` on success; otherwise `false`.
     */
    bool parseJsonBody(SwJsonDocument& outDocument, SwString& outError) const;

    /**
     * @brief Returns the current parse Url Encoded Body.
     * @return The current parse Url Encoded Body.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwMap<SwString, SwString> parseUrlEncodedBody() const;

    /**
     * @brief Sets the status.
     * @param statusCode Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setStatus(int statusCode);

    /**
     * @brief Sets the header.
     * @param key Value passed to the method.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setHeader(const SwString& key, const SwString& value);

    /**
     * @brief Performs the `noContent` operation.
     * @param statusCode Value passed to the method.
     */
    void noContent(int statusCode = 204);

    /**
     * @brief Performs the `send` operation.
     * @param body Value passed to the method.
     * @param contentType Value passed to the method.
     * @param statusCode Value passed to the method.
     */
    void send(const SwByteArray& body,
              const SwString& contentType = SwString("application/octet-stream"),
              int statusCode = 200);

    /**
     * @brief Performs the `send` operation.
     * @param body Value passed to the method.
     * @param contentType Value passed to the method.
     * @param statusCode Value passed to the method.
     */
    void send(const SwString& body,
              const SwString& contentType = SwString("text/plain; charset=utf-8"),
              int statusCode = 200);

    /**
     * @brief Performs the `text` operation.
     * @param body Value passed to the method.
     * @param statusCode Value passed to the method.
     */
    void text(const SwString& body, int statusCode = 200);

    /**
     * @brief Performs the `html` operation.
     * @param body Value passed to the method.
     * @param statusCode Value passed to the method.
     */
    void html(const SwString& body, int statusCode = 200);

    /**
     * @brief Performs the `json` operation.
     * @param document Value passed to the method.
     * @param statusCode Value passed to the method.
     * @param format Value passed to the method.
     */
    void json(const SwJsonDocument& document,
              int statusCode = 200,
              SwJsonDocument::JsonFormat format = SwJsonDocument::JsonFormat::Compact);

    /**
     * @brief Performs the `json` operation.
     * @param value Value passed to the method.
     * @param statusCode Value passed to the method.
     */
    void json(const SwJsonValue& value, int statusCode = 200);

    /**
     * @brief Performs the `sendFile` operation.
     * @param filePath Path of the target file.
     * @param contentType Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool sendFile(const SwString& filePath, const SwString& contentType = SwString());

    /**
     * @brief Performs the `redirect` operation.
     * @param location Value passed to the method.
     * @param statusCode Value passed to the method.
     */
    void redirect(const SwString& location, int statusCode = 302);

    /**
     * @brief Closes the connection handled by the object.
     * @param close Value passed to the method.
     *
     * @details The call affects the runtime state associated with the underlying resource or service.
     */
    void closeConnection(bool close = true);

    /**
     * @brief Hands the connection socket to a higher-level protocol handler.
     * @param callback Callback receiving the detached socket.
     * @param sendHttpResponseFirst When `true`, the HTTP response is flushed before the handover.
     */
    void switchToRawSocket(const std::function<void(SwAbstractSocket*)>& callback,
                           bool sendHttpResponseFirst = true);

    /** Hands over the detached socket together with bytes already read past the HTTP request. */
    void switchToRawSocket(
        const std::function<void(SwAbstractSocket*, SwByteArray)>& callback,
        bool sendHttpResponseFirst = true);

    /**
     * @brief Returns the current take Response.
     * @return The current take Response.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwHttpResponse takeResponse() const;

private:
public:
    ~SwHttpContext();
public:
    SwHttpContext(const SwHttpContext& other);
    SwHttpContext& operator=(const SwHttpContext& other);
private:
    // What the class keeps (SwHttpContext_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
