#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http3/SwQuicHttp3Server.h"

struct SwQuicHttp3Server::Data {
    SwUdpSocket m_socket;
    SwQuicServerCredential m_credential;
    CredentialMap m_namedCredentials;
    SwHttpRouter* m_router;
    RequestHandler m_requestHandler;
    AsyncRequestHandler m_asyncRequestHandler;
    PendingBytesReserveHandler m_pendingBytesReserveHandler;
    PendingBytesReleaseHandler m_pendingBytesReleaseHandler;
    // Shared by all live H3 sessions; declared before m_clients so it remains
    // alive while their destructors return outstanding budget charges.
    std::size_t m_pendingRequestBytesGlobal = 0;
    std::map<std::string, Client_> m_clients;
    std::map<std::string, std::string> m_connectionIdIndex;
    SwQuicTicketStore m_ticketStore; // 0-RTT resumption tickets
    std::uint64_t m_credentialGeneration = 0;
    std::shared_ptr<AsyncCompletionCycle_> m_asyncCompletionCycle;
    SwTimer* m_tickTimer = nullptr;
    bool m_polling = false;
    bool m_closePending = false;
    bool m_automaticPolling = false;
    bool m_draining = false;
    bool m_addressValidationEnabled = false;
    std::size_t m_retryPendingThreshold = 0;
    std::uint64_t m_retryTokenMaxAgeSeconds = 30;
    std::uint64_t m_retryPacketsSent = 0;
    SwByteArray m_retryKey;
    std::size_t m_maxClients = 4096;
    std::size_t m_maxPendingHandshakes = 1024;
    std::uint64_t m_handshakeTimeoutMs = 10000;
    SwHttpLimits m_httpLimits;
};
