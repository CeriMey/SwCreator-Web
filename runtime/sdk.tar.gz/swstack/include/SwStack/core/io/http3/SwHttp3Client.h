#ifndef SWHTTP3CLIENT_H
#define SWHTTP3CLIENT_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwCoreApplication.h"
#include "SwMap.h"
#include "SwObject.h"
#include "SwString.h"
#include "SwTimer.h"
#include "SwUdpSocket.h"
#include "SwVector.h"
#include "http3/SwHttp3Connection.h"
#include "quic/SwQuicConnection.h"
#include "quic/SwQuicHandshakeClient.h"
#include "quic/SwQuicSessionTicket.h"
#include "quic/SwTls13Messages.h"

#include <chrono>
#include <cstdint>
#include <limits>
#include <memory>
#include <utility>
#include <vector>

// Event-driven HTTP/3 client (RFC 9114 over QUIC v1 + TLS 1.3).
//
// It is the QUIC counterpart of SwHttpClient and follows the same SwObject
// conventions: get()/post()/request() start the request and return whether it
// started, then finished(body) or errorOccurred(message) settles it. Results
// (statusCode(), responseBody(), responseHeaders(), sessionTicket()) stay
// readable until the next request. The client owns one SwUdpSocket per
// request; with an SwCoreApplication event loop running, incoming datagrams
// arrive through the socket's readyRead signal and the QUIC timers (PTO
// retransmissions, overall deadline) through a single-shot SwTimer.
//
// On a thread without an event loop, start the request the same way and call
// waitForFinished(): it drives the exact same state machine by polling the
// socket, so blocking harnesses keep a synchronous request path.
//
// ALPN is "h3"; QPACK is static-table only (always interoperable). For a
// self-signed peer, call setVerifyCertificateChain(false) to keep verifying the
// CertificateVerify signature while not requiring a trusted root.
class SW_QUIC_EXPORT SwHttp3Client : public SwObject {
    SW_OBJECT(SwHttp3Client, SwObject)

public:
    explicit SwHttp3Client(SwObject* parent = nullptr);

    ~SwHttp3Client() override;

    void setVerifyPeer(bool verify);
    void setVerifyCertificateChain(bool verify);

    // Resume with a previously captured ticket: the next request is sent as
    // 0-RTT early data if the ticket permits it.
    void setResumptionTicket(const SwQuicSessionTicket& ticket);
    // A NewSessionTicket captured from the last request (valid() when present),
    // usable with setResumptionTicket() for a subsequent 0-RTT request.
    bool hasSessionTicket() const;
    const SwQuicSessionTicket& sessionTicket() const;
    // Whether the last request's early data was accepted as 0-RTT.
    bool earlyDataAccepted() const;

    int statusCode() const;
    const SwByteArray& responseBody() const;
    SwString responseBodyAsString() const;
    const SwMap<SwString, SwString>& responseHeaders() const;
    const SwString& errorString() const;
    bool isRunning() const;

    // Extra request headers applied to every request until cleared.
    void setRawHeader(const SwByteArray& name, const SwByteArray& value);
    void clearRawHeaders();

    bool get(const SwString& host, uint16_t port, const SwString& path,
             int timeoutMs = 10000);

    bool post(const SwString& host, uint16_t port, const SwString& path,
              const SwByteArray& body,
              const SwByteArray& contentType = SwByteArray("application/json"),
              int timeoutMs = 10000);

    // Starts the request; returns false (and emits errorOccurred) when it could
    // not start. A request already in flight is silently aborted first.
    bool request(const SwByteArray& method, const SwString& host, uint16_t port,
                 const SwString& path, const SwByteArray& body,
                 const SwByteArray& contentType, int timeoutMs = 10000);

    // Silently cancels any in-flight request: no signal is emitted and the
    // previous results are left untouched.
    void abort();

    // Synchronous bridge for threads without an event loop: polls the socket
    // and drives the state machine until finished/errorOccurred has been
    // emitted, then returns whether the request succeeded. Must not be called
    // from within this client's own signal handlers.
    bool waitForFinished();

signals:
    SW_SIGNAL(finished, const SwByteArray&)
    SW_SIGNAL(errorOccurred, const SwString&)

private slots:
    void onSocketReadyRead_();
    void onTimer_();

private:
    enum class Phase { Idle, Handshaking, Response };
    enum class Outcome { Pending, Failed, Done };

    // Clears the re-entrancy flag on every exit path, including an exception
    // thrown out of advance_() (e.g. std::bad_alloc) -- without this the client
    // would latch m_inStep=true and ignore every later step_() forever.
    struct SW_QUIC_EXPORT InStepGuard_ {
        explicit InStepGuard_(bool& flag);
        ~InStepGuard_();
        bool& m_flag;
    };

    // The current handshake API coalesces one 0-RTT packet behind the
    // minimum-sized Initial in a single UDP datagram. Keep that first flight
    // below the QUIC drivers' 2048-byte receive slots; larger requests are
    // sent after the handshake as ordinary packetised 1-RTT stream data.
    static std::size_t kMaxSingleFlightEarlyRequestBytes_();

    static std::uint64_t nowMs_();

    // One turn of the state machine, triggered by readyRead, the QUIC timer or
    // waitForFinished(). Signals are emitted only after the request state has
    // been fully torn down, so a finished/errorOccurred handler may immediately
    // start the next request on this same client.
    void step_();

    // Records the outcome of the current request BEFORE the settling signal is
    // emitted, so waitForFinished() reports this request's result even if a slot
    // synchronously chains another one (which bumps m_generation).
    void settle_(bool ok);

    Outcome advance_(SwString& error);

    // 1-RTT connection over the derived application keys, client control
    // stream, and the request itself (unless it already went out as accepted
    // 0-RTT early data; on 0-RTT rejection the request is resent here).
    bool setupConnection_(SwString& error);

    bool sendDatagram_(const SwByteArray& datagram, SwString& error);

    // Wake-up point for event-loop use: the earlier of the overall deadline and
    // the connection's next QUIC timer. On a thread without an
    // SwCoreApplication no timer is armed -- waitForFinished() paces us there.
    void armTimer_();

    bool startFailed_(const SwString& message);

    void teardown_();

    void retireSocket_(SwUdpSocket* socket);

    // Frees every retired socket. Call ONLY from a frame that is outside any
    // retired socket's signal emission (they are already disconnected, so they
    // cannot call back once here).
    void drainRetiredSockets_();

    // Parse NewSessionTicket messages from the 1-RTT CRYPTO stream and store
    // the resulting resumption ticket (RFC 8446 4.6.1).
    void captureSessionTicket_();

    bool finishResponse_(SwString& error);

private:
    // What the class keeps (SwHttp3Client_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

#endif
