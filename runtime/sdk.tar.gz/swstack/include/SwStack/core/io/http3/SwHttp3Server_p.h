#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http3/SwHttp3Server.h"

struct SwHttp3Server::Data {
    SwQuicConnection* m_connection;
    std::uint64_t m_nextServerUniStreamId;
    bool m_controlStreamOpened;
    bool m_peerSettingsReceived;
    bool m_peerH3Datagram;
    bool m_peerEnableConnectProtocol;
    bool m_peerEnableWebTransport;
    std::uint64_t m_peerMaxFieldSectionSize =
        (std::numeric_limits<std::uint64_t>::max)();
    bool m_haveControlStream = false;
    std::uint64_t m_controlStreamId = 0;
    std::size_t m_requestsHandled = 0;
    std::uint64_t m_localControlStreamId = 0;
    bool m_goawaySent = false;
    std::uint64_t m_goawayStreamId = 0;
    bool m_haveRequestStream = false;
    std::uint64_t m_largestRequestStreamId = 0;
    bool m_peerGoawayReceived = false;
    RequestHandler m_requestHandler;
    AsyncRequestHandler m_asyncRequestHandler;
    AsyncResponseReadyHandler m_asyncResponseReadyHandler;
    WebTransportHandler m_webTransportHandler;
    WebTransportProtocolHandler m_webTransportProtocolHandler;
    WebTransportDatagramHandler m_webTransportDatagramHandler;
    WebTransportStreamHandler m_webTransportStreamHandler;
    WebTransportSessionClosedHandler m_webTransportSessionClosedHandler;
    PendingBytesReserveHandler m_pendingBytesReserveHandler;
    PendingBytesReleaseHandler m_pendingBytesReleaseHandler;
    SwHttpLimits m_limits;
    std::size_t m_pendingRequestBytes = 0;
    std::map<std::uint64_t, UniStream_> m_uniStreams;
    std::map<std::uint64_t, RequestStream_> m_requestStreams;
    std::map<std::uint64_t, ResponseStream_> m_responseStreams;
    std::map<std::uint64_t, bool> m_webTransportSessions;
    std::map<std::uint64_t, std::uint64_t> m_completedRequestRanges;
    std::size_t m_responseSchedulingCursor = 0;
};
