#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http3/SwHttp3Client.h"

struct SwHttp3Client::Data {
    bool m_verifyPeer = true;
    bool m_verifyChain = true;
    std::vector<std::pair<SwByteArray, SwByteArray> > m_requestHeaders;
    // 0-RTT resumption.
    bool m_haveResumptionTicket = false;
    SwQuicSessionTicket m_resumptionTicket;
    SwQuicSessionTicket m_receivedTicket;
    bool m_earlyDataAccepted = false;
    // Last settled request.
    int m_statusCode = 0;
    SwByteArray m_responseBody;
    SwMap<SwString, SwString> m_responseHeaders;
    SwString m_errorString;
    bool m_succeeded = false;
    // Per-request identity + settled outcome, so waitForFinished() can report
    // the specific request it drove even across a slot-chained follow-up.
    std::uint64_t m_generation = 0;
    std::uint64_t m_settledGeneration = 0;
    bool m_settledOk = false;
    bool m_inWait = false;
    // Sockets awaiting deterministic same-thread deletion (no-event-loop path).
    std::vector<SwUdpSocket*> m_retiredSockets;
    // In-flight request state.
    SwUdpSocket* m_socket = nullptr;
    SwTimer* m_timer = nullptr;
    std::unique_ptr<SwQuicHandshakeClient> m_handshake;
    std::unique_ptr<SwQuicConnection> m_connection;
    SwByteArray m_requestStream;
    SwByteArray m_responseStream;
    SwString m_host;
    uint16_t m_port = 0;
    int m_timeoutMs = 0;
    bool m_resuming = false;
    std::uint64_t m_deadlineAt = 0;
    Phase m_phase = Phase::Idle;
    bool m_running = false;
    bool m_inStep = false;
    // Fixed per request: whether this thread drives its own event loop. Governs
    // socket-notification wiring, timer arming, and teardown disposal.
    bool m_eventLoopMode = false;
    // True only while a waitForFinished() drive loop is active on this thread.
    bool m_synchronousDrive = false;
};
