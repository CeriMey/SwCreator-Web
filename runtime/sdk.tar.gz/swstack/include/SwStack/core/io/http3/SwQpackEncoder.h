#ifndef SWQPACKENCODER_H
#define SWQPACKENCODER_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "http3/SwHpackHuffman.h"
#include "http3/SwQpackStaticTable.h"

#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

//--------------------------------------------------------------------------------------------------
// SwQpackEncoder
//
// Encodes a single QPACK encoded field section (RFC 9204 section 4.5) that references only the
// static table. The dynamic table is never used, so the section prefix always carries Required
// Insert Count = 0 and Base = 0, i.e. the two leading bytes 0x00 0x00.
//
// Each header field is emitted as the most compact representation available:
//   - Indexed Field Line (static)                 when name+value are in the static table.
//   - Literal Field Line With Name Reference       when only the name is in the static table.
//   - Literal Field Line With Literal Name         otherwise.
// String literals are Huffman-encoded (RFC 7541 Appendix B) whenever that is strictly shorter.
//
// Note: QPACK integers use the HPACK N-bit prefix integer representation (RFC 7541 section 5.1),
// which is a distinct wire format from the QUIC variable-length integer, so SwQuicVarIntCodec does
// not apply here and is intentionally not used.
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwQpackEncoder {
public:
    static bool encodeFieldSection(const std::vector<std::pair<SwByteArray, SwByteArray> >& headers,
                                   SwByteArray& out,
                                   SwString* error = nullptr);

private:
    static void clearError_(SwString* error);

    // HPACK N-bit prefix integer (RFC 7541 section 5.1). The non-prefix high bits carried in the
    // first byte are supplied via 'pattern'; its low 'prefixBits' bits must be zero.
    static void encodeInteger_(SwByteArray& out,
                               std::uint64_t value,
                               int prefixBits,
                               std::uint8_t pattern);

    // Encodes a string literal: a length integer whose 'hBit' (top of the prefix byte) flags
    // Huffman coding, followed by the raw or Huffman-coded octets. Huffman is chosen only when it
    // is strictly shorter.
    static bool encodeString_(SwByteArray& out,
                              const SwByteArray& str,
                              int prefixBits,
                              std::uint8_t basePattern,
                              std::uint8_t hBit,
                              SwString* error);
};

#endif
