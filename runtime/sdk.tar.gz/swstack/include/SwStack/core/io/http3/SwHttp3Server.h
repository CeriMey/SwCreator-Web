#ifndef SWHTTP3SERVER_H
#define SWHTTP3SERVER_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwFile.h"
#include "SwString.h"
#include "SwVector.h"
#include "http/SwHttpMultipart.h"
#include "http/SwHttpTypes.h"
#include "http3/SwHttp3FrameCodec.h"
#include "http3/SwQpackDecoder.h"
#include "http3/SwQpackEncoder.h"
#include "http3/SwWebTransportSession.h"
#include "quic/SwQuicConnection.h"
#include "quic/SwQuicVarIntCodec.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

// Stateful server-side HTTP/3 session (RFC 9114) bound to a SwQuicConnection.
//
// It closes the gap between the transport (SwQuicConnection) and the
// application: it opens the server control stream, exchanges SETTINGS,
// demultiplexes the client's unidirectional stream types, turns each client
// request stream (HEADERS + DATA) into an SwHttpRequest, hands it to a handler
// (which can be an SwHttpRouter adapter), and encodes the SwHttpResponse back
// into HEADERS + DATA on the same stream. QPACK is static-table only, which is
// always interoperable because the QPACK dynamic table is optional.
//
// Sans-IO driving: after the owning driver feeds datagrams into the
// SwQuicConnection, call pump() to advance the HTTP/3 state machine, then flush
// the connection's outgoing datagrams as usual.
class SW_QUIC_EXPORT SwHttp3Server {
private:
    struct RequestStream_;
    struct ResponseStream_;

public:
    typedef std::function<SwHttpResponse(const SwHttpRequest&)> RequestHandler;
    typedef std::function<void(SwHttpResponse)> ResponseCallback;
    typedef std::function<void(const SwHttpRequest&, const ResponseCallback&)>
        AsyncRequestHandler;
    typedef std::function<void(std::uint64_t, SwHttpResponse)>
        AsyncResponseReadyHandler;
    typedef std::function<bool(std::size_t)> PendingBytesReserveHandler;
    typedef std::function<void(std::size_t)> PendingBytesReleaseHandler;
    // Called when a client opens a WebTransport session via Extended CONNECT
    // (RFC 9220); return true to accept (204/200) or false to reject (404).
    typedef std::function<bool(const SwHttpRequest&, std::uint64_t sessionId)>
        WebTransportHandler;
    typedef std::function<bool(const SwHttpRequest&,
                               std::uint64_t sessionId,
                               SwString& selectedProtocol)>
        WebTransportProtocolHandler;
    typedef std::function<void(std::uint64_t sessionId,
                               const SwByteArray& payload)>
        WebTransportDatagramHandler;
    typedef std::function<void(std::uint64_t sessionId,
                               std::uint64_t streamId,
                               const SwByteArray& payload,
                               bool bidirectional,
                               bool fin)>
        WebTransportStreamHandler;
    typedef std::function<void(std::uint64_t sessionId)>
        WebTransportSessionClosedHandler;

    struct WebTransportDatagramQueueStats {
        std::size_t pendingFrames = 0;
        std::size_t pendingBytes = 0;
        std::uint64_t droppedFrames = 0;
    };

    static std::size_t defaultMaxPendingWebTransportDatagrams();
    static std::size_t defaultMaxPendingWebTransportDatagramBytes();

    static std::uint64_t streamTypeControl();
    static std::uint64_t settingEnableConnectProtocol();

    explicit SwHttp3Server(SwQuicConnection* connection);

    ~SwHttp3Server();

    // One server per connection, never copied. Said explicitly because an exported class gets its
    // implicit copy operations generated, and the stream maps hold move-only requests and files.
    SwHttp3Server(const SwHttp3Server&) = delete;
    SwHttp3Server& operator=(const SwHttp3Server&) = delete;

    void setRequestHandler(const RequestHandler& handler);
    void setAsyncRequestHandler(const AsyncRequestHandler& handler);
    void setAsyncResponseReadyHandler(const AsyncResponseReadyHandler& handler);
    void setWebTransportHandler(const WebTransportHandler& handler);
    void setWebTransportProtocolHandler(
        const WebTransportProtocolHandler& handler);
    void setWebTransportDatagramHandler(const WebTransportDatagramHandler& handler);
    void setWebTransportStreamHandler(const WebTransportStreamHandler& handler);
    void setWebTransportSessionClosedHandler(
        const WebTransportSessionClosedHandler& handler);

    void setWebTransportDatagramQueueLimits(std::size_t maximumFrames,
                                            std::size_t maximumBytes);

    WebTransportDatagramQueueStats webTransportDatagramQueueStats() const;

    bool hasWebTransportSession(std::uint64_t sessionId) const;

    bool handleWebTransportDatagram(const SwByteArray& datagram,
                                    SwString* error = nullptr);

    bool sendWebTransportDatagram(std::uint64_t sessionId,
                                  const SwByteArray& payload,
                                  SwString* error = nullptr);

    bool sendWebTransportStreamData(std::uint64_t sessionId,
                                    std::uint64_t streamId,
                                    const SwByteArray& payload,
                                    bool bidirectional,
                                    bool firstWrite,
                                    bool fin,
                                    SwString* error = nullptr);

    void setLimits(const SwHttpLimits& limits);

    // Optional driver-wide budget hooks. SwQuicHttp3Server uses these to make
    // maxPendingRequestBytesGlobal cover all of its live HTTP/3 connections,
    // while this session always enforces maxPendingRequestBytes locally.
    void setPendingRequestBudgetHandlers(
        const PendingBytesReserveHandler& reserveHandler,
        const PendingBytesReleaseHandler& releaseHandler);

    bool peerSettingsReceived() const;
    bool peerH3Datagram() const;
    bool peerEnableConnectProtocol() const;
    bool peerEnableWebTransport() const;
    std::size_t requestsHandled() const;
    std::size_t pendingRequestBytes() const;
    std::size_t requestStreamStateCount() const;
    std::size_t completedRequestRangeCount() const;
    std::size_t responseStreamStateCount() const;
    SwString firstPendingRequestDiagnostic() const;

    // Feed a bounded, fair window of response DATA frames into QUIC. The
    // method is intentionally public for socket drivers: ACK-only datagrams
    // and QUIC timer callbacks do not necessarily touch an HTTP/3 stream, but
    // both can release transport send-buffer capacity.
    bool pumpResponseStreams(SwString* error = nullptr);

    // Completes a response produced after the request-dispatch call returned.
    // The owning QUIC driver invokes this on its affinity thread, then flushes
    // the newly queued response frames.
    bool completeAsyncResponse(std::uint64_t streamId,
                               SwHttpResponse& response,
                               SwHttpRequest* completedRequest = nullptr,
                               SwString* error = nullptr);

    // Open the control stream and emit our SETTINGS. Call once the QUIC
    // connection can send 1-RTT application data.
    bool start(SwString* error = nullptr);

    // Graceful shutdown (RFC 9114 5.2): emit GOAWAY on our control stream.
    // Requests already being processed complete normally; new request streams
    // at or above the announced ID are rejected with H3_REQUEST_REJECTED so
    // the client can retry them on another connection. WebTransport data
    // streams keep flowing: their lifetime is their CONNECT session's.
    bool initiateGracefulShutdown(SwString* error = nullptr);

    bool gracefulShutdownInitiated() const;
    std::uint64_t goawayStreamId() const;
    bool peerGoawayReceived() const;

    // True once every accepted request has been answered and fully handed to
    // QUIC and no WebTransport session is alive. Only meaningful after
    // initiateGracefulShutdown(); the owning driver then closes the QUIC
    // connection (after the transport confirms delivery).
    bool isDrained() const;

    // Advance: read newly-arrived stream bytes and act on them.
    bool pump(SwString* error = nullptr);

    // Hot-path variant for drivers that already know which streams the latest
    // datagram touched. It avoids scanning every historical stream per packet.
    bool pumpStreams(const SwVector<std::uint64_t>& ids,
                     SwString* error = nullptr);

private:
    struct SW_QUIC_EXPORT UniStream_ {
        bool typeKnown;
        std::uint64_t type;
        bool webTransportSessionKnown;
        std::uint64_t webTransportSessionId;
        SwByteArray buffer;
        std::size_t accountedBytes;
        UniStream_();
    };

    struct SW_QUIC_EXPORT RequestStream_ {
        SwByteArray buffer;
        SwByteArray body;
        std::vector<std::pair<SwByteArray, SwByteArray> > fields;
        std::unique_ptr<SwHttpRequest> activeRequest;
        std::size_t accountedBytes;
        bool headersDecoded;
        bool trailersDecoded;
        bool responded;
        bool awaitingResponse;
        bool resourceLimitExceeded;
        bool webTransportDataStream;
        std::uint64_t webTransportSessionId;
        bool frameOrderError; // DATA before HEADERS, or a control frame on this stream
        RequestStream_();
    };

    struct ResponseStream_ {
        enum class Source {
            None,
            Body,
            ChunkParts,
            File
        };

        Source source = Source::None;
        SwByteArray body;
        std::size_t bodyOffset = 0;
        SwList<SwByteArray> chunkParts;
        std::size_t chunkPartIndex = 0;
        std::size_t chunkPartOffset = 0;
        std::unique_ptr<SwFile> file;
        std::size_t fileBytesRemaining = 0;
        std::size_t chunkBytes = 64U * 1024U;
        SwByteArray pendingFrame;
        bool hasPendingFrame = false;
        bool pendingFin = false;
    };

    static void setError_(SwString* error, const char* message);
    static void clearError_(SwString* error);

    static bool isUnidirectional_(std::uint64_t streamId);

    static std::uint64_t h3ExcessiveLoad_();
    static std::uint64_t h3RequestCancelled_();
    static std::uint64_t h3InternalError_();
    static std::uint64_t h3RequestRejected_();

    bool abortRequestStream_(std::uint64_t streamId,
                             std::uint64_t applicationErrorCode,
                             bool peerAlreadyReset,
                             SwString* error);

    bool isCompletedRequestStream_(std::uint64_t streamId) const;

    void markCompletedRequestStream_(std::uint64_t streamId);

    bool reservePendingBytes_(std::size_t bytes);

    bool appendUniStreamBytes_(UniStream_& stream,
                               const SwByteArray& chunk,
                               SwString* error);

    void synchronizeUniStreamAccounting_(UniStream_& stream);

    void releaseUniStreamStorage_(UniStream_& stream);

    void releasePendingBytes_(std::size_t bytes);

    static std::size_t retainedRequestBytes_(const RequestStream_& state);

    static bool multipartExpansionBytes_(const SwHttpRequest& request,
                                         std::size_t& outBytes);

    bool reserveMultipartParseBudget_(RequestStream_& state,
                                      const SwHttpRequest& request,
                                      std::size_t& reservedBytes);

    bool reconcileMultipartParseBudget_(RequestStream_& state,
                                        const SwHttpRequest& request,
                                        std::size_t reservedBytes);

    void releaseRequestStorage_(RequestStream_& state);

    void markResourceLimitExceeded_(RequestStream_& state);

    bool synchronizeRequestAccounting_(RequestStream_& state);

    bool finishRequestStream_(std::uint64_t streamId,
                              RequestStream_& state,
                              const SwHttpResponse& response,
                              bool finishStream,
                              SwString* error);

    static bool statusForbidsResponseBody_(int status);

    static std::size_t responseChunkBytes_(std::size_t requested);

    static bool chunkPartsHaveBytes_(const ResponseStream_& state);

    // HTTP/3 has no Transfer-Encoding framing. Even responses produced through
    // the HTTP/1.x-style chunk API therefore have a deterministic representation
    // length on the wire: explicit parts win, with body as the legacy fallback
    // only when no parts were supplied.
    static bool responseRepresentationLength_(const SwHttpResponse& response,
                                              std::size_t& outLength);

    bool encodeResponseHeaders_(const SwHttpResponse& response,
                                SwByteArray& out,
                                SwString* error) const;

    bool beginResponseStream_(std::uint64_t streamId,
                              const SwHttpResponse& originalResponse,
                              SwString* error);

    bool failResponseStream_(std::uint64_t streamId,
                             SwString* error);

    bool encodeDataFrame_(const SwByteArray& payload,
                          ResponseStream_& state,
                          bool fin,
                          SwString* error);

    bool prepareNextResponseFrame_(std::uint64_t streamId,
                                   ResponseStream_& state,
                                   std::size_t maxPayloadBytes,
                                   SwString* error);

    bool pumpOneResponseStream_(std::uint64_t streamId,
                                bool& progressed,
                                SwString* error);

    bool pumpResponseStreams_(SwString* error);

    bool ensureControlStream_(SwString* error);

    bool handleUniStream_(std::uint64_t streamId, const SwByteArray& chunk,
                          bool fin, SwString* error);

    bool parseControlStream_(SwByteArray& buffer, SwString* error);

    bool handleRequestStream_(std::uint64_t streamId,
                              const SwByteArray& chunk,
                              bool fin,
                              SwString* error);

    static bool prepareResponseForHttp3_(const SwHttpRequest& request,
                                         SwHttpResponse& response,
                                         SwString* error);

    // For WebTransport CONNECT the response has no body; a rejected session
    // finishes the stream, an accepted one keeps it open as the session stream.
    bool sendResponseHeadersOnly_(std::uint64_t streamId,
                                  const SwHttpResponse& response,
                                  bool finish,
                                  SwString* error);

    static void pushStatus_(std::vector<std::pair<SwByteArray, SwByteArray> >& fields,
                            int status);

    void closeWebTransportSession_(std::uint64_t sessionId);

    static bool fieldLineSize_(
        const std::pair<SwByteArray, SwByteArray>& field,
        std::uint64_t& outBytes);

    static bool fieldSectionSize_(
        const std::vector<std::pair<SwByteArray, SwByteArray> >& fields,
        std::uint64_t& outBytes);

    static bool isValidResponseHeaderName_(const SwString& name);

    static bool isValidResponseHeaderValue_(const SwString& value);

    static void appendHeaderMap_(const SwMap<SwString, SwString>& headers,
                                 std::vector<std::pair<SwByteArray, SwByteArray> >& fields);

    static bool isConnectionSpecificHeader_(const SwString& lower);

    static bool validateTrailerFields_(
        const std::vector<std::pair<SwByteArray, SwByteArray> >& fields);

    static bool isTokenCharacter_(std::uint8_t value);

    // HTTP/3 field names are HTTP tokens encoded entirely in lowercase. A
    // request pseudo-header has one leading ':' followed by such a token.
    static bool isValidRequestFieldName_(const SwByteArray& name, bool pseudo);

    static bool isValidRequestFieldValue_(const SwByteArray& value);

    static bool isValidRequestMethod_(const SwByteArray& method);

    static bool parseContentLength_(const SwByteArray& value,
                                    std::uint64_t& outLength);

    static bool authoritiesMatch_(const SwString& authority,
                                  const SwString& host);

    // Returns true when the request is an Extended CONNECT (WebTransport). Sets
    // outMalformed per RFC 9114 4.1.2/4.2/4.3.1 (connection-specific fields,
    // bad TE, unknown/duplicate/misplaced pseudo-headers, missing mandatory
    // pseudo-headers).
    static bool fieldsToRequest_(const std::vector<std::pair<SwByteArray, SwByteArray> >& fields,
                                 SwByteArray& body,
                                 SwHttpRequest& request,
                                 bool& outMalformed);


private:
    // What the class keeps (SwHttp3Server_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

#endif
