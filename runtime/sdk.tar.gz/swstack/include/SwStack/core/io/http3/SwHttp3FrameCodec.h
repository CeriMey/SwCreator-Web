#ifndef SWHTTP3FRAMECODEC_H
#define SWHTTP3FRAMECODEC_H

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "quic/SwQuicVarIntCodec.h"

#include <cstddef>
#include <cstdint>
#include <limits>
#include <utility>
#include <vector>

//--------------------------------------------------------------------------------------------------
// SwHttp3Frame
//
// Models a single HTTP/3 frame as defined in RFC 9114 section 7:
//   HTTP/3 Frame { Type (i), Length (i), Frame Payload (..) }
// where Type and Length are QUIC variable-length integers (RFC 9000 section 16).
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwHttp3Frame {
public:
    enum class Type {
        Data,        // 0x00
        Headers,     // 0x01
        CancelPush,  // 0x03
        Settings,    // 0x04
        PushPromise, // 0x05
        GoAway,      // 0x07
        MaxPushId,   // 0x0d
        Unknown      // reserved / GREASE / unrecognized
    };

    // Wire type codes (RFC 9114 section 11.2.1).
    static std::uint64_t typeData();
    static std::uint64_t typeHeaders();
    static std::uint64_t typeCancelPush();
    static std::uint64_t typeSettings();
    static std::uint64_t typePushPromise();
    static std::uint64_t typeGoAway();
    static std::uint64_t typeMaxPushId();

    // Known SETTINGS identifiers (RFC 9114 section 7.2.4.1, RFC 9204, RFC 9297, WebTransport).
    static std::uint64_t settingQpackMaxTableCapacity();
    static std::uint64_t settingMaxFieldSectionSize();
    static std::uint64_t settingQpackBlockedStreams();
    static std::uint64_t settingH3Datagram();
    // Chromium/QUICHE still ships both interoperable WebTransport-over-H3
    // wire versions.  Advertise both so a browser with draft-07 disabled can
    // fall back to draft-02 instead of rejecting the HTTP/3 session.
    static std::uint64_t settingEnableWebTransportDraft02();
    static std::uint64_t settingEnableWebTransport();

    typedef std::pair<std::uint64_t, std::uint64_t> Setting;
    typedef std::vector<Setting> SettingList;

    SwHttp3Frame();

    // Factories ----------------------------------------------------------------------------------

    static SwHttp3Frame data(const SwByteArray& payload);

    static SwHttp3Frame headers(const SwByteArray& payload);

    static SwHttp3Frame settings(const SettingList& pairs);

    static SwHttp3Frame goAway(std::uint64_t id);

    static SwHttp3Frame maxPushId(std::uint64_t id);

    static SwHttp3Frame cancelPush(std::uint64_t id);

    static SwHttp3Frame pushPromise(std::uint64_t pushId, const SwByteArray& encodedFieldSection);

    // Constructs a frame that carries an unrecognized / reserved (GREASE) type unchanged.
    static SwHttp3Frame unknown(std::uint64_t rawType, const SwByteArray& payload);

    // Accessors ----------------------------------------------------------------------------------

    Type type() const;
    std::uint64_t rawType() const;
    const SwByteArray& payload() const;
    std::uint64_t id() const;
    std::uint64_t pushId() const;
    const SettingList& settings() const;

private:
    explicit SwHttp3Frame(Type type);

public:
    ~SwHttp3Frame();
public:
    SwHttp3Frame(const SwHttp3Frame& other);
    SwHttp3Frame& operator=(const SwHttp3Frame& other);
private:
    // What the class keeps (SwHttp3FrameCodec_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};

//--------------------------------------------------------------------------------------------------
// SwHttp3FrameCodec
//
// Stateless encoder/decoder for HTTP/3 frames. Every fallible operation returns bool and reports
// a human-readable message through the trailing SwString* error out-parameter.
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwHttp3FrameCodec {
public:
    static bool encodeFrame(const SwHttp3Frame& frame,
                            SwByteArray& out,
                            SwString* error = nullptr);

    static bool decodeFrame(const SwByteArray& buffer,
                            std::size_t& offset,
                            SwHttp3Frame& out,
                            SwString* error = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static void clearError_(SwString* error);

    static bool appendVarInt_(std::uint64_t value, SwByteArray& out, SwString* error);

    static bool readVarInt_(const SwByteArray& buffer,
                            std::size_t& offset,
                            std::uint64_t& outValue,
                            SwString* error);

    static bool readSlice_(const SwByteArray& buffer,
                           std::size_t& offset,
                           std::uint64_t length,
                           SwByteArray& outSlice,
                           SwString* error);

    static bool buildPayload_(const SwHttp3Frame& frame,
                              std::uint64_t& typeValue,
                              SwByteArray& payload,
                              SwString* error);

    static bool readSinglePayloadVarInt_(const SwByteArray& payload,
                                         std::uint64_t& outValue,
                                         SwString* error);

    static bool parseSettings_(const SwByteArray& payload,
                               SwHttp3Frame::SettingList& outPairs,
                               SwString* error);
};

#endif
