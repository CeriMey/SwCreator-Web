#ifndef SWHPACKHUFFMAN_H
#define SWHPACKHUFFMAN_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"

#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>

//--------------------------------------------------------------------------------------------------
// SwHpackHuffman
//
// Implements the canonical HPACK Huffman code defined in RFC 7541 Appendix B. The exact same
// static Huffman table is reused by QPACK (RFC 9204) for HTTP/3 header string literals. The table
// carries 257 symbols: one code per possible octet value (0..255) plus the End-Of-String (EOS,
// symbol 256) marker used for padding.
//
// encode() serialises an octet sequence into its Huffman representation, MSB first, and pads the
// final partial byte with the most-significant bits of the EOS symbol (all ones), as required by
// RFC 7541 section 5.2.
//
// decode() walks the bit stream, emitting a symbol as soon as a complete code is matched. It
// enforces the RFC 7541 section 5.2 padding rules: a fully decoded EOS symbol is illegal, any
// padding longer than 7 bits is illegal, and any padding that is not a prefix of EOS (i.e. not all
// ones) is illegal.
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwHpackHuffman {
public:
    struct Code {
        std::uint32_t bits;   // right-aligned code value
        std::uint8_t length;  // number of significant bits (1..30)
    };

    static bool encode(const SwByteArray& in, SwByteArray& out, SwString* error = nullptr);

    static bool decode(const SwByteArray& in, SwByteArray& out, SwString* error = nullptr);

    static bool decode(const SwByteArray& in,
                       SwByteArray& out,
                       std::size_t maxOutputBytes,
                       SwString* error = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static void clearError_(SwString* error);

    static std::uint64_t key_(int length, std::uint32_t code);

    static const std::map<std::uint64_t, int>& decodeLookup_();

    static std::map<std::uint64_t, int> buildLookup_();

    static const Code* table_();
};

#endif
