#ifndef SWWEBTRANSPORTSESSION_H
#define SWWEBTRANSPORTSESSION_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "http3/SwHttp3FrameCodec.h"
#include "http3/SwQpackEncoder.h"
#include "http3/SwQpackDecoder.h"
#include "quic/SwQuicVarIntCodec.h"

#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

//--------------------------------------------------------------------------------------------------
// SwWebTransportSession
//
// WebTransport-over-HTTP/3 session framing (draft-ietf-webtrans-http3). Client-oriented and
// stateless: every routine operates on byte buffers so the caller owns the actual QUIC streams.
//
// A WebTransport session is established with an HTTP/3 Extended CONNECT request (RFC 9220) that
// carries the :protocol pseudo-header set to "webtransport". Once the server answers 2xx, the
// client may open WebTransport streams and send HTTP/3 datagrams associated with the session:
//   - Unidirectional WT stream : stream type 0x54 (varint) then Session ID (varint).
//   - Bidirectional  WT stream : frame  type 0x41 WEBTRANSPORT_STREAM (varint) then Session ID.
//   - HTTP/3 datagram          : Quarter Stream ID (varint = Session ID / 4) then the payload.
//
// Every fallible operation returns bool and reports a human-readable message through the trailing
// SwString* error out-parameter (nullptr accepted). Reuses SwHttp3FrameCodec + SwQpackEncoder for
// the CONNECT HEADERS frame and SwQuicVarIntCodec for every QUIC/HTTP3 varint.
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwWebTransportSession {
public:
    // Wire constants (draft-ietf-webtrans-http3, RFC 9220, RFC 9297) ------------------------------

    // WebTransport unidirectional stream type prefix.
    static std::uint64_t uniStreamType();
    // WEBTRANSPORT_STREAM frame type, opening a bidirectional WebTransport stream.
    static std::uint64_t bidiStreamFrameType();
    // SETTINGS_ENABLE_CONNECT_PROTOCOL (RFC 9220): permits Extended CONNECT in HTTP/3.
    static std::uint64_t settingEnableConnectProtocol();

    // SETTINGS a WebTransport client must advertise on its HTTP/3 control stream ------------------
    static SwHttp3Frame::SettingList requiredClientSettings();

    struct ConnectRequest {
        SwByteArray authority; // e.g. "example.com:443"
        SwByteArray path;      // e.g. "/wt"
    };

    // Builds the Extended CONNECT request as a single HTTP/3 HEADERS frame carrying the QPACK
    // encoded pseudo-header set required to open a WebTransport session.
    static bool buildConnect(const ConnectRequest& req,
                             SwByteArray& outRequestStream,
                             SwString* err = nullptr);

    // Inspects the server's decoded response field section (QPACK encoded field-section bytes) and
    // reports whether the WebTransport session was accepted, i.e. :status is 2xx.
    static bool isSessionAccepted(const SwByteArray& responseHeadersDecoded,
                                  bool& accepted,
                                  SwString* err = nullptr);

    // Emits the leading bytes of a WebTransport unidirectional stream: type 0x54 then session id.
    static bool buildUniStreamHeader(std::uint64_t sessionId,
                                     SwByteArray& out,
                                     SwString* err = nullptr);

    // Emits the leading bytes of a WebTransport bidirectional stream: the WEBTRANSPORT_STREAM frame
    // type 0x41 then the session id.
    static bool buildBidiStreamHeader(std::uint64_t sessionId,
                                      SwByteArray& out,
                                      SwString* err = nullptr);

    // Encodes an HTTP/3 datagram bound to a WebTransport session: the Quarter Stream ID
    // (session id / 4, RFC 9297 section 2.1) as a varint, followed by the raw payload.
    static bool encodeDatagram(std::uint64_t sessionId,
                               const SwByteArray& payload,
                               SwByteArray& out,
                               SwString* err = nullptr);

    // Decodes an HTTP/3 datagram: the leading Quarter Stream ID varint, then the trailing payload.
    static bool decodeDatagram(const SwByteArray& in,
                               std::uint64_t& quarterStreamId,
                               SwByteArray& payload,
                               SwString* err = nullptr);

private:
    static void setError_(SwString* error, const char* message);

    static void clearError_(SwString* error);
};

#endif
