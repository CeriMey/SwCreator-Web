#ifndef SWQPACKDECODER_H
#define SWQPACKDECODER_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"
#include "SwString.h"
#include "http3/SwHpackHuffman.h"
#include "http3/SwQpackStaticTable.h"

#include <cstddef>
#include <cstdint>
#include <limits>
#include <utility>
#include <vector>

//--------------------------------------------------------------------------------------------------
// SwQpackDecoder
//
// Decodes a single QPACK encoded field section (RFC 9204 section 4.5) produced against the static
// table only. The section prefix must announce Required Insert Count = 0 and Base = 0; any other
// value refers to the dynamic table, which this decoder does not implement and rejects.
//
// It understands the three static field-line representations emitted by SwQpackEncoder and always
// supports Huffman-coded string literals (RFC 7541 Appendix B).
//
// Note: QPACK integers use the HPACK N-bit prefix integer representation (RFC 7541 section 5.1),
// not the QUIC variable-length integer, so SwQuicVarIntCodec is intentionally not used here.
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwQpackDecoder {
public:
    static bool decodeFieldSection(const SwByteArray& in,
                                   std::vector<std::pair<SwByteArray, SwByteArray> >& out,
                                   SwString* error = nullptr);

    static bool decodeFieldSection(
        const SwByteArray& in,
        std::vector<std::pair<SwByteArray, SwByteArray> >& out,
        std::size_t maxFieldCount,
        std::size_t maxDecodedBytes,
        SwString* error = nullptr);

private:
    static std::size_t remainingBytes_(std::size_t limit,
                                       std::size_t used,
                                       std::size_t reserved);

    static bool appendField_(
        std::vector<std::pair<SwByteArray, SwByteArray> >& out,
        SwByteArray name,
        SwByteArray value,
        std::size_t decodedLimit,
        std::size_t& decodedBytes,
        SwString* error);

    static void setError_(SwString* error, const char* message);

    static void clearError_(SwString* error);

    // HPACK N-bit prefix integer (RFC 7541 section 5.1).
    static bool decodeInteger_(const SwByteArray& in,
                               std::size_t& offset,
                               int prefixBits,
                               std::uint64_t& value,
                               SwString* error);

    // Decodes a string literal whose length integer uses 'prefixBits' and whose 'hBit' (in the
    // length byte) flags Huffman coding.
    static bool decodeString_(const SwByteArray& in,
                              std::size_t& offset,
                              int prefixBits,
                              std::uint8_t hBit,
                              std::size_t maxOutputBytes,
                              SwByteArray& out,
                              SwString* error);
};

#endif
