#ifndef SWQPACKSTATICTABLE_H
#define SWQPACKSTATICTABLE_H

#include "../../SwStackExport.h"

#include "SwByteArray.h"

#include <cstddef>
#include <string>

//--------------------------------------------------------------------------------------------------
// SwQpackStaticTable
//
// The QPACK static table defined in RFC 9204 Appendix A. It holds 99 predefined name/value pairs
// addressed by absolute index 0..98. Unlike HPACK, the QPACK static table is decoupled from the
// dynamic table, so these indices are stable and always available to both peers.
//
// nameValueAt() returns the pair at a given index. findExact() locates an entry matching both name
// and value (used to emit an Indexed Field Line). findName() locates the first entry with a given
// name (used to emit a Literal Field Line With Name Reference).
//--------------------------------------------------------------------------------------------------

class SW_QUIC_EXPORT SwQpackStaticTable {
public:
    static std::size_t entryCount();

    static bool nameValueAt(std::size_t index, SwByteArray& name, SwByteArray& value);

    static bool findExact(const SwByteArray& name, const SwByteArray& value, std::size_t& index);

    static bool findName(const SwByteArray& name, std::size_t& index);

private:
    struct Entry {
        const char* name;
        const char* value;
    };

    static bool matches_(const SwByteArray& value, const char* literal);

    static const Entry* table_();
};

#endif
