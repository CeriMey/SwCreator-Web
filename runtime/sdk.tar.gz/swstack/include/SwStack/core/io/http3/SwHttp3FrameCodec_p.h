#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/http3/SwHttp3FrameCodec.h"

struct SwHttp3Frame::Data : SwSharedData {
    Type m_type;
    std::uint64_t m_rawType;
    std::uint64_t m_id;
    SwByteArray m_payload;
    SettingList m_settings;
};
