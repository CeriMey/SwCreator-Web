#ifndef SWQUICHTTP3SERVER_H
#define SWQUICHTTP3SERVER_H

#include "../../SwStackExport.h"

#include "SwObject.h"
#include "SwMap.h"
#include "SwMutex.h"
#include "SwPointer.h"
#include "SwString.h"
#include "SwTimer.h"
#include "SwUdpSocket.h"
#include "SwVector.h"
#include "http/SwHttpRouter.h"
#include "http/SwHttpTypes.h"
#include "http3/SwHttp3Server.h"
#include "quic/SwQuicConnection.h"
#include "quic/SwQuicHandshakeServer.h"
#include "quic/SwQuicRandom.h"
#include "quic/SwQuicRetry.h"
#include "quic/SwQuicServerCredential.h"
#include "quic/SwQuicSessionTicket.h"

#include <chrono>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <exception>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <string>
#include <vector>

// End-to-end HTTP/3-over-QUIC server driver.
//
// It binds a single UDP socket and, per client, runs the full stack: the QUIC
// v1 + TLS 1.3 server handshake (`SwQuicHandshakeServer`) until 1-RTT keys are
// derived, then hands the application packet-number space to a
// `SwQuicConnection` and drives an `SwHttp3Server` over it, dispatching each
// request through an `SwHttpRouter` (or a request handler). This is the glue
// that turns an accepted QUIC connection into routed HTTP/3 requests -- the
// same route table can therefore serve HTTP/1.x (via SwHttpServer) and HTTP/3.
//
// It is poll-driven like `SwQuicServer`: bind with listen(), then either rely
// on the socket's readyRead signal or call poll() from an event loop.
class SW_QUIC_EXPORT SwQuicHttp3Server : public SwObject {
    SW_OBJECT(SwQuicHttp3Server, SwObject)

private:
    struct Client_;
    struct AsyncCompletionCycle_;

public:
    typedef std::function<SwHttpResponse(const SwHttpRequest&)> RequestHandler;
    typedef std::function<void(const SwHttpRequest&,
                               const SwHttp3Server::ResponseCallback&)>
        AsyncRequestHandler;
    typedef SwHttp3Server::PendingBytesReserveHandler PendingBytesReserveHandler;
    typedef SwHttp3Server::PendingBytesReleaseHandler PendingBytesReleaseHandler;
    typedef SwMap<SwString, SwQuicServerCredential> CredentialMap;

    explicit SwQuicHttp3Server(SwObject* parent = nullptr);

    ~SwQuicHttp3Server() override;

    // The credential (certificate chain + CertificateVerify signer) the server
    // presents to every client. Required before listen()/poll().
    void setCredential(const SwQuicServerCredential& credential);

    void setCredentials(const SwQuicServerCredential& defaultCredential,
                        const CredentialMap& credentialsByHost);

    // Route requests through an SwHttpRouter (shared with the HTTP/1.x server).
    void setRouter(SwHttpRouter* router);

    // Or dispatch through a plain handler (takes precedence only if no router).
    void setRequestHandler(const RequestHandler& handler);
    void setAsyncRequestHandler(const AsyncRequestHandler& handler);
    void setMaxClients(std::size_t maximum);
    void setMaxPendingHandshakes(std::size_t maximum);
    void setHandshakeTimeoutMs(std::uint64_t timeoutMs);
    void setMaxSessionTickets(std::size_t maximum);
    void setHttpLimits(const SwHttpLimits& limits);

    // Stateless address validation via Retry (RFC 9000 8.1.2). When enabled,
    // a new Initial arriving without a token is answered with a Retry packet
    // -- allocating NO server state -- once `pendingHandshakeThreshold`
    // handshakes are already in progress (0 = validate every new connection).
    // The address token binds the client address, the original DCID and the
    // Retry SCID under an HMAC key minted per listen(), and expires after
    // `tokenMaxAgeSeconds`. This is the anti-DoS gate against Initial floods:
    // an attacker must prove return routability before costing a handshake.
    void setAddressValidation(bool enabled,
                              std::size_t pendingHandshakeThreshold = 0,
                              std::uint64_t tokenMaxAgeSeconds = 30);
    bool addressValidationEnabled() const;
    std::uint64_t retryPacketsSent() const;
    // Optional cross-transport budget. Configure before listen(); the driver
    // still tracks its own H3 usage for diagnostics while the external gate can
    // combine that usage with TCP/TLS sessions.
    void setPendingRequestBudgetHandlers(
        const PendingBytesReserveHandler& reserveHandler,
        const PendingBytesReleaseHandler& releaseHandler);

    // Event-loop integration. When enabled, UDP readiness drives packet work
    // and a one-shot timer is re-armed to the earliest QUIC deadline. Manual
    // poll() remains available for dedicated-loop users and existing tests.
    void setAutomaticPollingEnabled(bool enabled);

    bool automaticPollingEnabled() const;

    bool listen(const SwString& bindAddress, uint16_t port, SwString* error = nullptr);

    void close();

    // Graceful shutdown (RFC 9114 5.2): GOAWAY every established session and
    // refuse new connections while the socket keeps draining in-flight work.
    // poll()/timers keep running; each connection is closed with H3_NO_ERROR
    // once its requests are answered and the responses are acknowledged.
    // Observe completion with isDrained(), then call close().
    void beginGracefulShutdown();

    bool gracefulShutdownInitiated() const;

    // True once every session has finished its in-flight requests and had its
    // CONNECTION_CLOSE initiated. The remaining transport-level draining is
    // time-bounded; close() can follow safely.
    bool isDrained() const;

    bool isListening() const;
    uint16_t localPort() const;
    SwString localAddress() const;
    std::size_t clientCount() const;
    std::size_t pendingRequestBytes() const;

    int poll(int timeoutMs = 0, SwString* error = nullptr);

    std::int64_t nextTimeoutMs() const;

signals:
    SW_SIGNAL(requestServed, const SwHttpRequest&, const SwHttpResponse&)
    SW_SIGNAL(clientRejected, const SwString&, uint16_t, const SwString&)
    SW_SIGNAL(serverError, const SwString&)

private:
    class SW_QUIC_EXPORT PollScope_ {
    public:
        explicit PollScope_(SwQuicHttp3Server* server);
        ~PollScope_();
    private:
        SwQuicHttp3Server* m_server;
    };

    struct SW_QUIC_EXPORT Client_ {
        SwQuicHandshakeServer handshake;
        std::unique_ptr<SwQuicConnection> connection;
        std::unique_ptr<SwHttp3Server> http3;
        SwString host;
        uint16_t port;
        bool credentialSet;
        std::uint64_t credentialGeneration;
        bool established;
        bool failed;
        std::uint64_t createdMs;
        std::uint64_t lastActivityMs;
        std::shared_ptr<std::atomic<std::size_t> > pendingAsyncResponses;

        Client_();
    };

    struct AsyncCompletion_ {
        std::string clientKey;
        std::uint64_t streamId = 0;
        std::shared_ptr<SwHttpResponse> response;
    };

    struct AsyncCompletionCycle_ {
        SwMutex mutex;
        std::deque<AsyncCompletion_> queue;
        std::atomic<std::size_t> queued{0};
        bool accepting = true;
    };

    std::int64_t nextTimeoutMs_() const;

    void armTimer_();

    void closeNow_();

    void beginAsyncCompletionCycle_();

    void invalidateAsyncCompletionCycle_();

    void advanceCredentialGeneration_();

    static void setError_(SwString* error, const SwString& message);

    bool reservePendingRequestBytes_(std::size_t bytes);

    void releasePendingRequestBytes_(std::size_t bytes);

    static std::string endpointKey_(const SwString& host, uint16_t port);

    static std::string connectionMapKey_(const std::string& initialDestinationId);

    static std::string connectionIdKey_(const SwByteArray& connectionId);

    static bool extractDestinationConnectionId_(const SwByteArray& datagram,
                                                std::string& outConnectionId);

    static std::uint64_t nowMs_();

    static bool isValidInitial_(const SwByteArray& datagram);

    // Extracts the source connection id and the token from a client Initial
    // whose outer geometry isValidInitial_() already vetted.
    static bool parseInitialScidAndToken_(const SwByteArray& datagram,
                                          SwByteArray& outScid,
                                          SwByteArray& outToken);

    std::size_t pendingHandshakeCount_() const;

    void purgeClients_(std::uint64_t now);

    bool processDatagram_(const SwByteArray& datagram,
                          const SwString& sender,
                          uint16_t senderPort,
                          SwString* error);

    bool establishConnection_(const std::string& clientKey,
                              Client_& client,
                              SwString* error);

    bool issueSessionTicket_(Client_& client, SwString* error);

    SwHttp3Server::RequestHandler makeRequestHandler_(Client_* client);

    SwHttp3Server::AsyncRequestHandler makeAsyncRequestHandler_(Client_* client);

    SwHttp3Server::AsyncResponseReadyHandler makeAsyncResponseReadyHandler_(
        const std::string& clientKey);

    void drainAsyncCompletions_(
        const std::shared_ptr<AsyncCompletionCycle_>& cycle);

    void deliverAsyncCompletion_(AsyncCompletion_& completion);

    // During a graceful shutdown, close each session once its HTTP/3 work is
    // done AND the transport confirmed delivery of every queued byte (GOAWAY,
    // final responses). CONNECTION_CLOSE with H3_NO_ERROR then ends it.
    void advanceGracefulShutdown_();

    // Drive per-connection QUIC timers (PTO retransmission, idle) for every
    // established client, then flush any resulting datagrams.
    void fireTimers_();

    bool flushConnection_(Client_& client, SwString* error);

    bool sendDatagrams_(const SwVector<SwByteArray>& datagrams,
                        const Client_& client,
                        SwString* error);

    void emitClientRejected_(const SwString& sender, uint16_t senderPort, const SwString& reason);

private:
    // What the class keeps (SwQuicHttp3Server_p.h): its size and layout do not depend on it.
    struct Data;
    SwObjectDataPointer<Data> d_;
};

#endif
