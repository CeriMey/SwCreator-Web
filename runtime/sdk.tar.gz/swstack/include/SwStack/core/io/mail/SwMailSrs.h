#pragma once

#include "../../SwStackExport.h"

#include "SwMailCommon.h"


#include <cctype>
#include <string>
#include <vector>

// Sender Rewriting Scheme (SRS0) : lors d'un forwarding d'alias vers une adresse
// externe, l'enveloppe MAIL FROM est réécrite vers le domaine forwardeur pour que
// SPF passe chez le destinataire final. L'adresse reste décodable (HMAC + timestamp)
// afin de re-router les bounces vers l'expéditeur d'origine.
// Format : srs0=<hash>=<tt>=<domaine-origine>=<local-origine>@<domaine-forwardeur>
class SW_MAIL_EXPORT SwMailSrs {
public:
    static constexpr int kMaxAgeDays = 21;

    static SwString generateSecret();

    static bool isSrsAddress(const SwString& address);

    static SwString encode(const SwString& secret,
                           const SwString& originalSender,
                           const SwString& forwardDomain);

    static bool decode(const SwString& secret,
                       const SwString& srsAddress,
                       SwString* outOriginalSender,
                       SwString* outError = nullptr);

private:
    static const char* base32Chars_();

    static long long currentDayIndex_();

    static SwString encodeTimestamp_(long long dayIndex);

    static int decodeTimestamp_(const SwString& timestamp);

    static int base32Index_(char c);

    static SwString computeHash_(const SwString& secret,
                                 const SwString& timestamp,
                                 const SwString& domain,
                                 const SwString& localPart);
};
