#pragma once

#include "../../SwStackExport.h"

#include "SwMailDkim.h"
#include "SwMailDmarc.h"
#include "SwMailSpf.h"

// Orchestrateur de l'authentification entrante : enchaîne SPF → DKIM → DMARC sur
// un unique SwMailDnsClient et assemble l'en-tête Authentication-Results (RFC 8601).
// Les évaluateurs SwMailSpf / SwMailDkimVerifier / SwMailDmarc restent purs.
struct SW_MAIL_EXPORT SwInboundAuthResult {
    SwMailSpf::Result spf = SwMailSpf::Result::None;
    SwString spfMailfrom;        // smtp.mailfrom= (adresse complète)
    SwString spfAuthedDomain;    // domaine MAIL FROM authentifié (vide si fallback HELO)
    SwMailDkim::VerifyResult dkim = SwMailDkim::VerifyResult::None;
    SwString dkimDomain;         // header.d= de la première signature Pass
    SwList<SwString> dkimPassDomains;
    SwMailDmarc::Disposition dmarcDisposition = SwMailDmarc::Disposition::Fail;
    bool dmarcEvaluated = false;
    SwString headerFromDomain;   // header.from=
    bool dmarcReject = false;
    SwMailDmarc::Result dmarc;
};

class SW_MAIL_EXPORT SwMailInboundAuth {
public:
    static SwMailSpf::Result evaluateSpf(SwMailDnsClient& dns, const SwString& clientIp,
                                         const SwString& mailFrom, const SwString& helo,
                                         SwString* outMailfrom, SwString* outAuthedDomain);

    static SwMailDkim::VerifyResult verifyDkim(SwMailDnsClient& dns, const SwByteArray& message,
                                               SwString* outFirstPassDomain,
                                               SwList<SwString>* outPassDomains);

    static SwMailDmarc::Disposition evaluateDmarc(SwMailDnsClient& dns, const SwByteArray& message,
                                                  SwInboundAuthResult& io,
                                                  SwMailConfig::InboundAuthMode mode,
                                                  int* outRejectCode);

    // RFC 8601 — valeur de l'en-tête uniquement (sans nom de champ ni CRLF). Les
    // valeurs issues de l'enveloppe/des en-têtes (mailfrom, d=, from) ne sont émises
    // que si propres : un MAIL FROM:<a@b; dmarc=pass> ne doit pas pouvoir injecter une
    // pseudo-propriété dans NOTRE en-tête (corruption de grammaire AR).
    static SwString buildAuthenticationResults_(const SwString& authservId, const SwInboundAuthResult& r);

    static bool selfTest_();

private:
    // Une valeur sûre pour une propriété AR : non vide, sans espace/séparateur de
    // grammaire ni CR/LF (pas d'injection de propriété ni de pliage).
    static bool isArSafe_(const SwString& s);

    static SwString dmarcToken_(const SwInboundAuthResult& r);
};
