#pragma once

#include "../../SwStackExport.h"

#include "SwMailCommon.h"
#include "SwMailDnsClient.h"
#include "SwList.h"
#include "SwString.h"

#include <cctype>
#include <cstdint>
#include <cstring>
#include <functional>
#include <string>
#include <vector>

// RFC 7208 — évaluateur SPF du courrier entrant. Pur (aucun état), DNS injectable
// pour les tests. Mécanismes v1 : all, ip4, ip6, a, mx, include, exists, redirect=.
// SKIPPÉ et documenté : ptr (déprécié → no-match), exp= (ignoré), expansion de
// macros (% → terme ignoré). Limites RFC §4.6.4 appliquées : 10 lookups DNS, 2 void.
class SW_MAIL_EXPORT SwMailSpf {
public:
    enum class Result {
        None = 0, Neutral, Pass, Fail, SoftFail, TempError, PermError
    };

    struct Evaluation {
        Result result = Result::None;
        SwString checkedDomain;     // domaine dont la policy a autorisé l'IP
        SwString mailFromDomain;    // domaine RFC5321.MailFrom (vide si fallback HELO) — alignement DMARC
        SwString explanation;
        int dnsLookups = 0;
    };

    // Sources DNS injectables (chaque fn renvoie la liste de chaînes pour le host).
    struct DnsFns {
        std::function<SwList<SwString>(const SwString&)> txt;
        std::function<SwList<SwString>(const SwString&)> a;
        std::function<SwList<SwString>(const SwString&)> aaaa;
        std::function<SwList<SwString>(const SwString&)> mx;
    };

    static Evaluation evaluate(const SwString& clientIp,
                               const SwString& mailFromDomain,
                               const SwString& heloDomain,
                               SwMailDnsClient& dns);

    static Evaluation evaluateWith(const SwString& clientIp,
                                   const SwString& mailFromDomain,
                                   const SwString& heloDomain,
                                   const DnsFns& dns);

    static SwString resultToken(Result r);

    static bool selfTest_();

private:
    struct ClientIp_ {
        int family = 0;  // 4, 6, ou 0
        uint8_t v4[4] = {0, 0, 0, 0};
        uint8_t v6[16] = {0};
    };

    struct Budget_ {
        int dnsLookups = 0;
        int voidLookups = 0;
    };

    static std::string lower_(const std::string& in);

    static int hexVal_(char c);

    static bool parseIpv4Bytes_(const std::string& in, uint8_t out[4]);

    static bool parseIpv6Bytes_(const std::string& in, uint8_t out[16]);

    static bool parseClientIp_(const SwString& raw, ClientIp_& out);

    static bool matchPrefix_(const uint8_t* ip, const uint8_t* net, int byteLen, int prefix);

    static int parseCidrNumber_(const std::string& s, bool& ok);

    // Découpe un terme-mécanisme en name/value/cidrs. Renvoie false si CIDR invalide.
    static bool splitMechanism_(const std::string& tok, std::string& name, std::string& value,
                                int& v4cidr, int& v6cidr);

    static Result qualifierResult_(char q);

    static bool ipMatchesList_(const ClientIp_& ip, const SwList<SwString>& addrs, int v4cidr, int v6cidr);

    static Result checkHost_(const SwString& domain, const ClientIp_& ip, const DnsFns& dns,
                             Budget_& budget, int depth);
};

