#pragma once

#include "../../SwStackExport.h"

#include "SwMailCommon.h"
#include "SwMailDnsClient.h"
#include "SwMailSpf.h"
#include "SwList.h"
#include "SwString.h"

#include <cctype>
#include <cstdlib>
#include <functional>
#include <map>
#include <string>
#include <vector>

// RFC 7489 — DMARC. Consomme directement SwMailSpf::Result et la liste des
// domaines d= DKIM vérifiés. Limitation documentée : pas de Public Suffix List,
// le « domaine organisationnel » est approximé par les 2 derniers labels
// (faux positifs possibles sur les suffixes multi-labels type co.uk).
class SW_MAIL_EXPORT SwMailDmarc {
public:
    enum class Policy { None = 0, Quarantine, Reject };
    enum class Alignment { Relaxed = 0, Strict };
    enum class Disposition { Pass = 0, Fail };
    enum class AlignedBy { None = 0, Dkim, Spf };
    enum class Action { Accept = 0, Flag, Reject };

    struct Record {
        bool present = false;
        bool valid = false;
        Policy p = Policy::None;
        Policy sp = Policy::None;
        bool hasSp = false;
        Alignment adkim = Alignment::Relaxed;
        Alignment aspf = Alignment::Relaxed;
        int pct = 100;
        SwString policyDomain;
        bool fromOrgApproximation = false;
    };

    struct Result {
        bool evaluated = false;
        SwString fromDomain;
        bool multipleFromRejected = false;
        Record record;
        Disposition disposition = Disposition::Fail;
        AlignedBy alignedBy = AlignedBy::None;
        Policy applicablePolicy = Policy::None;
        SwString authResultsFragment;  // "dmarc=pass header.from=..." (informatif)
        SwString diagnostic;
    };

    struct SpfInput {
        SwMailSpf::Result result = SwMailSpf::Result::None;
        SwString authenticatedDomain;  // domaine MAIL FROM authentifié par SPF
    };
    struct DkimInput {
        SwList<SwString> passingDomains;  // d= des signatures vérifiées (minuscule)
    };

    static Result evaluate(const SwByteArray& raw, const SpfInput& spf, const DkimInput& dkim,
                           SwMailDnsClient& dns);

    static Result evaluateWith(const SwByteArray& raw, const SpfInput& spf, const DkimInput& dkim,
                               const std::function<SwString(const SwString&)>& txtLookup);

    static Action applyPolicy(const Result& r, SwMailConfig::InboundAuthMode mode, int& outSmtpRejectCode);

    static SwString organizationalDomainApprox_(const SwString& domain);

    // Retire les commentaires RFC 5322 (...) hors guillemets (parenthèses imbriquées).
    static std::string stripComments_(const std::string& in);

    // Extraction robuste du domaine du RFC5322.From. Gère les noms d'affichage avec
    // virgule ("Doe, John <a@b>") sans les confondre avec plusieurs adresses, et les
    // commentaires. Ne marque outMultipleFrom que pour un VRAI multi-identité.
    static SwString extractFromDomain_(const SwByteArray& raw, bool& outMultipleFrom);

    static Record parseRecord_(const SwString& txt);

    static bool selfTest_();

private:
    static std::string lower_(const std::string& s);

    static std::string trim_(const std::string& s);

    static std::map<std::string, std::string> parseTags_(const std::string& v);

    static std::string getTag_(const std::map<std::string, std::string>& tags, const std::string& key);

    static Policy policyFromString_(const std::string& s);

    static bool aligned_(const SwString& candidate, const SwString& fromDomain, Alignment mode);

    static Record discoverRecord_(const SwString& fromDomain,
                                  const std::function<SwString(const SwString&)>& txtLookup);

    static int pctGate_(const SwString& seed);
};

