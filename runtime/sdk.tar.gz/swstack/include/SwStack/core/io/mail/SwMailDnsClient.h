#pragma once

#include "SwSharedData.h"
#include "../../SwStackExport.h"

#include "SwDebug.h"
#include "SwFile.h"
#include "SwList.h"
#include "SwMailCommon.h"
#include "SwString.h"

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>


class SW_MAIL_EXPORT SwMailDnsClient {
public:
    explicit SwMailDnsClient(int timeoutMs = 2500);

    SwList<SwMailMxRecord> resolveMx(const SwString& domain, SwString* outError = nullptr) const;

    SwList<SwString> resolveA(const SwString& host, SwString* outError = nullptr) const;

    SwList<SwString> resolveAaaa(const SwString& host, SwString* outError = nullptr) const;

    SwList<SwMailDnsTxtRecord> resolveTxt(const SwString& host, SwString* outError = nullptr) const;

    SwList<SwString> defaultMailTargetsForDomain(const SwString& domain, SwString* outError = nullptr) const;

private:

    static uint16_t readU16_(const unsigned char* bytes, std::size_t offset);

    static uint32_t readU32_(const unsigned char* bytes, std::size_t offset);

    static void writeU16_(std::vector<unsigned char>& buffer, uint16_t value);

    static std::vector<unsigned char> buildQueryPacket_(const SwString& host, uint16_t type, uint16_t id);

    static bool parseName_(const std::vector<unsigned char>& packet,
                           std::size_t& offset,
                           SwString& outName);

    SwList<SwString> resolverAddresses_() const;

    bool sendUdpQuery_(const SwString& resolverIp,
                       const std::vector<unsigned char>& query,
                       std::vector<unsigned char>& response,
                       SwString* outError) const;

    static void closeSocket_(
#if defined(_WIN32)
        std::uintptr_t   // a SOCKET
#else
        int
#endif
            sock);

    bool skipQuestion_(const std::vector<unsigned char>& packet, std::size_t& offset) const;

    bool queryMx_(const SwString& domain,
                  SwList<SwMailMxRecord>& out,
                  SwString* outError) const;

    bool queryTxt_(const SwString& host,
                   SwList<SwMailDnsTxtRecord>& out,
                   SwString* outError) const;

    bool queryHostAddresses_(const SwString& host,
                             uint16_t qtype,
                             SwList<SwString>& out,
                             SwString* outError) const;

    std::vector<unsigned char> performQuery_(const SwString& host,
                                             uint16_t type,
                                             SwString* outError) const;

    bool parseMxAnswers_(const std::vector<unsigned char>& packet,
                         SwList<SwMailMxRecord>& out,
                         SwString* outError) const;

    bool parseTxtAnswers_(const std::vector<unsigned char>& packet,
                          SwList<SwMailDnsTxtRecord>& out,
                          SwString* outError) const;

    bool parseAddressAnswers_(const std::vector<unsigned char>& packet,
                              uint16_t qtype,
                              SwList<SwString>& out,
                              SwString* outError) const;
public:
    ~SwMailDnsClient();
public:
    SwMailDnsClient(const SwMailDnsClient& other);
    SwMailDnsClient& operator=(const SwMailDnsClient& other);
private:
    // What the class keeps (SwMailDnsClient_p.h), shared by its copies until one of them changes:
    // its size and layout do not depend on it.
    struct Data;
    SwSharedDataPointer<Data> d_;
};
