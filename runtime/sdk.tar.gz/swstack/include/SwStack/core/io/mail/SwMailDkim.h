#pragma once

#include "../../SwStackExport.h"
#include "../SwOpenSslDefs.h"   // OpenSSL's types, without its headers

#include "SwCrypto.h"
#include "SwDebug.h"
#include "SwMailCommon.h"
#include "SwMailDnsClient.h"
#include "SwMailStore.h"


#include <algorithm>
#include <cstdlib>
#include <functional>
#include <map>
#include <string>
#include <vector>

// Canonicalisation DKIM relaxed partagée entre le signeur et le vérifieur.
// Les corps sont déplacés verbatim depuis SwMailDkimSigner pour garantir que la
// vérification reproduit exactement ce que la signature a calculé (R1).

class SW_MAIL_EXPORT SwMailDkimSigner {
public:
    static bool ensureDomainKey(SwMailStore& store,
                                const SwString& domain,
                                const SwString& selector,
                                SwMailDkimRecord& outRecord,
                                SwString& outError);

    static bool signMessage(const SwMailConfig& config,
                            SwMailStore& store,
                            SwByteArray& rawMessage,
                            SwString& outSelector,
                            SwString& outError);

private:
    // RFC 6376 §5.4.1 : tout en-tête qui change le sens du message pour son
    // lecteur est couvert, sinon un relais peut le réécrire sans casser la
    // signature. Bcc, Received et Return-Path n'y figurent jamais.
    static SwList<SwString> signedHeaderNames_();

    static bool generateRecord_(SwMailDkimRecord& record, SwString& outError);

    static SwString bioToString_(BIO* bio);

    static SwString buildPublicTxt_(const SwString& publicPem, SwString& outError);

    static SwString computeBodyHash_(const SwByteArray& rawMessage);

    static std::string canonicalizeBody_(const std::string& raw);

    static SwString buildSigningHeader_(const SwString& domain,
                                        const SwString& selector,
                                        const SwList<SwString>& signedHeaders,
                                        const SwString& bodyHash);

    static SwString canonicalizeHeaders_(const SwMap<SwString, SwString>& headers,
                                         const SwList<SwString>& names);

    static SwString canonicalizeHeaderLine_(const SwString& name, const SwString& value);

    static bool signSha256_(const SwString& privatePem,
                            const std::string& input,
                            SwString& outSignature,
                            SwString& outError);
};

// Coquille de portée pour l'enum de résultat partagé par DMARC / l'orchestrateur.
class SW_MAIL_EXPORT SwMailDkim {
public:
    enum class VerifyResult { None = 0, Pass, Fail, TempError, PermError };

    static SwString resultToken(VerifyResult r);
};

struct SW_MAIL_EXPORT SwDkimSignatureResult {
    SwString domain;    // d= (minuscule, point final retiré)
    SwString selector;  // s=
    SwMailDkim::VerifyResult result = SwMailDkim::VerifyResult::None;
    SwString reason;
};

// RFC 6376 — vérification DKIM du courrier entrant. relaxed/relaxed uniquement
// (le seul mode que notre signeur émet et le seul byte-exactement reproductible).
class SW_MAIL_EXPORT SwMailDkimVerifier {
public:
    static SwList<SwDkimSignatureResult> verifyMessage(const SwByteArray& rawMessage,
                                                       SwMailDnsClient& dns);

    static SwList<SwDkimSignatureResult> verifyMessage(
        const SwByteArray& rawMessage,
        const std::function<SwString(const SwString&)>& txtLookup);

    static bool anyPass(const SwList<SwDkimSignatureResult>& results,
                        SwList<SwString>* outPassDomains = nullptr);

    // Round-trip : signe via SwMailDkimSigner puis vérifie avec la clé publique
    // injectée. Valide la cohérence signeur↔vérifieur (R1). Nécessite un store ouvert.
    static bool roundTripSelfTest_(SwMailStore& store, const SwMailConfig& config);

private:
    static constexpr std::size_t kMaxDkimSignatures_ = 5;

    static std::string trim_(const std::string& s);

    static std::string stripWs_(const std::string& s);

    static std::string lower_(const std::string& s);

    static std::map<std::string, std::string> parseTags_(const std::string& v);

    static std::string getTag_(const std::map<std::string, std::string>& tags, const std::string& key);

    // Vide la valeur du tag b= en préservant la structure (pour le hash d'en-tête).
    static std::string emptyBTag_(const std::string& v);

    static std::string buildSigningInput_(const SwByteArray& raw, const std::string& hTag,
                                          const SwString& sigRawValue);

    static bool rsaVerify_(const std::string& pubKeyBase64, const std::string& input,
                           const std::string& sigBase64);

    static SwDkimSignatureResult verifyOne_(const SwByteArray& raw, const SwString& sigRawValue,
                                            const std::function<SwString(const SwString&)>& txtLookup);
};

