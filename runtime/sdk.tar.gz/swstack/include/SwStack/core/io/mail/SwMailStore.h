#pragma once

#include <memory>
#include "../../SwStackExport.h"

#include "SwDebug.h"
#include "SwEmbeddedDb.h"
#include "SwMailCommon.h"
#include "SwMailSrs.h"

#define SW_MAIL_RETURN_IF_NOT_OPEN_() \
    if (!m_opened) { \
        return SwDbStatus(SwDbStatus::NotOpen, "Mail store not open"); \
    }

class SW_MAIL_EXPORT SwMailStore {
public:
    SwMailStore();

    void setConfig(const SwMailConfig& config);

    const SwMailConfig& config() const;

    SwDbStatus open();

    void close();

    bool isOpen() const;

    SwDbStatus createAccount(const SwString& address,
                             const SwString& password,
                             SwMailAccount* createdOut = nullptr);

    SwDbStatus updateAccount(const SwMailAccount& account);

    SwDbStatus setAccountPassword(const SwString& address, const SwString& password);

    SwDbStatus setAccountSuspended(const SwString& address, bool suspended);

    SwDbStatus getAccount(const SwString& address, SwMailAccount* outAccount);

    bool authenticate(const SwString& address,
                      const SwString& password,
                      SwMailAccount* outAccount = nullptr,
                      SwString* outError = nullptr);

    SwList<SwMailAccount> listAccounts();

    SwDbStatus upsertAlias(const SwMailAlias& alias);

    SwList<SwMailAlias> listAliases();

    SwDbStatus getAlias(const SwString& address, SwMailAlias* outAlias);

    SwDbStatus deleteAlias(const SwString& address);

    SwDbStatus ensureSrsSecret(SwString* outSecret);

    SwDbStatus ensureDefaultMailboxes(const SwString& accountAddress);

    SwList<SwMailMailbox> listMailboxes(const SwString& accountAddress);

    SwDbStatus appendMessage(const SwString& accountAddress,
                             const SwString& mailboxName,
                             const SwByteArray& rawMessage,
                             const SwList<SwString>& flags,
                             const SwString& internalDate = SwString(),
                             SwMailMessageEntry* createdOut = nullptr);

    SwList<SwMailMessageEntry> listMessages(const SwString& accountAddress,
                                            const SwString& mailboxName);

    SwDbStatus getMessage(const SwString& accountAddress,
                          const SwString& mailboxName,
                          unsigned long long uid,
                          SwMailMessageEntry* outMessage);

    SwDbStatus setMessageFlags(const SwString& accountAddress,
                               const SwString& mailboxName,
                               unsigned long long uid,
                               const SwList<SwString>& flags);

    SwDbStatus copyMessage(const SwString& accountAddress,
                           const SwString& sourceMailbox,
                           unsigned long long uid,
                           const SwString& targetMailbox);

    SwDbStatus expungeMailbox(const SwString& accountAddress,
                              const SwString& mailboxName,
                              unsigned long long* removedCountOut = nullptr);

    SwDbStatus storeQueueItem(const SwMailQueueItem& item);

    SwList<SwMailQueueItem> listQueueItems();

    SwDbStatus getQueueItem(const SwString& id, SwMailQueueItem* outItem);

    SwList<SwMailQueueItem> listDueQueueItems(long long nowEpochMs, std::size_t maxItems = 32);

    SwDbStatus removeQueueItem(const SwString& id);

    SwDbStatus upsertDkimRecord(const SwMailDkimRecord& record);

    SwDbStatus getDkimRecord(const SwString& domain,
                             const SwString& selector,
                             SwMailDkimRecord* outRecord);

    SwList<SwMailDkimRecord> listDkimRecords();

    // Résolution trois-voies : comptes locaux d'un côté, cibles externes issues
    // d'alias de l'autre. L'expansion d'alias est récursive (profondeur bornée,
    // cycles ignorés). Retourne NotFound si un destinataire de premier niveau
    // n'est ni un compte ni un alias actif du domaine.
    SwDbStatus resolveRecipients(const SwList<SwString>& recipients,
                                 SwList<SwString>* outLocalTargets,
                                 SwList<SwMailResolvedForward>* outForwardTargets);

    SwDbStatus resolveLocalRecipients(const SwList<SwString>& recipients, SwList<SwString>* outTargets);

private:

    static SwByteArray toPrimaryKey_(const SwString& key);

    static SwByteArray toSecondaryKey_(const SwString& key);

    SwDbStatus ensureDefaultMailboxesLocked_(const SwString& accountAddress);

    SwDbStatus ensureMailboxLocked_(const SwString& accountAddress,
                                    const SwString& mailboxName,
                                    SwMailMailbox* outMailbox);

    SwDbStatus loadAccountLocked_(const SwString& canonicalAddress, SwMailAccount& outAccount);

    static constexpr int kMaxAliasDepth_ = 8;

    SwDbStatus resolveRecipientLocked_(const SwString& address,
                                       const SwString& rootRecipient,
                                       int depth,
                                       SwList<SwString>& visitedAliases,
                                       SwList<SwString>* outLocalTargets,
                                       SwList<SwMailResolvedForward>* outForwardTargets);

    SwDbStatus getMessageUnlocked_(const SwString& accountAddress,
                                   const SwString& mailboxName,
                                   unsigned long long uid,
                                   SwMailMessageEntry& outMessage);

    SwList<SwMailMessageEntry> listMessagesUnlocked_(const SwString& accountAddress,
                                                     const SwString& mailboxName);

    static bool hasSeenFlag_(const SwList<SwString>& flags);

    static SwJsonObject accountToJson_(const SwMailAccount& account);

    static SwMailAccount accountFromJson_(const SwJsonObject& object);

    static SwJsonObject aliasToJson_(const SwMailAlias& alias);

    static SwMailAlias aliasFromJson_(const SwJsonObject& object);

    static SwJsonObject mailboxToJson_(const SwMailMailbox& mailbox);

    static SwMailMailbox mailboxFromJson_(const SwJsonObject& object);

    static SwJsonObject messageToJson_(const SwMailMessageEntry& entry);

    static SwMailMessageEntry messageFromJson_(const SwJsonObject& object);

    static SwJsonObject queueItemToJson_(const SwMailQueueItem& item);

    static SwMailQueueItem queueItemFromJson_(const SwJsonObject& object);

    static SwJsonObject dkimToJson_(const SwMailDkimRecord& record);

    static SwMailDkimRecord dkimFromJson_(const SwJsonObject& object);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForAccount_(const SwMailAccount& account);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForAlias_(const SwMailAlias& alias);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForMailbox_(const SwMailMailbox& mailbox);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForMessage_(const SwMailMessageEntry& entry);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForQueueItem_(const SwMailQueueItem& item);

    static SwMap<SwString, SwList<SwByteArray>> secondaryKeysForDkim_(const SwMailDkimRecord& record);
public:
    ~SwMailStore();
private:
    // What the class keeps (SwMailStore_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};

#undef SW_MAIL_RETURN_IF_NOT_OPEN_
