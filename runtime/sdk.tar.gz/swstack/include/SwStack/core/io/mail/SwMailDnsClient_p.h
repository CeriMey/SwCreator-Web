#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/io/mail/SwMailDnsClient.h"

// The platform, which the public header no longer shows (SwMailDnsClient.h).
#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#include <iphlpapi.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

struct SwMailDnsClient::Data : SwSharedData {
    int m_timeoutMs = 2500;
};
