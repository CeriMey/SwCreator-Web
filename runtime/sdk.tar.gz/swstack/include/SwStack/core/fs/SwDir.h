#pragma once

#include "../SwStackExport.h"

/**
 * @file src/core/fs/SwDir.h
 * @ingroup core_fs
 * @brief Declares the public interface exposed by SwDir in the CoreSw filesystem layer.
 *
 * This header belongs to the CoreSw filesystem layer. It wraps platform-specific path, directory,
 * settings, and related utility services behind framework-native types.
 *
 * Within that layer, this file focuses on the dir interface. The declarations exposed here define
 * the stable surface that adjacent code can rely on while the implementation remains free to
 * evolve behind the header.
 *
 * The main declarations in this header are SwDir.
 *
 * Directory and path declarations here usually define normalization, lookup, traversal, and
 * platform-neutral path manipulation rules that other modules can depend on.
 *
 * Filesystem declarations in this area are meant to keep file and path behavior predictable
 * across platforms while staying inside the Sw* type system.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include <string>
#include <iostream>

#include "Sw.h"
#include "SwString.h"
#include "SwList.h"
#include "SwFile.h"
#include "SwDirEntryList.h"
#include "SwDebug.h"
static constexpr const char* kSwLogCategory_SwDir = "sw.core.fs.swdir";


class SW_CORE_EXPORT SwDir {
public:
    /**
     * @brief Constructs a `SwDir` instance.
     * @param path Path used by the operation.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    explicit SwDir(const SwString& path = ".");

    /**
     * @brief Destroys the `SwDir` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwDir() = default;

    /**
     * @brief Returns the current exists.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool exists() const;

    /**
     * @brief Returns the current path.
     * @return The current path.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString path() const;

    /**
     * @brief Performs the `exists` operation.
     * @param path Path used by the operation.
     * @return The requested exists.
     */
    static bool exists(const SwString& path);

    /**
     * @brief Returns @p path absolute and resolved, in SwStack's portable spelling.
     * @param path Path in any spelling: relative, with "\\" or "/" separators, or native
     * ("\\?\C:\dir" on Windows).
     * @return The path as every SwStack API gives paths back, the same way on every system:
     * "/" separators, "." and ".." resolved, doubled separators merged, a trailing separator
     * kept, links not followed, and no Windows long-path prefix — "C:/dir/file",
     * "//server/share/file", "/home/me/file". SwStack converts it to the system's form itself
     * where it calls the system, so a path longer than MAX_PATH works as any other.
     */
    static SwString normalizePath(const SwString& path);

    /**
     * @brief Returns whether the system tells file names apart by their case.
     * @return `false` where "Main.cpp" and "main.cpp" name the same file (Windows, macOS),
     * `true` elsewhere. Compare paths with toLower() when it is `false`.
     */
    static bool isCaseSensitive();

    /**
     * @brief Returns whether two file names, or two paths spelled alike, name the same entry
     * under the system's rules: compared as they are where names are case sensitive, with
     * case ignored over all of Unicode elsewhere ("Été.ui" and "été.UI" on Windows).
     */
    static bool isSameName(const SwString& first, const SwString& second);

    /**
     * @brief Performs the `mkpathAbsolute` operation.
     * @param path Path used by the operation.
     * @param normalizeInput Value passed to the method.
     * @return The requested mkpath Absolute.
     */
    static bool mkpathAbsolute(const SwString& path, bool normalizeInput = true);

    /**
     * @brief Performs the `mkpath` operation.
     * @param subPath Value passed to the method.
     * @return `true` on success; otherwise `false`.
     */
    bool mkpath(const SwString& subPath) const;

    /**
     * @brief Sets the path.
     * @param path Path used by the operation.
     * @return `true` on success; otherwise `false`.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    bool setPath(const SwString& path);

    /**
     * @brief Performs the `entryList` operation.
     * @param flags Flags that refine the operation.
     * @return The requested entry List.
     */
    SwStringList entryList(EntryTypes flags) const;

    /**
     * @brief Performs the `entryList` operation.
     * @param filters Value passed to the method.
     * @param flags Flags that refine the operation.
     * @return The requested entry List.
     */
    SwStringList entryList(const SwStringList& filters, EntryTypes flags = EntryType::AllEntries) const;
    /** Enumerate without exceeding maxScannedEntries (including rejected entries).
     *  Publish destination only on Complete. Cancellation is checked before
     *  opening and between entries; callback exceptions propagate with resources closed.
     */
    SwDirEntryListStatus entryList(const SwStringList& filters, EntryTypes flags,
        SwStringList& destination, std::size_t maxScannedEntries,
        const std::function<bool()>& cancelled = {}) const;

    /**
     * @brief Returns the current absolute Path.
     * @return The current absolute Path.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString absolutePath() const;

    /**
     * @brief Performs the `absoluteFilePath` operation.
     * @param relativePath Value passed to the method.
     * @return The requested absolute File Path.
     */
    SwString absoluteFilePath(const SwString& relativePath) const;

    /**
     * @brief Performs the `mkdir` operation.
     * @param path Path used by the operation.
     * @return The requested mkdir.
     */
    static bool mkdir(const SwString& path);

    /**
     * @brief Removes the specified recursively.
     * @param path Path used by the operation.
     * @return The requested recursively.
     */
    static bool removeRecursively(const SwString& path);

    /**
     * @brief Returns the current recursively.
     * @return `true` on success; otherwise `false`.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    bool removeRecursively();

    /**
     * @brief Performs the `copy` operation.
     * @param sourcePath Value passed to the method.
     * @param destinationPath Value passed to the method.
     * @return The requested copy.
     */
    static bool copy(const SwString& sourcePath, const SwString& destinationPath);

    /**
     * @brief Performs the `findFiles` operation.
     * @param filter Value passed to the method.
     * @return The requested find Files.
     */
    SwStringList findFiles(const SwString& filter) const;

    /**
     * @brief Returns the current current Path.
     * @return The current current Path.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static SwString currentPath();

    /**
     * @brief Returns whether the provided path is absolute on the active platform.
     * @param path Path used by the operation.
     * @return `true` when the path is absolute; otherwise `false`.
     */
    static bool isAbsolutePath(const SwString& path);

    /**
     * @brief Returns the current dir Name.
     * @return The current dir Name.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString dirName() const;

private:
    SwString m_path;

    static bool createPathTree(const SwString& rawPath);
};
