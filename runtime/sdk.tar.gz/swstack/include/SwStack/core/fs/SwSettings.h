#ifndef SWSETTINGS_H
#define SWSETTINGS_H

#include "../SwStackExport.h"

/**
 * @file src/core/fs/SwSettings.h
 * @ingroup core_fs
 * @brief Declares the public interface exposed by SwSettings in the CoreSw filesystem layer.
 *
 * This header belongs to the CoreSw filesystem layer. It wraps platform-specific path, directory,
 * settings, and related utility services behind framework-native types.
 *
 * Within that layer, this file focuses on the settings interface. The declarations exposed here
 * define the stable surface that adjacent code can rely on while the implementation remains free
 * to evolve behind the header.
 *
 * The main declarations in this header are SwSettings.
 *
 * Settings-oriented declarations here describe how named configuration values are grouped,
 * persisted, and retrieved in a way that remains portable across storage backends.
 *
 * Filesystem declarations in this area are meant to keep file and path behavior predictable
 * across platforms while staying inside the Sw* type system.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwAny.h"
#include "SwMap.h"
#include "SwList.h"
#include "SwString.h"
#include "SwStandardPaths.h"
#include "SwJsonValue.h"
#include "SwJsonDocument.h"
#include "SwJsonObject.h"
#include "SwJsonArray.h"
#include "SwFile.h"
#include "SwFileInfo.h"


class SW_CORE_EXPORT SwSettings {
public:
    /**
     * @brief Constructs a `SwSettings` instance.
     * @param organization Value passed to the method.
     * @param application Value passed to the method.
     * @param false Value passed to the method.
     *
     * @details The instance is initialized and prepared for immediate use.
     */
    SwSettings(const SwString& organization = SwString(),
               const SwString& application = SwString());

    /**
     * @brief Destroys the `SwSettings` instance.
     *
     * @details Use this hook to release any resources that remain associated with the instance.
     */
    ~SwSettings();

    /**
     * @brief Sets the value.
     * @param key Value passed to the method.
     * @param value Value passed to the method.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    void setValue(const SwString& key, const SwAny& value);

    /**
     * @brief Performs the `value` operation.
     * @param key Value passed to the method.
     * @param defaultValue Value passed to the method.
     * @return The requested value.
     */
    SwAny value(const SwString& key, const SwAny& defaultValue = SwAny()) const;

    /**
     * @brief Performs the `contains` operation.
     * @param key Value passed to the method.
     * @return `true` when the object reports contains; otherwise `false`.
     */
    bool contains(const SwString& key) const;

    /**
     * @brief Removes the specified remove.
     * @param key Value passed to the method.
     */
    void remove(const SwString& key);

    /**
     * @brief Clears the current object state.
     */
    void clear();

    /**
     * @brief Atomically replaces the complete settings file when values changed.
     *
     * Checked write, flush and replacement failures leave isDirty() true and
     * preserve the previous file. Success is not a journaled crash transaction.
     * Browser IDBFS persistence to IndexedDB remains asynchronous.
     */
    void sync();

    /**
     * @brief Returns whether the object reports dirty.
     * @return `true` when the object reports dirty; otherwise `false`.
     *
     * @details Remains true until sync() successfully replaces the settings file.
     */
    bool isDirty() const;

    /**
     * @brief Performs the `beginGroup` operation.
     * @param prefix Prefix used by the operation.
     */
    void beginGroup(const SwString& prefix);

    /**
     * @brief Performs the `endGroup` operation.
     */
    void endGroup();

    /**
     * @brief Returns the current group.
     * @return The current group.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    SwString group() const;

private:
    using ValueMap = SwMap<SwString, SwJsonValue>;

    void initializePaths();

    SwString canonicalKey(const SwString& key) const;

    void loadFromDisk();

    void saveToDisk();

    static SwJsonValue anyToJson(const SwAny& value);

    static SwAny jsonToAny(const SwJsonValue& value);

    static void buildJsonTree(const SwString& key, const SwJsonValue& value, SwJsonObject& root);

    static void flattenJson(const SwString& prefix, const SwJsonValue& value, ValueMap& out);

    static SwString sanitizeName(const SwString& input);

    static SwString parentDirectory(const SwString& filePath);

    static bool ensureDirectory(const SwString& path);

    static SwString platformPath(const SwString& path);

    static SwString joinPath(const SwString& base, const SwString& child);

    SwString organization_;
    SwString application_;
    SwString filePath_;
    ValueMap values_;
    SwList<SwString> groupStack_;
    bool dirty_;
};

#endif // SWSETTINGS_H
