#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwString.h"

/** Tells when the entries of watched directories change.
 *
 * A directory is watched for files and folders created, deleted or renamed in it, not for
 * changes inside files, and not recursively: watch each directory whose contents matter.
 * The owner polls takeChanges(), from a timer for instance, and reloads what it shows. The
 * system's own notifications are used where there are some (Windows, Linux); elsewhere the
 * directories' timestamps are compared, off the calling thread. Instances are owned by one
 * thread; paths are given in any spelling (SwDir::normalizePath).
 */
class SW_CORE_EXPORT SwDirectoryWatcher {
public:
    SwDirectoryWatcher();
    ~SwDirectoryWatcher();
    SwDirectoryWatcher(const SwDirectoryWatcher&) = delete;
    SwDirectoryWatcher& operator=(const SwDirectoryWatcher&) = delete;

    /// Watches @p path from now on; a directory already watched starts over, so a directory
    /// replaced by another of the same name is watched anew.
    void watch(const SwString& path);
    /// Stops watching every directory.
    void clear();
    /// Whether the entries of a watched directory changed since the previous call.
    bool takeChanges();

private:
    // What the class keeps (SwDirectoryWatcher.cpp): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
