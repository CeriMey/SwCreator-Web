/* Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include <cstddef>
#include <functional>

// Bounded directory enumeration never publishes a partial result. The scan
// budget includes filtered-out files and directories, excluding only . and ...
enum class SwDirEntryListStatus { Complete, Cancelled, ResourceLimit, IoError };
