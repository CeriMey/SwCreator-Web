#pragma once

#include <memory>
#include "../SwStackExport.h"

#include "SwStandardPaths.h"
#include "SwString.h"
#include <cerrno>
#include <cstring>


/** Nonblocking, process-owned file lock. Closing or process death releases it.
 * The lock file is deliberately never unlinked: removing a locked inode would
 * allow another process to create a second, independently locked inode.
 */
class SW_CORE_EXPORT SwLockFile {
public:
    explicit SwLockFile(const SwString& path);
    ~SwLockFile();
    SwLockFile(const SwLockFile&) = delete;
    SwLockFile& operator=(const SwLockFile&) = delete;

    static SwString userRuntimePath(const SwString& name);

    bool tryLock();

    void unlock();
    bool isLocked() const;
    const SwString& fileName() const;
    const SwString& errorString() const;

private:
private:
    // What the class keeps (SwLockFile_p.h): its size and layout do not depend on it.
    struct Data;
    std::unique_ptr<Data> d_;
};
