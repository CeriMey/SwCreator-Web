#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

// The two spellings of a path. SwStack's API speaks the portable one, as Qt's does: absolute, with
// "/" separators and no Windows long-path prefix ("C:/dir/file", "//server/share/file",
// "/home/me/file"). The system calls take the native one: on Windows the extended-length form
// ("\\?\C:\dir\file", "\\?\UNC\server\share\file"), with which paths longer than MAX_PATH work.
// Only the library converts between them, right before it calls the system.

#include "core/types/SwString.h"

#if defined(_WIN32)
#include "platform/win/SwWindows.h"
#include <string>
#endif

namespace swPath {

#if defined(_WIN32)

// Absolute, resolved ("." and ".." gone, doubled separators merged) and prefixed. A path already
// prefixed is the system's own spelling and is kept as it is.
inline SwString native(const SwString& path) {
    SwString result = path.trimmed();
    result.replace("/", "\\");
    if (result.isEmpty() || result.startsWith("\\\\?\\")) {
        return result;
    }
    // The \\?\ prefix added below turns Windows' own path parsing off: a separator doubled by a
    // concatenation ("Temp\\" + "/name"), "." and ".." would then name nothing. GetFullPathNameW
    // resolves them first, for absolute paths as for relative ones, at any length.
    const std::wstring wide = result.toStdWString();
    const DWORD needed = GetFullPathNameW(wide.c_str(), 0, nullptr, nullptr);
    if (needed != 0) {
        std::wstring buffer(needed, L'\0');
        const DWORD length = GetFullPathNameW(wide.c_str(), needed, &buffer[0], nullptr);
        if (length != 0 && length < needed) {
            buffer.resize(length);
            result = SwString::fromWCharArray(buffer.c_str());
            result.replace("/", "\\");
        }
    }
    if (result.startsWith("\\\\")) {
        return SwString("\\\\?\\UNC\\") + result.mid(2);
    }
    return SwString("\\\\?\\") + result;
}

// The portable spelling of a native, portable or mixed path, without resolving it.
inline SwString portable(const SwString& path) {
    SwString result = path;
    result.replace("\\", "/");
    if (result.startsWith("//?/UNC/") || result.startsWith("//?/unc/")) {
        return SwString("//") + result.mid(8);
    }
    if (result.startsWith("//?/")) {
        return result.mid(4);
    }
    return result;
}

#else

// Elsewhere both spellings are the same: "/" is the only separator and "\" may name a file.
inline SwString native(const SwString& path) { return path; }
inline SwString portable(const SwString& path) { return path; }

#endif

} // namespace swPath
