#ifndef SWREADWRITELOCK_H
#define SWREADWRITELOCK_H

#include "../SwStackExport.h"

/**
 * @file src/core/fs/SwReadWriteLock.h
 * @ingroup core_fs
 * @brief Declares the public interface exposed by SwReadWriteLock in the CoreSw utility layer.
 *
 * This header provides a framework-native read/write locking API with Qt-like naming and RAII
 * helpers while remaining compatible with the project's C++11 baseline.
 *
 * Non-recursive mode uses a native shared lock backend on supported platforms:
 * - Windows: `SRWLOCK`
 * - Linux/POSIX: `pthread_rwlock_t`
 *
 * Recursive mode falls back to a recursive mutex because those native reader/writer primitives
 * are not recursively lockable in a portable way.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include <chrono>
#include <map>
#include <mutex>
#include <thread>


class SW_CORE_EXPORT SwReadWriteLock {
public:
    enum RecursionMode {
        NonRecursive,
        Recursive
    };

    explicit SwReadWriteLock(RecursionMode mode = NonRecursive);

    ~SwReadWriteLock();

    SwReadWriteLock(const SwReadWriteLock&) = delete;
    SwReadWriteLock& operator=(const SwReadWriteLock&) = delete;

    void lockForRead();

    void lockForWrite();

    bool tryLockForRead();

    bool tryLockForRead(int timeoutMs);

    bool tryLockForWrite();

    bool tryLockForWrite(int timeoutMs);

    template<typename Rep, typename Period>
    bool tryLockForRead(const std::chrono::duration<Rep, Period>& duration) {
        return tryLockForRead(durationToTimeoutMs_(duration));
    }

    template<typename Rep, typename Period>
    bool tryLockForWrite(const std::chrono::duration<Rep, Period>& duration) {
        return tryLockForWrite(durationToTimeoutMs_(duration));
    }

    void unlock();

    bool isRecursive() const;

private:
    enum UnlockKind {
        UnlockNone,
        UnlockRead,
        UnlockWrite
    };

    struct SW_CORE_EXPORT ThreadLockState {
        int readCount;
        int writeCount;

        ThreadLockState();
    };

    void initNative_();

    void destroyNative_();

    void lockForReadNative_();

    void lockForWriteNative_();

    bool tryLockReadImmediateNative_();

    bool tryLockWriteImmediateNative_();

    void unlockReadNative_();

    void unlockWriteNative_();

    bool tryLockRecursive_(int timeoutMs);

    bool tryLockNative_(int timeoutMs, bool writeLock);

    bool tryLockImmediateNative_(bool writeLock);

    void registerReadLock_() const;

    void registerWriteLock_() const;

    UnlockKind unregisterLock_() const;

    static std::map<const SwReadWriteLock*, ThreadLockState>& threadLockStates_();

    static void pauseBeforeRetry_();

    template<typename Rep, typename Period>
    static int durationToTimeoutMs_(const std::chrono::duration<Rep, Period>& duration) {
        if (duration < std::chrono::duration<Rep, Period>::zero()) {
            return -1;
        }

        const long long timeoutMs =
            std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();

        if (timeoutMs > 2147483647LL) {
            return 2147483647;
        }

        return static_cast<int>(timeoutMs);
    }

    RecursionMode mode_;
    std::recursive_timed_mutex recursiveMutex_;
#if defined(_WIN32)
    void* nativeLock_;   // an SRWLOCK (SwReadWriteLock.cpp)
#else
    pthread_rwlock_t nativeLock_;
#endif
};

class SW_CORE_EXPORT SwReadLocker {
public:
    explicit SwReadLocker(SwReadWriteLock* lock);

    explicit SwReadLocker(SwReadWriteLock& lock);

    ~SwReadLocker();

    SwReadLocker(const SwReadLocker&) = delete;
    SwReadLocker& operator=(const SwReadLocker&) = delete;

    void unlock();

    void relock();

    SwReadWriteLock* readWriteLock() const;

    bool isLocked() const;

private:
    SwReadWriteLock* lock_;
    bool locked_;
};

class SW_CORE_EXPORT SwWriteLocker {
public:
    explicit SwWriteLocker(SwReadWriteLock* lock);

    explicit SwWriteLocker(SwReadWriteLock& lock);

    ~SwWriteLocker();

    SwWriteLocker(const SwWriteLocker&) = delete;
    SwWriteLocker& operator=(const SwWriteLocker&) = delete;

    void unlock();

    void relock();

    SwReadWriteLock* readWriteLock() const;

    bool isLocked() const;

private:
    SwReadWriteLock* lock_;
    bool locked_;
};

#endif
