#ifndef SWSTANDARDPATHS_H
#define SWSTANDARDPATHS_H

#include "../SwStackExport.h"

/**
 * @file src/core/fs/SwStandardPaths.h
 * @ingroup core_fs
 * @brief Declares the public interface exposed by SwStandardPaths in the CoreSw filesystem layer.
 *
 * This header belongs to the CoreSw filesystem layer. It wraps platform-specific path, directory,
 * settings, and related utility services behind framework-native types.
 *
 * Within that layer, this file focuses on the standard paths interface. The declarations exposed
 * here define the stable surface that adjacent code can rely on while the implementation remains
 * free to evolve behind the header.
 *
 * The main declarations in this header are SwStandardPaths.
 *
 * Directory and path declarations here usually define normalization, lookup, traversal, and
 * platform-neutral path manipulation rules that other modules can depend on.
 *
 * Filesystem declarations in this area are meant to keep file and path behavior predictable
 * across platforms while staying inside the Sw* type system.
 *
 */

/***************************************************************************************************
 * This file is part of a project developed by Eymeric O'Neill.
 *
 * Copyright (C) 2025 Ariya Consulting
 * Author/Creator: Eymeric O'Neill
 * Contact: +33 6 52 83 83 31
 * Email: eymeric.oneill@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************************************/

#include "SwString.h"
#include "SwList.h"
#include "Sw.h"
#include "SwDir.h"
#include "SwFileInfo.h"
#include "SwStandardLocation.h"

#include <cstdlib>


class SW_CORE_EXPORT SwStandardPaths {
public:
    enum StandardLocation {
        DesktopLocation,
        DocumentsLocation,
        PicturesLocation,
        MusicLocation,
        MoviesLocation,
        DownloadLocation,
        ApplicationsLocation,
        FontsLocation,
        HomeLocation,
        TempLocation,
        GenericDataLocation,
        GenericConfigLocation,
        AppDataLocation,
        AppConfigLocation,
        AppLocalDataLocation,
        CacheLocation,
        RuntimeLocation
    };

    enum LocateOption {
        LocateFile = 0x1,
        LocateDirectory = 0x2
    };
    using LocateOptions = SwFlagSet<LocateOption>;

    /**
     * @brief Performs the `writableLocation` operation.
     * @param type Value passed to the method.
     * @return The requested writable Location.
     */
    static SwString writableLocation(StandardLocation type);

    /**
     * @brief Performs the `writableLocations` operation.
     * @param type Value passed to the method.
     * @return The requested writable Locations.
     */
    static SwList<SwString> writableLocations(StandardLocation type);

    /**
     * @brief Performs the `standardLocations` operation.
     * @param type Value passed to the method.
     * @return The requested standard Locations.
     */
    static SwList<SwString> standardLocations(StandardLocation type);

    /**
     * @brief Performs the `displayName` operation.
     * @param type Value passed to the method.
     * @return The requested display Name.
     */
    static SwString displayName(StandardLocation type);

    /**
     * @brief Sets the test Mode Enabled.
     * @param enabled Value passed to the method.
     * @return The requested test Mode Enabled.
     *
     * @details Call this method to replace the currently stored value with the caller-provided one.
     */
    static void setTestModeEnabled(bool enabled);

    /**
     * @brief Returns whether the object reports test Mode Enabled.
     * @return The current test Mode Enabled.
     *
     * @details The returned value reflects the state currently stored by the instance.
     */
    static bool isTestModeEnabled();

    /**
     * @brief Overrides writable standard locations with an application-owned root directory.
     *
     * This is intended for embedded runtimes such as Android where the host application already
     * provides a private writable directory and process environment variables are not reliable.
     */
    static void setWritableLocationRootOverride(const SwString& root);

    /**
     * @brief Returns the current writable location root override.
     */
    static SwString writableLocationRootOverride();

    /**
     * @brief Performs the `findExecutable` operation.
     * @param executableName Value passed to the method.
     * @param searchPaths Value passed to the method.
     * @return The requested find Executable.
     */
    static SwString findExecutable(const SwString& executableName,
                                   const SwList<SwString>& searchPaths = SwList<SwString>());

    /**
     * @brief Performs the `locate` operation.
     * @param type Value passed to the method.
     * @param fileName Value passed to the method.
     * @param options Option set controlling the operation.
     * @return The requested locate.
     */
    static SwString locate(StandardLocation type,
                           const SwString& fileName,
                           LocateOptions options = LocateFile);

    /**
     * @brief Performs the `locateAll` operation.
     * @param type Value passed to the method.
     * @param fileName Value passed to the method.
     * @param options Option set controlling the operation.
     * @return The requested locate All.
     */
    static SwList<SwString> locateAll(StandardLocation type,
                                      const SwString& fileName,
                                      LocateOptions options = LocateFile);

private:
    static SwString envValue_(const char* name);

    static SwString resolveLocation(StandardLocation type);

    static SwList<SwString> fallbackLocations(StandardLocation type);

    static SwStandardLocationId toLocationId(StandardLocation type);

    static bool& testModeEnabledFlag();

    static SwString& testRootStorage();

    static SwString& writableLocationRootOverrideStorage();

    static SwString writableOverridePath(StandardLocation type, const SwString& root);

    static SwString testRootPath();

    static bool isMatch(const SwString& path, LocateOptions options);

    static bool isExecutableFile(const SwString& path);

    static SwList<SwString> environmentPaths();

    static bool containsPathSeparator(const SwString& path);

    static void appendUnique(SwList<SwString>& list, const SwString& value);

    static SwString normalizeForPlatform(const SwString& path);

    static bool ensureDirectory(const SwString& path);

    static SwString joinPath(const SwString& base, const SwString& child);
};

#endif // SWSTANDARDPATHS_H
