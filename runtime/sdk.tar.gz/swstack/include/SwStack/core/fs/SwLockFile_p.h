#pragma once

//
//  W A R N I N G
//  -------------
//
// This file is not part of the SwStack API. It is used by the library's own .cpp files only and
// may change from one version to the next, or disappear.
//

#include "core/fs/SwLockFile.h"

// The platform, which the public header no longer shows (SwLockFile.h).
#ifdef _WIN32
#include <windows.h>
#elif !defined(__EMSCRIPTEN__)
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

struct SwLockFile::Data {
    SwString path_, error_;
#ifdef _WIN32
    HANDLE handle_{INVALID_HANDLE_VALUE};
#elif defined(__EMSCRIPTEN__)
    int browserLock_{0};
#else
    int fd_{-1};
#endif
};
