const api = globalThis.browser || chrome;
const ticket = new URLSearchParams(location.hash.slice(1)).get('ticket');
const request = async type => {
    const reply = await api.runtime.sendMessage({browserPair:type,ticket});
    if (!reply?.ok) throw new Error('Association expirée ou indisponible');
    return reply.value;
};
request('read').then(value => {
    document.querySelector('#identity').textContent = value.application + '\n' + value.url;
    document.querySelector('#allow').disabled = false;
}).catch(error => document.querySelector('#status').textContent = error.message);
for (const [id,type] of [['allow','approve'],['deny','deny']]) document.querySelector('#'+id).onclick = async () => {
    document.querySelector('#allow').disabled = true;
    try { await request(type); window.close(); }
    catch (error) { document.querySelector('#status').textContent = error.message; }
};
