// Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: LicenseRef-IaAssistant-Commercial
// Subscription OAuth transport shared by the shipped browser broker.
export const claudeProduction = Object.freeze({
    authorize: 'https://claude.com/cai/oauth/authorize',
    token: 'https://platform.claude.com/v1/oauth/token',
    revoke: 'https://platform.claude.com/v1/oauth/token/revoke',
    profile: 'https://api.anthropic.com/api/oauth/profile',
    models: 'https://api.anthropic.com/v1/models',
    messages: 'https://api.anthropic.com/v1/messages',
    callback: 'https://platform.claude.com/oauth/code/callback',
    // The same public client identifier used by the native account transport.
    // Availability depends on Anthropic; do not present this as our registration.
    clientId: '9d1c250a-e61b-44d9-88ed-5944d1962f5e'
});
const scope = 'user:profile user:inference';
const credential = value => typeof value === 'string' && /^[\x21-\x7e]{1,32768}$/.test(value);
function httpError(operation, response) {
    return Object.assign(new Error('Claude ' + operation +
        (response.status === 429 ? ' rate limited' : ' rejected') + ' (HTTP ' + response.status + ')'),
        {httpStatus: response.status, retryAfterSeconds: response.retryAfterSeconds});
}

export async function claudeLogin(ep, random, base64url) {
    const verifier = random(), state = random();
    const challenge = base64url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))));
    const url = new URL(ep.authorize);
    url.search = new URLSearchParams({code: 'true', client_id: ep.clientId, response_type: 'code',
        redirect_uri: ep.callback, scope, code_challenge: challenge, code_challenge_method: 'S256', state}).toString();
    return {authorization: url.href, verifier, state, callback: ep.callback};
}

function acceptTokens(tokens, previous) {
    const refresh = tokens?.refresh_token ?? previous?.refresh_token ?? '';
    const scopes = tokens?.scope ?? previous?.scope;
    if (!credential(tokens?.access_token) || (refresh && !credential(refresh)) ||
        (tokens.token_type && tokens.token_type.toLowerCase() !== 'bearer') ||
        typeof tokens.expires_in !== 'number' || !Number.isFinite(tokens.expires_in) ||
        tokens.expires_in < 1 || tokens.expires_in > 366 * 86400 ||
        typeof scopes !== 'string' || !scopes.split(' ').includes('user:inference'))
        throw new Error('Claude returned an invalid subscription session');
    return {...tokens, refresh_token: refresh, scope: scopes, expiresAt: Date.now() + tokens.expires_in * 1000};
}
export function claudeHeaders(tokens) {
    return {Accept: 'application/json', Authorization: 'Bearer ' + tokens.access_token,
        'anthropic-version': '2023-06-01', 'anthropic-beta': 'oauth-2025-04-20',
        'anthropic-dangerous-direct-browser-access': 'true'};
}
async function profile(ep, tokens, fetchBounded) {
    const response = await fetchBounded(ep.profile, {headers: claudeHeaders(tokens)});
    if (!response.ok || typeof response.json?.account?.uuid !== 'string' || !response.json.account.uuid ||
        typeof response.json?.organization?.uuid !== 'string' || !response.json.organization.uuid)
        throw httpError('profile', response);
    const plan = response.json.organization.organization_type;
    return {subject: response.json.account.uuid, organization: response.json.organization.uuid,
        planType: typeof plan === 'string' ? plan.replace(/^claude_/, '') : 'unknown'};
}
export async function exchangeClaude(pending, code, fetchBounded) {
    const response = await fetchBounded(pending.ep.token, {method: 'POST',
        headers: {'Content-Type': 'application/json', Accept: 'application/json'},
        body: JSON.stringify({grant_type: 'authorization_code', code, state: pending.state,
            client_id: pending.ep.clientId, code_verifier: pending.verifier, redirect_uri: pending.callback})});
    if (!response.ok || !response.json) throw httpError('token exchange', response);
    const tokens = acceptTokens(response.json);
    return {tokens, client: pending.ep.clientId, ...(await profile(pending.ep, tokens, fetchBounded))};
}
export async function renewClaude(ep, account, fetchBounded) {
    if (!credential(account.tokens.refresh_token)) throw new Error('Claude session cannot be renewed');
    const response = await fetchBounded(ep.token, {method: 'POST',
        headers: {'Content-Type': 'application/json', Accept: 'application/json'},
        body: JSON.stringify({grant_type: 'refresh_token', refresh_token: account.tokens.refresh_token,
            client_id: account.client, scope: account.tokens.scope})});
    if (!response.ok || !response.json) throw httpError('renewal', response);
    const tokens = acceptTokens(response.json, account.tokens);
    const identity = await profile(ep, tokens, fetchBounded);
    if (identity.subject !== account.subject || identity.organization !== account.organization)
        throw new Error('Claude account changed during renewal');
    return {...account, tokens, ...identity};
}
export async function revokeClaude(ep, account, fetchBounded) {
    if (!account?.tokens.refresh_token) return {remoteRevoked: false};
    const response = await fetchBounded(ep.revoke, {method: 'POST',
        headers: {'Content-Type': 'application/json', Accept: 'application/json'},
        body: JSON.stringify({token: account.tokens.refresh_token, token_type_hint: 'refresh_token', client_id: account.client})});
    return {remoteRevoked: response.ok}; // A successful 204 intentionally has no JSON.
}
