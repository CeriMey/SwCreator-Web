// Persistent extension vault. CryptoKey is non-extractable and kept in IndexedDB;
// only encrypted account records are written to extension local storage.
const api = globalThis.browser || chrome;
const keyReady = new Promise((resolve, reject) => {
    const open = indexedDB.open('iaassistant-vault', 1);
    open.onupgradeneeded = () => open.result.createObjectStore('keys');
    open.onerror = () => reject(new Error('Browser vault unavailable'));
    open.onsuccess = async () => {
        const db = open.result;
        try {
            const existing = await new Promise((done, fail) => {
                const read = db.transaction('keys').objectStore('keys').get('accounts');
                read.onsuccess = () => done(read.result); read.onerror = fail;
            });
            if (existing) { resolve(existing); return; }
            const key = await crypto.subtle.generateKey({name:'AES-GCM',length:256}, false, ['encrypt','decrypt']);
            await new Promise((done, fail) => {
                const transaction = db.transaction('keys','readwrite');
                transaction.objectStore('keys').put(key,'accounts');
                transaction.oncomplete = done; transaction.onerror = fail;
            });
            resolve(key);
        } catch (_) { reject(new Error('Browser vault unavailable')); }
        finally { db.close(); }
    };
});
const encode = bytes => btoa(String.fromCharCode(...bytes));
const decode = text => Uint8Array.from(atob(text), character => character.charCodeAt(0));
export async function saveAccount(key, value) {
    if (!value) { await api.storage.local.remove(key); return; }
    const bytes = new TextEncoder().encode(JSON.stringify(value));
    if (bytes.length > 96 * 1024) throw new Error('Account record exceeds vault limit');
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv,
        additionalData:new TextEncoder().encode(key)}, await keyReady, bytes));
    // Encode in chunks to avoid engine argument limits for large ID tokens.
    let binary = ''; for (let offset=0; offset<encrypted.length; offset+=8192)
        binary += String.fromCharCode(...encrypted.subarray(offset,offset+8192));
    await api.storage.local.set({[key]:{version:1,iv:encode(iv),encrypted:btoa(binary)}});
}
export async function loadAccount(key) {
    const record = (await api.storage.local.get(key))[key];
    if (!record) return null;
    if (record.version !== 1 || typeof record.encrypted !== 'string' || record.encrypted.length > 132 * 1024)
        throw new Error('Invalid encrypted account record');
    try {
        const bytes = await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(record.iv),
            additionalData:new TextEncoder().encode(key)}, await keyReady, decode(record.encrypted));
        return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
    } catch (_) { throw new Error('Browser vault integrity check failed'); }
}
