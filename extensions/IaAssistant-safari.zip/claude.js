// Experimental browser probe of the wire flow already in ClaudeAccountAgent.cpp.
// This is not an official third-party Claude sign-in integration.
export const claudeProduction = Object.freeze({
    authorize: 'https://claude.com/cai/oauth/authorize',
    token: 'https://platform.claude.com/v1/oauth/token',
    revoke: 'https://platform.claude.com/v1/oauth/token/revoke',
    profile: 'https://api.anthropic.com/api/oauth/profile',
    models: 'https://api.anthropic.com/v1/models',
    messages: 'https://api.anthropic.com/v1/messages',
    callback: 'https://platform.claude.com/oauth/code/callback',
    // The same legacy public registration as the existing experimental C++ agent.
    // Availability depends on Anthropic; do not present this as our registration.
    clientId: '9d1c250a-e61b-44d9-88ed-5944d1962f5e'
});
const scope = 'user:profile user:inference';
const credential = value => typeof value === 'string' && /^[\x21-\x7e]{1,32768}$/.test(value);
function httpError(operation, response) {
    return Object.assign(new Error('Claude ' + operation +
        (response.status === 429 ? ' rate limited' : ' rejected') + ' (HTTP ' + response.status + ')'),
        {httpStatus: response.status, retryAfterSeconds: response.retryAfterSeconds});
}

export async function claudeLogin(ep, random, base64url) {
    const verifier = random(), state = random();
    const challenge = base64url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))));
    const url = new URL(ep.authorize);
    url.search = new URLSearchParams({code: 'true', client_id: ep.clientId, response_type: 'code',
        redirect_uri: ep.callback, scope, code_challenge: challenge, code_challenge_method: 'S256', state}).toString();
    return {authorization: url.href, verifier, state, callback: ep.callback};
}

function acceptTokens(tokens, previous) {
    const refresh = tokens?.refresh_token ?? previous?.refresh_token ?? '';
    const scopes = tokens?.scope ?? previous?.scope;
    if (!credential(tokens?.access_token) || (refresh && !credential(refresh)) ||
        (tokens.token_type && tokens.token_type.toLowerCase() !== 'bearer') ||
        typeof tokens.expires_in !== 'number' || !Number.isFinite(tokens.expires_in) ||
        tokens.expires_in < 1 || tokens.expires_in > 366 * 86400 ||
        typeof scopes !== 'string' || !scopes.split(' ').includes('user:inference'))
        throw new Error('Claude returned an invalid subscription session');
    return {...tokens, refresh_token: refresh, scope: scopes, expiresAt: Date.now() + tokens.expires_in * 1000};
}
export function claudeHeaders(tokens) {
    return {Accept: 'application/json', Authorization: 'Bearer ' + tokens.access_token,
        'anthropic-version': '2023-06-01', 'anthropic-beta': 'oauth-2025-04-20',
        'anthropic-dangerous-direct-browser-access': 'true'};
}
async function profile(ep, tokens, fetchBounded) {
    const response = await fetchBounded(ep.profile, {headers: claudeHeaders(tokens)});
    if (!response.ok || typeof response.json?.account?.uuid !== 'string' || !response.json.account.uuid ||
        typeof response.json?.organization?.uuid !== 'string' || !response.json.organization.uuid)
        throw httpError('profile', response);
    const plan = response.json.organization.organization_type;
    return {subject: response.json.account.uuid, organization: response.json.organization.uuid,
        planType: typeof plan === 'string' ? plan.replace(/^claude_/, '') : 'unknown'};
}
export async function exchangeClaude(pending, code, fetchBounded) {
    const response = await fetchBounded(pending.ep.token, {method: 'POST',
        headers: {'Content-Type': 'application/json', Accept: 'application/json'},
        body: JSON.stringify({grant_type: 'authorization_code', code, state: pending.state,
            client_id: pending.ep.clientId, code_verifier: pending.verifier, redirect_uri: pending.callback})});
    if (!response.ok || !response.json) throw httpError('token exchange', response);
    const tokens = acceptTokens(response.json);
    return {tokens, client: pending.ep.clientId, ...(await profile(pending.ep, tokens, fetchBounded))};
}
export async function renewClaude(ep, account, fetchBounded) {
    if (!credential(account.tokens.refresh_token)) throw new Error('Claude session cannot be renewed');
    const response = await fetchBounded(ep.token, {method: 'POST',
        headers: {'Content-Type': 'application/json', Accept: 'application/json'},
        body: JSON.stringify({grant_type: 'refresh_token', refresh_token: account.tokens.refresh_token,
            client_id: account.client, scope: account.tokens.scope})});
    if (!response.ok || !response.json) throw httpError('renewal', response);
    const tokens = acceptTokens(response.json, account.tokens);
    const identity = await profile(ep, tokens, fetchBounded);
    if (identity.subject !== account.subject || identity.organization !== account.organization)
        throw new Error('Claude account changed during renewal');
    return {...account, tokens, ...identity};
}
export async function revokeClaude(ep, account, fetchBounded) {
    if (!account?.tokens.refresh_token) return {remoteRevoked: false};
    const response = await fetchBounded(ep.revoke, {method: 'POST',
        headers: {'Content-Type': 'application/json', Accept: 'application/json'},
        body: JSON.stringify({token: account.tokens.refresh_token, token_type_hint: 'refresh_token', client_id: account.client})});
    return {remoteRevoked: response.ok}; // A successful 204 intentionally has no JSON.
}
export async function claudeModels(ep, account, fetchBounded) {
    const response = await fetchBounded(ep.models, {headers: claudeHeaders(account.tokens)});
    if (!response.ok || !Array.isArray(response.json?.data))
        throw httpError('catalogue', response);
    return {status: response.status, count: response.json.data.length};
}
// Preserve the working native generation protocol, including its own attribution
// in the JSON body. This diagnostic never copies the official CLI/SDK identity.
export function claudeGenerationBody(model, instructions = '') {
    if (typeof model !== 'string' || !/^[A-Za-z0-9._:-]{1,256}$/.test(model) ||
        typeof instructions !== 'string' || instructions.length > 8192) throw new Error('Invalid marker configuration');
    const system = [{type: 'text',
        text: 'x-anthropic-billing-header: cc_version=0.1.0; cc_entrypoint=iaassistant;'}];
    if (instructions) system.push({type: 'text', text: instructions});
    return {model, max_tokens: 64, stream: true, system,
        messages: [{role: 'user', content: [{type: 'text', text: 'Reply with exactly CLAUDE_EXTENSION_OK.'}]}]};
}
export async function claudeMarker(ep, account, model, instructions, identityReady) {
    const body = claudeGenerationBody(model, instructions);
    await identityReady;
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 60000);
    let reader;
    try {
        const response = await fetch(ep.messages, {method: 'POST', credentials: 'omit', cache: 'no-store',
            redirect: 'error', signal: controller.signal,
            headers: {...claudeHeaders(account.tokens), 'Content-Type': 'application/json', Accept: 'text/event-stream'},
            body: JSON.stringify(body)});
        if (!response.ok) {
            const retry = response.headers.get('retry-after');
            throw httpError('generation', {status: response.status,
                retryAfterSeconds: retry && /^\d{1,8}$/.test(retry) ? Number(retry) : null});
        }
        if (!response.headers.get('content-type')?.startsWith('text/event-stream') || !response.body)
            throw new Error('Claude marker response is not an event stream');
        reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8', {fatal: true});
        let buffer = '', text = '', terminal = false, started = false, received = 0, chunks = 0;
        const event = block => {
            const lines = block.split('\n').map(line => line.endsWith('\r') ? line.slice(0, -1) : line);
            const data = lines.filter(line => line.startsWith('data:')).map(line => line.slice(5).replace(/^ /, '')).join('\n');
            if (!data) return;
            let value;
            try { value = JSON.parse(data); } catch (_) { throw new Error('Malformed Claude marker event'); }
            if (terminal || value.type === 'error') throw new Error('Claude marker stream failed');
            if (value.type === 'message_start') started = true;
            if (value.type === 'content_block_delta' && value.delta?.type === 'text_delta') {
                if (typeof value.delta.text !== 'string') throw new Error('Invalid Claude text delta');
                text += value.delta.text;
                if (text.length > 8192) throw new Error('Claude marker text exceeded the limit');
            }
            if (value.type === 'message_stop') terminal = true;
        };
        const drain = () => {
            for (;;) {
                const delimiter = /\r?\n\r?\n/.exec(buffer);
                if (!delimiter) break;
                const block = buffer.slice(0, delimiter.index);
                buffer = buffer.slice(delimiter.index + delimiter[0].length);
                event(block);
            }
        };
        for (;;) {
            const {value, done} = await reader.read();
            if (done) break;
            received += value.byteLength; ++chunks;
            if (received > 256 * 1024) throw new Error('Claude marker stream exceeded the limit');
            buffer += decoder.decode(value, {stream: true});
            drain();
        }
        buffer += decoder.decode(); drain();
        if (buffer.trim() || !started || !terminal) throw new Error('Claude marker stream did not finish');
        return {status: response.status, markerReceived: text.trim() === 'CLAUDE_EXTENSION_OK',
            streamComplete: true, maxOutputTokens: 64, modelRequests: 1, chunks};
    } finally {
        clearTimeout(timeout); controller.abort();
        if (reader) await reader.cancel().catch(() => {});
    }
}
export function claudeManual(value, pending) {
    if (typeof value !== 'string' || value.length > 4225) throw new Error('Invalid Claude callback');
    const parts = value.trim().split('#');
    if (parts.length !== 2 || !credential(parts[0]) || parts[0].length > 4096 || parts[1] !== pending.state)
        throw new Error('Claude callback does not match the active login');
    return parts[0];
}
