const api = globalThis.browser || chrome;
// Copyright (c) 2026 Ariya Consulting. SPDX-License-Identifier: LicenseRef-IaAssistant-Commercial
// Feasibility probe only. Real tokens stay in trusted extension session storage:
// No OS vault or persistent token store is implemented. Real model generation
// requires an explicit marker-test action and is limited to one 64-token request.
// Claude renewal/revocation are tested separately from ChatGPT sign-in.
import {claudeProduction, claudeLogin, exchangeClaude, renewClaude, revokeClaude,
    claudeModels, claudeManual, claudeMarker} from './claude.js';
const production = Object.freeze({
    issuer: 'https://auth.openai.com',
    authorize: 'https://auth.openai.com/api/accounts/authorize',
    token: 'https://auth.openai.com/api/accounts/oauth/token',
    jwks: 'https://auth.openai.com/.well-known/jwks.json',
    models: 'https://api.openai.com/v1/models',
    callback: 'http://127.0.0.1:1455/auth/callback'
});
const scope = 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct';
const encoder = new TextEncoder();
let capturing = false;
let beginning = false;
let generating = false;
// Match the native transport's own identity. Chromium drops User-Agent set
// through fetch() and adds the extension Origin to POST requests. Host-authorized
// background requests do not need page CORS; keep Origin off this transport.
// Browser pages, sign-in navigation, and other providers are outside the rule.
const requestIdentityReady = api.declarativeNetRequest?.updateSessionRules ? api.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [1001],
    addRules: [{id: 1001, priority: 1,
        action: {type: 'modifyHeaders', requestHeaders: [
            {header: 'user-agent', operation: 'set', value: 'IaAssistant/0.1'},
            {header: 'origin', operation: 'remove'}]},
        condition: {regexFilter: '^https://(platform\\.claude\\.com/v1/oauth/token(/revoke)?|api\\.anthropic\\.com/(api/oauth/(profile|usage)|v1/(models|messages)))$',
            initiatorDomains: [new URL(api.runtime.getURL('')).hostname], requestMethods: ['get', 'post'], resourceTypes: ['xmlhttprequest']}}]
}) : Promise.resolve();
const storageReady = Promise.all([
    api.storage.local.setAccessLevel?.({accessLevel: 'TRUSTED_CONTEXTS'}),
    api.storage.session.setAccessLevel?.({accessLevel: 'TRUSTED_CONTEXTS'}),
    requestIdentityReady
]);
const base64url = bytes => btoa(String.fromCharCode(...bytes))
    .replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
const random = () => base64url(crypto.getRandomValues(new Uint8Array(32)));
const decode = value => Uint8Array.from(atob(value.replaceAll('-', '+').replaceAll('_', '/')), c => c.charCodeAt(0));
const object = value => {
    try { return JSON.parse(new TextDecoder().decode(decode(value))); }
    catch (_) { throw new Error('Malformed identity token'); }
};
const providerId = value => {
    if (!value) return 'chatgpt';
    if (!['chatgpt', 'claude'].includes(value)) throw new Error('Unknown provider');
    return value;
};
const applicationId = value => {
    if (typeof value !== 'string' || !value || value.length > 128 || value !== value.trim() || /[\x00-\x1f\x7f]/.test(value)) throw new Error('Invalid application identity');
    return value;
};
const resultKey = (app, provider = 'chatgpt') => 'result:' + provider + ':' + app;
const accountKey = (app, provider = 'chatgpt') => 'account:' + provider + ':' + app;

async function endpoints(provider = 'chatgpt') {
    const key = provider === 'claude' ? 'claudeFixture' : 'fixture';
    return (await api.storage.session.get(key))[key] || (provider === 'claude' ? claudeProduction : production);
}
async function setResult(app, value, provider = 'chatgpt') {
    await api.storage.session.set({[resultKey(app, provider)]: {...value, updatedAt: Date.now()}});
}
async function fetchBounded(url, options = {}, maxBytes = 256 * 1024) {
    await storageReady;
    const response = await fetch(url, {credentials: 'omit', cache: 'no-store', redirect: 'error',
        signal: AbortSignal.timeout(20000), ...options});
    const chunks=[];let total=0;
    if(response.body){
        const reader=response.body.getReader();
        try{
            for(;;){
                const {value,done}=await reader.read();if(done)break;
                total+=value.length;
                if(total>maxBytes){
                    await reader.cancel().catch(()=>{});
                    throw Object.assign(new Error('Response exceeded limit'),{code:'response_too_large'});
                }
                chunks.push(value);
            }
        }finally{reader.releaseLock();}
    }
    const bytes=new Uint8Array(total);let offset=0;
    for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
    const text=new TextDecoder().decode(bytes);
    let json = null;
    try { json = JSON.parse(text); } catch (_) { /* e.g. an access-denied HTML page */ }
    const retry = response.headers.get('retry-after');
    return {status: response.status, ok: response.ok, json,
        retryAfterSeconds: retry && /^\d{1,8}$/.test(retry) ? Number(retry) : null};
}
function failedResult(error) {
    const result = {phase: 'failed', error: error.message};
    if (Number.isInteger(error.httpStatus) && error.httpStatus >= 100 && error.httpStatus <= 599) {
        result.httpStatus = error.httpStatus;
        result.rateLimited = error.httpStatus === 429;
        result.retryAfterSeconds = Number.isFinite(error.retryAfterSeconds) ? error.retryAfterSeconds : null;
    }
    return result;
}
async function publicNetwork(provider = 'chatgpt') {
    const ep = await endpoints(provider);
    const rows = [];
    const requests = provider === 'claude' ? [['models_without_credentials', ep.models]] :
        [['discovery', ep.issuer + '/.well-known/openid-configuration'],
        ['jwks', ep.jwks], ['models_without_credentials', ep.models]];
    for (const [name, url] of requests) {
        try {
            const value = await fetchBounded(url);
            rows.push({name, status: value.status, json: value.json !== null,
                issuerMatches: name === 'discovery' ? value.json?.issuer === ep.issuer : undefined,
                keyCount: name === 'jwks' ? value.json?.keys?.length : undefined});
        } catch (_) { rows.push({name, error: 'Network request failed'}); }
    }
    return rows;
}
async function begin(app, callbackKind, provider = 'chatgpt') {
    await storageReady;
    applicationId(app);
    if (beginning) throw new Error('A sign-in is already starting');
    beginning = true;
    try {
        return await beginExclusive(app, callbackKind, provider);
    } finally { beginning = false; }
}
async function beginExclusive(app, callbackKind, provider) {
    if (capturing || (await api.storage.session.get('pending')).pending) throw new Error('A sign-in is already pending');
    const ep = await endpoints(provider);
    if (provider === 'claude') {
        const login = await claudeLogin(ep, random, base64url);
        const tab = await api.tabs.create({url: 'about:blank', active: true});
        const {authorization, ...parameters} = login;
        const pending = {app, provider, ...parameters, attempt: random(), createdAt: Date.now(), tabId: tab.id, ep};
        await api.storage.session.set({pending, activeAttempt: pending.attempt});
        await setResult(app, {phase: 'waiting', callbackKind: 'claude-hosted-or-manual'}, provider);
        await api.tabs.update(tab.id, {url: authorization});
        return {phase: 'waiting', tabId: tab.id};
    }
    let hostId = (await api.storage.local.get('hostId')).hostId;
    if (!hostId) {
        hostId = 'urn:uuid:' + crypto.randomUUID();
        await api.storage.local.set({hostId});
    }
    const verifier = random();
    const challenge = base64url(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(verifier))));
    // The extension redirect is a compatibility probe, not a documented SIWC redirect.
    const callback = callbackKind === 'extension'
        ? 'https://' + api.runtime.id + '.chromiumapp.org/auth/callback' : ep.callback;
    const pending = {app, provider, attempt: random(), state: random(), nonce: random(), verifier, callback,
        createdAt: Date.now(), tabId: -1, ep};
    const auth = new URL(ep.authorize);
    auth.search = new URLSearchParams({client_id: 'dynamic_agent_client', agent_name_hint: app,
        ext_agent_host_id: hostId, response_type: 'code', redirect_uri: callback,
        scope, resource: 'https://api.openai.com/v1', state: pending.state,
        nonce: pending.nonce, code_challenge_method: 'S256', code_challenge: challenge}).toString();
    const tab = await api.tabs.create({url: 'about:blank', active: true});
    pending.tabId = tab.id;
    await api.storage.session.set({pending, activeAttempt: pending.attempt});
    await setResult(app, {phase: 'waiting', callbackKind: callbackKind || 'loopback'});
    await api.tabs.update(tab.id, {url: auth.href});
    return {phase: 'waiting', tabId: tab.id};
}
async function validateIdToken(token, keys, pending, client) {
    if (typeof token !== 'string' || token.length > 65536) throw new Error('Missing identity token');
    const parts = token.split('.');
    if (parts.length !== 3) throw new Error('Malformed identity token');
    const header = object(parts[0]), claims = object(parts[1]);
    if (header.alg !== 'RS256' || typeof header.kid !== 'string') throw new Error('Unexpected identity signature');
    const jwk = keys.keys?.find(key => key.kid === header.kid && key.kty === 'RSA' &&
        (!key.alg || key.alg === 'RS256') && (!key.use || key.use === 'sig'));
    if (!jwk) throw new Error('Identity signing key is missing');
    const key = await crypto.subtle.importKey('jwk', jwk,
        {name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256'}, false, ['verify']);
    if (!await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, decode(parts[2]), encoder.encode(parts[0] + '.' + parts[1])))
        throw new Error('Identity signature rejected');
    const audience = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
    if (claims.iss !== pending.ep.issuer || !audience.includes(client) ||
        (pending.nonce !== undefined && claims.nonce !== pending.nonce) || typeof claims.sub !== 'string' || !claims.sub ||
        typeof claims.exp !== 'number' || claims.exp <= Date.now() / 1000)
        throw new Error('Identity claims rejected');
    return claims;
}
async function capture(details) {
    await storageReady;
    if (capturing) return;
    const pending = (await api.storage.session.get('pending')).pending;
    if (!pending || details.tabId !== pending.tabId) return;
    const url = new URL(details.url), expected = new URL(pending.callback);
    if (url.origin !== expected.origin || url.pathname !== expected.pathname || url.hash ||
        url.username || url.password || url.searchParams.getAll('state').length !== 1 ||
        url.searchParams.get('state') !== pending.state) return;
    capturing = true;
    try {
        await api.storage.session.set({exchangePending: pending});
        await api.storage.session.remove('pending'); // One-time consumption before any exchange.
        await api.tabs.update(pending.tabId, {url: api.runtime.getURL('probe.html')});
        if (Date.now() - pending.createdAt > 10 * 60 * 1000) throw new Error('Sign-in expired');
        if (url.searchParams.has('error')) throw new Error('Authorization was declined');
        if (pending.provider === 'claude') {
            const codes = url.searchParams.getAll('code');
            if (codes.length !== 1 || !/^[\x21-\x7e]{1,4096}$/.test(codes[0])) throw new Error('Invalid Claude callback');
            await finishClaude(pending, codes[0]);
            return;
        }
        const client = url.searchParams.get('client_id'), code = url.searchParams.get('code');
        if (!client || client === 'dynamic_agent_client' || !/^[a-zA-Z0-9_-]{1,512}$/.test(client) ||
            !code || code.length > 16384 || url.searchParams.getAll('code').length !== 1 ||
            url.searchParams.getAll('client_id').length !== 1) throw new Error('Invalid callback');
        await setResult(pending.app, {phase: 'exchanging'});
        const exchange = await fetchBounded(pending.ep.token, {method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json'},
            body: new URLSearchParams({grant_type: 'authorization_code', client_id: client, code,
                code_verifier: pending.verifier, redirect_uri: pending.callback,
                resource: 'https://api.openai.com/v1'}).toString()});
        if (!exchange.ok || !exchange.json) throw new Error('Token exchange rejected (HTTP ' + exchange.status + ')');
        const tokens = exchange.json;
        if (!Number.isFinite(tokens.expires_in) || tokens.expires_in < 1 || tokens.expires_in > 366 * 86400)
            throw new Error('Invalid ChatGPT session expiry');
        tokens.expiresAt = Date.now() + tokens.expires_in * 1000;
        if (!tokens.scope?.split(' ').includes('chatgpt.tokens.use.direct')) throw new Error('ChatGPT plan permission missing');
        if (tokens.token_type?.toLowerCase() !== 'bearer' || typeof tokens.access_token !== 'string' || !tokens.access_token)
            throw new Error('Access credentials missing');
        const jwks = await fetchBounded(pending.ep.jwks);
        if (!jwks.ok || !jwks.json) throw new Error('Signing-key request failed');
        const claims = await validateIdToken(tokens.id_token, jwks.json, pending, client);
        // Never return bearer/refresh/ID tokens to the website, console, or report.
        if ((await api.storage.session.get('activeAttempt')).activeAttempt !== pending.attempt) return;
        await api.storage.session.set({[accountKey(pending.app)]: {tokens, client, subject: claims.sub}});
        await setResult(pending.app, {phase: 'authenticated', identityVerified: true,
            planPermission: true, renewable: typeof tokens.refresh_token === 'string' && !!tokens.refresh_token});
    } catch (error) {
        if ((await api.storage.session.get('activeAttempt')).activeAttempt === pending.attempt)
            await setResult(pending.app, failedResult(error), pending.provider);
    } finally {
        if ((await api.storage.session.get('activeAttempt')).activeAttempt === pending.attempt)
            await api.storage.session.remove('activeAttempt');
        if ((await api.storage.session.get('exchangePending')).exchangePending?.attempt === pending.attempt)
            await api.storage.session.remove('exchangePending');
        capturing = false;
    }
}
async function finishClaude(pending, code) {
    await setResult(pending.app, {phase: 'exchanging'}, 'claude');
    const account = await exchangeClaude(pending, code, fetchBounded);
    if ((await api.storage.session.get('activeAttempt')).activeAttempt !== pending.attempt) return;
    await api.storage.session.set({[accountKey(pending.app, 'claude')]: account});
    await setResult(pending.app, {phase: 'authenticated', profileVerified: true, planPermission: true,
        planType: account.planType, renewable: !!account.tokens.refresh_token}, 'claude');
}
async function completeClaude(app, value) {
    if (capturing) throw new Error('An exchange is already running');
    const pending = (await api.storage.session.get('pending')).pending;
    if (!pending || pending.provider !== 'claude' || pending.app !== app ||
        Date.now() - pending.createdAt > 10 * 60 * 1000) throw new Error('No active Claude login');
    const code = claudeManual(value, pending);
    capturing = true;
    try {
        await api.storage.session.set({exchangePending: pending});
        await api.storage.session.remove('pending');
        await api.tabs.update(pending.tabId, {url: api.runtime.getURL('probe.html')});
        await finishClaude(pending, code);
    } catch (error) {
        if ((await api.storage.session.get('activeAttempt')).activeAttempt === pending.attempt)
            await setResult(app, failedResult(error), 'claude');
    } finally {
        if ((await api.storage.session.get('activeAttempt')).activeAttempt === pending.attempt)
            await api.storage.session.remove('activeAttempt');
        if ((await api.storage.session.get('exchangePending')).exchangePending?.attempt === pending.attempt)
            await api.storage.session.remove('exchangePending');
        capturing = false;
    }
    return status(app, 'claude');
}
api.webRequest.onBeforeRequest.addListener(details => {
    void capture(details).catch(() => {});
}, {urls: ['http://127.0.0.1/*', 'https://*.chromiumapp.org/*',
    'https://platform.claude.com/oauth/code/callback*'], types: ['main_frame']});
api.tabs.onRemoved.addListener(tabId => {
    void (async () => {
        const values = await api.storage.session.get(['pending', 'exchangePending']);
        const pending = values.pending || values.exchangePending;
        if (pending?.tabId !== tabId) return;
        await api.storage.session.remove(['pending', 'exchangePending', 'activeAttempt']);
        await setResult(pending.app, {phase: 'cancelled'}, pending.provider);
    })();
});
async function status(app, provider = 'chatgpt') {
    await storageReady;
    applicationId(app);
    const values = await api.storage.session.get([resultKey(app, provider), accountKey(app, provider)]);
    return {application: app, provider, authenticated: !!values[accountKey(app, provider)], result: values[resultKey(app, provider)] || null};
}
async function internal(message) {
    const provider = providerId(message.provider);
    switch (message.type) {
    case 'network': return publicNetwork(provider);
    case 'begin': return begin(message.application, message.callbackKind, provider);
    case 'status': return status(message.application, provider);
    case 'complete':
        if (provider !== 'claude') throw new Error('Manual callback is only available for Claude');
        return completeClaude(applicationId(message.application), message.code);
    case 'models': case 'renew': case 'logout': case 'marker': {
        if (provider !== 'claude') throw new Error('Operation not implemented for this provider');
        const app = applicationId(message.application), key = accountKey(app, provider);
        const account = (await api.storage.session.get(key))[key], ep = await endpoints(provider);
        if (message.type === 'logout') {
            await api.storage.session.remove(key);
            await setResult(app, {phase: 'signed_out'}, provider);
            return revokeClaude(ep, account, fetchBounded);
        }
        if (!account) throw new Error('Claude is not signed in');
        if (message.type === 'models') return claudeModels(ep, account, fetchBounded);
        if (message.type === 'marker') {
            if (generating) throw new Error('A marker request is already running');
            generating = true;
            try {
                return await claudeMarker(ep, account, message.model, message.instructions || '', requestIdentityReady);
            } finally { generating = false; }
        }
        const renewed = await renewClaude(ep, account, fetchBounded);
        if ((await api.storage.session.get(key))[key]?.tokens.access_token !== account.tokens.access_token)
            throw new Error('Claude session changed during renewal');
        await api.storage.session.set({[key]: renewed});
        await setResult(app, {phase: 'authenticated', profileVerified: true, planPermission: true,
            planType: renewed.planType, renewable: !!renewed.tokens.refresh_token}, provider);
        return status(app, provider);
    }
    case 'cancel': {
        const values = await api.storage.session.get(['pending', 'exchangePending']);
        const pending = values.pending || values.exchangePending;
        if (message.application !== undefined && (!pending || pending.app !== applicationId(message.application) ||
            pending.provider !== provider || (message.tabId !== undefined && pending.tabId !== message.tabId))) return {cancelled: false};
        await api.storage.session.remove(['pending', 'exchangePending', 'activeAttempt']);
        if (pending) {
            await setResult(pending.app, {phase: 'cancelled'}, pending.provider);
            await api.tabs.remove(pending.tabId).catch(() => {});
        }
        return {cancelled: true};
    }
    case 'reset':
        await internal({type: 'cancel'});
        await api.storage.session.clear();
        return {reset: true};
    default: throw new Error('Unknown probe operation');
    }
}
api.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== api.runtime.id || typeof message.type !== 'string') return false;
    internal(message).then(value => respond({ok: true, value}), () => respond({ok: false, error: 'Probe operation failed'}));
    return true;
});
api.runtime.onMessageExternal.addListener((message, sender, respond) => {
    void (async () => {
        // Fixture websites only. Derive identity from a trusted URL mapping;
        // never accept the website's claimed application or expose secret records.
        const apps = (await api.storage.session.get('fixtureApps')).fixtureApps || {};
        const url = new URL(sender.url);
        const app = apps[url.origin + url.pathname];
        if (!app || message.type !== 'status') throw new Error('Website is not paired');
        if (message.application && message.application !== app) throw new Error('Application mismatch');
        respond({ok: true, value: await status(app, providerId(message.provider))});
    })().catch(() => respond({ok: false, error: 'Website is not paired'}));
    return true;
});
// The shipped browser broker reuses this OAuth implementation. Credentials are
// accessible only to trusted extension modules, never through the page bridge.
export {internal as oauthOperation, accountKey, fetchBounded, storageReady, production,
    validateIdToken, endpoints};
