import {oauthOperation,accountKey,fetchBounded,storageReady,production,validateIdToken,endpoints} from './oauth.js';
import {saveAccount,loadAccount} from './vault.js';
import {claudeHeaders} from './claude.js';
const api = globalThis.browser || chrome;
const operations = new Map(), approvals = new Map(), renewals = new Map(), writes = new Map();
async function persist(key,value) {
    const task=(writes.get(key) || Promise.resolve()).catch(()=>{}).then(async()=>{
        if(value && (await api.storage.session.get(key))[key]?.tokens.access_token!==value.tokens.access_token)
            throw new Error('Session changed before persistence');
        await saveAccount(key,value);
    });
    writes.set(key,task);
    try{await task;}finally{if(writes.get(key)===task)writes.delete(key);}
}
const delay = milliseconds => new Promise(resolve => setTimeout(resolve,milliseconds));
const publicFailure = message => Object.assign(new Error(message),{publicMessage:message});
function loginFailure(provider,result) {
    const name=provider==='claude'?'Claude':'ChatGPT';
    const details={
        'ChatGPT plan permission missing':'Le compte ChatGPT n’autorise pas l’accès direct aux modèles pour cet assistant.',
        'Signing-key request failed':'ChatGPT : impossible de récupérer les clés de vérification de la connexion.',
        'Identity signature rejected':'ChatGPT : la signature de la connexion n’a pas pu être vérifiée.',
        'Identity claims rejected':'ChatGPT : les informations de la connexion ne correspondent pas à la demande.',
        'Authorization was declined':name+' : la connexion a été refusée.',
        'Sign-in expired':name+' : la demande de connexion a expiré. Réessayez.',
        'Invalid callback':name+' : le retour de connexion reçu est invalide.',
        'Failed to fetch':name+' : impossible de joindre le service de connexion. Vérifiez le réseau et réessayez.'
    };
    if (result?.phase==='cancelled') return publicFailure(name+' : connexion annulée.');
    if (details[result?.error]) return publicFailure(details[result.error]);
    const status=result?.httpStatus || /^Token exchange rejected \(HTTP (\d{3})\)$/.exec(result?.error || '')?.[1];
    if (status && Number(status)>=100 && Number(status)<=599)
        return publicFailure(name+' : la connexion a été refusée par le service (HTTP '+Number(status)+').');
    return publicFailure(name+' : la connexion n’a pas pu être vérifiée. Réessayez de vous connecter.');
}
const identity = value => typeof value === 'string' && value.length > 0 && value.length <= 128 &&
    value === value.trim() && !/[\x00-\x1f\x7f]/.test(value);
function pageIdentity(sender) {
    const url = new URL(sender.url);
    if (!['https:','http:'].includes(url.protocol) || sender.frameId !== 0 || !sender.tab) throw new Error('Unsupported page');
    return url.origin + url.pathname;
}
async function paired(sender, application) {
    if (!identity(application)) throw new Error('Invalid application');
    const key = pageIdentity(sender), pairs = (await api.storage.local.get('pairs')).pairs || {};
    return pairs[key] === application;
}
async function authorize(sender, application, owner, signal) {
    if (await paired(sender,application)) return;
    if (signal.aborted) throw new Error('Application pairing cancelled');
    const ticket = crypto.randomUUID();
    const url = pageIdentity(sender);
    const completion = new Promise((resolve,reject) => approvals.set(ticket,
        {application,url,owner,resolve,reject,createdAt:Date.now(),tabId:-1}));
    // Cancellation may arrive while tabs.create is still pending.
    void completion.catch(()=>{});
    const cancelled = () => rejectApproval(ticket);
    signal.addEventListener('abort',cancelled,{once:true});
    const timeout = setTimeout(() => rejectApproval(ticket), 300000);
    let tab;
    try {
        tab = await api.tabs.create({url:api.runtime.getURL('pair.html')+'#ticket='+ticket,active:true});
        const approval = approvals.get(ticket); if (approval) approval.tabId = tab.id;
        if (signal.aborted) cancelled();
        await completion;
    } finally {
        clearTimeout(timeout); signal.removeEventListener('abort',cancelled); approvals.delete(ticket);
        if (tab) await api.tabs.remove(tab.id).catch(()=>{});
    }
}
function rejectApproval(ticket) {
    const approval = approvals.get(ticket);
    if (approval) { approvals.delete(ticket); approval.reject(new Error('Application pairing cancelled')); }
}
api.runtime.onMessage.addListener((message,sender,respond) => {
    if (!message.browserPair || sender.id !== api.runtime.id || !sender.url?.startsWith(api.runtime.getURL('pair.html'))) return false;
    (async () => {
        const value = approvals.get(message.ticket);
        if (!value || sender.tab?.id !== value.tabId || Date.now()-value.createdAt > 300000) throw new Error();
        if (message.browserPair === 'read') return {application:value.application,url:value.url};
        if (message.browserPair === 'approve') {
            const pairs = (await api.storage.local.get('pairs')).pairs || {};
            pairs[value.url] = value.application; await api.storage.local.set({pairs});
            approvals.delete(message.ticket); value.resolve(); return {approved:true};
        }
        rejectApproval(message.ticket); return {approved:false};
    })().then(value => respond({ok:true,value}), () => respond({ok:false}));
    return true;
});
api.tabs.onRemoved.addListener(id => { for (const [ticket,value] of approvals) if (value.tabId === id) rejectApproval(ticket); });
async function account(application,provider) {
    await storageReady;
    const key = accountKey(application,provider);
    let value = (await api.storage.session.get(key))[key];
    if (!value) { value = await loadAccount(key); if (value) await api.storage.session.set({[key]:value}); }
    return value;
}
async function binding(application,provider,value) {
    if (!value) return '';
    const bytes = await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(
        [application,provider,value.subject,value.organization || '',value.client])));
    return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2,'0')).join('');
}
async function publicAccount(application,provider,value) {
    const id = await binding(application,provider,value);
    return {authenticated:!!value,binding:id,planType:value?.planType || '',
        credential:value ? 'ia-browser.'+btoa(unescape(encodeURIComponent(JSON.stringify({application,provider,binding:id})))) : ''};
}
async function renew(application,provider) {
    const key = accountKey(application,provider);
    if (renewals.has(key)) return renewals.get(key);
    const operation = (async () => {
        const previous = await account(application,provider); if (!previous) throw new Error('Sign-in required');
        if (provider === 'claude') await oauthOperation({type:'renew',application,provider});
        else {
            const ep = await endpoints(provider);
            const response = await fetchBounded(ep.token,{method:'POST',
                headers:{'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},
                body:new URLSearchParams({grant_type:'refresh_token',client_id:previous.client,
                    refresh_token:previous.tokens.refresh_token,resource:'https://api.openai.com/v1'}).toString()});
            const tokens = response.json;
            if (!response.ok || !tokens || typeof tokens.access_token !== 'string' || !/^[\x21-\x7e]{1,32768}$/.test(tokens.access_token) ||
                tokens.token_type?.toLowerCase() !== 'bearer' || !Number.isFinite(tokens.expires_in) ||
                tokens.expires_in < 10 || tokens.expires_in > 366*86400) throw new Error('ChatGPT renewal rejected');
            tokens.scope ??= previous.tokens.scope;
            tokens.refresh_token ??= previous.tokens.refresh_token;
            if (!tokens.scope?.split(' ').includes('chatgpt.tokens.use.direct') ||
                !/^[\x21-\x7e]{1,32768}$/.test(tokens.refresh_token)) throw new Error('Invalid renewable session');
            if (tokens.id_token) {
                const keys = await fetchBounded(ep.jwks);
                const claims = await validateIdToken(tokens.id_token,keys.json,
                    {ep,nonce:undefined},previous.client);
                if (claims.sub !== previous.subject) throw new Error('ChatGPT identity changed');
            }
            tokens.expiresAt = Date.now()+tokens.expires_in*1000;
            // A cancelled or replaced session cannot be overwritten by a late renewal.
            if ((await api.storage.session.get(key))[key]?.tokens.access_token !== previous.tokens.access_token)
                throw new Error('Session changed during renewal');
            await api.storage.session.set({[key]:{...previous,tokens}});
        }
        const value = (await api.storage.session.get(key))[key]; await persist(key,value); return value;
    })();
    renewals.set(key,operation);
    try { return await operation; } finally { renewals.delete(key); }
}
async function readyAccount(application,provider) {
    let value = await account(application,provider);
    if (value && (!Number.isFinite(value.tokens.expiresAt) || value.tokens.expiresAt <= Date.now()+60000))
        value = await renew(application,provider);
    return value;
}
const responseHeaders = response => Object.fromEntries(Array.from(response.headers).filter(([name]) =>
    ['content-type','retry-after','retry-after-ms','x-should-retry','request-id','x-request-id'].includes(name) || name.startsWith('anthropic-ratelimit-')));
async function http(message,port,operation) {
    const {application,provider,params} = message;
    let value = await readyAccount(application,provider);
    if (!value || await binding(application,provider,value) !== params.binding) throw new Error('Account changed; reconnect the assistant');
    const url = new URL(params.url), ep = await endpoints(provider);
    if (url.username || url.password || url.search || url.hash) throw new Error('Invalid account endpoint');
    const paths = provider === 'claude' ? {
        '/api/oauth/profile':ep.profile,'/api/oauth/usage':ep.usage || 'https://api.anthropic.com/api/oauth/usage',
        '/v1/models':ep.models,'/v1/messages':ep.messages} : {'/v1/models':ep.models,'/v1/responses':ep.responses || 'https://api.openai.com/v1/responses'};
    const expectedOrigin = provider === 'claude' ? 'https://api.anthropic.com' : 'https://api.openai.com';
    if (url.origin !== expectedOrigin || !paths[url.pathname]) throw new Error('Account endpoint is not allowed');
    const posting = url.pathname.endsWith('/messages') || url.pathname.endsWith('/responses');
    if (params.method !== (posting ? 'POST':'GET')) throw new Error('Invalid account method');
    if (posting && (!params.body || typeof params.body !== 'object' || JSON.stringify(params.body).length > 32*1024*1024))
        throw new Error('Invalid model request');
    const headers = provider === 'claude' ? claudeHeaders(value.tokens) : {Authorization:'Bearer '+value.tokens.access_token};
    headers.Accept=posting?'text/event-stream':'application/json';
    if (posting) headers['Content-Type']='application/json';
    const options = {method:params.method,headers,credentials:'omit',redirect:'error',cache:'no-store',signal:operation.controller.signal};
    if (posting) options.body = JSON.stringify(params.body);
    let response = await fetch(paths[url.pathname],options);
    // Do not replay generation. A 401 before a read can be renewed once safely.
    if (response.status === 401 && !posting) {
        value = await renew(application,provider);
        if (await binding(application,provider,value) !== params.binding) throw new Error('Account changed');
        headers.Authorization='Bearer '+value.tokens.access_token;
        response = await fetch(paths[url.pathname],options);
    }
    port.postMessage({id:message.id,type:'headers',status:response.status,headers:responseHeaders(response)});
    if (response.body) {
        const reader = response.body.getReader(); operation.reader = reader; let total = 0;
        for (;;) {
            const {value:bytes,done} = await reader.read(); if (done) break;
            total += bytes.length; if (total > 64*1024*1024) throw new Error('Response exceeded limit');
            for (let offset=0; offset<bytes.length; offset+=32768) {
                const chunk = bytes.subarray(offset,offset+32768);
                const acknowledgement = new Promise((resolve,reject) => { operation.ack=resolve; operation.rejectAck=reject; });
                port.postMessage({id:message.id,type:'bytes',data:btoa(String.fromCharCode(...chunk))});
                const timer = setTimeout(() => operation.rejectAck?.(new Error('Stream consumer stalled')),15000);
                try { await acknowledgement; } finally { clearTimeout(timer); operation.ack=null; operation.rejectAck=null; }
            }
        }
    }
    return {};
}
api.runtime.onConnect.addListener(port => {
    if (port.name !== 'iaassistant.v1') return;
    try { pageIdentity(port.sender); } catch (_) { port.disconnect(); return; }
    const owner = crypto.randomUUID(), active = new Map();
    port.postMessage({type:'ready',version:1,extensionVersion:api.runtime.getManifest().version});
    port.onMessage.addListener(message => {
        if (message?.type === 'ack') { active.get(message.id)?.ack?.(); return; }
        if (message?.type === 'cancel') { const item=active.get(message.id); item?.controller.abort(); item?.rejectAck?.(new Error('Cancelled')); return; }
        if (!message || typeof message.id !== 'string' || message.id.length > 64 || active.has(message.id) || active.size >= 16) return;
        const operation = {controller:new AbortController()}; active.set(message.id,operation);
        const timeout = setTimeout(() => { operation.controller.abort(); operation.rejectAck?.(new Error('Timed out')); }, message.operation==='login'?600000:120000);
        (async () => {
            if (!identity(message.application) || !['chatgpt','claude'].includes(message.provider)) throw new Error('Invalid account identity');
            const {application,provider} = message;
            if (message.operation === 'login') await authorize(port.sender,application,owner,operation.controller.signal);
            if (operation.controller.signal.aborted) throw new Error('Cancelled');
            if (!await paired(port.sender,application)) {
                if (message.operation === 'status') return {paired:false,authenticated:false};
                throw new Error('Application pairing required');
            }
            if (message.operation === 'status') return publicAccount(application,provider,await readyAccount(application,provider));
            if (message.operation === 'models') {
                const record=await readyAccount(application,provider),ep=await endpoints(provider);
                if (!record || await binding(application,provider,record)!==message.params?.binding) throw new Error('Account changed');
                const headers=provider==='claude'?claudeHeaders(record.tokens):{Accept:'application/json',Authorization:'Bearer '+record.tokens.access_token};
                let response;
                try{response=await fetchBounded(ep.models,{headers},2*1024*1024);}
                catch(error){
                    if(error.code==='response_too_large')throw publicFailure((provider==='claude'?'Claude':'ChatGPT')+
                        ' : le catalogue de modèles dépasse la taille maximale autorisée (2 Mio).');
                    throw error;
                }
                const source=response.json?.models || response.json?.data;
                if (!response.ok) throw publicFailure((provider==='claude'?'Claude':'ChatGPT')+
                    ' : impossible de récupérer les modèles (HTTP '+response.status+').');
                if (!Array.isArray(source)) throw publicFailure((provider==='claude'?'Claude':'ChatGPT')+
                    ' : le catalogue de modèles reçu est invalide.');
                const models=[];
                for (const item of source.slice(0,200)) {
                    const id=item.slug || item.id;
                    if (typeof id!=='string' || !id || id.length>200 || (item.visibility && item.visibility!=='list')) continue;
                    models.push({model:id,displayName:item.display_name || id,isDefault:models.length===0,
                        inputModalities:item.input_modalities || item.inputModalities || ['text'],
                        supportedReasoningEfforts:(item.supported_reasoning_levels || item.supported_reasoning_efforts || []).map(value=>
                            typeof value==='string'?{reasoningEffort:value}: {reasoningEffort:value.reasoningEffort || value.reasoning_effort || value.effort,description:value.description || ''})});
                }
                if (!models.length) throw new Error('No model available');
                return {models};
            }
            if (message.operation === 'login') {
                const attempt=await oauthOperation({type:'begin',application,provider});
                const login={application,provider,tabId:attempt.tabId}; operations.set(owner,login);
                try {
                    while (!operation.controller.signal.aborted) {
                        const value = await oauthOperation({type:'status',application,provider});
                        if (value.result?.phase === 'authenticated') {
                            const record = await account(application,provider);
                            await persist(accountKey(application,provider),record);
                            return publicAccount(application,provider,record);
                        }
                        if (['failed','cancelled'].includes(value.result?.phase)) throw loginFailure(provider,value.result);
                        await delay(200);
                    }
                    throw new Error('Account sign-in cancelled');
                } finally {
                    if (operations.get(owner)===login) operations.delete(owner);
                    if (operation.controller.signal.aborted) await oauthOperation({type:'cancel',...login});
                }
            }
            if (message.operation === 'cancelLogin') {
                if (operations.has(owner)) await oauthOperation({type:'cancel',...operations.get(owner)});
                return {};
            }
            if (message.operation === 'renew') return publicAccount(application,provider,await renew(application,provider));
            if (message.operation === 'logout') {
                const key=accountKey(application,provider);
                // Clear durable state even if remote revocation is unavailable.
                const clearing=persist(key,null);
                try {if(provider==='claude')await oauthOperation({type:'logout',application,provider});}
                finally {await api.storage.session.remove(key);await clearing;}
                return {authenticated:false};
            }
            if (message.operation === 'http') return http(message,port,operation);
            throw new Error('Unknown browser operation');
        })().then(value => { try { port.postMessage({id:message.id,type:'result',value}); } catch (_) {} },
            error => { try { port.postMessage({id:message.id,type:'error',error:error?.publicMessage || 'La connexion de l’extension a échoué. Vérifiez la connexion au compte et réessayez.'}); } catch (_) {} })
            .finally(() => { clearTimeout(timeout); active.delete(message.id); operation.reader?.cancel().catch(()=>{}); });
    });
    port.onDisconnect.addListener(() => {
        for (const value of active.values()) { value.controller.abort(); value.rejectAck?.(new Error('Page closed')); }
        for (const [ticket,value] of approvals) if (value.owner===owner) rejectApproval(ticket);
        if (operations.has(owner)) void oauthOperation({type:'cancel',...operations.get(owner)});
    });
});
