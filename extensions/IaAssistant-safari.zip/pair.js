const api = globalThis.browser || chrome;
const ticket = new URLSearchParams(location.hash.slice(1)).get('ticket');
const allow = document.querySelector('#allow');
const deny = document.querySelector('#deny');
const status = document.querySelector('#status');
function failed(error) {
    status.textContent = error.message + '. Revenez dans votre application pour réessayer.';
    status.dataset.error = '';
    document.querySelector('#identity').setAttribute('aria-busy','false');
    deny.disabled = false;
}
const request = async type => {
    const reply = await api.runtime.sendMessage({browserPair:type,ticket});
    if (!reply?.ok) throw new Error('Association expirée ou indisponible');
    return reply.value;
};
request('read').then(value => {
    document.querySelector('#application').textContent = value.application;
    document.querySelector('#application-url').textContent = value.url;
    document.querySelector('#identity').setAttribute('aria-busy','false');
    document.title = 'Autoriser ' + value.application + ' · IaAssistant · Ariya Consulting';
    status.textContent = '';
    allow.disabled = false;
}).catch(error => {
    document.querySelector('#application').textContent = 'Demande indisponible';
    failed(error);
});
for (const [id,type] of [['allow','approve'],['deny','deny']]) document.querySelector('#'+id).onclick = async () => {
    allow.disabled = true;
    deny.disabled = true;
    delete status.dataset.error;
    status.textContent = type === 'approve' ? 'Autorisation en cours…' : 'Annulation en cours…';
    try { await request(type); window.close(); }
    catch (error) { failed(error); }
};
