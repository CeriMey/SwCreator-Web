// Minimal isolated-world adapter. No DOM, form, cookie or credential access.
(() => {
    const api = globalThis.browser || chrome;
    let clients = 0;
    window.addEventListener('message', event => {
        if (event.source !== window || event.origin !== location.origin ||
            event.data?.channel !== 'iaassistant.connect.v1' || event.ports.length !== 1 || clients >= 8) return;
        ++clients;
        const page = event.ports[0], background = api.runtime.connect({name:'iaassistant.v1'});
        page.onmessage = message => {
            try { background.postMessage(message.data); } catch (_) { page.close(); }
        };
        background.onMessage.addListener(message => page.postMessage(message));
        background.onDisconnect.addListener(() => { page.postMessage({type:'disconnected'}); page.close(); --clients; });
        window.addEventListener('pagehide', () => background.disconnect(), {once:true});
        page.start();
    });
})();
