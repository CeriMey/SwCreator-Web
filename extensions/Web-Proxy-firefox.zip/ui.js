// Shared presentation only; approvals and network transport remain in the worker.
(function () {
    const english=!navigator.language?.toLowerCase().startsWith('fr');
    const copy=english ? {
        eyebrow:'WEB PROXY EXTENSION',productNote:'Your connections, with your permission.',
        title:'Allow this connection?',intro:'This application wants to contact a server. Check the addresses before allowing access.',
        application:'Application',page:'Application page',server:'Server to contact',
        scope:'Your permission applies only to this page and this server. Browser cookies are not shared. The application can send the data and credentials you provide.',
        loading:'Checking the request…',ready:'Your browser may also ask you to confirm access to this server.',
        allow:'Allow',deny:'Deny',expired:'This request expired or was cancelled. Return to the application to try again.',
        failed:'The connection could not be authorized. Return to the application to try again.',
        footer:'Web Proxy · An Ariya Consulting extension',popupTitle:'Ready to connect',
        popupIntro:'Web Proxy connects your web applications to the servers you authorize.',
        popupGuide:'Return to your application and retry your action. When it asks for permission, check the page and server, then choose Allow.',
        popupNote:'Each permission applies to one page and one server. Browser cookies are not shared.',close:'Close'
    } : {
        eyebrow:'EXTENSION WEB PROXY',productNote:'Vos connexions, avec votre accord.',
        title:'Autoriser la connexion ?',intro:'Cette application souhaite contacter un serveur. Vérifiez les adresses avant d’autoriser.',
        application:'Application',page:'Page de l’application',server:'Serveur à contacter',
        scope:'Votre accord concerne uniquement cette page et ce serveur. Les cookies du navigateur ne sont pas partagés. L’application peut envoyer les données et les identifiants que vous lui confiez.',
        loading:'Vérification de la demande…',ready:'Votre navigateur peut aussi vous demander de confirmer l’accès à ce serveur.',
        allow:'Autoriser',deny:'Refuser',expired:'Cette demande a expiré ou a été annulée. Revenez dans l’application pour réessayer.',
        failed:'La connexion n’a pas pu être autorisée. Revenez dans l’application pour réessayer.',
        footer:'Web Proxy · Une extension Ariya Consulting',popupTitle:'Prêt à vous connecter',
        popupIntro:'Web Proxy relie vos applications web aux serveurs que vous autorisez.',
        popupGuide:'Revenez dans votre application et relancez votre action. Quand elle vous demande l’accès, vérifiez la page et le serveur, puis choisissez Autoriser.',
        popupNote:'Chaque autorisation concerne une page et un serveur. Les cookies du navigateur ne sont pas partagés.',close:'Fermer'
    };
    document.documentElement.lang=english ? 'en' : 'fr';
    for (const node of document.querySelectorAll('[data-i18n]')) node.textContent=copy[node.dataset.i18n];
    const api=globalThis.browser || chrome;
    for (const node of document.querySelectorAll('[data-version]')) node.textContent='v'+api.runtime.getManifest().version;
    const popup=document.body.classList.contains('popup');
    document.title=(popup ? copy.popupTitle : copy.title)+' · Web Proxy';
    document.querySelector('[data-close]')?.addEventListener('click',()=>window.close());
    globalThis.webProxyUi={text:key=>copy[key] || copy.failed};
})();
