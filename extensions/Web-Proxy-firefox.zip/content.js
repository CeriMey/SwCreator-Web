// Isolated world: forward an explicit top-level MessageChannel, without reading
// the page, credentials, forms, cookies or storage.
(() => {
    const api = globalThis.browser || chrome;
    let clients = 0;
    window.addEventListener('message', event => {
        if (window.top !== window || event.source !== window || event.origin !== location.origin ||
            event.data?.channel !== 'swstack.network.connect.v1' || event.ports.length !== 1 || clients >= 4) return;
        ++clients;
        const page = event.ports[0], background = api.runtime.connect({name:'swstack.network.v1'});
        let closed = false;
        const close = () => {
            if (closed) return;
            closed = true; --clients;
            try { page.postMessage({type:'disconnected'}); } catch (_) {}
            page.close(); background.disconnect();
        };
        page.onmessage = message => {
            if (message.data?.type === 'disconnect') { close(); return; }
            try { background.postMessage(message.data); } catch (_) { close(); }
        };
        background.onMessage.addListener(message => { try { page.postMessage(message); } catch (_) { close(); } });
        background.onDisconnect.addListener(close);
        window.addEventListener('pagehide',close,{once:true});
        page.start();
    });
})();
