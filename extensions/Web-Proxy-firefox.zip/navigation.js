// Generic, ephemeral navigation capture. The application owns OAuth state,
// PKCE, token exchange, validation, renewal and credential persistence.
const api = globalThis.browser || chrome;
const navigations = new Set(), tabs = new Map();
const failure = (code, message) => Object.assign(new Error(message), {code});
function endpoint(value) {
    if (typeof value !== 'string' || !value.length || value.length > 16384)
        throw failure('protocol', 'Invalid authorization URL.');
    const url = new URL(value);
    const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
    if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && loopback)) || url.username || url.password || url.hash)
        throw failure('protocol', 'Authorization requires HTTPS or an HTTP loopback URL.');
    return url;
}
export function authorizationEndpoints(authorizeUrl, redirectUri) {
    const url = endpoint(authorizeUrl), redirect = endpoint(redirectUri);
    if (redirect.href.length > 2048 || redirect.search ||
        url.searchParams.getAll('redirect_uri').length !== 1 || url.searchParams.get('redirect_uri') !== redirectUri)
        throw failure('protocol', 'Authorization redirect URI must match the requested callback.');
    return {url, redirect};
}
export function captureNavigation(url, redirect, signal) {
    if (signal.aborted) return Promise.reject(failure('aborted', 'Authorization cancelled.'));
    if (navigations.size >= 4) return Promise.reject(failure('limit', 'Too many active authorization windows.'));
    return new Promise((resolve, reject) => {
        const entry = {tabId: -1, redirect, finished: false};
        navigations.add(entry);
        entry.finish = (error, callback) => {
            if (entry.finished) return;
            entry.finished = true; navigations.delete(entry); tabs.delete(entry.tabId);
            clearTimeout(entry.timer); signal.removeEventListener('abort', cancel);
            if (entry.tabId !== -1) void api.tabs.remove(entry.tabId).catch(() => {});
            if (error) reject(error); else resolve(callback);
        };
        const cancel = () => entry.finish(failure('aborted', 'Authorization cancelled.'));
        signal.addEventListener('abort', cancel, {once: true});
        entry.timer = setTimeout(() => entry.finish(failure('timeout', 'Authorization expired.')), 600000);
        // Reserve ownership before any provider navigation can occur.
        void api.tabs.create({url: 'about:blank', active: true}).then(async tab => {
            if (entry.finished) {void api.tabs.remove(tab.id).catch(() => {}); return;}
            entry.tabId = tab.id; tabs.set(tab.id, entry);
            await api.tabs.update(tab.id, {url: url.href});
        }).catch(() => entry.finish(failure('navigation', 'Could not open the authorization window.')));
        if (signal.aborted) cancel();
    });
}
function observe(tabId, value) {
    const entry = tabs.get(tabId);
    if (!entry || typeof value !== 'string' || value.length > 16384) return;
    let url;
    try {url = new URL(value);} catch (_) {return;}
    if (!url.username && !url.password && !url.hash && url.origin === entry.redirect.origin && url.pathname === entry.redirect.pathname)
        entry.finish(null, url.href);
}
api.webNavigation.onBeforeNavigate.addListener(details => {
    if (details.frameId === 0) observe(details.tabId, details.url);
});
api.tabs.onUpdated.addListener((id, change) => {if (change.url) observe(id, change.url);});
api.tabs.onRemoved.addListener(id => tabs.get(id)?.finish(failure('cancelled', 'Authorization window was closed.')));
