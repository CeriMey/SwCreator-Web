# Web Proxy brand assets

`proxy.svg` is the original vector mark for Web Proxy: two directional arrows
pass through a central relay. `icon-16.png`, `icon-32.png`, `icon-48.png` and
`icon-128.png` are Chromium raster exports of that SVG at the manifest sizes.

`ariya-black.svg` and `ariya-white.svg` are the official Ariya Consulting logos,
copied without changes from `IaAssistant/extensions/browser/assets/`. Their
original sources are `AriyaConsulting/Identite visuelle/01_Logo/SVG/`:
`ariya-consulting_logo_noir.svg` and `ariya-consulting_logo_blanc.svg`.
