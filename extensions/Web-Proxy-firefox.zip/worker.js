// Privileged transport. Only an extension-owned approval can grant a trusted
// sender page access to one exact target origin. No credentials are persisted.
import {authorizationEndpoints, captureNavigation} from './navigation.js';
const api=globalThis.browser || chrome;
const chunkSize=65536,hardBodyLimit=64*1024*1024,hardHeaderLimit=65536;
const approvals=new Map(),approvalKeys=new Map();
let activeRequests=0,writes=Promise.resolve();
const failure=(code,message)=>Object.assign(new Error(message),{code});
const validId=value=>typeof value === 'string' && /^[0-9]{1,16}$/.test(value);
const identity=value=>typeof value === 'string' && value.length > 0 && value.length <= 128 &&
    value === value.trim() && !/[\x00-\x1f\x7f]/.test(value);
function pageIdentity(sender) {
    const url=new URL(sender.url);
    if (!['http:','https:'].includes(url.protocol) || url.username || url.password || sender.frameId !== 0 || !sender.tab)
        throw failure('permission-required','Only top-level HTTP(S) pages can use Web Proxy.');
    return url.origin+url.pathname;
}
function target(value,originOnly=false) {
    if (typeof value !== 'string' || value.length > 16384) throw failure('protocol','Invalid HTTP URL.');
    const url=new URL(value);
    if (!['http:','https:'].includes(url.protocol) || url.username || url.password || url.hash ||
        (originOnly && (url.pathname !== '/' || url.search))) throw failure('protocol','Invalid HTTP URL.');
    return url;
}
const hostPattern=url=>url.protocol+'//'+url.hostname+'/*';
const grantKey=(page,origin)=>JSON.stringify([page,origin]);
async function authorized(page,url) {
    const grants=(await api.storage.local.get('networkGrants')).networkGrants || {};
    return !!grants[grantKey(page,url.origin)] && await api.permissions.contains({origins:[hostPattern(url)]});
}
async function saveGrant(approval) {
    const task=writes.catch(()=>{}).then(async()=>{
        const stillWaiting=()=>approvals.get(approval.ticket) === approval;
        const cancelled=()=>failure('denied','Authorization cancelled.');
        if (!stillWaiting()) throw cancelled();
        const grants=(await api.storage.local.get('networkGrants')).networkGrants || {};
        if (!stillWaiting()) throw cancelled();
        grants[approval.key]={application:approval.application,approvedAt:Date.now(),approval:approval.ticket};
        await api.storage.local.set({networkGrants:grants});
        if (!stillWaiting()) {
            // Cancellation can arrive during the storage write. The serialized
            // queue prevents a rollback from erasing a later valid approval.
            const current=(await api.storage.local.get('networkGrants')).networkGrants || {};
            if (current[approval.key]?.approval === approval.ticket) {
                delete current[approval.key];await api.storage.local.set({networkGrants:current});
            }
            throw cancelled();
        }
    });
    writes=task;await task;
}
function rejectApproval(ticket,error=failure('denied','Server authorization was declined.')) {
    const approval=approvals.get(ticket);if (!approval) return;
    approvals.delete(ticket);approvalKeys.delete(approval.key);clearTimeout(approval.timer);
    for (const waiter of approval.waiters) waiter.reject(error);
    if (approval.tabId !== -1) void api.tabs.remove(approval.tabId).catch(()=>{});
}
async function authorize(sender,application,url,signal) {
    const page=pageIdentity(sender);
    if (!identity(application)) throw failure('protocol','Invalid application name.');
    if (signal.aborted) throw failure('aborted','Authorization cancelled.');
    if (await authorized(page,url)) return {authorized:true};
    const key=grantKey(page,url.origin);
    let approval=approvals.get(approvalKeys.get(key));
    if (!approval) {
        if (approvals.size >= 8) throw failure('limit','Too many pending server approvals.');
        const ticket=crypto.randomUUID();
        approval={ticket,key,page,application,origin:url.origin,pattern:hostPattern(url),tabId:-1,waiters:new Set(),createdAt:Date.now()};
        approvals.set(ticket,approval);approvalKeys.set(key,ticket);
        approval.timer=setTimeout(()=>rejectApproval(ticket,failure('timeout','Server authorization expired.')),300000);
        void api.tabs.create({url:api.runtime.getURL('pair.html')+'#ticket='+ticket,active:true}).then(tab=>{
            if (approvals.get(ticket) !== approval) {void api.tabs.remove(tab.id).catch(()=>{});return;}
            approval.tabId=tab.id;
        },()=>rejectApproval(ticket,failure('denied','Could not open the server authorization page.')));
    }
    return new Promise((resolve,reject)=>{
        const waiter={resolve:value=>{signal.removeEventListener('abort',cancel);resolve(value);},
            reject:error=>{signal.removeEventListener('abort',cancel);reject(error);}};
        const cancel=()=>{
            approval.waiters.delete(waiter);waiter.reject(failure('aborted','Authorization cancelled.'));
            if (!approval.waiters.size) rejectApproval(approval.ticket);
        };
        approval.waiters.add(waiter);signal.addEventListener('abort',cancel,{once:true});
        if (signal.aborted) cancel();
    });
}
api.runtime.onMessage.addListener((message,sender,respond)=>{
    if (!message?.networkPair || sender.id !== api.runtime.id ||
        sender.url?.split('#')[0] !== api.runtime.getURL('pair.html')) return false;
    (async()=>{
        const value=approvals.get(message.ticket);
        if (!value || sender.tab?.id !== value.tabId || Date.now()-value.createdAt > 300000)
            throw failure('denied','Authorization expired.');
        if (message.networkPair === 'read') return {application:value.application,page:value.page,origin:value.origin,pattern:value.pattern};
        if (message.networkPair === 'deny') {rejectApproval(message.ticket);return {authorized:false};}
        if (message.networkPair !== 'approve' || !await api.permissions.contains({origins:[value.pattern]}))
            throw failure('denied','Browser host permission was not granted.');
        await saveGrant(value);
        if (approvals.get(message.ticket) !== value) throw failure('denied','Authorization cancelled.');
        approvals.delete(message.ticket);approvalKeys.delete(value.key);clearTimeout(value.timer);
        for (const waiter of value.waiters) waiter.resolve({authorized:true});
        return {authorized:true};
    })().then(value=>respond({ok:true,value}),()=>respond({ok:false}));
    return true;
});
api.tabs.onRemoved.addListener(id=>{for (const [ticket,value] of approvals) if (value.tabId === id) rejectApproval(ticket);});
function bounded(value,maximum,fallback) {
    if (value === undefined || value === null || value === 0) return fallback;
    if (!Number.isSafeInteger(value) || value < 0) throw failure('protocol','Invalid HTTP limit.');
    return Math.min(value,maximum);
}
function limits(value={}) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw failure('protocol','Invalid HTTP limits.');
    return {
        maxBodyBytes:bounded(value.maxBodyBytes,hardBodyLimit,hardBodyLimit),
        maxRequestBodyBytes:bounded(value.maxRequestBodyBytes,hardBodyLimit,hardBodyLimit),
        maxHeaderBytes:bounded(value.maxHeaderBytes,hardHeaderLimit,hardHeaderLimit),
        maxHeaderCount:bounded(value.maxHeaderCount,256,256),
        headerTimeoutMs:bounded(value.headerTimeoutMs,25000,25000),
        bodyInactivityTimeoutMs:bounded(value.bodyInactivityTimeoutMs ?? value.bodyInactivityMs,25000,25000)
    };
}
function requestHeaders(value,bounds) {
    if (!Array.isArray(value) || value.length > bounds.maxHeaderCount) throw failure('limit','Too many request headers.');
    const headers=new Headers();let size=0;
    for (const pair of value) {
        if (!Array.isArray(pair) || pair.length !== 2 || pair.some(item=>typeof item !== 'string'))
            throw failure('protocol','Invalid request headers.');
        const [name,content]=pair,lower=name.toLowerCase();
        size+=new TextEncoder().encode(name+content).length+4;
        if (size > bounds.maxHeaderBytes) throw failure('limit','Request headers exceed the configured limit.');
        if (/^(accept-charset|accept-encoding|access-control-request-headers|access-control-request-method|connection|content-length|cookie2?|date|dnt|expect|host|keep-alive|origin|permissions-policy|referer|te|trailer|transfer-encoding|upgrade|user-agent|via)$/.test(lower) ||
            lower.startsWith('sec-') || lower.startsWith('proxy-')) continue;
        headers.append(name,content);
    }
    return headers;
}
function base64(bytes) {
    let binary='';for (let offset=0;offset<bytes.length;offset+=8192) binary+=String.fromCharCode(...bytes.subarray(offset,offset+8192));
    return btoa(binary);
}
api.runtime.onConnect.addListener(port=>{
    if (port.name !== 'swstack.network.v1') {port.disconnect();return;}
    let page;
    try {page=pageIdentity(port.sender);}catch (_) {port.disconnect();return;}
    const operations=new Map();let closed=false,requests=0;
    const post=value=>{if (!closed) try{port.postMessage(value);}catch (_) {closed=true;}};
    const abort=(operation,error=failure('aborted','Request cancelled.'))=>{
        operation.error=error;operation.controller.abort();operation.ack?.reject(error);
    };
    const finish=(id,error)=>{
        const operation=operations.get(id);if (!operation) return;
        operations.delete(id);clearTimeout(operation.timer);clearTimeout(operation.ackTimer);
        if (operation.kind === 'request') {--requests;--activeRequests;}
        if (error) {abort(operation,error);post({type:'error',id,code:error.code || 'network',error:error.message || 'HTTP request failed.'});}
    };
    const arm=(id,operation,timeout,phase)=>{
        clearTimeout(operation.timer);
        operation.timer=setTimeout(()=>finish(id,failure('timeout',phase+' timed out.')),timeout);
    };
    async function fetchRequest(id,operation) {
        operation.phase='fetch';clearTimeout(operation.timer);
        arm(id,operation,operation.bounds.headerTimeoutMs,'Response headers');
        try {
            const response=await fetch(operation.url.href,{method:operation.method,headers:operation.headers,
                body:operation.hasBody ? operation.body : undefined,signal:operation.controller.signal,
                credentials:'omit',redirect:'error',cache:'no-store',referrerPolicy:'no-referrer'});
            if (!operations.has(id) || operation.controller.signal.aborted) return;
            clearTimeout(operation.timer);operation.body=null;
            let headerBytes=0,count=0;const headers=[];
            for (const [name,value] of response.headers) {
                if (name === 'set-cookie' || name === 'set-cookie2') continue;
                headerBytes+=new TextEncoder().encode(name+value).length+4;
                if (++count > operation.bounds.maxHeaderCount || headerBytes > operation.bounds.maxHeaderBytes)
                    throw failure('limit','Response headers exceed the configured limit.');
                headers.push([name,value]);
            }
            const length=response.headers.get('content-length');
            if (operation.method !== 'HEAD' && ![204,205,304].includes(response.status) && !response.headers.has('content-encoding') &&
                length && /^\d+$/.test(length) && Number(length) > operation.bounds.maxBodyBytes)
                throw failure('limit','Response body exceeds the configured limit.');
            post({type:'headers',id,status:response.status,statusText:response.statusText,headers});
            const reader=response.body?.getReader();let received=0,sequence=0;
            while (reader) {
                arm(id,operation,operation.bounds.bodyInactivityTimeoutMs,'Response body');
                const {done,value}=await reader.read();clearTimeout(operation.timer);
                if (!operations.has(id) || operation.controller.signal.aborted) return;
                if (done) break;
                received+=value.byteLength;
                if (received > operation.bounds.maxBodyBytes) throw failure('limit','Response body exceeds the configured limit.');
                for (let offset=0;offset<value.byteLength;offset+=chunkSize) {
                    const current=sequence++;
                    const acknowledged=new Promise((resolve,reject)=>{operation.ack={sequence:current,resolve,reject};});
                    operation.ackTimer=setTimeout(()=>{operation.ack?.reject(failure('timeout','Response reader did not acknowledge data.'));},10000);
                    post({type:'bytes',id,sequence:current,data:base64(value.subarray(offset,offset+chunkSize))});
                    try {await acknowledged;}finally{clearTimeout(operation.ackTimer);operation.ack=null;}
                    if (!operations.has(id) || operation.controller.signal.aborted) return;
                }
            }
            post({type:'end',id});finish(id);
        } catch (error) {
            if (!operations.has(id)) return;
            finish(id,operation.error || (error.code ? error : failure('network','Extension HTTP request failed (network, TLS, or redirect).')));
        }
    }
    async function begin(message) {
        const {id}=message;
        if (operations.has(id)) throw failure('protocol','Request ID is already active.');
        if (message.type === 'probe') {
            let granted=false;
            if (message.origin) granted=await authorized(page,target(message.origin,true));
            post({type:'result',id,value:{authorized:granted}});return;
        }
        const controller=new AbortController();
        if (message.type === 'authorize') {
            if (operations.size >= 8) throw failure('limit','Too many pending operations.');
            const {url,redirect}=authorizationEndpoints(message.url,message.redirectUri);
            const operation={kind:'navigation',controller};operations.set(id,operation);
            arm(id,operation,600000,'Authorization');
            try {
                await authorize(port.sender,message.application,url,controller.signal);
                const callback=await captureNavigation(url,redirect,controller.signal);
                if (operations.has(id)) {post({type:'result',id,value:callback});finish(id);}
            } catch (error) {finish(id,error);}
            return;
        }
        if (message.type === 'permission') {
            if (operations.size >= 8) throw failure('limit','Too many pending operations.');
            const operation={kind:'permission',controller};operations.set(id,operation);
            try {
                const result=await authorize(port.sender,message.application,target(message.origin,true),controller.signal);
                if (operations.has(id)) {post({type:'result',id,value:result});finish(id);}
            } catch (error) {finish(id,error);}
            return;
        }
        if (message.type !== 'request') throw failure('protocol','Unsupported extension operation.');
        if (requests >= 4 || activeRequests >= 32) throw failure('limit','Too many concurrent HTTP requests.');
        const bounds=limits(message.limits),url=target(message.url),method=message.method;
        if (!['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'].includes(method)) throw failure('protocol','Invalid HTTP method.');
        if (!Number.isSafeInteger(message.bodyLength) || message.bodyLength < 0 || message.bodyLength > bounds.maxRequestBodyBytes ||
            typeof message.hasBody !== 'boolean' || (!message.hasBody && message.bodyLength !== 0) ||
            (message.hasBody && ['GET','HEAD'].includes(method))) throw failure('limit','Invalid or oversized request body.');
        const headers=requestHeaders(message.headers,bounds);
        // Reserve before awaiting storage: a flood of simultaneous requests
        // cannot race past concurrency limits or duplicate IDs.
        const operation={kind:'request',controller,bounds,url,method,headers,hasBody:message.hasBody,
            bodyLength:message.bodyLength,body:null,uploaded:0,uploadSequence:0,phase:'authorize'};
        operations.set(id,operation);++requests;++activeRequests;
        try {
            if (!await authorized(page,url)) throw failure('permission-required','Authorize this page and server in Web Proxy first.');
            if (!operations.has(id) || controller.signal.aborted) return;
            operation.body=new Uint8Array(message.bodyLength);operation.phase='upload';
            arm(id,operation,10000,'Request upload');post({type:'uploadReady',id,sequence:-1});
        } catch (error) {finish(id,error);}
    }
    port.onMessage.addListener(message=>{
        if (closed || !message || !validId(message.id) || typeof message.type !== 'string') return;
        const {id}=message,operation=operations.get(id);
        if (message.type === 'ping') {
            // Receiving this message refreshes Chrome's worker idle timer.
            // It has no result, grant, navigation or deadline side effects.
            if (Object.keys(message).length !== 2 || !operation ||
                (operation.kind !== 'navigation' && operation.kind !== 'permission')) return;
            return;
        }
        if (message.type === 'abort') {finish(id,failure('aborted','Request cancelled.'));return;}
        if (message.type === 'ack') {
            if (operation?.ack?.sequence === message.sequence) operation.ack.resolve();
            else if (operation) finish(id,failure('protocol','Invalid response acknowledgement.'));
            return;
        }
        if (message.type === 'upload' || message.type === 'uploadEnd') {
            try {
                if (!operation || operation.phase !== 'upload') throw failure('protocol','No upload is active.');
                if (message.type === 'uploadEnd') {
                    if (operation.uploaded !== operation.bodyLength) throw failure('protocol','Incomplete request upload.');
                    void fetchRequest(id,operation);return;
                }
                if (message.sequence !== operation.uploadSequence++ || typeof message.data !== 'string' ||
                    message.data.length > Math.ceil(chunkSize/3)*4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(message.data))
                    throw failure('protocol','Invalid request upload chunk.');
                const bytes=Uint8Array.from(atob(message.data),character=>character.charCodeAt(0));
                if (!bytes.length || bytes.length > chunkSize || operation.uploaded+bytes.length > operation.bodyLength)
                    throw failure('limit','Request upload exceeds the declared size.');
                operation.body.set(bytes,operation.uploaded);operation.uploaded+=bytes.length;
                arm(id,operation,10000,'Request upload');post({type:'uploadAck',id,sequence:message.sequence});
            } catch (error) {
                if (operation) finish(id,error);else post({type:'error',id,code:error.code || 'protocol',error:error.message});
            }
            return;
        }
        void begin(message).catch(error=>post({type:'error',id,code:error.code || 'protocol',error:error.message || 'Invalid extension request.'}));
    });
    port.onDisconnect.addListener(()=>{
        closed=true;
        for (const [id,operation] of operations) {abort(operation);finish(id);}
    });
    post({type:'ready',protocol:1,extensionVersion:api.runtime.getManifest().version});
});
