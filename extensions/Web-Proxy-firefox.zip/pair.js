const api=globalThis.browser || chrome;
const ui=globalThis.webProxyUi;
const ticket=new URLSearchParams(location.hash.slice(1)).get('ticket');
const allow=document.querySelector('#allow'),deny=document.querySelector('#deny'),status=document.querySelector('#status');
let identity,heartbeat;
const send=async (action,extra={})=>{
    const reply=await api.runtime.sendMessage({networkPair:action,ticket,...extra});
    if (!reply?.ok) throw Object.assign(new Error(ui.text('expired')),{userMessage:ui.text('expired')});
    return reply.value;
};
const failed=error=>{clearInterval(heartbeat);status.textContent=error.userMessage || ui.text('failed');status.dataset.error='';allow.disabled=true;deny.disabled=false;};
send('read').then(value=>{
    identity=value;
    document.querySelector('#application').textContent=value.application;
    document.querySelector('#application').setAttribute('aria-busy','false');
    document.querySelector('#page').textContent=value.page;
    document.querySelector('#origin').textContent=value.origin;
    allow.disabled=false;status.textContent=ui.text('ready');
    // An open runtime port alone does not keep Chrome MV3 workers alive.
    // Refresh this trusted ticket while the user reads the approval page.
    heartbeat=setInterval(()=>{void send('read').catch(failed);},20000);
}).catch(failed);
allow.onclick=async()=>{
    if (!identity) return;
    allow.disabled=true;deny.disabled=true;delete status.dataset.error;
    try {
        // Called directly from this extension-owned click: browsers require a
        // user gesture for optional host permissions.
        const granted=await api.permissions.request({origins:[identity.pattern]});
        await send(granted ? 'approve' : 'deny');window.close();
    } catch (error) {failed(error);}
};
deny.onclick=async()=>{allow.disabled=true;deny.disabled=true;try{await send('deny');window.close();}catch(error){failed(error);}};
