# Web Proxy browser extension

Shared HTTP transport for `SwHttpClient` and `SwNetworkAccessManager` on WebAssembly. The extension
executes explicitly authorized HTTP(S) requests outside the page's CORS context.
It does not provide an open proxy, inspect pages, read cookies, or keep credentials.

`authorize(authorizeUrl, redirectUri, signal)` supplies generic platform
navigation for C++ OAuth clients. After explicit page/authorization-origin
approval, it opens an owned tab and returns only a callback URL observed in that
tab's top-level frame, matching the exact redirect origin, port and path. HTTPS
and HTTP loopback endpoints are supported. Cancellation, closing the tab,
disconnect and a ten-minute deadline retire the operation and close its tab.
The authorization URL must contain exactly one matching `redirect_uri`.
The application remains responsible for state, PKCE, nonce, token exchange,
identity/signature verification, renewal and persistence. No provider endpoint
or credential store is implemented in the addon. Version 0.2 adds this operation
and the browser `webNavigation` permission; existing installations need updating.

Generate the Chrome/Edge and Firefox ZIP packages and the Emscripten pre-JS:

```console
python tools/package_browser_network_extension.py --output build/browser-network
```

Chrome/Edge: extract the Chromium ZIP, open `chrome://extensions` or
`edge://extensions`, enable developer mode, and load the extracted directory.
Firefox: extract the Firefox ZIP, open `about:debugging#/runtime/this-firefox`, and
load `manifest.json` as a temporary add-on. Permanent distribution needs Mozilla
signing. Safari requires an Apple-signed conversion and is not included.

The application owns all installation dialogs. The extension owns the final
page/server approval screen. `Module.swNetworkBrowserBridge.probe(origin)`
reports extension presence separately from authorization. Missing-extension
downloads are explicit calls to `download(browser)`. An installed extension is
never treated as absent merely because a server has not been authorized.
`requestPermission(origin, application)` opens the extension's own confirmation
page. It displays the trusted top-level page origin and pathname and the target
origin. Approval grants the browser's optional host permission, then records an
exact page + target-origin association. Different pages and target ports remain
separate even when browser host permissions cover the same hostname. Grants can
be removed by uninstalling/clearing the extension; revoking browser site access
also makes existing grants unusable.

`request(url, options, limits)` returns a Fetch-compatible streaming `Response`.
Bodies are binary. Requests omit browser cookies, refuse redirects, and discard
browser-owned headers. Request and response streaming use 64 KiB chunks with
acknowledgements and independent cancellation. Each connection permits four
concurrent requests, with a global ceiling of 32; a stalled reader does not block
other requests. Request/response bodies have a hard 64 MiB ceiling. Caller bounds
may reduce it. Headers have a 64 KiB / 256-header ceiling. Header and body idle
timeouts are capped at 25 seconds to respect extension service-worker lifetimes.

The transport never retries a failed HTTP operation or opens an approval dialog
automatically. Applications may select an already authorized extension before
sending a request. A Fetch `TypeError` alone cannot reliably distinguish CORS
from network or TLS failure, so an installation prompt should explain that CORS
is suspected. In particular, applications must not automatically replay a failed
POST or Git push.

Run `python extensions/browser-network/tests/browser_network.py` for real
Chromium extension tests against two local HTTP origins (requires Playwright).

## Identity and compatibility

Web Proxy is the shared Ariya Consulting browser proxy. The toolbar popup and
authorization screen use the official Ariya logos, the original relay icon in
`assets/proxy.svg`, and the system light/dark theme. French and English follow
the browser language. Icon PNGs are exports of the SVG; asset provenance is in
`assets/README.md`.

The generated archives are `Web-Proxy-chromium.zip` and `Web-Proxy-firefox.zip`.
Version 0.2.1 changes presentation and packaging only; the minimum compatible
extension remains 0.2.0. The `swstack.network.*` channels, public
`Module.swNetworkBrowserBridge` API, saved grants and Firefox extension ID remain
unchanged, so existing compatible installations continue to work.
